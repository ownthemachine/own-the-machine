REVIEW TARGET AND VERSION BOUNDARY
Assess the COMPLETE proposed replacement under proposals/2026-09-07-substantive-closure/candidate/ as if its articles were integrated together. It is not adopted or merged. Its own MEMORANDUM.md and PLAIN.md are the corresponding explanatory layers. The package is deliberately a review candidate, not an assertion that any gate is passed.

The root regulation/, campaign/ and existing website files appended for comparison are the BASELINE and historical context, not operative provisions of this alternative. Do not import a missing rule from the baseline or treat an expressly labelled alternative as an unannounced website change. Assess every substantive concern in the actual candidate, including admitted incomplete financing, reconciliation and sizing. Review all 46 constraints in the baseline counter-arguments table; disclosure of a constraint conflict does not cure it. All previous legal uncertainties remain subject to independent assessment. Later gates may run diagnostically with REVISE results carried forward, never as release approval.



# SOURCE: own-the-machine/GOVERNANCE.md

# Governance: how an open-source law changes

This repository is public. Every rule here is written for that fact:
strangers proposing amendments to a draft statute, in public, with the
history permanent.

## Roles

- **Editor:** David Vanheeswijck, until a campaign organisation exists and
  formally assumes the role. The editor merges; nobody else does, including
  automated tooling.
- **Reviewers:** anyone. Review rounds run by the team are committed to
  pipeline/reviews/ so outside reviewers can see the standard applied.
- **Contributors:** anyone, via issues and pull requests. No CLA; the
  licences (LICENSING.md) are the contract.

## The merge criteria

Two layers, both mandatory. Prose quality is judged last, not first.

**Substantive: the four tests.** A change fails review by definition if it
makes the instrument
1. less about assets and more about flows,
2. less universal (any means test, any discretionary gate),
3. less raid-proof (weakening entrenchment, adding emergency clauses,
   permitting sovereign self-dealing), or
4. later (moving obligations past the formation of the gains).

**Mechanical: the constraints table.** Every PR touching regulation/ must
state which DCs from regulation/memorandum/counter-arguments.md it touches.
A draft that violates a DC is rejected regardless of drafting quality. A PR
arguing a DC itself is wrong must amend the counter-arguments file first, in
the same PR, and survives only if the underlying objection is answered at
least as well as before.

## Change classes

| Class | Examples | Required before merge |
|---|---|---|
| Editorial | typo, punctuation, layout | editor's read |
| Prose | recital wording, memorandum text | legal-form gate + editor |
| Substantive | any enacting term, any threshold, any definition | full pipeline (all six gates) + editor |
| Constitutional | the four tests, the DC table, this file | full pipeline + public issue open ≥14 days + editor |

### The 14-day window assumes a public, and there is not one yet

The constitutional window was written for a repository people read. This one
is public but unannounced, and nobody has been asked to look at it. Running
a 14-day comment period against that audience produces no comments and then
treats the silence as ratification, which is a worse outcome than not
running it: it manufactures a legitimacy this project has not earned and
would have to defend later.

So the window runs from the first outreach, not from the merge. Until this
draft has been put in front of people who were invited to argue with it:

- constitutional changes may be merged by the editor on the full pipeline
  alone, and are **provisional**;
- each one is listed below as it is made;
- at first outreach every provisional change re-opens together, for the full
  14 days, and anything unable to survive that is reverted.

Provisional constitutional changes, pending the window:

- 21 August 2026: "Versions: the freeze at registration", added below.
- 22 August 2026: objections 20 and 21 and constraints DC-43 to DC-46 in
  regulation/memorandum/counter-arguments.md.
- 22 August 2026, second entry: the designation-ratio package. Article
  3(2)(b) redesignated on fair market value against audited compensation
  of labour; Annex I point 3 rewritten accordingly; Article 1(2)
  quantified objective; Article 14(1)(e) labour-share indicator; recitals
  5, 6, 7 and 30 amended; DC-45 and DC-46 restated. Two prior designs
  were killed in gate review before this one; the record is in
  pipeline/reviews/2026-08-22-designation-ratio.md. DC-46 records that Article 1's
  objective needs quantifying before filing, which is the largest open
  drafting item this file has; the reasoning is in
  pipeline/reviews/2026-08-22-objections-20-21.md.

This clause is itself provisional under its own terms.

## Process

1. Open an issue describing the change and which objections (1-18) it
   relates to. Drafting starts in the issue, not the PR.
2. PR from a branch; template requires: DCs touched, change class, gates run,
   review files added under pipeline/reviews/.
3. Gates run per class (pipeline/README.md). Verdicts are committed, PUBLISH
   and REVISE alike. A REVISE with a written editor disposition can merge;
   silent overrides cannot.
4. Editor merges with a message stating what the change does to the
   instrument, not what it does to the text.

## Versions: the freeze at registration

Everything above describes a living draft. Registration under Regulation
(EU) 2019/788 changes that, and this repository has to change with it.
From the moment an initiative is registered, the annex as registered is
what citizens are asked to sign, and it cannot be amended. A draft that
keeps moving while signatures are collected against a fixed text is not
transparency; it is a gap between what was signed and what is published,
and it would rightly be read that way.

The rule is adopted here before there is anything to freeze, so that it
cannot later be written to suit a convenience.

1. **On the day of registration the filed text is frozen.** It is copied
   verbatim into versions/, with the commit it was taken from, the date of
   filing and the Commission's decision. Nothing in that directory is ever
   edited afterwards. A correction to a frozen version is a new frozen
   version, never an edit of the old one.
2. **versions/REGISTERED.json is the machine-readable state.** It names the
   registered version or records that there is none. The site reads that
   file and reports what it finds; no page states the answer from memory.
3. **The living draft continues, and says so on every page.** Work does not
   stop at registration, because the Commission's response is argued
   against the best version of the case, not the filed one. Every page
   rendering the living draft carries the distinction plainly, and the
   registered text is reachable in one click from any of them.
4. **Divergence is published, not characterised.** Where the living draft
   and the registered text differ, the difference is a diff a reader can
   read for themselves, never a claim about how minor it is.
5. **The frozen text is authoritative for what was signed. The living draft
   is authoritative for nothing until it is itself filed.**

Before registration, which is where this project stands, the state is
simply that no version is registered and the whole repository is a draft.

## Transparency rules

- No force-pushes to main, ever, once public. History is the product.
- Every review round, including failed ones, is committed.
- Editor dispositions that decline a finding are written into the review
  file, as in the wider project's practice.
- The site's public ledger is rendered from the review files and release
  notes: outcomes and dispositions are the public story; prompts and tooling
  remain inspectable in the tools repository.
- Funding and support are declared in campaign/FUNDING.md, and the
  declaration is kept current from now rather than from the moment
  Regulation (EU) 2019/788 makes it compulsory. "None" is not an
  acceptable answer while anyone is paying for anything.


# SOURCE: own-the-machine/pipeline/README.md

# The legislation pipeline

The strictest gate set in the project, because the artefact is a draft
statute that professionals must be unable to dismiss on form, and because
the repo is public: the pipeline is part of the credibility, visible to
every reader.

Inherited from the book project's hard-won lessons: reviewers get FULL
document context, never fragments; every round is committed, PUBLISH and
REVISE alike; declined findings carry a written editor disposition; and the
automated gate is trusted on rule violations, never on whether a sentence
lands. The final read is always human.

## The six gates

Run in this order; later gates assume earlier ones passed. **The runner, the
six gate prompts and the linter live in the
[own-the-machine-tools](https://github.com/ownthemachine/own-the-machine-tools)
repository (MIT)**: machinery there, so this repository stays the civic
artefact: the law, its evidence, its governance and the ledger of its own
evolution. Review OUTPUTS are committed here under pipeline/reviews/,
because a verdict on a statute is part of the statute's history.

| # | Gate | Catches | Suggested model tier |
|---|---|---|---|
| 1 | Legal form | Joint Practical Guide violations, powers architecture, DMA threshold pattern, memorandum skeleton | fast |
| 2 | DC compliance | violations of the 30-row constraints table | fast |
| 3 | Legal basis and rights | Art. 114/173 reasoning, subsidiarity, proportionality, Charter Art. 17, Art. 345 | strongest available |
| 4 | Hostile counsel | how a litigator for covered undertakings, or the Legal Service, kills the text | strongest available |
| 5 | Acquis coherence | collisions with company law, Prospectus, IORP II, PEPP, DMA definitions | strong |
| 6 | Layer fidelity | drift between the articles, the memorandum and the plain-language layer | fast |

Before any gate: the linter from the tools repo (mechanical checks; free; no
excuse to skip).

## Which gates when

- Editorial changes: lint only.
- Prose changes: lint + gates 1 and 6.
- Substantive changes: lint + all six.
- Constitutional changes: all six plus the 14-day public issue
  (GOVERNANCE.md).

## Review file convention, and what the public actually sees

Review files live at pipeline/reviews/YYYY-MM-DD-<gate>-<slug>.md and open
with front matter the site can render:

    gate: hostile-counsel
    target: regulation/articles/03-designation.md
    commit: <sha>
    verdict: REVISE
    disposition: merged-with-fixes | declined (reason) | pending
    date: 2026-09-04

The campaign site renders a public ledger of the law's evolution from these
files and from release notes: what changed, what prompted it, what review
found, how the editor disposed of it, with a diff link. That ledger, not
this tooling, is the public story. The prompts and runner stay inspectable
here, because the repo is open and hiding machinery reads worse than owning
it, but the product is a law that shows its work, not a showcase of the
workshop.

## Status

All six gates are operational. DRAFTING-RULES.md was completed from the
legislative-drafting research on 18 August (source record with all URLs:
research-drafting-2026-08-18.md); the legal-form gate now enforces the Joint
Practical Guide, the DMA Article 3 threshold pattern, the BRRD property
architecture and the Commission's memorandum skeleton.


# SOURCE: own-the-machine/pipeline/DRAFTING-RULES.md

# Drafting rules

Distilled 18 August 2026 from the legislative-drafting research
(pipeline/research-drafting-2026-08-18.md carries the full findings and
sources). These rules are operative: the legal-form gate enforces them, and a
draft violating them is not "stylistically imperfect", it is the first
dismissal the institutions will reach for.

## The three acts on the desk

1. **DMA, Regulation (EU) 2022/1925**, Articles 2, 3, 4, 17, 49, 53 and the
   Annex: the complete threshold, presumption, notification, designation,
   rebuttal and review machine. Our micro-giant designation chapter follows
   it almost line for line.
2. **BRRD, Directive 2014/59/EU**, recitals 13, 49-51, 88, 120-124, 130-131;
   Articles 34, 36, 47, 59-62, 73-75, 85: the only judicially validated
   architecture for diluting or extinguishing equity by act of law (Kotnik
   C-526/14, Ledra C-8/15 P, Dowling C-41/15, Aeris Invest C-535/22 P). Our
   property-rights chapter.
3. **AI Act package**, COM(2021) 206 plus Regulation (EU) 2024/1689 Articles
   51-52 and 97: the current-generation explanatory memorandum to copy
   structurally, and a second example of presumption thresholds kept
   technology-proof by delegated act.

Do NOT cite Regulation 2022/1854 (the solidarity contribution) as validated
precedent: its characterisation defence is untested (T-802/22 outcome not
final) and its emergency logic is unavailable to a permanent instrument. Use
its surplus-only base design and review clauses as drafting aids only.

## Structure (Joint Practical Guide, 2nd ed. 2015)

- Title, citations, recitals, enacting terms, annexes. Enacting-terms order:
  subject matter and scope; definitions; rights and obligations; powers;
  procedure; transitional and final provisions. Articles numbered
  continuously across chapters.
- One idea per sentence. Ambiguity papering over disagreement gets read
  restrictively by the Court (C-6/98 ARD).
- A Regulation applies directly: draft obligations on the addressee ("Every
  covered undertaking shall...") never "Member States shall ensure", except
  where a duty is genuinely the Member State's.
- Enacting terms command in the present indicative "shall". Recitals reason
  with "should" and contain zero normative content (JPG G10; C-162/97
  Nilsson: recitals cannot derogate from articles). Nothing normative may
  live only in a recital; every obligation needs a motivating recital, in
  the order of the provisions.
- All definitions in Article 2, none containing an obligation, every defined
  term used with exactly one meaning and no synonyms.
- Cross-references minimal, precise, intelligible without lookup. Annexes
  technical only: no new right or obligation may live in an annex.
- Mandatory reasoning (Art 296 TFEU) for derogations, exceptions,
  retroactivity and provisions prejudicial to particular interests; the JPG's
  model subsidiarity recital has gaps that MUST be filled case by case:
  unfilled boilerplate is itself a recognised defect.

## Powers architecture (Arts 290/291 TFEU)

- Essential elements stay in the articles, reviewably (C-355/10): for us the
  warrant trigger, the reserve's ownership structure, the dividend
  entitlement and the interference with shareholders are essential and may
  never be delegated.
- Delegated acts supplement or amend non-essential elements (threshold
  methodology, annex counting rules); implementing acts make individual
  designation decisions and templates (C-427/12; Reg 182/2011 comitology).
- Use the standard six-paragraph "Exercise of the delegation" article
  (CSDR Art 67 pattern) and the standard delegated-acts and comitology
  recitals with the 2016 IIA expert-consultation language.

## Thresholds (the DMA Article 3 model, followed exactly)

Cumulative qualitative test in paragraph 1; quantitative rebuttable
presumption in paragraph 2 with each metric mapped to one qualitative limb in
the recitals; self-notification within a deadline; designation decision
within a deadline; rebuttal only by "sufficiently substantiated arguments"
that "manifestly put into question" the presumption, with market-definition
economics excluded; below-threshold designation via market investigation;
review of designations at least every three years. Numbers in the article,
counting methodology in an annex, adjustment by tightly conditioned
delegated act.

## Property rights (the BRRD formula, adapted)

- An honest interference recital naming Charter Article 17 (BRRD recital 13
  model) plus a full Article 52(1) proportionality recital (recital 49
  model) plus the standard Charter recital naming Articles 17, 16, 47 and 34
  (recital 130 model).
- A quantified no-worse-off safeguard with independent valuation,
  compensation mechanism and separately challengeable valuation (BRRD Arts
  36, 73-75; upheld in Aeris Invest). ADAPTATION REQUIRED: BRRD's
  counterfactual is insolvency; ours must be market-consistent (no
  shareholder worse off than under an equivalent market-terms issuance),
  because a permanent regime cannot lean on crisis reasoning (Dowling's
  limit).
- Express, clearly and narrowly defined derogations from Directive (EU)
  2017/1132 pre-emption and capital-increase rules and from SRD 2007/36
  (BRRD recitals 120-124 formula). Silent conflict with company law reads as
  amateurism.
- A judicial-review article (BRRD Art 85; Charter Art 47).

## Interfaces the articles must write explicitly

Prospectus exemption (Reg 2017/1129: the warrant is a transferable
security); the reserve is not an AIF (AIFMD 2011/61); CRR own-funds
interaction; IORP II and PEPP interface preserving Member State social
competence; an EDPS recital for pension-rail data processing (Art 42(1) Reg
2018/1725); distinguish the golden-shares case law under Art 345 TFEU.

## The explanatory memorandum

Reproduce the Commission's five-section skeleton exactly, numbering
included (verified against COM(2021) 206): 1 context; 2 legal basis,
subsidiarity, proportionality, choice of instrument; 3 evaluations,
consultations, impact assessment, with a fundamental-rights subsection;
4 budgetary implications; 5 other elements including article-by-article
explanation. Annex a completed subsidiarity grid (COM(2018) 703). Our
evidence base substitutes for the impact assessment and must be presented
as such; Parliament uses EPRS added-value assessments for this and an ECI
has no equivalent, so the memorandum does that work itself.

## Monitoring and review

A monitoring article that generates the data, then: "By [date], and every
three years thereafter, the Commission shall evaluate this Regulation and
report to the European Parliament, the Council and the European Economic and
Social Committee", closing with measures "which may include legislative
proposals" (DMA Art 53 pattern). Pair with the falsification condition
(DC-18), which is our addition to the genre.

## The characterisation ladder

The single highest-stakes drafting decision: Art 114 (internal market,
centre of gravity per C-376/98 Tobacco Advertising: disparities alone are
not enough, the measure must genuinely improve the internal market's
functioning), falling back Art 115 (unanimity), Art 352 (unanimity plus
consent), with fatal drift being Art 311 own resources. Registration is NOT
where this fight happens: the test there is "manifestly outside" the
Commission's powers (Reg 2019/788 Art 6(3)(c)), partial registration is
judicially established (C-899/19 P), and the EU wealth-tax ECI was
registered in 2023. The characterisation fight comes in Council. Draft every
ask severable, each with its own defensible basis.

## The strategic rule

No outsider text has ever been enacted as written. Draft so the mechanics
(thresholds, designation, no-worse-off safeguard, review cycle) survive
transplantation into a Commission-rewritten shell. Form buys the hearing;
severability buys survival; the mechanics are the legacy.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/README.md

# Substantive closure: integrated review candidate

Authorised continuation on 7 September 2026. Baseline: law 6ae2fa3,
tools 32709fb, site 93027d7. This local issue continues the recorded repair
issue; no public message, filing, merge or deployment is authorised or made.

The complete replacement candidate is under candidate/regulation/. It is
an Article 352 Council Regulation alternative, with the operational choices
integrated for review. It is NOT the selected website draft in /regulation,
not an adopted policy and not an assertion that Article 352 is sufficient.
The editor can assess the concrete consequences before choosing it. The
old candidate remains available for comparison, not as a source of missing
operative rules in this alternative.

Scope: all six gates, with all 46 DCs tested. The ownership objective,
percentage, thresholds, non-voting status and universal adult citizenship
remain. No constitutional constraint is silently amended. Immediate loss
recognition, accrued daily allocations, institutional governance and an
Article 352 route are now testable text rather than isolated suggestions.
DC-1's wording and DC-45/46 sizing remain explicitly contested; a favourable
model verdict cannot override those questions.

Sources start with the already completed ECI Forum request 2332: sent
21 August, answered 27 August, acknowledged the same day. Its independent
non-binding advice and the reply are in pipeline/EXTERNAL-REVIEWS.md and
campaign/GATE1-LETTER.md. No repeat enquiry is proposed or sent.

Deliverables:
- RESEARCH.md: verified authorities, what they support and what they do not.
- candidate/regulation/: complete operative alternative, not patch fragments.
- candidate/MEMORANDUM.md and candidate/PLAIN.md: explanation of this version.
- DECISIONS.md: choices made for review, unresolved feasibility conditions.
- REVIEW-STATUS.md: actual gate results and assistant dispositions once run.

The immediate objective is to reduce concrete defects and identify the
remaining decision boundary. It is not to rerun unchanged material until
all models return PUBLISH. Later diagnostic gates may run with earlier
REVISE results explicitly carried forward; this is not release clearance.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/RESEARCH.md

# Legal research carried forward from the Forum advice

Checked 7 September 2026. This is a source-qualified drafting assessment,
not an institutional opinion or a prediction of registration or litigation.
The existing Forum request 2332 and reply of 27 August are the starting
point, not a task still to be performed. Original correspondence remains
verbatim in pipeline/EXTERNAL-REVIEWS.md, review 4.

## 1. What the cited registration decision actually supports

Decision 2023/1487, recitals 3–7, identifies Articles 115, 311 and 175 for
the wealth-tax initiative's different requests. Recital 7 reserves the
substantive conditions, including proportionality, subsidiarity and rights.
It is a useful registration example. It is not an Article 114 precedent
for the warrant or an approval of compulsory ownership participation.
The Forum's suggestion to cite the decision does not change what it says.
[Decision 2023/1487](https://eur-lex.europa.eu/eli/dec_impl/2023/1487/oj/eng).

## 2. Article 114 is neither automatically sufficient nor categorically unavailable

C-217/04, paragraphs 42–45, permits a Union body closely linked to the
implementation of harmonisation. It contradicts the absolute proposition
that an agency can never be established using that legal basis. It does
not establish the necessary link for this Reserve.
[C-217/04](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:62004CJ0217).

C-270/12, paragraphs 100–108, likewise addresses agency powers within a
harmonising framework. Again, the missing step is showing a genuine
harmonisation objective and a proportionate connection between the actual
rules and that objective. Creating a universal capital fund is not made
harmonisation merely by naming divergent national digital taxes.
[C-270/12](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:62012CJ0270).

The baseline draft does not replace the national taxes invoked in its
fragmentation narrative. The new candidate therefore does not claim that
it removes them. A genuine Article 114 variant would need evidence of the
specific national ownership rules affected and an operative account of
what is approximated. No such evidentiary map has been established here.

## 3. Article 352: concrete alternative, conditional competence

Article 352 requires necessity within Treaty policies, an applicable Treaty
objective and the absence of the necessary specific powers. It requires
Council unanimity and Parliament consent and gives national parliaments a
subsidiarity role. Its exclusions remain. Changing the preamble cannot
establish these substantive conditions.
[Article 352](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:12016E352).

Opinion 2/94, paragraphs 29–35, illustrates the limits of the predecessor
power: it is not a substitute for Treaty amendment. Its subject was ECHR
accession, not ownership funds. It neither authorises nor definitively
forbids this proposal. The candidate needs a specific analysis of the
Treaty-policy connection and institutional effects.
[Opinion 2/94](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex:61994CV0002).

The Forum also supplied Recommendation 92/443/EEC, an employee-participation
precedent under the predecessor power. It concerns a recommendation about
employed persons; it is not precedent approving compulsory universal equity
issuance. It supports further examination, not an automatic extension.
[Recommendation 92/443/EEC](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:31992H0443).

The integrated alternative uses one Article 352 Council Regulation, without
mixing ordinary and special procedures or pretending the warrant can operate
without a recipient Reserve. ECI objectives remain separable at registration;
that is different from judicial severability of this full instrument.
Article 115 remains a different route involving directives and national-law
approximation, not a interchangeable citation for this Council Regulation.
[Article 115](https://eur-lex.europa.eu/eli/treaty/tfeu_2016/art_115/oj/eng).

## 4. The property question cannot be resolved by a recital

Charter Article 17 distinguishes deprivation, with its compensation
requirement, from regulation of use in the general interest. A small
percentage and a correct valuation limit execution; they do not decide
which limb applies. Nominal subscription is not itself fair compensation.
[Charter Article 17](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:12016P017).

The candidate removes the argument that avoiding public expenditure justifies
refusing compensation, and the claim that bank-resolution cases establish a
safe percentage for healthy companies. The affirmative case is bounded,
prospective, non-controlling participation serving broad capital ownership.
The strongest countercase is compulsory acquisition of existing economic
value without equivalent consideration. Both still require adjudicative
assessment; no directly controlling approval of this mechanism was found.

A proper comparison must include fractional percentages and an appreciation-
only warrant, with the same generational objective and realistic financing.
Choosing the smallest integer is not by itself proof of legal necessity.
The stress runs compare fractional percentages but establish no calibrated
minimum. The alternative of market-price purchases requires identifying a
funding source; it is not inserted as if it preserved this design costlessly.

## 5. Concrete company-law and prospectus repairs

Directive 2017/1132 Article 70 concerns non-cash consideration, Article 72
cash pre-emption and Article 74 capital reduction. Article 84(1) permits
specified national derogations encouraging participation by employees or
other groups defined in national law. That provision is relevant context,
not an EU competence grant or blanket exemption from property safeguards.
The 2022 consolidation was read; no claim of an exhaustive review of all
later company-law amendments is made. Broader derogations require checking
all amendments applicable at filing.
[Consolidated Directive](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:02017L1132-20220812),
[original Article 84](https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32017L1132).

The candidate declines the previous review's misnumbered mandatory redrafts.
It removes the candidate's special admission-to-trading exemption and leaves
admission and subsequent public offers to the Prospectus Regulation and its
own exemptions. The class need not be listed for a statutory subscription.
This avoids depending on a same-class exemption for a new non-voting class.
[Prospectus Regulation](https://eur-lex.europa.eu/legal-content/en/ALL/?uri=CELEX:32017R1129).

## 6. Judicial protection and public-service compensation

The EU's involvement does not by itself exclude national-court jurisdiction
where the Treaties have not conferred it on the EU Court. Article 263 covers
review of Union acts under its conditions, not every private valuation.
The candidate assigns issuer/Reserve valuation and execution disputes to
national courts, with Belgium for issuers without an EU registered office,
while expressly preserving Treaty jurisdiction. Foreign recognition of a
judgment is a separate issue; naming a forum does not guarantee recovery.
[Article 274](https://eur-lex.europa.eu/eli/treaty/tfeu_2008/art_274/oj),
[Article 263](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:12016E263).

Altmark's conditions concern whether public-service compensation constitutes
aid; compatibility if it is aid is a separate question. The candidate
requires defined tasks, cost parameters, recovery of overcompensation and
compliance with applicable notification/standstill rules. It does not claim
that designation as a vehicle alone removes State aid scrutiny.
[Altmark Court press release](https://curia.europa.eu/site/upload/docs/application/pdf/2009-03/cp0364en.pdf),
[BUPA judgment summary, paragraphs 99–103](https://eur-lex.europa.eu/legal-content/EN/SUM/?uri=celex:62005TJ0354).

## What research has and has not closed

Source errors and specific drafting gaps have concrete repairs. Treaty
competence and the compulsory-property interference remain the central
legal decision boundary. Real initial service finance, national eligibility
records and foreign enforcement require operational evidence as well as
legal text. A further professional brief should attach this candidate and
these precise questions, rather than repeat the original Forum enquiry.
No external contact has been made.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/DECISIONS.md

# Decisions embodied in the complete review candidate

Continued drafting is authorised. These recommended choices are integrated
for examination, not adopted or merged. The editor retains final selection.

| Area | Concrete candidate | Remaining boundary |
|---|---|---|
| Legal route | Single Article 352 Council Regulation | Necessity within Treaty policies, specific powers, property rights and unanimity |
| Reserve | Five-member board, director/deputy, custody segregation, audit, financial and staffing rules | Actual pre-income service finance and provider commitments |
| Issuer | Parent or non-overlapping issuers; equivalent holding entity for forms without shares | Restructuring feasibility, minority interests and foreign enforcement |
| Remedies and information | Reasoned information decisions, privilege, national courts for valuation/execution | Anonymous-trade data access and foreign recognition of judgments |
| Existing EU law | Ordinary trading-admission rules, segregated vehicles, explicit aid compliance | Current amendments and selected providers' supervisory arrangements |
| Accounting | Immediate losses, recovery benchmark, reserved cash, bounded technical powers | Calibrated DC-45/46 sizing, including fractional alternatives |
| Eligibility | Equal daily accrual, inheritance of monetary claims, late registration and portability | Complete records, multi-nationality deduplication and post-payment correction |

A founding act cannot make a private provider finance services before income.
No lender, volunteer or donated custody is assumed. Nominal-value participation
still faces a deprivation/compensation objection; changing the Treaty citation
does not answer it. No-share entities can face costly restructuring under the
candidate, so this is a policy burden to assess, not a free technical fix.

A corrected eligibility denominator after payment may require recovery or a
financed reserve. The prototype rejects silent edits to a posted year rather
than inventing that policy. The candidate requires reconciliation but an
executable cross-border correction protocol remains incomplete. Defining a
trading day and reasonable-enquiry duties likewise does not grant access to
every market transaction. DC-1 and DC-45/46 remain unresolved on their merits.

The sensitivity exercise uses hypothetical distinct-company cohorts rather
than repeatedly imposing a warrant on the same company's growth. It separates
cash yield and appreciation and compares fractional percentages. It contains
no current market census or measured target and cannot certify sufficiency.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/MEMORANDUM.md

# Explanatory memorandum: integrated Article 352 alternative

Review candidate only. This memorandum describes candidate/regulation/ here,
not the website's earlier Article 114 draft. Source checks are in ../RESEARCH.md.

## 1. Context of the proposal

### Reasons and objectives

The objective remains broadly held capital over a generation, with equal
adult citizen participation. Distributions are contingent property income,
not an income-replacement target. Article 1's objective, the 3% subscription
and designation thresholds remain. The Reserve gets no votes. The mechanism
is not an annual revenue levy; legal classification still depends on substance.

### Consistency with existing provisions and other Union policies

The proposal complements competition and automation rules by addressing
ownership. It does not replace national taxes or claim to eliminate their
divergence. Pension and PEPP providers must segregate this activity. Ordinary
prospectus rules govern admission and later public offers. National public-
service compensation remains subject to State aid rules.

## 2. Legal basis, subsidiarity and proportionality

### Legal basis and choice of instrument

This alternative tests Article 352 through a Council Regulation with Parliament
consent and unanimity, as suggested for consideration by the Forum. Necessary
action within Treaty policies and the absence of sufficient specific powers
still need establishing. Treaty objectives alone confer no general power.
The 2023 wealth-tax registration decision does not supply an Article 114
holding for this mechanism. An Article 114 variant needs evidence of actual
national ownership rules and an account of what its provisions approximate.
This candidate does not combine incompatible legislative procedures.

### Subsidiarity

The proposed advantage is common treatment of consolidated undertakings and
participation following citizens across borders, with national payment rails.
Evidence comparing national or coordinated alternatives remains necessary.
The cross-border nature of automation alone is insufficient justification.

### Proportionality and rights

The affirmative case is bounded participation, prospective attachment,
retained control, reasoned designation and separately challengeable execution.
The countercase is compulsory dilution of healthy companies at nominal value,
including capital formed earlier. Neither a small percentage nor company-law
form decides whether this is deprivation requiring compensation. Avoiding
public expenditure is not a sufficient answer. No directly controlling
approval of this combination is identified here.

Fractional percentages, appreciation-only warrants and funded purchases need
comparison against the same objective, including financing and avoidance.
The retained 3% is a policy candidate, not a newly demonstrated minimum.
DC-1's 'future value' wording and DC-45/46's calibrated sizing remain open.
The candidate does not silently amend those constitutional constraints.

## 3. Evaluations, consultation and impact assessment

### Existing evaluations and consultation

The baseline evidence and strongest null findings remain relevant. This
package does not establish that AI has already caused aggregate European
employment or the labour share to collapse. Article 14's falsification and
review requirements remain. Forum request 2332 was sent on 21 August,
answered on 27 August and acknowledged that day. The ECI veteran replied
on 5 September. These are completed soundings, not institutional approval.
No new consultation or completed EDPS opinion is claimed.

### Impact assessment and regulatory fitness

No completed Commission impact assessment is claimed. Thirty-year scenarios
use hypothetical cash yields, price growth, costs and distinct annual
subscription cohorts. They include cashless growth and an asset-price crash,
and pair capital with payments. They establish neither future market coverage
nor that 3% reaches Article 1's target. No measured median-income target is
inserted. The reference assumes year-end contributions; the candidate Annex
also specifies monthly inflation weighting for intra-year contributions.

The holder-day prototype checks duplicate intervals, accrual, late registration,
transfers, payment retries and fractional balances with synthetic identifiers.
It is not a cross-border identity system. Complete national records, nationality
deduplication, succession verification and correction after payment remain
operational requirements, not things made available by drafting a clause.

## 4. Budgetary implications

Reserve capital is held for citizens, with no general-budget contribution or
discretionary treasury access. Applicable tax, withheld amounts and actual
service charges remain payable. Commission administration and national-vehicle
compensation can involve public budgets; fines accrue to the Union budget.
There is no claim of zero public expenditure.

The five-member board and accountable director govern the proposed fund,
not campaign staffing. The candidate requires a cash plan and published
contractual charges and deferrals. It does not invent a lender, unpaid staff
or donated custody. Subscription borrowing remains on existing terms.
Securing services before income exists is an open launch condition; financing
difficulties do not extinguish warrants or citizen claims.

## 5. Other elements

### Implementation and monitoring

Articles 3–4 identify issuers and holding entities, with bounded information
powers. No-share-form restructuring and foreign enforcement require further
assessment. Articles 5–7 retain all triggers and clocks, define an end-of-day
transfer-threshold valuation and provide national courts for issuer/Reserve
disputes, without altering Treaty jurisdiction. Ordinary exchange trading
counts: seven years is not a promised dormant period for listed issuers.

Articles 8–11 integrate governance, immediate losses, carried preservation
shortfalls and separately reserved allocations. Equal eligible-day accrual
survives death and late registration; the personal entitlement cannot be
sold or cashed out. The payment backstop counts three positive-allocation
years. Missing instructions preserve the money. Correcting a denominator
after payment requires a further explicit reconciliation protocol.

### Explanatory documents and detailed provisions

This Regulation alternative operates directly; it does not claim a national
transposition exercise. The complete candidate articles and annexes describe
its machinery. Articles 12–18 retain investment prohibitions, safeguards,
penalties and monitoring. Technical powers cannot change essential ownership,
loss or succession policy. Preparatory governance starts before general
application. Separable ECI objectives are distinct from judicial severability:
the warrant in this candidate requires a recipient Reserve.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/PLAIN.md

# What this alternative would do

This proposed alternative is under review. It has not replaced the website
draft and has not been filed or approved. It develops the published book's
case for long-term citizen ownership.

A covered company's warrant would arise when designation takes effect.
At the first statutory trigger, the Reserve would subscribe at nominal value
for new non-voting shares calculated from 3% of pre-subscription capital.
That base includes existing value, not just appreciation after designation.
Triggers include qualifying liquidity events, sustained shareholder extraction
and elapsed time. Ordinary exchange trading counts toward the 20% transfer
threshold, so seven years is not a promised waiting period for listed companies.
Reporting duties can apply before subscription.

The Reserve would hold capital for citizens. Citizens could not sell or cash
out their personal entitlement. Five independent board members and an
accountable executive would oversee custody, audit and an automated operation,
without directing investee companies. These are fund responsibilities, not
a campaign staffing requirement. Initial services still need actual financing.

Every adult EU citizen would accrue the same amount for the same eligible
days, with no income, wealth or employment test. Moving country changes payment
administration, not ownership. Money accrued while eligible survives death
and late registration. Money received is freely usable. National-record
coordination is necessary; the prototype does not solve that identity system.

Payments depend on realised income after subscription debt, costs and capital
preservation. Losses are recognised immediately. Capital can grow without a
payment, and both can fall short of the policy's ambition. Allocated cash is
reserved separately. The backstop counts three years with positive new
allocations, not three calendar years regardless of income. Neither capital
preservation nor larger annual payments is guaranteed.

This alternative examines Article 352, requiring Council unanimity and
Parliament consent. It does not establish the necessary Treaty power or
settle the property-rights question. The Forum's advice has already been
received; it is not registration or legislative approval. Illustrative
scenarios do not newly justify the unchanged 3% percentage.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/annexes/annex-1-counting.md

# Annex I: Methodology for turnover, employment and value

## 1. Union turnover

Annual Union turnover comprises the amounts derived by the undertaking
during the financial year from the sale of products and the provision of
services to undertakings or consumers in the Union, after deduction of
sales rebates and of value added tax and other taxes directly related to
turnover. Turnover is attributed to the Union where the customer is
established or, in the case of consumers, resident in the Union.
Intra-group transactions are excluded. Where the undertaking
comprises linked enterprises, turnover is calculated on a
consolidated basis.

## 2. Turnover of the automated segment

The turnover attributable to the provision of the goods and services
referred to in point (a) of Article 3(1), used for the assessment of that
point and in any market investigation pursuant to Article 4, comprises the
worldwide turnover derived from that provision. Where such goods or services
are sold together with other goods or services for a single consideration,
the consideration is attributed between them on a consistent and documented
basis reflecting their relative stand-alone value.

## 3. Compensation of labour

The annual worldwide compensation of labour of an undertaking comprises
all compensation of employees within the meaning of the European system
of accounts, including social contributions payable by the employer and
share-based compensation measured at grant value, as recorded in accounts
audited in accordance with the law applicable to the undertaking,
calculated on a consolidated basis for the group of linked enterprises,
and averaged over the last two financial years.

The compensation figure excludes artificial increases established by the
Commission under Article 3(8). Genuine remuneration includes increased pay
for existing work; it does not require additional hours or employees.

## 4. Fair market value

Fair market value is determined by reference to the most recent of
the following, adjusted for capital raised or returned since:
(a) the price per share paid in the most recent transaction in which
shares representing at least 2 % of the capital were issued or
transferred for consideration to persons independent of the undertaking,
applied to the fully diluted capital;
(b) an independent valuation prepared in accordance with internationally
accepted valuation standards within the preceding 12 months;
(c) where shares of the undertaking are admitted to trading, the average
market capitalisation over the preceding six months.

## 5. Information accompanying a notification

A notification pursuant to Article 3(3) contains:
(a) the identity of the undertaking and of all linked enterprises;
(b) the calculations referred to in points 1 to 4, with the data and
attribution bases used;
(c) the audited financial statements for the last two financial years;
(d) a description of the goods and services referred to in point (a) of
Article 3(1) which the undertaking provides, and of the automated
cognitive systems on which their provision depends;
(e) the law governing the undertaking and, where that law is the law of a
third country, the measures by which the undertaking intends to give
effect to Article 5.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/annexes/annex-2-retention.md

# Annex II: Allocation and preservation calculation

## 1. Separate balances

A denotes total assets at fair value, C cash, D subscription debt, K unpaid
administrative costs, H cash backing allocations already made and P the
protected-capital benchmark. Opening balances are those of the preceding
year's audited closing accounts, subject to published corrections.
Unallocated net capital is A minus D minus K minus H.

## 2. Contributions and preservation

A new subscription contributes the fair value of the shares less the nominal
amount paid. Borrowing is a liability and is not income or contributed
capital. The preservation target T is opening P indexed for the year's
Union harmonised index of consumer prices plus net contributions indexed
from their recognition dates to year-end. Monthly published indices and
recognition dates determine this weighting. New contributions enter both
actual capital and T; they therefore cannot erase an earlier shortfall.
Fair-value losses enter actual assets in full in the year they arise.

## 3. Cash-income ceiling

I is cash income received as dividends, interest and other realised returns,
net of applicable source taxation, plus realised disposal gains from permitted
diversification, excluding disposals effected to fund distributions. Disposal
principal is not income. F is the non-negative remainder after the repayment
of subscription borrowing and payment of outstanding and current costs.
Unpaid costs remain K. No item is deducted twice.

## 4. Annual allocation

U is unallocated net capital after contributions, income, valuation changes,
debt repayment and costs, before the current allocation. Q is the greater
of 1,25 times the average annual allocation for the preceding three available
financial years and 0,02 times the greater of U and zero. With no prior year,
the average is zero. The annual allocation is the least of F, the greater
of U minus T and zero, and Q. The closing benchmark P is the greater of T
and U minus that allocation. A shortfall is the greater of T minus U and
zero. H increases by the new allocation and decreases by payments made.
All of H is backed by reserved cash. Actual net assets are A minus D minus K;
H is included in holders' reported beneficial stake, without being preserved
a second time as unallocated capital.

## 5. Execution cost

The average execution cost is the total verified payment-service and vehicle
execution charges for the most recent payment round divided by payees paid.
Before the first round it is the weighted average of written execution quotes.
It excludes a cost already deducted in calculating F and is reported separately
from recurring custody or account administration costs. The threshold comparison
uses accumulated allocations due, divided by the number of payees for that round.
Missing payment instructions are accounted for separately under Article 10(6).


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/01-subject-matter.md

# Article 1: Subject matter and scope

1. This Regulation establishes a common mechanism ensuring the participation of
citizens of the Union in the capital value created by hyper-automated
undertakings operating in the internal market.

2. The participation referred to in paragraph 1 shall be of such scale
that, on the designations made under Article 3 and the methodology laid
down in Annex II, the aggregate value of the holdings attributable to each
citizen's entitlement is capable of reaching, within one generation of the
first designations and in constant prices, an amount of the order of six
months of the median equivalised disposable income in the Union as
published by the Commission (Eurostat). Distributions under Article 10
shall remain the property income of the holders and shall be governed solely by
Article 8 and Annex II. The Commission shall assess progress against this
objective in each report under Article 14(2), and where the assessment
shows the objective to be manifestly unattainable or manifestly exceeded,
the report shall be accompanied, where appropriate, by a proposal to amend
the percentage laid down in Article 5(2) or the thresholds laid down in
Article 3(2).

3. To that end, this Regulation establishes:
(a) criteria and a procedure for the designation of covered undertakings;
(b) an obligation on covered undertakings to issue citizens' capital
warrants to the European Citizens' Capital Reserve;
(c) the European Citizens' Capital Reserve and the rules governing its
holdings and conduct;
(d) an individual entitlement of citizens of the Union to distributions from
the Reserve, administered through national vehicles;
(e) rules protecting the Reserve and individual entitlements.

4. This Regulation applies to undertakings offering goods or services in the
internal market, irrespective of their place of establishment.

5. This Regulation is without prejudice to Directive (EU) 2016/2341 and to
Regulation (EU) 2019/1238, save as expressly provided in Article 11.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/02-definitions.md

# Article 2: Definitions

For the purposes of this Regulation, the following definitions apply:

(1) 'undertaking' means an entity engaged in an economic activity,
regardless of its legal status and the way in which it is financed,
including all linked enterprises within the meaning of Article 3(3) of the
Annex to Recommendation 2003/361/EC;

(2) 'covered undertaking' means an undertaking designated pursuant to
Article 3;

(3) 'automated cognitive services' means services whose provision depends to
a significant extent on software systems, including artificial intelligence
systems within the meaning of Article 3(1) of Regulation (EU) 2024/1689,
performing tasks that would otherwise require human cognitive labour;

(4) 'citizens' capital warrant' means a financial instrument arising
pursuant to Article 5 which confers the right to subscribe for shares in a
covered undertaking;

(5) 'Reserve' means the European Citizens' Capital Reserve established by
Article 8;

(6) 'liquidity event' means any of the following:
(a) the admission of shares of the covered undertaking to trading on a
regulated market or multilateral trading facility, in the Union or in a
third country;
(b) a change of control of the covered undertaking;
(c) one or more transactions within any period of 12 months by which shares
representing at least 20 % of the capital of the covered undertaking are
transferred for consideration;

(7) 'change of control' means the acquisition, directly or indirectly, of
decisive influence over the covered undertaking within the meaning of
Article 3(2) of Regulation (EC) No 139/2004;

(8) 'compensation of labour' means the annual worldwide compensation of
employees of an undertaking, calculated in accordance with point 3 of
Annex I;

(9) 'fair market value' means the value determined in accordance with
Annex I on the basis of the most recent funding transaction, independent
valuation or observable market price, whichever is most recent;

(10) 'holder' means a natural person in whom an entitlement is vested
pursuant to Article 10;

(11) 'national vehicle' means the body or arrangement designated by a
Member State pursuant to Article 11 to administer entitlements;

(12) 'distribution' means a payment made from the Reserve to holders
pursuant to Article 10;

(13) 'shareholder extraction' means, in respect of a covered undertaking
and a period, the aggregate value transferred by it to its shareholders, to
undertakings within the same group, to persons controlling it and to persons
connected with any of them, a person being connected where the same natural
persons hold, directly or indirectly, the majority of the economic rights in
both, comprising:
(a) dividends and other distributions, consideration paid for the
repurchase or redemption of its own shares, and reductions of capital paid
out;
(b) repayments of principal on debt owed to any such person, and loans made
to and claims acquired on any such person to the extent not repaid or
realised within twelve months;
(c) interest on such debt, and payments for the use of intellectual
property, for management and for other services rendered by any such
person, in each case to the extent that the payment exceeds what would
have been agreed between independent undertakings;

(14) 'automated assets' means the software systems referred to in point (3),
the model parameters, training and inference infrastructure, data sets and
intellectual property rights on which the provision of the goods or services
referred to in Article 3(1)(a) principally depends;

(15) 'legal issuer' means a legal person identified in a designation or
transfer decision as responsible for the warrant and subscription;

(16) 'eligible day' means a calendar day on which a person is living,
is a citizen of the Union and has attained the age of 18 years;

(17) 'allocation' means the monetary claim attributed to a holder under
Article 10 for eligible days in a completed financial year.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/03-designation.md

# Article 3: Designation of covered undertakings

1. An undertaking shall be designated as a covered undertaking where:
(a) it provides automated cognitive services, or goods or services whose
production depends to a significant extent on automated cognitive systems,
in the internal market;
(b) the economic output of the undertaking is substantially decoupled from
its employment of labour; and
(c) the position referred to in points (a) and (b) is durable.

2. An undertaking shall be presumed to satisfy: (a) point (a) of paragraph
   1, where it achieves an annual Union turnover equal to or above EUR 7,5
   billion, or where its fair market value amounts to at least EUR 75
   billion, and it provides the goods or services referred to in that point
   in at least three Member States; (b) point (b) of paragraph 1, where its
   fair market value equals or exceeds eighty times its annual worldwide
   compensation of labour, each calculated in accordance with Annex I; (c)
   point (c) of paragraph 1, where the thresholds in points (a) and (b) of
   this paragraph were met in each of the last two financial years.

3. Where an undertaking meets all the thresholds laid down in paragraph 2,
it shall notify the Commission thereof within two months after those
thresholds are met, providing the information listed in Annex I. A failure
to notify shall not prevent designation on the basis of the facts
available to the Commission.

4. The Commission shall, without undue delay and at the latest 45 working
days after receiving the complete information referred to in paragraph 3,
designate by decision the undertaking as a covered undertaking.

5. The undertaking may, with its notification, present sufficiently
substantiated arguments demonstrating that, exceptionally, although it
meets all the thresholds in paragraph 2, it does not satisfy the
requirements of paragraph 1. Those arguments shall be taken into account
only where they manifestly call the presumption into question; arguments
based on the definition of the relevant market shall not be taken into
account. Where such arguments require detailed assessment, the Commission
may open a market investigation pursuant to Article 4(1) instead of
designating within the period laid down in paragraph 4.

6. The Commission may designate as a covered undertaking any undertaking
that satisfies the requirements of paragraph 1 without meeting the
thresholds of paragraph 2, following a market investigation conducted
pursuant to Article 4.

7. The obligations laid down in this Regulation shall apply to a covered
undertaking irrespective of whether its shares are admitted to trading, and
designation shall precede any liquidity event wherever the thresholds of
paragraph 2 are met before that event.

8. An undertaking shall not segment, divide, combine or restructure its
   activities, or acquire or dispose of undertakings, where the main purpose
   or one of the main effects thereof is to avoid meeting the thresholds
   laid down in paragraph 2. The Commission shall disregard any such
   arrangement when applying this Regulation, and shall likewise disregard
   any transaction, arrangement or attribution which artificially increases
   the compensation of labour or artificially reduces the fair market value
   referred to in point (b) of paragraph 2. An increase in remuneration for
   genuine work, including an increase without additional hours or employees,
   or a reduction in value supported by an independent transaction or
   valuation satisfying Annex I, shall not be disregarded solely because it
   changes the ratio referred to in that point. The third sentence of this paragraph shall not
   prevent the application of the first sentence to acquisitions, disposals
   or restructuring arrangements.

9. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex I where necessary to
reflect technological and market developments. Those delegated acts shall
not amend the thresholds laid down in paragraph 2.

10. A designation decision shall identify the legal issuer and the
consolidated ownership perimeter. Where a group has an ultimate parent
whose equity represents that perimeter, that parent shall be the issuer.
The valuer shall value outside minority interests separately and shall not
count subsidiary equity already represented in a parent's equity again.
Where no single parent represents the perimeter, the decision shall
identify the constituent issuers and their non-overlapping ownership
interests. Articles 5 to 7 and 13 shall bind each identified issuer.

11. Where a legal issuer has no share capital, it shall procure equity
participation through a corporate holding entity representing the same
residual economic interest, without increasing the interference under
Article 7(2), impairing creditor rights or giving the Reserve a vote.
The Commission shall identify that entity and the equivalence conditions
in its reasoned designation decision after the hearing under Article 4(4).
The use of a holding entity shall not restart the statutory clock or
convert the obligation into a payment charge. For an issuer governed by
third-country law, this paragraph shall operate as an obligation to procure
the result and shall not override that law.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/04-review-of-designation.md

# Article 4: Market investigation and review of designation

1. The Commission may conduct a market investigation for the purpose of
Article 3(6). It shall conclude the investigation within 12 months by a
decision designating the undertaking or closing the investigation.

2. The Commission shall review each designation at least every three years,
and whenever the covered undertaking so requests on the basis of a
substantial change in the facts on which the designation was based.

3. The Commission shall repeal a designation where the covered undertaking
has not satisfied the requirements of Article 3(1) for two consecutive
financial years. Repeal shall not be granted where the failure to satisfy
those requirements results from an arrangement referred to in Article 3(8). Repeal shall not affect a citizens' capital warrant
already arisen, save that a warrant shall lapse five years after repeal if
it has not crystallised by that date.

4. Before adopting a decision under this Article or under Article 3, the
Commission shall communicate its preliminary findings to the undertaking
concerned and give it the opportunity to be heard within a period of not
less than 20 working days.

5. The Commission may by reasoned decision require a legal issuer or an
undertaking under investigation to supply specified records necessary to
establish designation, crystallisation, valuation or compliance. The decision
shall state its purpose, legal basis, the records requested, a proportionate
time limit and the available remedy. The Commission shall protect legal
professional privilege and confidential information. It shall not require
an admission of infringement. Before relying on contested information it
shall give the addressee access to the material relied upon, subject to
protection of the rights of others, and an opportunity to respond.

6. A legal issuer shall keep a record of reportable transfers notified to
it and of capital, ownership and extraction information necessary to apply
Articles 5 and 6. It shall make reasonable documented enquiries of its
registrar and persons whose transactions are relevant. A failure to predict
or discover transactions not reasonably accessible to it shall not alone
constitute an intentional or negligent infringement. This paragraph shall
not confer inspection or search powers on the Commission.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/05-warrant.md

# Article 5: The citizens' capital warrant

1. A citizens' capital warrant shall arise in favour of the Reserve by
operation of law on the date on which designation of a covered undertaking
takes effect. References in this Article to designation shall mean that effective
date. The covered undertaking shall issue the instrument recording that warrant
within three months of designation. Failure or delay in issuing the
instrument shall not postpone the attachment or crystallisation of the
warrant. No more than one warrant shall arise in respect of the same
designation, without prejudice to paragraphs 11 and 12.

2. The citizens' capital warrant shall entitle the Reserve, upon the first
liquidity event following designation or upon crystallisation under paragraph
3, whichever occurs first, and upon no other occasion, to subscribe at
nominal value for newly issued shares representing 3 % of the fully diluted
capital of the covered undertaking determined immediately before that event
or, in the case of paragraph 3, immediately before the date of
crystallisation.

3. The citizens' capital warrant shall also crystallise, and shall be
exercisable on the same terms, where either of the following occurs before
a liquidity event:
(a) shareholder extraction by the covered undertaking in any period of
three consecutive financial years exceeds 25 % of its turnover from the
goods and services referred to in Article 3(1)(a) over the same period;
(b) seven years have elapsed since the date on which the warrant arose.

For a warrant arising under paragraph 11 or 12, the period referred to in
point (b) shall run from the date on which the warrant of the original
covered undertaking arose. A transfer or a fresh recording instrument
shall not restart that period.

Crystallisation under this paragraph shall take effect on the last day of
the financial year in which the condition is met, and the valuation under
Article 6 shall be performed as at that date.

4. The citizens' capital warrant shall:
(a) confer no voting rights, no rights of information beyond those provided
in this Regulation and no right to participate in the management of the
covered undertaking;
(b) entitle the Reserve to shares which rank, as regards dividends, other
distributions and the proceeds of any sale, liquidation or winding up,
equally with the class of shares ranking most favourably in those respects
among the classes created after the designation of the covered
undertaking, and otherwise equally with its ordinary shares, without
affecting the ranking of claims of creditors;
(c) be incapable of settlement in cash or in assets other than the shares
referred to in paragraph 2;
(d) be non-transferable, save to a successor of the Reserve established by
Union legislative act;
(e) confer no right to require subscription before the first liquidity
 event following designation or crystallisation under paragraph 3,
 whichever occurs first, without prejudice to any issuance, notification,
 information, valuation or anti-avoidance obligation laid down in this
 Regulation.

Shares subscribed pursuant to the citizens' capital warrant shall be
non-voting for as long as they are held by the Reserve.

5. The right to the subscription referred to in paragraph 2 shall vest by
operation of law at the completion of the liquidity event or on the date of
crystallisation under paragraph 3. The number of shares to be subscribed
shall be determined by the valuation under Article 6, and the subscription
shall be executed accordingly. Where the law
governing the covered undertaking does not give effect to the first
sentence, the covered undertaking shall procure a subscription of
 equivalent effect within the execution period laid down in this paragraph.
 It shall put in place the arrangements necessary to secure that result
 no later than the liquidity event or the date of crystallisation under
 paragraph 3; those arrangements shall provide for the share count to be
 fixed by the valuation under Article 6. The dilution resulting from the subscription shall not
exceed the percentage laid down in paragraph 2. The covered undertaking shall execute the
subscription within 20 working days of the delivery of the valuation
referred to in Article 6, and the Reserve shall pay up the shares in full
in cash at their nominal value upon execution.

6. A covered undertaking shall notify the Reserve and the Commission of any
impending liquidity event no later than the earlier of its public
announcement and 30 working days before its completion. Where an event
cannot reasonably be known by that deadline, the undertaking shall notify
it without undue delay after becoming aware of it, stating the reasons why
earlier notification was not possible. The burden of establishing those
reasons shall rest on the undertaking. A notification shall not be a
condition for crystallisation. For an event under Article 2(6)(c), the
event date shall be the first trading or business day on which the rolling
12-month total reaches the threshold after designation, counting each
completed transfer once. Transfers completed before designation shall not
count. The valuation time shall be the close of that day. Ordinary exchange
transactions shall count towards that threshold.

The undertaking shall notify the Reserve and the Commission of
crystallisation under paragraph 3 within five working days of the end of
the relevant financial year. It shall provide its extraction calculation
and supporting management records, without awaiting annual audit, and
correct them without undue delay when audited information is available.
The Commission shall appoint the valuer in time for the deadline in
Article 6(3), using provisional information where necessary. The undertaking
shall provide that valuer with the capital and transaction records needed
for the valuation. Correction of the information shall not postpone the
original crystallisation date or exclude a correction under Article 6(4).

7. Article 49, Article 68(1), (2) and (3), the first subparagraph of
Article 70(2), Article 72 and Article 73 of Directive (EU) 2017/1132, and
any
corresponding provisions of the law of a Member State conferring
pre-emption rights, requiring a decision of the general meeting or
requiring an expert report on consideration, shall not apply to the
issuance of the citizens' capital warrant or to the subscription of
shares pursuant to it. Provisions of the law of a Member State restricting the
proportion, issuance conditions or characteristics of non-voting shares
shall not apply to the extent that they would prevent the issuance or
holding of shares pursuant to this Article.

8. The issuance of the citizens' capital warrant and the issuance, offer
and subscription of shares pursuant to this Article shall not constitute an
offer of securities to the public for the purposes
of Regulation (EU) 2017/1129. The admission to trading or subsequent offer of those shares shall remain
subject to Regulation (EU) 2017/1129, including any exemption available
under that Regulation. This Article shall not require admission of the
Reserve's class or make its subscription conditional on such admission.

9. The valuation of the fully diluted capital for the purposes of paragraphs
2 and 3 shall be performed by an independent valuer appointed in accordance
with Article 6, and shall be open to challenge before the courts in
accordance with Article 7 separately from any other element of the
designation or the event.

10. An arrangement that subordinates, reduces or defeats the economic
participation conferred by this Article shall not be effective as against
the Reserve, which shall be placed in the position it would have occupied
had the arrangement not been made; the arrangement shall remain effective
between the parties to it and as against third parties. In particular, the
issuance of shares ranking ahead of those held or subscribable by the
Reserve, any alteration of the rights attaching to any class of shares, and
any reorganisation of capital shall be of no effect as against the Reserve
to the extent that its main purpose or one of its main effects is to place
the Reserve in a position less favourable than that provided for in
paragraph 4(b).

The first subparagraph shall not apply to an issuance of shares or other
instruments for new consideration in money or money's worth, at arm's
length, to persons who are not members of the same group as the covered
undertaking, do not control it, are not connected with it and are not acting
in concert with any person who controls it, where at the time of the
issuance the covered undertaking is in a likelihood of insolvency within the
meaning of Directive (EU) 2019/1023 or the issuance is necessary to comply
with a prudential requirement under Union law, and only to the extent of the
new consideration provided. To the extent that the preference, ranking or
other advantage conferred by the issuance exceeds the new consideration
provided, the first subparagraph shall apply to the excess. The covered
undertaking shall bear the burden of establishing that the conditions of
this subparagraph are met.

11. Where a covered undertaking transfers automated assets to another
undertaking, whether by sale, contribution, licence, demerger, division or
otherwise, where the transfer, alone or together with related arrangements,
confers in substance the economic benefit of the automated assets on the
transferee, and the transfer is not made at arm's length or the transferee is
a member of the same group or is controlled, directly or indirectly, by
persons who control the covered undertaking, the transferee shall issue to
the Reserve a citizens' capital warrant within three months of the transfer as if
it were a covered undertaking. The warrant shall arise on the date of the
transfer. The obligations of the covered undertaking
under this Article shall continue in respect of the automated assets it
retains. The aggregate of the subscriptions to which the Reserve is entitled
in respect of the same designation, under this paragraph and under paragraph
2, shall not exceed the percentage laid down in paragraph 2 of the combined
fully diluted capital of the covered undertaking and of every transferee, and
the valuation under Article 6 shall determine the subscription in each of
them accordingly.

Paragraphs 2 to 10 and Articles 6, 7 and 13 shall apply to the transferee
as they apply to a covered undertaking. For paragraph 2, references to
designation shall mean the date of transfer; the original date shall
continue to apply to ranking under paragraph 4(b). Where the original warrant has
already crystallised, or its paragraph 3 date has been reached, the
transferee's warrant shall crystallise on the transfer date. The aggregate
cap in the first subparagraph shall take account of shares already
subscribed in respect of that designation.

The obligations of a transferee under this paragraph shall arise irrespective of
whether the transferee meets the conditions laid down in Article 3, and this
paragraph shall apply to any onward transfer of the automated assets by a
transferee as it applies to a transfer by a covered undertaking. For the
purposes of the valuation under Article 6, the value of the fully diluted
capital of the transferee shall reflect the automated assets at the value
they would have had on a transfer at arm's length.

12. Where the automated assets of a covered undertaking are acquired by
another undertaking in or in consequence of insolvency proceedings, a
restructuring procedure, including a procedure under Directive (EU)
2019/1023, or any comparable procedure, and, upon completion, the
transferee is controlled directly or indirectly by persons who controlled
the covered undertaking, or those persons hold, directly or indirectly, the
majority of the economic rights in the transferee, the obligations under
this Article shall attach to
the transferee as if it were the covered undertaking, and the transferee
shall issue a citizens' capital warrant afresh within three months of the
completion of the acquisition. The warrant shall arise on completion of
the acquisition, or on the later acquisition of control referred to in the
second subparagraph. Paragraphs 2 to 10 and Articles 6, 7 and 13 shall
apply to the transferee. The clock, crystallisation on transfer and
aggregate-cap rules in paragraph 11 shall apply correspondingly.

For the purposes of this paragraph, persons acting in concert with those
who controlled the covered undertaking, and persons connected with them,
shall be treated as those persons; and where any of them acquires control
of the transferee, at any time while it holds the automated assets, the
obligations under this Article shall attach to the transferee from the date
of that acquisition.

This paragraph shall not otherwise apply where control of the transferee
is acquired by persons who did not control the covered undertaking, and in
that case the extinguishment of a warrant in such a procedure shall give
rise to no obligation under this Article.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/06-valuation.md

# Article 6: Independent valuation

1. The valuation referred to in Article 5(9) shall be performed by a valuer
who is independent of the covered undertaking, of the Reserve and of any
party to the liquidity event, appointed by the Commission from a list
established after an open call. The Commission shall establish the list and
the criteria and rotation governing appointments from it by means of
implementing acts, adopted in accordance with the examination procedure
referred to in Article 16(2). An individual appointment shall be made by
decision of the Commission in accordance with those criteria and that
rotation, and shall not require that procedure.

2. The valuation shall determine the fully diluted capital of the covered
undertaking immediately before the liquidity event or, in the case of
crystallisation under Article 5(3), immediately before the date of
crystallisation, in accordance with internationally accepted valuation
standards and, where an event itself establishes a price, on the basis of
that price.

3. The valuer shall deliver the valuation within 20 working days of the
completion of the liquidity event or of the date of crystallisation under
Article 5(3). The costs of the valuation shall be borne by the
covered undertaking.

4. Where a court finds, pursuant to Article 7, that the valuation
overstated the fully diluted capital, the Reserve shall transfer back to
the covered undertaking, or cancel, the shares subscribed in excess of the
percentage laid down in Article 5(2). Where a court finds that the
valuation understated it, the covered undertaking shall issue the missing
shares to the Reserve.

5. A challenge to the valuation shall not suspend the liquidity event, the
crystallisation or the subscription.

6. The valuer shall determine share numbers and economic rights, the
value of each non-overlapping ownership interest, nominal subscription
amounts and the treatment of prior subscriptions under the same designation.
For multiple issuers, the valuer shall publish a reconciliation of the
combined economic base and resulting dilution using a common currency and
valuation date. The valuer shall not treat a sum of share numbers from different issuers
as a combined capital value and shall not include any interest twice. A prior
subscription shall count at the value of the participation it represents
at the relevant valuation date, not merely at its historic subscription
price. The valuer shall give issuers and the Reserve the calculation and
supporting reasons. The valuer shall apply the closing-time rule laid down in Article 5(6)
for a transfer-threshold event.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/07-safeguards.md

# Article 7: Safeguards and judicial review

1. The courts of the Member State in which a legal issuer has its
registered office shall have jurisdiction over a challenge to the independent
valuation or a dispute over execution of the subscription between that issuer
and the Reserve. Where the issuer has no registered office in the Union,
the courts of Belgium shall have jurisdiction over that dispute. The issuer,
the Reserve and a shareholder whose economic interest is affected may bring
a separate valuation challenge. A challenge shall not require an appeal
against designation or an administrative reconsideration of the valuation.
This paragraph shall not confer power on a national court to invalidate an
act of a Union institution or alter jurisdiction conferred by the Treaties.

2. The dilution borne by the shareholders of a covered undertaking in
consequence of this Regulation shall not exceed the percentage laid down in
Article 5(2), determined on the basis of the valuation under Article 6 as
corrected, where applicable, pursuant to Article 6(4). Where warrants have
been issued by transferees pursuant to Article 5(11), that percentage
shall apply to the dilution borne, taken together, by the shareholders of the
covered undertaking and of every such transferee.

3. This Regulation shall not affect any right of shareholders to
compensation under the law of a Member State against parties other than
the Reserve.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/08-reserve.md

# Article 8: The European Citizens' Capital Reserve

1. The European Citizens' Capital Reserve is established. The Reserve shall
have legal personality and shall enjoy in each Member State the most
extensive legal capacity accorded to legal persons under the law of that
Member State.

2. The Reserve shall hold its assets exclusively for the benefit of
holders. Its assets and income shall not constitute revenue of the Union or
of any Member State and shall not be entered in the general budget of the
Union or in any public budget.

3. The Reserve shall be financed exclusively by the instruments referred to
in Article 5, by the proceeds of their crystallisation and by the returns
on its assets. It shall receive no contribution from, and shall make no
payment to, the general budget of the Union or the budget of any Member
State.

4. The Reserve shall determine the amount available for allocation in each
financial year under Annex II. It shall apply realised income first to
subscription borrowing under Article 9(1)(e), then to outstanding and current
administrative costs and then to capital preservation. It shall recognise
losses immediately and carry the preservation shortfall forward. New
contributions shall not discharge a shortfall on previously held capital.
It shall separately reserve cash backing holder allocations. Such cash
shall not meet subscription or operating costs or bear a second retention.
No distribution shall be financed by borrowing or a disposal effected for
that purpose. The annual allocation shall not exceed available realised
income, capital above the preservation benchmark or the collar in Annex II.

5. The Reserve shall state in its accounts, for each financial year, the
amount of tax withheld at source which it was unable to recover, and the
Commission shall address that amount in the report referred to in Article
14(2).

6. The Reserve shall publish annually audited accounts, the valuation of
its holdings and the calculation referred to in paragraph 4.

7. The Reserve shall not be considered an investment firm within the
meaning of Directive 2014/65/EU, an alternative investment fund or an
alternative investment fund manager within the meaning of Directive
2011/61/EU, or an institution for occupational retirement provision within
the meaning of Directive (EU) 2016/2341.

8. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend technical valuation and inflation-conversion methods
in Annex II. Those acts shall not change the cash-income requirement,
priority of debt and costs, immediate recognition and recovery of losses,
separation of allocated cash, numerical collar, entitlement period or
payment backstop laid down in this Regulation.

9. The Reserve shall have a board of five independent members and an
executive director. The Commission shall appoint the members following an
open call, publication of a reasoned shortlist and a public hearing before
the European Parliament. Selection shall reflect competence in fiduciary
administration, financial accounting, custody, information security and
citizens' rights. No member shall represent a government or undertaking.
Members shall serve a non-renewable term of six years. For the first board,
two members selected by lot shall serve three years. The Commission shall
fill a vacancy within three months by the same procedure.

10. The board shall appoint the executive director after an open competition
for a non-renewable term of five years. The director shall represent the
Reserve in contracts and proceedings and execute its statutory duties.
The board shall appoint a deputy by the same procedure to act during absence,
vacancy or conflict of the director. The board shall decide by a majority
of its members, with at least three unconflicted members participating.
Neither vacancy nor a failure to decide shall suspend a statutory entitlement
or authorise postponement of a distribution required by Article 10.

11. Members, the director and the deputy shall neither seek nor take
instructions from a Union institution, a Member State, a covered undertaking
or a national vehicle. They shall disclose interests and recuse themselves
from a matter involving a conflict. They shall not simultaneously hold
public office or a remunerated position with a covered undertaking or a
service provider to the Reserve. The appointing authority may remove a
person only for serious misconduct, permanent incapacity or failure to
satisfy these conditions, by a reasoned decision after a hearing, subject
to judicial review under the Treaties.

12. The board shall adopt and publish an annual administration budget,
custody and procurement arrangements, and a policy for permitted
investment and currency hedging. It shall monitor compliance with Articles
8 to 12. No policy or instruction shall change the warrant, the entitlement,
the distribution calculation, or the prohibitions in Articles 9 and 12.
It shall appoint an independent external auditor after open procurement.
The auditor shall report on the accounts, asset custody, distribution
calculation, conflicts and compliance with the statutory prohibitions.
The Reserve shall send the report and its response annually to the European
Parliament, the Council and the Court of Auditors. This paragraph shall not
restrict the powers of the Court of Auditors under Article 287 TFEU.

13. The director may use automated systems and procure administrative
services for statutory tasks. The director shall remain responsible for
those tasks and for correction of errors. The Reserve shall maintain an
auditable record of the inputs, rules, authorisations and outputs of each
payment and material asset transaction. A decision refusing or reducing a
holder's payment shall state reasons and provide for review by an authorised
person and access to a court or tribunal under the applicable Union and
national procedures. Automation shall not introduce an additional condition
of entitlement or an administrative appeal that must be exhausted before
a valuation challenge under Article 7.

14. Regulation (EU) 2018/1725 shall apply to processing of personal data by
the Reserve. The Reserve shall publish its rules, contracts, accounts and
decisions, subject to protection of personal data and legally protected
confidential information. Holders shall be able to obtain the records
necessary to understand their own payment without disclosure of another
holder's personal data.

15. The seat of the Reserve shall be Brussels. Its contractual liability
shall be governed by the law applicable to the contract. Its non-contractual
liability shall be governed by the general principles common to the laws of
the Member States, subject to the jurisdiction conferred by the Treaties.
The Staff Regulations of Officials and the Conditions of Employment of Other
Servants of the European Union shall apply to its staff. The board shall
exercise the powers of the appointing authority, with delegation to the
director for staff other than the director and deputy. Regulation (EC)
No 1049/2001 shall apply to documents held by the Reserve.

16. The board shall adopt financial rules requiring segregation of custody
from payment authorisation, annual accounts and audit, open procurement,
recorded conflicts and recovery of irregular expenditure. It shall publish
a costed cash plan before entering commitments. A contract shall specify
its maximum charge, payment source and any deferral agreed by the provider.
Neither a service contract nor a deferred fee shall confer rights over
holders' allocated money or permit conduct prohibited by Articles 9 and 12.
The board shall publish an annual assessment of its ability to meet custody,
audit and payment obligations. A financing shortfall shall not extinguish a
warrant or a holder's entitlement.

17. For paragraph 3, subscription borrowing permitted by Article 9(1)(e)
shall not constitute a budget contribution. Tax required by applicable law,
including unrecoverable withholding, and payment of an arm's-length charge
for an actual service shall not constitute a diversion to a public budget
under paragraphs 2 and 3. This paragraph shall not create a tax exemption,
a power to levy a charge on covered undertakings or permission to arrange
holdings for the purpose of reducing withholding.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/09-prohibited-conduct.md

# Article 9: Prohibited holdings and conduct of the Reserve

1. The Reserve shall not:
(a) exercise, directly or indirectly, any voting right attached to any
share it holds;
(b) seek or accept representation in the administrative, management or
supervisory bodies of any undertaking;
(c) give instructions, formally or informally, to any undertaking in which
it holds an interest;
(d) acquire an interest in any undertaking otherwise than pursuant to
Article 5, by reinvestment of its income or by prudent diversification of
crystallised holdings;
(e) borrow, save for temporary liquidity purposes not exceeding 2 % of the
value of its assets and save for the payment of subscription amounts under
Article 5(5), which borrowing shall be repaid from the first realised
income of the Reserve;
(f) grant loans or guarantees;
(g) enter into derivative contracts, save for hedging currency risk on
assets it holds.

2. The Reserve shall manage its holdings with the sole objective of
long-term preservation and growth of value for the benefit of holders.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/10-entitlement.md

# Article 10: The citizens' entitlement

1. Every citizen of the Union who has attained the age of 18 years shall hold an
entitlement under this Regulation.

2. The entitlement shall arise by operation of law. It shall not be subject to
any condition relating to income, wealth, employment, contribution history
or any other personal circumstance, nor to any application, save
registration for payment purposes with a national vehicle.

3. All entitlements shall be equal for the same eligible days. For each
financial year, the Reserve shall divide the allocation under Article 8(4)
by the total eligible days of all holders in that year. Each holder's
allocation shall be that common daily amount multiplied by that holder's
eligible days. Nationality, residence and payment registration shall not
alter the daily amount. The Reserve shall retain fractional currency units
in the holder's account and shall not extinguish them by rounding.

4. The entitlement shall comprise the personal right to participation for
eligible days and the monetary claims allocated for those days. A monetary
claim shall accrue for eligible days even if the holder dies before the
annual calculation or registers for payment later. It shall be inheritable
under the applicable succession law. Death or loss of Union citizenship
shall end accrual for subsequent days and shall not cancel prior accrual.

5. The personal entitlement shall be incapable of assignment, pledge,
attachment, seizure, surrender or redemption. Money allocated under
paragraph 4 shall be the holder's property and shall be separately accounted
for pending payment. Money received shall be freely usable.

6. The Reserve shall pay accumulated allocations in a year when the average
amount due per payee is at least ten times the average execution cost under
Annex II. It shall in any event pay no later than the third financial year
with a positive new allocation since the previous payment. A zero-allocation
year shall not count towards that period. The Reserve shall reserve funds
for unregistered holders and disputed identities; registration or correction
shall release amounts already due without a fresh cost threshold or waiting
period. A delay attributable to missing payment instructions shall not cancel
the claim. National vehicles shall credit the individual holder accounts.

7. The Reserve shall publish annually the new allocation, accumulated unpaid
allocations, actual net assets per holder, the preservation benchmark and
any shortfall. A reported benchmark shall not be described as guaranteed
capital or an amount redeemable by a holder.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/11-national-vehicles.md

# Article 11: National vehicles

1. Each Member State shall designate, within 12 months of the entry into
force of this Regulation, one or more national vehicles to administer
entitlements. Existing institutions within the meaning of Directive (EU)
2016/2341, providers within the meaning of Regulation (EU) 2019/1238 and
statutory funds may be designated. By way of derogation from Article 7 of
Directive (EU) 2016/2341, an institution designated as a national vehicle
may carry out the account administration and distribution activities
provided for in this Regulation. A provider within the meaning of
Regulation (EU) 2019/1238 designated as a national vehicle shall maintain
holders' accounts separately from any product governed by that Regulation,
and the requirements of that Regulation shall not apply to those accounts.

2. A national vehicle shall:
(a) maintain an individual account in the name of each holder registered
with it;
(b) credit distributions to holders' accounts without deduction other than
charges permitted under paragraph 3;
(c) treat amounts standing to a holder's account as the holder's property
in accordance with Article 10(4);
(d) apply no condition of access other than identity and the condition in
Article 10(1).

3. Charges levied by a national vehicle on holders shall not exceed the
costs actually incurred in administering the accounts and in any event
0,3 % annually of the amounts administered. A Member State may compensate a
national vehicle for verifiable net costs exceeding that ceiling; such
compensation shall not be charged to holders or to the Reserve.

4. Where a Member State has not designated a national vehicle, or where the
designated vehicle does not comply with paragraph 2, a holder residing in
that Member State may register with a national vehicle of another Member
State, which shall not refuse the registration on grounds of residence.
Where a national vehicle registers a holder pursuant to this paragraph, the
Member State of residence of that holder shall reimburse that national
vehicle for verifiable net costs exceeding the ceiling laid down in
paragraph 3.

5. National vehicles shall process personal data in accordance with
Regulation (EU) 2016/679 and only for the purposes of this Regulation.

6. A holder shall have one active registration for payments under this
Regulation. A national vehicle shall coordinate with other designated
vehicles to prevent duplicate payments for the same holder and period.
A transfer between vehicles shall preserve unpaid allocations, their
original period and their treatment under Article 10(4). Registration
shall not create or extinguish the entitlement.

7. A citizen residing outside the Union may register with a vehicle in a
Member State of that citizen's nationality. Where no such vehicle can
provide the service in compliance with paragraph 2, the right of registration laid down in paragraph 4 shall apply correspondingly. Member States of nationality
shall agree responsibility for costs without delaying the holder's access.

8. National vehicles shall provide reasons for a refusal or correction,
a means to correct identity records, and an effective remedy before a court
or tribunal. A pending duplicate check shall preserve the disputed amount
pending resolution and shall not cancel it. Information exchanged shall
be limited to identifying the holder, eligibility, the relevant period and
whether payment or transfer has occurred. It shall not include income,
wealth, employment or unrelated transaction histories.

9. A designated institution shall segregate the assets, liabilities,
accounts and administrative costs of this Regulation from occupational
pension schemes and PEPP products. Its competent supervisory authority
shall supervise that segregation and operational ability. Designation shall
not exempt the institution's other activities from their applicable regime.

10. Before awarding compensation under paragraph 3 or 4, a Member State
shall specify the public-service tasks, duration, calculation parameters,
permitted costs and recovery of overcompensation. It shall comply with
applicable Union State aid rules and any notification and standstill
obligation. Designation as a vehicle shall not itself establish that
compensation is free of aid or compatible with the internal market.

11. National vehicles shall reconcile eligible-day totals and duplicate
registrations using civil-status records lawfully available to them. They
shall submit only the aggregates and pseudonymous settlement identifiers
necessary for calculation, reconciliation and audit to the Reserve.
A provisional calculation shall reserve an expressly identified amount for
unregistered holders and unresolved records. The Reserve shall reconcile
that calculation when verified records become available; a correction shall
apply the same rate to the same eligible days and shall preserve the rights
of affected holders to reasons and review. The Commission shall lay down, by means of implementing acts, technical
specifications for exchange formats, settlement identifiers and security
standards. Those implementing acts shall be adopted in accordance with the
examination procedure referred to in Article 16(2). Those acts shall not
alter the rules on eligibility, accrual, succession or the payment backstop.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/12-protection.md

# Article 12: Protection of the Reserve and of entitlements

1. The assets of the Reserve and the entitlements of holders shall not be
cancelled, written down, compulsorily redeemed, seized, transferred,
suspended, lent, encumbered or otherwise applied, in whole or in part, for
the benefit of the general budget of the Union, of any Member State or of
any public body, by any act of the Union or of a Member State.

2. The Reserve shall not acquire or hold, directly or indirectly, debt
instruments issued or guaranteed by the Union, by a Member State, by a
regional or local authority of a Member State, by a central bank or by any
body the obligations of which are guaranteed by any of them.

3. This Regulation shall not be interpreted as authorising any authority
of the Union or of a Member State to derogate from paragraphs 1 and 2.

4. Every holder, and every national vehicle acting for its holders, shall
have the right to an effective remedy before a court or tribunal against
any act or omission infringing this Article, in accordance with Article 47
of the Charter of Fundamental Rights of the European Union.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/13-penalties.md

# Article 13: Penalties

1. The Commission may by decision impose on a covered undertaking or an
undertaking bound under Article 5(11) or (12) fines not
exceeding 10 % of its total worldwide turnover in the preceding financial
year where it finds that the undertaking, intentionally or negligently:
(a) fails to issue the citizens' capital warrant in accordance with
Article 5(1), (11) or (12);
(b) fails to execute or procure the subscription, or to put in place the
arrangements securing it, in accordance with Article 5(5);
(c) fails to notify an event or crystallisation, or to provide or correct
information required under Article 5(6);
(d) supplies incorrect, incomplete or misleading information under
Article 3(3) or Article 4, or fails to comply with a reasoned information
decision under Article 4(5);
(e) circumvents Article 3(8), or fails to comply with a decision adopted
pursuant to that paragraph.

2. The Commission may by decision impose periodic penalty payments not
exceeding 5 % of the average daily worldwide turnover of the undertaking
concerned in the preceding financial year for each day of continued
non-compliance, in order to compel compliance with the obligations
referred to in paragraph 1.

3. Where an undertaking referred to in paragraph 1 that is not established
in the Union
persistently fails to comply with the obligations referred to in points
(a) and (b) of paragraph 1, the Commission may by decision, as a measure
of last resort and for no longer than the non-compliance persists,
prohibit the making available of the goods and services referred to in
point (a) of Article 3(1) on the internal market by that undertaking.

4. In fixing the amount of a fine or periodic penalty payment, the
Commission shall have regard to the gravity, duration and recurrence of
the infringement. Before adopting a decision under this Article, the
Commission shall give the undertaking the opportunity to be heard.

5. The Court of Justice of the European Union shall have unlimited
jurisdiction within the meaning of Article 261 TFEU to review decisions
under this Article and may cancel, reduce or increase the fine or periodic
penalty payment imposed.

6. Fines and periodic penalty payments imposed under this Article shall
accrue to the general budget of the Union. They shall not accrue to the
Reserve.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/14-monitoring-review.md

# Article 14: Monitoring and evaluation

1. The Commission shall monitor, on the basis of data published by the
   European Central Bank, Eurostat and the national statistical institutes:
   (a) the diffusion of automated cognitive systems among undertakings in
   the Union; (b) the distribution of household holdings of equity
   instruments in the Union; (c) the share of value added accruing to labour
   and to capital in the sectors in which covered undertakings operate; (d)
   the number of designations, crystallisations and distributions under this
   Regulation and their amounts; (e) the evolution of the share of Union
   gross value added accruing to compensation of employees, as published by
   the Commission (Eurostat), relative to the year 2025, together with the
   Commission's assessment of the contribution of automated cognitive
   systems to any change in either direction.

2. By 31 December 2032, and every three years thereafter, the Commission
shall evaluate this Regulation and submit a report to the European
Parliament, the Council and the European Economic and Social Committee.

3. The report shall state, on the basis of the indicators in paragraph 1,
whether the premise of this Regulation that gains from automated cognitive
systems accrue disproportionately to the holders of the systems remains
supported by the evidence. Where the report finds that the share of
undertakings referred to in point (a) of paragraph 1 exceeds one quarter
and that neither the indicator in point (b) nor the indicator in point (c)
of that paragraph shows the concentration the premise predicts, the report
shall say so expressly and shall be accompanied, where appropriate, by a
proposal for the amendment or repeal of this Regulation.

4. Where a report under paragraph 2 accompanies or precedes a proposal for
the amendment of Article 5, Article 8, Article 10 or Article 12, it shall
include an independent assessment of the effect of the proposal on the
entitlements of holders.

5. The report shall be published.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/15-delegation.md

# Article 15: Exercise of the delegation

1. The power to adopt delegated acts is conferred on the Commission subject
to the conditions laid down in this Article.

2. The power to adopt delegated acts referred to in Article 3(9) and
Article 8(8) shall be
conferred on the Commission for a period of five years from the entry into
force of this Regulation. The Commission shall draw up a report in respect
of the delegation of power not later than nine months before the end of
the five-year period. The delegation of power shall be tacitly extended
for periods of an identical duration, unless the European Parliament or
the Council opposes such extension not later than three months before the
end of each period.

3. The delegation of power referred to in Article 3(9) and Article 8(8)
may be revoked at
any time by the European Parliament or by the Council. A decision to
revoke shall put an end to the delegation of the power specified in that
decision. It shall take effect the day following the publication of the
decision in the Official Journal of the European Union or at a later date
specified therein. It shall not affect the validity of any delegated acts
already in force.

4. Before adopting a delegated act, the Commission shall consult experts
designated by each Member State in accordance with the principles laid
down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making.

5. As soon as it adopts a delegated act, the Commission shall notify it
simultaneously to the European Parliament and to the Council.

6. A delegated act adopted pursuant to Article 3(9) or Article 8(8) shall
enter into force
only if no objection has been expressed either by the European Parliament
or by the Council within a period of two months of notification of that
act to the European Parliament and the Council or if, before the expiry of
that period, the European Parliament and the Council have both informed
the Commission that they will not object. That period shall be extended by
two months at the initiative of the European Parliament or of the Council.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/16-committee.md

# Article 16: Committee procedure

1. The Commission shall be assisted by a committee. That committee shall be
a committee within the meaning of Regulation (EU) No 182/2011.

2. Where reference is made to this paragraph, Article 5 of Regulation (EU)
No 182/2011 shall apply.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/17-transitional.md

# Article 17: Transitional provisions

1. An undertaking that meets the thresholds laid down in Article 3(2) on
the date of entry into force of this Regulation shall make the
notification under Article 3(3) within two months of that date.

2. Where the shares of a covered undertaking were admitted to trading
before the entry into force of this Regulation, that admission shall not
constitute a liquidity event. The citizens' capital warrant of such an
undertaking shall crystallise upon the first liquidity event within the
meaning of point (b) or point (c) of Article 2(6) occurring after its
designation, or upon crystallisation under Article 5(3), whichever occurs
first.

3. A liquidity event completed before the date of general application of
this Regulation shall not give rise to any obligation under Article 5.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/articles/18-final.md

# Article 18: Entry into force and application

1. This Regulation shall enter into force on the twentieth day following
that of its publication in the Official Journal of the European Union.

2. It shall apply from [OP: please insert the date 18 months after the
date of entry into force of this Regulation], with the exception of Articles 3, 4, 6(1), 8(1) and (9) to (17), 11(1), (9) and (11), 15 and 16 and
Article 17(1), which shall apply from the date of entry into force for
preparatory administration. A designation decision adopted during that
period shall take effect on the date of general application. The period
under Article 5(3)(b) and the warrant under Article 5(1) shall arise no
earlier than that date. Liquidity events completed before that date shall
not crystallise a warrant. The Commission shall complete the initial
valuation appointment arrangements before that date.

3. This Regulation shall be binding in its entirety and directly applicable
in all Member States.


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/candidate/regulation/recitals.md

# Proposal for a COUNCIL REGULATION

on a common mechanism for citizen participation in the capital value of
hyper-automated undertakings operating in the internal market

THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 352 thereof,

Having regard to the proposal from the European Commission,

[After transmission of the draft legislative act to the national parliaments,]

[Having regard to the consent of the European Parliament,]

Acting in accordance with a special legislative procedure,

Whereas:

(1) Broad participation in capital ownership should support the Union's social market economy. A common mechanism should link the ownership interests of citizens to covered undertakings operating across the internal market, with shared rules for consolidated obligations and portable entitlements. A single Union Reserve should receive those interests for the benefit of holders.

(2) Advances in artificial intelligence and related automation
technologies enable a new category of undertaking: one which attains very
substantial turnover and market value while engaging very little human
labour in production. Such undertakings are lawful, productive and often
beneficial. Their emergence is nevertheless economically unprecedented,
because the mechanisms by which productivity gains have historically been
diffused through the population, above all wages and the broad taxation of
labour income, presuppose that production requires labour at scale.

(3) Where output is substantially decoupled from employment, the gains
from automation accrue by default to a narrow base of shareholders. No
existing instrument of Union law addresses the resulting concentration of
capital ownership. Competition law addresses conduct, not ownership;
Regulation (EU) 2022/1925 addresses the contestability of digital markets;
Regulation (EU) 2024/1689 addresses the safety of artificial intelligence
systems. This Regulation complements those instruments by addressing the
distribution of the ownership of automated production itself.

(4) The mechanism should establish an equity interest participating in the undertaking's performance. Its capital should be segregated for holders and should remain unavailable for discretionary public expenditure. Participation should arise through instruments rather than an annual revenue levy.

(5) This Regulation addresses the distribution of the capital value
created by hyper-automated production and does not purport to regulate
employment, wages, taxation as such, or the internal organisation of
undertakings beyond what the citizens' capital warrant requires. It does
not promise status, purpose, meaning or the other goods that employment
supplies as a by-product, and nothing in this Regulation, and no material
presenting it, should be read as making such a promise. Its object is
narrower and more precise than that: a broadly held equity stake in the
value that automation creates, and nothing beyond it. That object is
stated in Article 1 with its scale: an ownership position for each
citizen measured against a published statistic of Union living
standards, reached within a generation, so that the necessity of the
percentage laid down in Article 5 can be assessed against a stated
objective and revisited on the evidence. The stake is the objective;
distributions remain the property income that follows from ownership
and are not the purpose of the obligation.

(6) Designation should use a rebuttable group-consolidated presumption and a reasoned investigation where necessary. Genuine labour remuneration and evidenced value changes should remain recognised. The warrant should attach at effective designation and use the whole capital at the statutory event, including value accumulated earlier, to establish the proposed common ownership interest.

(7) The quantitative thresholds should capture only undertakings of very
substantial scale whose market valuation stands in a proportion to their
expenditure on human labour that has no precedent among labour-intensive
undertakings. Compensation of labour is the appropriate measure of the
labour actually engaged, because it is recorded in audited accounts and
cannot be increased without genuine payment for genuine work, so that an
undertaking reduces its decoupling ratio only by remunerating labour,
which is consistent with the objectives of this Regulation. The ratio
laid down in this Regulation is fixed in its own terms, so that an
undertaking can establish its position from audited remuneration and turnover records together with
the valuation evidence specified in Annex I: it exceeds by a margin of more than double the highest ratios
observed among capital-intensive undertakings whose value remains
explained by their expenditure on labour, and by an order of magnitude
the prevailing ratio among large undertakings admitted to trading in the
Union. That ratio should be reviewed under Article 14. For the same
reasons the thresholds should be assessed at the level of the group of linked enterprises, the single
economic unit to which the value of the automated services accrues.

(8) Designation should follow a notification by the undertaking itself
within a fixed period, with a decision of the Commission within a fixed
period thereafter. Arguments against the presumption should be taken into
account only where they manifestly call it into question, and arguments
based on the definition of the relevant market should not be taken into
account, since designation does not depend on a finding of market power.
Where a designation is repealed, a warrant not yet crystallised should
lapse after five years, ensuring legal certainty for the undertaking while
preserving for a reasonable period the rights acquired by the Reserve.
Reasoned information requests should support investigation and verification,
with protection of privilege, confidentiality and the right to be heard.
Issuers should maintain accessible records and make reasonable enquiries
without being held strictly liable for inaccessible trading information.

(9) The warrant should provide a single bounded economic participation per designation, without votes or management powers. The decision should identify the legal issuers and any holding entity expressly so that the obligation has an enforceable addressee. Outside minority interests and overlapping ownership should be reconciled to limit the combined interference.

(10) The claim should arise at effective designation independently of its documentation. Subscription should follow the first qualifying liquidity, extraction or elapsed-time event. The original seven-year clock should continue through bound transfers. Ordinary exchange transactions should count toward the transfer threshold, with a daily closing-time valuation to provide a determinate calculation point. Reporting duties should support those events and completed pre-application events should be excluded.

(11) Shareholder extraction should provide an additional trigger where distributions to owners exceed the statutory threshold. It should not be assumed that every other liquidity event involves a cash receipt by every shareholder. The triggers should identify observable statutory events rather than depend on a claim that all owners have realised gains.

(12) The seven-year long-stop answers a case the liquidity-event and
extraction triggers do not reach: an undertaking that remains privately
held indefinitely, keeps its distributions to shareholders below the
extraction threshold, and so never crystallises the warrant at all, while
its value continues nonetheless to accrue for the benefit of those
shareholders. Absent a long-stop, such an undertaking could defeat the
objective of this Regulation by the simple expedient of staying private
and patient. The long-stop is the answer to that possibility, and it is
proportionate under Article 52(1) of the Charter of Fundamental Rights of
the European Union: it is quantified in years rather than left to
discretion, it is known to the undertaking from the moment of its
designation, and it is subject to the same independent valuation and the
same separate right of challenge before the courts that apply to
crystallisation at a liquidity event.

(13) The warrant should be incapable of settlement in cash. It confers an
entitlement to shares and to nothing else. It is accordingly not a levy,
not a charge on turnover or profit and not revenue of any public
authority, and it is so designed that no payment obligation towards any
budget can arise from it. In excluding settlement in money, the
prohibition restricts the freedom of the undertaking to structure the
discharge of its obligation; that restriction is justified and
proportionate, because it confines the interference to capital ownership
and keeps the undertaking's operating liquidity untouched, which a cash
alternative would not.

(14) The worldwide-value alternative to Union turnover should apply together with the multi-country activity condition. For third-country issuers the subscription should be an obligation to procure an equivalent result, without overriding foreign company law. Proportionate enforcement should support equal application to undertakings serving the internal market.

(15) Company-law derogations should be confined to the specific requirements that would otherwise prevent the statutory subscription. The participation provision in Article 84 of Directive (EU) 2017/1132 should inform that assessment without being treated as a Treaty power or as authority for this particular compulsory design. Capital-reduction safeguards should not be disapplied merely because the instrument issues new shares.

(16) The directed statutory subscription should be distinguished from an offer to the public. Admission of a new share class and subsequent public offers should remain subject to the Prospectus Regulation and its own exemptions. The Reserve's class should not be required to be listed as a condition of subscription. Pension and PEPP institutions acting as national vehicles should segregate this scheme from their existing products.

(17) The obligations laid down in this Regulation would be of little
value if they could be routed around by an arrangement that subordinates
the Reserve's participation, by moving the automated assets on which a
covered undertaking's designation rests into another entity, or by the
extinguishment of the warrant in an insolvency or restructuring procedure
engineered or exploited by the same persons who controlled the covered
undertaking. An arrangement that subordinates, reduces or defeats the
Reserve's participation should accordingly be ineffective as against the
Reserve, while remaining effective between the parties to it and as
against third parties, so that anti-avoidance is achieved without
unwinding transactions to which the Reserve was not a party. Where a
covered undertaking transfers its automated assets to another undertaking
otherwise than at arm's length, or to a member of its own group or a
person who controls it or is controlled by it, the obligations laid down
in this Regulation should attach to the transferee as if it were the
covered undertaking, so that the assets which carry the value cannot be
moved beyond the warrant's reach while the covered undertaking that
issued it remains bound in respect of what it retains. Anti-avoidance
should not become a multiplier: a group that divides its automated assets
among several entities should owe the same share of its capital as one
that does not, and the stated percentage should therefore apply to the
dilution borne by the shareholders of the covered undertaking and of every
transferee taken together, and not separately to each of them. Where those assets are instead
acquired in an insolvency or restructuring procedure and control of the
transferee ends up, directly or indirectly, with the persons who
controlled the covered undertaking, or with persons acting in concert or
connected with them, the same obligations should reattach to the
transferee, because no genuine change of ownership has in substance
occurred. That reattachment should not extend to a transferee controlled
by persons who did not control the covered undertaking: a genuine sale to
unconnected purchasers in insolvency or restructuring is the ordinary
operation of that law, not an avoidance of this Regulation, and should be
left to run its course without the obligations of this Regulation
attaching to it.

(18) The mandatory warrant and resulting equity dilution interfere with
the right to property under Article 17 of the Charter and the freedom to
conduct a business under Article 16 thereof. The limited non-controlling
participation should serve broad citizen ownership while leaving operating
control with existing shareholders. In accordance with Article 52(1) of the
Charter, that interference should be provided for by law, respect the essence
of those rights and be necessary and proportionate to an objective of general
interest. The statutory cap, prospective attachment and separately reviewable
execution should support that fair balance. The requirements applicable to
a deprivation of possessions under Article 17 should remain unaffected.

(19) The independent valuation and correction procedure should ensure that execution does not exceed the stated percentage. Separate access to a court should enable the issuer and affected shareholders to challenge that calculation without holding up the underlying transaction. Effective judicial protection should operate within the jurisdiction established by the Treaties.

(20) Where a liquidity event itself establishes a price, a valuation
delivered in advance of the event would be conjecture about a number the
event is about to produce. The independent valuation should therefore be
delivered promptly after completion, while the legal effect of the
subscription attaches at completion and its execution follows delivery of
the valuation.

(21) The Reserve should hold capital exclusively for holders through segregated custody, independent governance, an accountable executive and audited accounts. Published financial rules, costed cash plans and contract terms should support continuity of custody and payments. Taxes required by applicable law and charges for actual services should be distinguished from diversion to a public budget.

(22) Income from holdings in undertakings governed by the law of a third
country may be taxed at source in that country at rates which the Reserve,
being resident in no State, may be unable to reduce by treaty. The remedy, where there is one, lies in
international agreements, which are concluded in accordance with the
procedures laid down in the Treaties and which this Regulation neither
prejudges nor requires. This Regulation does not direct the Reserve to
arrange its holdings so as to reduce taxation in a third country; an
instrument founded on the proposition that capital should be broadly owned
is in no position to legislate its own treaty shopping. What this
Regulation can do, and does, is oblige the Reserve to report each year the
amount it was unable to recover, so that the cost is known rather than
assumed away.

(23) The Reserve should exercise no votes,
seek no influence over the management of any undertaking and pursue no
industrial policy. Its function is to hold and to distribute, not to
direct. The mandatory presence of the Reserve in the capital of covered
undertakings restricts the free movement of capital. That restriction is
justified: it serves the general interest set out in these recitals, it
applies without distinction to undertakings and investors of the Union
and of third countries, and it is proportionate precisely because the
statutory passivity of the Reserve withholds from it every attribute of
special control that has led the Court of Justice to censure public
shareholdings. A holding which can neither vote nor veto nor instruct
exerts no public influence for an investor to fear.

(24) Capital preservation should precede new allocations. Losses should be recognised immediately and an unrecovered shortfall carried forward without being concealed by new subscriptions. Cash already allocated to holders should be reserved separately and should not incur a second retention. Income, unrealised appreciation, borrowing and payments should remain distinct in the accounts.

(25) Every adult Union citizen should acquire the personal entitlement by operation of law. The same daily allocation rate should apply to the same eligible days, irrespective of income, work, residence or registration. Monetary accrual for those days should survive death and late registration, while the personal entitlement should not be transferable or redeemable.

(26) The entitlement should be personal. It should be incapable of
transfer, assignment, pledge, attachment, surrender or redemption, so that
it cannot be bought out of the hands of those it serves, whether by
markets, by creditors or by the holder's own moment of hardship. That
restriction on the alienability of the entitlement is a justified and
proportionate limitation under Article 52(1) of the Charter and respects
the essence of the right, since it attaches to the underlying entitlement
only, while amounts distributed are the holder's property, freely usable
and inheritable, and it is necessary so that the objective of durable,
broadly held capital ownership is not defeated by immediate liquidation.

(27) National vehicles should reuse existing infrastructure, segregate this scheme from pension and PEPP products and coordinate a single payment registration, including for citizens abroad. Verification should preserve disputed claims and provide reasons and remedies. Defined tasks, cost parameters and recovery of overcompensation should support compliance with applicable State aid rules.

(28) The history of pooled public assets is a history of raids. The assets
of the Reserve should therefore be protected by enumerated prohibitions on
lending, guarantee, transfer and encumbrance in favour of public
authorities, and the Reserve should not acquire sovereign debt, so that it
cannot become a captive purchaser of the obligations of any government.
The exclusion of sovereign debt is a rule of portfolio governance internal
to the Reserve, securing its independence, and restricts no movement of
capital by any other person. An
ordinary regulation cannot bind future legislatures, and this Regulation
does not pretend otherwise; what it can do is ensure that no derogation
from these protections arises by interpretation, and that any future
weakening would need to be enacted expressly, in public, informed by the
independent assessment its reporting provisions require.

(29) Penalties should be effective, proportionate and dissuasive. Fault,
the gravity and duration of non-compliance and the right to be heard should
be considered. Market exclusion should remain a last resort and fines
should accrue to the Union budget rather than the Reserve.

(30) The premise of this Regulation, that automation at the designated
scale durably decouples output from labour and concentrates ownership, is
an empirical claim, and empirical claims can prove wrong. The Commission
should monitor adoption, employment effects and ownership concentration,
and where the evidence does not support the premise, should state so
expressly and propose amendment or repeal. A regulation founded on a
falsifiable claim should carry its own test. The same monitoring should
extend to the share of value added accruing to labour in the Union as a
whole, in both directions: where that share declines, the evidence
informs the assessment under Article 1 of whether the participation
secured remains adequate to its objective, and where it does not
decline, the same assessment asks whether the obligations imposed remain
justified at their level, so that the indicator moves no obligation of
any undertaking but disciplines the instrument itself.

(31) In order to keep the methodologies for counting turnover, employment
and value and the technical valuation and inflation-conversion methods
of Annex II aligned with technological and market
developments, the power to adopt acts in accordance with Article 290 of
the Treaty on the Functioning of the European Union should be delegated to
the Commission in respect of amendments to Annexes I and II. The essential
elements of this Regulation, including the designation criteria, the
percentage and terms of the warrant, the entitlement and its protections,
are laid down in the enacting terms and are not subject to delegation. It
is of particular importance that the Commission carry out appropriate
consultations during its preparatory work, including at expert level, and
that those consultations be conducted in accordance with the principles
laid down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making. In particular, to ensure equal participation in the
preparation of delegated acts, the European Parliament and the Council
receive all documents at the same time as Member States' experts, and
their experts systematically have access to meetings of Commission expert
groups dealing with the preparation of delegated acts.
Essential allocation priorities, immediate loss recognition, the numerical
collar, entitlement periods and payment backstops should remain outside
that delegation.

(32) In order to ensure uniform conditions for the implementation of this
Regulation as regards the list and appointment criteria for independent
valuers and technical settlement formats and security standards, implementing
powers should be conferred on the Commission. Those powers should be
exercised in accordance with Regulation (EU) No 182/2011 of the European
Parliament and of the Council. Individual appointments and information
requests should remain reasoned administrative decisions.

(33) Personal-data processing by national vehicles should be governed by
Regulation (EU) 2016/679 and processing by the Reserve by Regulation (EU)
2018/1725. Only information necessary for entitlement, payment and audit
should be processed. The European Data Protection Supervisor should be
consulted under Article 42 of Regulation (EU) 2018/1725 during preparation
of a Commission proposal.

(34) Since the objective of common citizen participation in consolidated
undertakings across the Union cannot be sufficiently achieved by Member
States acting separately, whose individual schemes cannot establish a
single Union-wide claim or a common consolidated obligation, but can rather,
by reason of that cross-border scale and the portability of citizen claims,
be better achieved at Union level, the Union may adopt measures in accordance
with the principle of subsidiarity as set out in Article 5 of the Treaty on
European Union. In accordance with the principle of proportionality as set
out in that Article, this Regulation should not go beyond what is necessary
to achieve that objective. The warrant, the protection of holders and the
independent valuation and review arrangements should be assessed together
against that requirement.

(35) This Regulation respects the fundamental rights and observes the
principles recognised by the Charter of Fundamental Rights of the European
Union, in particular Articles 16, 17, 20, 34 and 47 thereof, concerning
respectively the freedom to conduct a business, the right to property,
equality before the law, social security and social assistance, and the
right to an effective remedy and to a fair trial.

(36) Substantive obligations should apply after an 18-month preparatory period. The Reserve's governing bodies, custody arrangements, information powers and national settlement arrangements should be prepared in advance. Early designation should take effect only at general application and should not capture completed earlier events. Operational difficulties should be disclosed without cancelling statutory claims,

HAS ADOPTED THIS REGULATION:


# SOURCE: own-the-machine/proposals/2026-09-07-substantive-closure/stress-scenarios.json

{
  "status": "Illustrative sensitivity only; no calibrated forecast or minimum-necessary percentage established",
  "assumptions": {
    "horizon_years": 30,
    "initial_company_value_eur": "10000000000000",
    "new_distinct_company_value_each_year_eur_year0": "500000000000",
    "holders": 350000000,
    "cash_yield": ".01",
    "real_price_growth": ".03",
    "inflation": ".02",
    "annual_cost_fraction": ".001",
    "nominal_subscription_amount": "0",
    "timing": "year-end contributions; no repeated warrant on an existing company",
    "median_income_target": "not supplied; no sufficiency verdict"
  },
  "rows": [
    {
      "scenario": "base_assumption",
      "warrant_percent": "0.5",
      "year": 30,
      "real_stake_per_holder": "683.1603776127591901985235258",
      "real_payout_per_holder": "5.791431099993742111478927063",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "base_assumption",
      "warrant_percent": "1",
      "year": 30,
      "real_stake_per_holder": "1359.556791090738586434685437",
      "real_payout_per_holder": "11.52552129800734816244816181",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "base_assumption",
      "warrant_percent": "2",
      "year": 30,
      "real_stake_per_holder": "2692.455605885580337841239792",
      "real_payout_per_holder": "22.82505198232827773347577148",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "base_assumption",
      "warrant_percent": "2.5",
      "year": 30,
      "real_stake_per_holder": "3349.152095125965786095200703",
      "real_payout_per_holder": "28.39213783167663815627474003",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "base_assumption",
      "warrant_percent": "3",
      "year": 30,
      "real_stake_per_holder": "3999.472890296056229997181427",
      "real_payout_per_holder": "33.90517430384685915749313618",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "base_assumption",
      "warrant_percent": "4",
      "year": 30,
      "real_stake_per_holder": "5281.355226929407585765508807",
      "real_payout_per_holder": "44.77221734995162170797170547",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "base_assumption",
      "warrant_percent": "5",
      "year": 30,
      "real_stake_per_holder": "6538.820757150695106185868041",
      "real_payout_per_holder": "55.43226909994010306701258765",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "0.5",
      "year": 30,
      "real_stake_per_holder": "674.4188140179027991445312989",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "1",
      "year": 30,
      "real_stake_per_holder": "1342.160214035628342851988031",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "2",
      "year": 30,
      "real_stake_per_holder": "2658.003561129381620157858645",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "2.5",
      "year": 30,
      "real_stake_per_holder": "3306.297112624352747025629041",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "3",
      "year": 30,
      "real_stake_per_holder": "3948.296551968887261011188085",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "4",
      "year": 30,
      "real_stake_per_holder": "5213.776216061479331848107355",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "no_cash_income",
      "warrant_percent": "5",
      "year": 30,
      "real_stake_per_holder": "6455.151505599926791811942437",
      "real_payout_per_holder": "0E+27",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 31
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "0.5",
      "year": 30,
      "real_stake_per_holder": "355.3660270078180525941719982",
      "real_payout_per_holder": "3.072870939420544337137840160",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "1",
      "year": 30,
      "real_stake_per_holder": "707.2135785007072135785007100",
      "real_payout_per_holder": "6.115317414094350611531741295",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "2",
      "year": 30,
      "real_stake_per_holder": "1400.560224089635854341736697",
      "real_payout_per_holder": "12.11072664359861591695501732",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "2.5",
      "year": 30,
      "real_stake_per_holder": "1742.160278745644599303135893",
      "real_payout_per_holder": "15.06456241032998565279770447",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "3",
      "year": 30,
      "real_stake_per_holder": "2080.443828016643550624133151",
      "real_payout_per_holder": "17.98972015990862364363221018",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "4",
      "year": 30,
      "real_stake_per_holder": "2747.252747252747252747252752",
      "real_payout_per_holder": "23.75565610859728506787330220",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "lower_growth",
      "warrant_percent": "5",
      "year": 30,
      "real_stake_per_holder": "3401.360544217687074829931982",
      "real_payout_per_holder": "29.41176470588235294117647068",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 1
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "0.5",
      "year": 30,
      "real_stake_per_holder": "497.1668214035212031269674840",
      "real_payout_per_holder": "4.206605938183405392077656631",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "1",
      "year": 30,
      "real_stake_per_holder": "989.4111990307699190942620241",
      "real_payout_per_holder": "8.371562312622420631758504792",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "2",
      "year": 30,
      "real_stake_per_holder": "1959.422178472701212323930672",
      "real_payout_per_holder": "16.57897634460518595701194084",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "2.5",
      "year": 30,
      "real_stake_per_holder": "2437.330026880677117768791808",
      "real_payout_per_holder": "20.62262911158206058067338981",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "3",
      "year": 30,
      "real_stake_per_holder": "2910.597993265274616364673723",
      "real_payout_per_holder": "24.62702311383100438274589274",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "4",
      "year": 30,
      "real_stake_per_holder": "3843.481965465683147250787093",
      "real_payout_per_holder": "32.52029975287940322336957629",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    },
    {
      "scenario": "loss_in_year_10",
      "warrant_percent": "5",
      "year": 30,
      "real_stake_per_holder": "4758.596719147988658500974490",
      "real_payout_per_holder": "40.26322826546973732417185631",
      "preservation_shortfall": "0E+27",
      "years_without_payment": 13
    }
  ]
}


# SOURCE: own-the-machine-tools/reference/entitlements.py

"""Exact candidate holder-day accounting; synthetic identifiers, not an ID system.

Intervals are half-open [start, end). Eligibility data must already be verified.
This models equal accrual and payment idempotency, not civil-registry discovery,
fraud detection, succession verification or a production payment connector.
"""
from dataclasses import dataclass, field
from datetime import date
from fractions import Fraction


def eligible_days(year, intervals):
    start, end = date(year, 1, 1), date(year + 1, 1, 1)
    clipped = []
    for a, b in intervals:
        if not isinstance(a, date) or not isinstance(b, date) or b < a:
            raise ValueError('Invalid eligibility interval')
        a, b = max(start, a), min(end, b)
        if a < b:
            clipped.append((a, b))
    merged = []
    for a, b in sorted(clipped):
        if merged and a <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(b, merged[-1][1]))
        else:
            merged.append((a, b))
    return sum((b - a).days for a, b in merged)


def allocate(year, amount, records):
    amount = Fraction(amount)
    if amount < 0:
        raise ValueError('Negative allocation')
    days = {holder: eligible_days(year, intervals) for holder, intervals in records.items()}
    total = sum(days.values())
    if not total:
        if amount:
            raise ValueError('Cannot allocate positive income without eligible days')
        return {holder: Fraction(0) for holder in days}
    return {holder: amount * count / total for holder, count in days.items()}


@dataclass
class Ledger:
    claims: dict = field(default_factory=dict)
    vehicles: dict = field(default_factory=dict)
    allocations: dict = field(default_factory=dict)
    payments: dict = field(default_factory=dict)
    allocated: Fraction = Fraction(0)
    paid: Fraction = Fraction(0)

    def post(self, year, amount, records):
        result = allocate(year, amount, records)
        if year in self.allocations:
            if self.allocations[year] != result:
                raise ValueError('Correcting a posted year requires explicit reconciliation')
            return
        self.allocations[year] = result.copy()
        for holder, claim in result.items():
            self.claims[holder] = self.claims.get(holder, Fraction(0)) + claim
        self.allocated += sum(result.values(), Fraction(0))
        self.validate()

    def register(self, holder, vehicle):
        if not holder or not vehicle:
            raise ValueError('Holder and vehicle required')
        self.vehicles[holder] = vehicle  # one active vehicle; claims remain unchanged

    def pay(self, holder, request_id):
        if request_id in self.payments:
            previous = self.payments[request_id]
            if previous[0] != holder:
                raise ValueError('Payment ID reused for another holder')
            return previous[2]
        if holder not in self.vehicles:
            raise ValueError('Payment instructions missing; claim remains reserved')
        claim = self.claims.get(holder, Fraction(0))
        amount = Fraction((claim * 100).__floor__(), 100)
        self.claims[holder] = claim - amount
        self.payments[request_id] = (holder, self.vehicles[holder], amount)
        self.paid += amount
        self.validate()
        return amount

    def validate(self):
        assert all(v >= 0 for v in self.claims.values())
        assert sum(self.claims.values(), Fraction(0)) + self.paid == self.allocated


# SOURCE: own-the-machine-tools/reference/reserve.py

"""Conservative candidate cash ledger, NOT an implementation of current Annex II.

All monetary inputs are Decimal-compatible strings. No network or dependencies.
A scalar holder count is used for scenarios; identity/period allocation is outside
this model. See the law repository's accounting-candidate.md for policy choices.
"""
from dataclasses import dataclass, field, asdict
from decimal import Decimal as D
import json

ZERO = D(0)
def dec(x):
    value = D(str(x))
    if not value.is_finite():
        raise ValueError('Inputs must be finite')
    return value

@dataclass
class State:
    assets: D = D(0)
    cash: D = D(0)
    debt: D = D(0)
    costs_due: D = D(0)
    protected: D = D(0)
    deferred: D = D(0)
    positive_years: int = 0
    history: list = field(default_factory=list)

    def validate(self):
        for k in ('assets', 'cash', 'debt', 'costs_due', 'protected', 'deferred'):
            v = getattr(self, k)
            if not isinstance(v, D) or not v.is_finite() or v < 0:
                raise ValueError(f'Invalid state: {k}')
        if self.cash > self.assets or self.deferred > self.cash:
            raise ValueError('Cash and deferred allocations must be fully backed')
        if self.positive_years < 0 or any(dec(v) < 0 for v in self.history):
            raise ValueError('Invalid distribution history')


def step(s, *, income='0', fair_change='0', costs='0', inflation='0',
         new_shares='0', nominal='0', holders=100, payment_cost='0.1'):
    """One year. Subscription borrowing is explicit in the returned ledger.

    New holdings arrive at year-end for this prototype; contribution inflation
    timing is therefore zero. Losses are recognised immediately, deliberately
    more conservative than current Annex II's five-year recognition.
    """
    s.validate()
    inc, change, expense, inf, shares, par, fee = map(dec,
        (income, fair_change, costs, inflation, new_shares, nominal, payment_cost))
    if min(inc, expense, shares, par, fee) < 0 or inf <= -1:
        raise ValueError('Invalid flow or inflation')
    if not isinstance(holders, int) or isinstance(holders, bool) or holders <= 0:
        raise ValueError('holders must be a positive integer')
    if par > shares:
        raise ValueError('This prototype excludes subscriptions above fair value')
    # Deferred allocations are cash reserved for holders, never subscription cash.
    borrowed = max(ZERO, par - (s.cash - s.deferred))
    debt_paid = min(s.debt + borrowed, inc)
    cost_paid = min(s.costs_due + expense, inc - debt_paid)
    debt = s.debt + borrowed - debt_paid
    costs_due = s.costs_due + expense - cost_paid
    assets = s.assets + shares + borrowed + inc + change - par - debt_paid - cost_paid
    cash = s.cash + borrowed + inc - par - debt_paid - cost_paid
    if assets < cash:
        raise ValueError('Valuation loss exceeds non-cash assets')
    target = s.protected * (1 + inf) + shares - par
    unallocated = assets - debt - costs_due - s.deferred
    shortfall = max(ZERO, target - unallocated)
    free_income = inc - debt_paid - cost_paid
    prior = [dec(v) for v in s.history[-3:]]
    avg = sum(prior, ZERO) / len(prior) if prior else ZERO
    collar = max(D('1.25') * avg, D('.02') * max(ZERO, unallocated))
    allocation = min(free_income, max(ZERO, unallocated - target), collar)
    deferred = s.deferred + allocation
    positive = s.positive_years + int(allocation > 0)
    payout = deferred if deferred > 0 and (
        deferred / holders >= 10 * fee or positive >= 3) else ZERO
    end = State(assets=assets-payout, cash=cash-payout, debt=debt,
                costs_due=costs_due, protected=max(target, unallocated-allocation),
                deferred=deferred-payout, positive_years=0 if payout else positive,
                history=[*s.history[-2:], allocation])
    end.validate()
    # Independent balance identities, including debt-funded nominal payment.
    assert end.assets == s.assets + shares + borrowed + inc + change - par - debt_paid - cost_paid - payout
    assert end.cash == s.cash + borrowed + inc - par - debt_paid - cost_paid - payout
    assert end.deferred == s.deferred + allocation - payout
    return end, dict(income=inc, fair_change=change, borrowed=borrowed,
                    debt_paid=debt_paid, costs_paid=cost_paid,
                    protected_target=target, preservation_shortfall=shortfall,
                    new_allocation=allocation, payout=payout,
                    payout_per_holder=payout/holders,
                    net_stake_per_holder=(end.assets-end.debt-end.costs_due)/holders,
                    closing=asdict(end))


def scenarios():
    examples = []
    for name, state, inputs in [
        ('Appreciation without cash income', State(D(1000), D(20), protected=D(1000)), dict(fair_change='100')),
        ('Income, costs and capital preservation', State(D(1000), D(20), protected=D(1000)), dict(income='50', costs='2', inflation='.02')),
        ('Costs exceed income', State(D(1000), D(20), protected=D(1000)), dict(income='1', costs='2')),
        ('First subscription financed by borrowing', State(), dict(new_shares='1000', nominal='10')),
        ('Fresh capital does not erase an old loss', State(D(80), D(10), protected=D(100)), dict(new_shares='100', income='5')),
    ]:
        _, result = step(state, **inputs)
        examples.append(dict(scenario=name, assumptions=inputs, result=result))
    return {'status':'Candidate accounting policy; illustrative units, not a forecast',
            'scenarios':examples}

if __name__ == '__main__':
    print(json.dumps(scenarios(), default=str, indent=2))


# SOURCE: own-the-machine-tools/reference/stress.py

"""Hypothetical 30-year capital sensitivity, not a current-company forecast.

Uses the candidate reserve ledger, year-end contributions and exact p/(1+p)
share fraction with zero nominal amount as a simplifying disclosed assumption.
All monetary parameters are assumptions in euros of year 0, not sourced facts.
"""
from decimal import Decimal as D
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from reserve import State, step


def run(percent, *, cash_yield='.01', real_growth='.03', inflation='.02',
        initial_company_value='10000000000000', annual_new_company_value='500000000000',
        holders=350000000, cost_rate='.001', crash_year=None):
    p=D(str(percent))/100;fraction=p/(1+p)
    state=State(); price_index=D(1); values=[]
    for year in range(31):
        opening=state.assets
        company_value=D(initial_company_value) if year==0 else D(annual_new_company_value)*price_index
        nominal_growth=(1+D(real_growth))*(1+D(inflation))-1
        noncash=state.assets-state.cash
        change=noncash*(D('-.4') if year==crash_year else nominal_growth)
        state,row=step(state,income=opening*D(cash_yield), fair_change=change,
            costs=opening*D(cost_rate),inflation=inflation if year else '0',
            new_shares=company_value*fraction,holders=holders,payment_cost='.1')
        values.append({'year':year,'real_stake_per_holder':row['net_stake_per_holder']/price_index,
            'real_payout_per_holder':row['payout_per_holder']/price_index,
            'preservation_shortfall':row['preservation_shortfall']/price_index})
        price_index*=1+D(inflation)
    return values


def report():
    scenarios={'base_assumption':{},'no_cash_income':{'cash_yield':'0'},
      'lower_growth':{'real_growth':'0'},'loss_in_year_10':{'crash_year':10}}
    rows=[]
    for name,args in scenarios.items():
        for pct in ['0.5','1','2','2.5','3','4','5']:
            years=run(pct,**args);rows.append({'scenario':name,'warrant_percent':pct,
                **years[-1],'years_without_payment':sum(x['real_payout_per_holder']==0 for x in years)})
    return {'status':'Illustrative sensitivity only; no calibrated forecast or minimum-necessary percentage established',
      'assumptions':{'horizon_years':30,'initial_company_value_eur':'10000000000000',
      'new_distinct_company_value_each_year_eur_year0':'500000000000',
      'holders':350000000,'cash_yield':'.01','real_price_growth':'.03','inflation':'.02',
      'annual_cost_fraction':'.001','nominal_subscription_amount':'0',
      'timing':'year-end contributions; no repeated warrant on an existing company',
      'median_income_target':'not supplied; no sufficiency verdict'},'rows':rows}

if __name__=='__main__':print(json.dumps(report(),default=str,indent=2))


# SOURCE: own-the-machine-tools/reference/test_entitlements.py

import unittest
from datetime import date as d
from fractions import Fraction as F
from entitlements import eligible_days, allocate, Ledger

class EntitlementTests(unittest.TestCase):
    def test_duplicate_and_transfer_records_do_not_duplicate_days(self):
        self.assertEqual(eligible_days(2028, [(d(2028,1,1),d(2029,1,1)),(d(2028,7,1),d(2029,1,1))]),366)
    def test_birthday_and_death_same_rate(self):
        records={'adult':[(d(2027,1,1),d(2028,1,1))], 'new18':[(d(2027,7,1),d(2028,1,1))], 'deceased':[(d(2027,1,1),d(2027,7,1))]}
        out=allocate(2027,'730',records)
        self.assertEqual(out,{'adult':F(365),'new18':F(184),'deceased':F(181)})
    def test_late_registration_and_transfer_preserve_claim(self):
        x=Ledger();x.post(2027,'10',{'a':[(d(2027,1,1),d(2028,1,1))]})
        with self.assertRaises(ValueError):x.pay('a','p1')
        self.assertEqual(x.claims['a'],10)
        x.register('a','BE');x.register('a','FR');self.assertEqual(x.pay('a','p1'),10)
        self.assertEqual(x.payments['p1'][1],'FR')
    def test_payment_retry_does_not_pay_twice(self):
        x=Ledger();x.post(2027,'1',{'a':[(d(2027,1,1),d(2028,1,1))]});x.register('a','BE')
        self.assertEqual(x.pay('a','p1'),1);self.assertEqual(x.pay('a','p1'),1);self.assertEqual(x.paid,1)
        with self.assertRaises(ValueError):x.pay('b','p1')
    def test_fractional_cents_survive_repeated_rounds(self):
        x=Ledger();records={n:[(d(2027,1,1),d(2028,1,1))] for n in ['a','b','c']};x.post(2027,'1',records)
        for n in records:x.register(n,'BE');x.pay(n,n)
        self.assertEqual(x.paid,F(99,100));self.assertEqual(sum(x.claims.values()),F(1,100));x.validate()
    def test_reposting_is_idempotent_but_correction_is_not_silent(self):
        x=Ledger();r={'a':[(d(2027,1,1),d(2028,1,1))]};x.post(2027,'1',r);x.post(2027,'1',r);self.assertEqual(x.allocated,1)
        with self.assertRaises(ValueError):x.post(2027,'2',r)
    def test_citizenship_gap_not_paid(self):
        self.assertEqual(eligible_days(2027,[(d(2027,1,1),d(2027,2,1)),(d(2027,12,1),d(2028,1,1))]),62)
    def test_invalid_and_empty_denominators(self):
        self.assertEqual(allocate(2027,'0',{}),{})
        with self.assertRaises(ValueError):allocate(2027,'1',{})
        with self.assertRaises(ValueError):eligible_days(2027,[(d(2028,1,1),d(2027,1,1))])

if __name__=='__main__': unittest.main()


# SOURCE: own-the-machine-tools/reference/test_reserve.py

import unittest
from decimal import Decimal as D
from reserve import State, step

class ReserveTests(unittest.TestCase):
    def base(self): return State(D(1000), D(20), protected=D(1000))
    def test_appreciation_is_not_cash(self):
        end,r=step(self.base(),fair_change=100)
        self.assertEqual(r['payout'],0); self.assertEqual(end.assets,1100)
    def test_full_loss_recovery_before_allocation(self):
        end,r=step(self.base(),fair_change=-100,income=20)
        self.assertEqual(r['new_allocation'],0); self.assertEqual(r['preservation_shortfall'],80)
        self.assertEqual(end.protected,1000)
    def test_new_contribution_cannot_mask_loss(self):
        end,r=step(State(D(80),D(10),protected=D(100)),new_shares=100,income=5)
        self.assertEqual(r['preservation_shortfall'],15); self.assertEqual(r['new_allocation'],0)
    def test_cost_deficit_has_floor_and_liability(self):
        end,r=step(self.base(),income=1,costs=2)
        self.assertEqual(end.costs_due,1); self.assertEqual(r['new_allocation'],0)
    def test_debt_has_first_claim_on_new_income(self):
        s=State(D(1000),D(20),debt=D(10),protected=D(990))
        end,r=step(s,income=5,costs=2)
        self.assertEqual(end.debt,5); self.assertEqual(end.costs_due,2)
        self.assertEqual(r['new_allocation'],0)
    def test_subscription_financing_conserves_net_capital(self):
        end,r=step(State(),new_shares=1000,nominal=10)
        self.assertEqual(end.assets,1000); self.assertEqual(end.debt,10)
        self.assertEqual(end.protected,990); self.assertEqual(end.cash,0)
    def test_deferred_cash_not_used_for_subscription(self):
        s=State(D(1000),D(10),protected=D(990),deferred=D(10))
        end,r=step(s,new_shares=100,nominal=5,payment_cost=100)
        self.assertEqual(r['borrowed'],5); self.assertEqual(end.deferred,10)
    def test_three_positive_years_pay_deferred_once(self):
        s=self.base(); total=D(0)
        for year in range(3):
            s,r=step(s,income=10,payment_cost=100)
            total+=r['new_allocation']
            self.assertEqual(r['payout'],total if year==2 else 0)
        self.assertEqual(s.deferred,0)
        s,r=step(s,payment_cost=100); self.assertEqual(r['payout'],0)
    def test_zero_years_do_not_increment_positive_clock(self):
        s,r=step(self.base(),income=10,payment_cost=100)
        s,r=step(s,payment_cost=100)
        self.assertEqual(s.positive_years,1); self.assertEqual(s.deferred,10)
    def test_no_duplicate_charge_to_deferred_allocation(self):
        s=State(D(1010),D(10),protected=D(1000),deferred=D(10),positive_years=2)
        end,r=step(s,income=1,payment_cost=100)
        self.assertEqual(r['payout'],11); self.assertEqual(end.assets,1000)
    def test_inflation_preservation(self):
        end,r=step(self.base(),income=30,inflation='.02',payment_cost=0)
        self.assertEqual(r['payout'],10); self.assertEqual(end.protected,1020)
    def test_invalid_inputs(self):
        for bad in ['NaN','Infinity','-1']:
            with self.assertRaises(ValueError): step(self.base(),income=bad)
        with self.assertRaises(ValueError): step(self.base(),holders=0)
        with self.assertRaises(ValueError): step(self.base(),fair_change=-1000)
    def test_cash_and_asset_conservation_over_mixed_years(self):
        s=self.base()
        for i in range(30):
            before=s
            inc=D(i%7); change=D(-5 if i%3==0 else 2)
            s,r=step(s,income=inc,fair_change=change,costs=1,inflation='.01')
            self.assertEqual(s.cash,before.cash+inc-r['debt_paid']-r['costs_paid']-r['payout'])
            self.assertEqual(s.assets,before.assets+inc+change-r['debt_paid']-r['costs_paid']-r['payout'])
            self.assertGreaterEqual(s.cash,s.deferred)
if __name__=='__main__': unittest.main()


# SOURCE: own-the-machine-tools/reference/test_stress.py

import unittest
from stress import run
class StressTests(unittest.TestCase):
    def test_cashless_growth_has_no_payment(self):
        rows=run('3',cash_yield='0')
        self.assertTrue(all(r['real_payout_per_holder']==0 for r in rows))
        self.assertGreater(rows[-1]['real_stake_per_holder'],rows[0]['real_stake_per_holder'])
    def test_crash_exposes_preservation_shortfall(self):
        rows=run('3',crash_year=10)
        self.assertGreater(rows[10]['preservation_shortfall'],0)
        self.assertEqual(rows[10]['real_payout_per_holder'],0)
    def test_fractional_percentages_are_compared(self):
        self.assertLess(run('2.5')[-1]['real_stake_per_holder'],run('3')[-1]['real_stake_per_holder'])


# SOURCE: own-the-machine/pipeline/EXTERNAL-REVIEWS.md

# External reviews: what was raised, what changed, what was refused

The gates in `pipeline/reviews/` record what the project's own machinery
found. This file records what people outside it found, and what happened
next. It exists so that anyone who takes the trouble to review this draft
can see exactly what their review did, including where it was refused and
why. A reviewer who cannot tell whether they were heard does not review
twice.

Format per review: the challenge in the reviewer's terms, the disposition,
and the provision that carries it.

---

## Review 3, 21 August 2026: legal basis, valuation bottleneck, empirical baseline

**1. Article 114 needs genuine harmonisation, not a desirable policy.**
ACCEPTED, and it was the most valuable finding of the three. Recital 1
asserted that Member States were diverging with nothing behind the
assertion, which is precisely what *Tobacco Advertising* (C-376/98)
forbids, in the recital carrying the legal basis. The answer is
`evidence/EVIDENCE.md` section 8: eight Member States operating digital
services taxes at rates from 1,5 % to 7,5 % on bases that do not match,
entry thresholds differing by four orders of magnitude, six more Member
States with proposals not yet adopted. The legal-basis gate then confirmed
the record suffices to carry Layer 1 under Article 114.

A second correction followed on 21 August: recital 1 had still said "a
majority of Member States", where the evidence says eight of twenty-seven.
The recital now says what the evidence says.

**2. Valuation disputes will bottleneck in litigation; insert binding
arbitration.** REFUSED, with reasons on the record. Article 6(5) means a
challenge does not suspend the transaction and Article 6(4) corrects in
both directions after the event, so the gridlock the proposal guards
against does not arise. A binding tier between the valuation and the
courts would have to satisfy Article 47 of the Charter and the *Meroni*
limits on delegation, and would buy nothing that Article 6 does not
already provide. DC-34 records the refusal so that the next reviewer to
propose it can see it was considered rather than missed.

**3. Argue from ownership rather than from the falling wage share.**
ALREADY DONE, and verified rather than asserted: the recitals contain no
wage-share or labour-share argument, and DC-15 is the rule that keeps it
that way.

---

## Review 4, 21 August 2026: six corporate-structuring routes

The most productive review the project has had, and the first where the
answers were not already in the articles. Five of the six required new
drafting.

**1. Stay private for ever and the warrant never crystallises.** ACCEPTED.
Article 5(3) now crystallises the warrant before any liquidity event on
either of two triggers: shareholder extraction exceeding 25 % of covered
turnover over the same period, and a seven-year long-stop from issuance.
DC-35.

**2. Bury the Reserve under later preference classes.** ACCEPTED. Article
5(4)(b) ranks the Reserve's shares equally with the most favourably
ranking class created *after* the designation, which answers the attack
without expropriating preferences investors actually paid for before it.
Article 5(10) makes a subordinating arrangement ineffective as against the
Reserve while leaving it effective between the parties, so anti-avoidance
does not unwind transactions the Reserve was never party to. DC-36.

**3. Demerge or licence the automated assets into a clean entity.**
ACCEPTED. Article 2(14) defines automated assets and Article 5(11) makes
the transferee issue its own warrant. See the correction below, which
matters.

**4. Third-country withholding tax strips the Reserve's income.**
ACCEPTED IN PART, and the partial answer is stated as partial. Article
8(5) requires the unrecoverable amount to be published annually. A second
limb permitting the Reserve to arrange its holdings so as to reduce the
rate was drafted and struck: it would have written treaty shopping into an
instrument whose entire case is that it is not a fiscal device. Objection
18 says in terms that publication is a smaller answer than the problem.
DC-38.

**5. Phoenix the business through an insolvency.** ACCEPTED. Article 5(12)
reattaches the obligation where the same owners, judged by control or by a
majority of economic rights, reacquire the assets, with no time window. It
expressly does not apply where control passes to persons who did not
control the covered undertaking, because reattaching to a genuine rescuer
would expropriate the rescue. DC-39.

**6. Early-phase distributions are pennies, and the scheme discredits
itself on its first payment.** ACCEPTED. Article 10(6) declares a
distribution only where each holder would receive at least ten times the
average cost of executing one payment, with a backstop of at least once in
every three calendar years, and Article 10(7) publishes the withheld
per-holder amount and the per-holder capital in a year with no payment.
Annex II point 4 states the threshold as a ratio to the payment cost
rather than a euro figure, because a number in an annex ages and gets
quoted. DC-40, and DC-31 requires the stake to be shown wherever a payout
figure is.

---

## What the project's own gates then found in the answers

Recorded here because it bears directly on the value of review 4, and
because it is the most useful thing in this file for anyone deciding
whether to spend time on this draft.

The answer to route 3 contained a defect worse than the route. Article
5(11) required the transferee to issue its own warrant while the
transferor's obligations continued "unaffected". A group dividing its
automated assets among five subsidiaries would therefore have owed 3 %
from each of them and 3 % from the parent. That breaks the 3 % ceiling in
Article 7(2), which is the proportionality anchor the entire defence of
this instrument rests on.

It is now capped: the transferor stays bound for the automated assets it
retains, and the aggregate across the covered undertaking and every
transferee cannot exceed the stated percentage of their combined fully
diluted capital, with Article 7(2) stating the same cap on the same
aggregate basis.

Two things about how it was found are worth more than the fix.

It survived nine rounds of hostile counsel. It was found only when the
Design Consequences table was corrected: DC-37 had described the provision
as attaching "pro rata to value", which was the rule before the article
was amended. The drafters had been reading the table rather than the
article. A derived description that misdescribes its source does not
merely mislead a reader; it hides the defect from the authors, because a
stale summary reads as a statement that the thing has already been
checked.

And it happened twice in one day. After Article 5(11) was capped, DC-37
still said the transferor's obligation "continues unaffected", the exact
words struck from the article that morning. Both are now corrected in the
memorandum and in all four translations.

---

## Standing burdens, not defects

Named here so no reviewer spends time discovering them. The
characterisation of the participation mechanism under Article 114 remains
contestable and the instrument is layered so that the fight happens where
it belongs; see `regulation/memorandum/severability.md`. The Charter
Article 17(1) fair-balance argument for healthy going concerns cannot lean
on the BRRD cases, which assume failing banks, and objection 1 says so.
Subsidiarity remains a yellow-card risk.

## Open, and deliberately so

Two items from the 21 August gate run were recorded rather than fixed,
because each is a drafting decision that should be taken deliberately:
the position of a sub-threshold transferee under Article 5(11), and five
further acquis interface points. Both are in
`pipeline/reviews/2026-08-21-full-suite-post-recitals.md`.


---

## Review 4, 27 August 2026: the ECI Forum's answer to the Gate 1 advice request

Received 27 August 2026, six days inside the eight-working-day maximum, in
answer to the four questions of campaign/GATE1-LETTER.md (submitted 21
August, request 2332). The advice is independent (European Citizen Action
Service via the Forum), expressly non-binding on the Commission, and is
recorded here verbatim before anything was decided on it, as the letter and
campaign/FORUM-REPLY-PLAYBOOK.md require.

### Verbatim

> Sent on: 27/08/2026

> Dear Citizen,
>
> Thank you for submitting your inquiry through the ECI Forum.
>
> We understand that by your proposal for an ECI you would like the European Commission (EC) to propose a measure that would ensure EU citizens' participation in the productivity gains of undertakings active in hyper-automated production by requiring such undertakings to issue a 3% non-voting warrant of their capital to a holding in the interest of EU citizens.
>
> To be successfully registered, a proposed European Citizens' Initiative (ECI) must be in accordance with Article 6 (3) Regulation (EU) 2019/788 (ECI Regulation), i.e. the proposed initiative must not manifestly fall outside the framework of the Commission's powers to submit a proposal for a legal act of the Union for the purpose of implementing the Treaties; furthermore it must not be manifestly abusive, frivolous or vexatious nor manifestly contrary to the values of the EU in Article 2 TEU and rights enshrined in the Charter of Fundamental Rights of the EU.
>
> Article 114 TFEU, proposed in your enquiry, could constitute a legal basis for your proposed measure only under a very wide interpretation of this provision. A measure based on Article 114 TFEU must aim to promote the proper functioning of the internal market, must harmonise the national laws of the EU member states, and must not concern fiscal measures.
>
> While the definition of undertakings active in hyper-automated production would require a harmonised EU-wide rule, the creation of a fund to which these undertakings must contribute would arguably not harmonise the laws of the EU member states. As the EC usually takes a more restrictive approach when it comes to harmonisation measures, we suggest that you consider an alternative legal basis for your proposal (particularly Article 352 TFEU, also proposed in your enquiry).
>
> Moreover, in your current proposal the measure is designed as a social measure rather than as internal market measure. If you want to suggest Article 114 TFEU as a legal basis, we recommend that you further elaborate why your proposal is an internal market measure aiming at harmonising the law of the EU member states. You could for example argue that divergent national rules on citizen participation could distort competition in the internal market and therefore should be harmonised. The EC has already accepted a similar logic related to the wealth tax initiative in Implementing Decision (EU) 2023/1487, and we consider that reference to this Decision would support your proposal.
>
> Although your measure does not directly concern taxation, the EC might take the view that it is also covered by the exclusion of fiscal provisions under Article 114(2) TFEU, because it has similar effects by imposing financial contributions on undertakings. If this is the case, you could suggest Article 115 TFEU as proposed legal basis for your measure, as Article 115 TFEU does not exclude fiscal measures. However, rules under Article 115 TFEU must equally harmonise the laws of the member states as provided for by Article 114 TFEU. It is therefore not sufficient to propose a separate legal act in addition to the national laws of the EU member states, but national rules must be replaced by the suggested act on EU level. This means that Article 115 TFEU would equally only offer a legal basis under a very wide interpretation.
>
> Given the narrow approach by the European Commission to the interpretation of Articles 114 and 115 TFEU, you might want to consider Article 352 as alternative legal basis for your proposed measure. Article 352 provides a more general legal basis for legal acts pursuing one of the goals of the EU set out in the Treaty on the EU (TEU). Your proposed measure could serve as a contribution to the goals set out in Article 3 TEU, namely balanced economic growth and price stability as well as a highly competitive social market economy, aiming at full employment and social progress. The Council has, for example, adopted a recommendation on employee participation in profits and enterprise results based on the predecessor of Article 352 TFEU (see EUR-Lex - 31992H0443 - EN - EUR-Lex).
>
> Please also note that measures based on Article 114 can be adopted by a qualified majority, whereas measures based on Articles 115 and 352 require unanimity. You might therefore wish to take into consideration a proposal for a recommendation instead of a binding legal act. As your idea affects fundamental rights such as equality, the freedom to choose an occupation and property (because only a defined type of companies is concerned), the EC might examine whether the measure is proportionate to the aims that you want to achieve. If the EC considers the measure to be disproportionate, it would not hinder registration of your ECI, but we consider that addressing these possible concerns upfront might increase the chances that your ECI is registered.
>
> Partial registration of your initiative is possible, if some of the suggested goals fall outside the competence of the EU to propose a legal act as anchored in Article 6(3) of the ECI Regulation. If the goals of your proposal comply with the requirements set out in the ECI Regulation, it must be registered by the EC, regardless of the mechanism described in your proposed legal act. The contestability of the proposed legal mechanism is therefore not a relevant consideration for the registration of the ECI itself, if the goals pursued do not manifestly fall outside the scope of the EC's competence.
>
> Likewise, the ECI Regulation itself does not state how the proposal should be formulated or that a full draft is required. As outlined above, the crucial element for the EC's assessment is whether the proposal is covered by their competences. Thus, you may provide a full draft for a legal act if it follows from the draft that the proposal falls within the Commission's competence.
>
> We trust that the above information is of assistance to you. Should you require further assistance, please do not hesitate to contact us.
>
> Kind regards,
>
> The European Citizens' Initiative Forum Team

### Disposition

Playbook scenario B, with the weakest-point answer of scenario C folded in.
Point by point:

1. **Decomposition rule 5 is CONFIRMED and moves from assumption to
   finding.** "If the goals of your proposal comply with the requirements
   set out in the ECI Regulation, it must be registered by the EC,
   regardless of the mechanism described in your proposed legal act." The
   objectives are the unit of assessment; the annexed mechanism's
   contestability "is not a relevant consideration for the registration".
   regulation/memorandum/severability.md rule 5 is rewritten accordingly,
   citing this reply and its non-binding character.
2. **The draft act carries no registration penalty.** It may be provided
   "if it follows from the draft that the proposal falls within the
   Commission's competence", which is precisely what the severable-layer
   drafting is for. The registration path stays as designed: objectives as
   Layer 0, full Regulation annexed.
3. **The weakest point is named where objection 2 already argues it**:
   Article 114 holds "only under a very wide interpretation"; the fund limb
   does not harmonise; the measure reads social rather than internal-market;
   and the 114(2) fiscal exclusion might be stretched over it by effect.
   Nothing in this changes the file's position, because the file already
   holds it; the advice to "further elaborate" the divergence-distorts-
   competition argument points at work the memorandum and evidence base
   have done since 21 August.
4. **Two citable gains.** The advisers recommend citing Implementing
   Decision (EU) 2023/1487 for the divergence logic ("we consider that
   reference to this Decision would support your proposal"), converting
   GATE1's open question 4 into a yes. And they supply a precedent the file
   did not have: Council Recommendation 92/443/EEC on employee
   participation in profits and enterprise results, adopted on Article
   352's predecessor, which strengthens the Layer 3 basis argument.
5. **Recorded, not adopted:** the suggestion of a non-binding
   recommendation instead of a legal act (it would surrender the
   instrument's entire point and is not required for registration); Article
   115 as a fiscal-safe fallback basis (noted in the legal-basis record as
   a third string, with the advisers' own caveat that it demands the same
   wide reading as 114); and the reminder that 115/352 require unanimity,
   which the severability architecture already prices in.
6. **Gate 1, sounding one: PASSED.** No kill criterion is touched: the core
   ask is registrable on the advisers' reading, partially at worst. The
   response, per playbook scenario B: thanks, no follow-up question.
   Soundings two and three proceed with this reasoning quoted.

## Review 5, 5 September 2026: an ECI veteran's reply to sounding letter C

Received 5 September 2026, within a day of the letter, in answer to
campaign/SOUNDING-LETTERS.md letter C. A short written reply from a
practitioner who has taken initiatives through registration; no call, no
question list taken up. Recorded verbatim on its substance, nameless as
the letter promised, before anything was decided on it.

### Verbatim (substance)

> One thing I did not see with your text was proposed legal basis in the
> Treaty on the functioning of the EU. Since you are demanding a new tax on
> companies I guess that without that the Commission might decide that
> your proposal implies a Treaty change and therefore not to register your
> ECI.

> I think it's also acceptable to put all ECI's in the same straight
> jacket: title, short proposal, legal basis, longer explanatory annex plus
> any requested law added. Without this discipline it would be difficult
> for people going on to the Commission portal to compare different ECIs
> and decide which to sign.

> My advice would be to draft your proposal as per instructions with the
> correct character count and see if it can resonate with the public.
> Several drafts are necessary.

### Disposition

1. **The legal basis was not visible where a reader lands. ACCEPTED as a
   presentation defect, verified before acceptance:** the site's landing
   page, law index and about page carried no Treaty article; the
   explanatory memorandum states the basis in section 2.1, a third of the
   way down; the registration-format text with its Treaty-provisions
   section existed only in this repository. Two fixes: the preamble now
   carries the citations every Union act opens with, naming Article 114
   (regulation/recitals.md, closing the legal-form finding of 19 August;
   the two-act form for the Article 352 layer is recorded in memorandum
   2.1), and the registration-format text is published on the site with the
   legal basis on the first screen.
2. **The fiscal reading is the default reading. RECORDED against objection
   2.** This is the third independent reader to reach for "tax" before
   anything else, after hostile counsel (pipeline/reviews, 27 August,
   attack 1) and the ECI Forum's advisers (Article 114(2) "by effect").
   Objection 2 already states the case at full strength; what changes is
   the status of the risk, from an adversary's argument to the ordinary
   reader's first impression, which the presentation must answer before
   the argument gets a hearing.
3. **The Treaty-change instinct. ANSWERED BY PRESENTATION, not by new
   drafting.** The file seeks no Treaty amendment (memorandum 2.1;
   severability layers); the registration text now says so in one
   sentence. The instinct arose because no basis was visible, and it is
   the instinct the Commission's registration unit will share.
4. **The format advice. ALREADY MET, NOW VISIBLE.** campaign/REGISTRATION-TEXT.md
   has held title, objectives, Treaty provisions and annex within the Annex
   II limits of Regulation (EU) 2019/788 since August; it is now rendered on
   the site. "Several drafts" and "see if it can resonate with the public"
   are taken as the sequencing rule for Gate 2: the short text is tested on
   people before the long one is perfected further.
5. **Gate 1, sounding three: ANSWERED.** No kill criterion is touched. What
   was asked for (the registration dialogue as lived) was not what came
   back; what came back was worth more.


# SOURCE: own-the-machine/campaign/GATE1-LETTER.md

# Gate 1: request for advice from the ECI Forum

Status: **ANSWERED 27 August 2026**, six days early. The reply is recorded
verbatim in pipeline/EXTERNAL-REVIEWS.md (review 4) with its disposition;
decomposition rule 5 moved from assumption to finding on it, and the
response followed campaign/FORUM-REPLY-PLAYBOOK.md scenario B: thanks, no
follow-up. Originally sent 21 August 2026, Submitted through the Forum's
Seek advice form as a legal enquiry, from David's own account. This was the
first of the three Gate 1 soundings in campaign/GATES.md.

The form turned out to be a five-field questionnaire, four of the fields
capped at 1 000 characters, not the single free-text box this letter was
written for. What was actually submitted is recorded below the letter, under
"What was sent". The letter is kept because it is the fuller statement and
the source the fields were cut from.

## How it is sent

It is not an email. The advice service runs as a form on the European
Citizens' Initiative Forum.

1. Go to the Forum at `citizens-initiative-forum.europa.eu` and log in, or
   register. It uses EU Login. This has to be David's own account.
2. Open **Seek advice** and start a request. Choose the **legal** category,
   which covers existing legislation, registration criteria and similar past
   initiatives.
3. Paste the submission below. It is written to stand alone, because the
   form is described as a short questionnaire and there is no guarantee that
   files can be attached. Every document it refers to is public and linked,
   so nothing needs to travel with it.

The advice is given by the European Citizen Action Service, independently of
the Commission, and the stated turnaround is a maximum of eight working
days. It does not bind the Commission, which the submission says in terms.

Verify before sending: every link below returned 200 on 21 August 2026, but
check them again on the day, and check that the draft on the site is the
version you want reviewed.

---

## Subject

Registrability of a planned initiative on citizen participation in
automated productivity gains

## Submission

Dear ECI Forum legal team,

I am preparing a European Citizens' Initiative and would value your advice
on registrability before I constitute an organisers' group. The text I
would enter in the registration form is set out in full below, so that you
can assess the words themselves rather than a description of them.

**Title, 79 characters.**

Citizens' participation in the productivity gains of hyper-automated
production

**Objectives, 944 characters without spaces.**

We ask the Commission to assess, and to propose instruments ensuring, the
participation of citizens of the Union in the productivity gains of
hyper-automated production, meaning production whose output is
substantially decoupled from employment.

Automation is concentrating the returns of production in a few very large
undertakings as the labour share falls. Member States have begun to respond
separately, with divergent levies and participation schemes, which
fragments the internal market.

We therefore ask the Commission:

1. to assess, and to propose harmonised criteria and a procedure for, the
designation of undertakings whose output is substantially decoupled from
employment;

2. to propose mechanisms by which the gains and value of such production
become broadly owned by, or shared with, citizens of the Union;

3. to report periodically on automation, employment and ownership
concentration, so that any instrument adopted can be corrected or repealed
on the evidence.

A complete draft Regulation accompanies this initiative as an
illustration. The objectives, not the draft, are what we ask for.

**Treaty provisions we consider relevant.**

Article 114 TFEU as the primary contemplated basis, Article 352 TFEU as
the residual basis for any element falling outside it, and Article 3(3)
TEU and Article 9 TFEU as to the objectives of a social market economy.

**The accompanying draft, in one sentence.** A complete draft Regulation
exists. It would designate undertakings above objective thresholds on the
model of Regulation (EU) 2022/1925 and require each to issue, once, a
non-voting warrant over 3 % of its capital to a common reserve holding for
all Union citizens. It is deliberately not a levy: nothing is payable in
cash and nothing enters any public budget, which matters to the Article
114(2) question below.

My present intention is to submit that draft formally as a draft legal act
under Article 6(2), together with the Annex II background text, rather than
merely to publish it. Whether that is wise is part of what question 3 asks,
so if the answer is that it should be withheld, that is a decision I have
not yet taken. I can paste either text in full if it would help.

Three questions.

**1. Competence under Article 6(3)(c).** What are the principal risks to
registration of the objectives above, taking Article 114 TFEU and Article
352 TFEU in turn? I am aware that Article 114(2) excludes fiscal
provisions, and that Article 114 requires genuine obstacles or appreciable
distortions of competition rather than a desirable policy. I would rather
have your unvarnished reading of where this is weakest than confirmation
that it is arguable.

**2. Partial registration.** The objectives ask only for an assessment and
a proposal, and the mechanism sits in the accompanying draft. I had assumed
that keeping the mechanism out of the objectives leaves room for the
Commission to trim under Article 6(4) rather than refuse. I would like to
know whether that is right, because a good deal of my drafting rests on it.
How would the Commission apply Article 6(4) if it considered that elements
of the mechanism exceeded Union powers, and does framing an objective as a
request to assess and propose make any difference to that?

**3. The accompanying draft act.** I take it from the case law that the
Commission examines the whole of an initiative, annexes and any draft legal
act included, rather than the title and objectives alone. On that footing,
how far does the design of the mechanism in the accompanying draft bear on
the assessment of the objectives themselves, and is there a point at which
submitting a complete draft act makes registration harder rather than
easier?

On precedent: the Commission registered "Taxing great wealth to finance the
ecological and social transition" on 11 July 2023 by Commission
Implementing Decision (EU) 2023/1487, on a subject where competence is at
least as contested as here. I have not assumed what that implies for my own
case, and I would value your view on whether it reads across at all.

I understand that your advice is independent and informal and does not bind
the Commission. I am asking now because the answer decides whether I
constitute an organisers' group at all.

Everything is published, unannounced, at https://ownthemachine.eu: the
draft Regulation, the objections I consider strongest against it, the
evidence the internal-market argument relies on, and the record of every
review the text has been through. Nothing there is needed to answer the
three questions above.

With thanks,
David Vanheeswijck
Belgium

---

## If the form will not take that much text

Cut, in this order: the sentence about the accompanying draft, then
question 3, then the precedent paragraph. Keep the title, the objectives
and questions 1 and 2 whatever happens, because those are what decide the
gate.

---

Drafting notes (not part of the submission). Revised on 21 August 2026
after a review that read it in the role of the adviser receiving it. Four
things changed and each is worth keeping in mind for the other soundings.

The registration text is now pasted in full rather than linked. An adviser
with eight working days and a queue will not open five external pages, and
if the text they are asked about is not in front of them the only possible
reply is a request for it, which costs a full cycle.

The questions were leading. "Do you agree that the ask is not manifestly
outside the framework" invites a yes that tells us nothing; asking where it
is weakest gets the answer worth having.

The third question used to ask whether attaching a draft act helps or
hinders. Annex II expressly permits a draft legal act, so that reads as
asking for tactical gossip rather than advice. It now asks the thing we
actually need to know: whether the draft is itself assessed under Article
6(3)(c).

The precedent is now stated as a fact with its decision number and put as a
question. It had asserted that the registration showed characterisation
disputes belong to the legislative stage, which is our inference and not
something the decision says. Asserting our own reading of a file to the
people who know it is the wrong way round, and the correct number is
2023/1487.

---

## What was sent

Submitted 21 August 2026 through the ECI Forum's Seek advice form, as a legal
enquiry. Recorded here verbatim, because the form is what the advisers
answered and the letter above is not.

**Are you an EU citizen?** Yes.
**Are you planning to submit an ECI for registration?** Yes.
**Needs personalised advice on:** Legal issues.

**Describe the subject matter of your initiative.** Citizens' participation in
the productivity gains of hyper-automated production, meaning production whose
output is substantially decoupled from employment.

**Describe the actions you want the European Union to undertake.**

> I ask the Commission:
>
> 1. to assess, and to propose harmonised criteria and a procedure for, the
> designation of undertakings whose output is substantially decoupled from
> employment;
>
> 2. to propose mechanisms by which the gains and value of such production
> become broadly owned by, or shared with, citizens of the Union;
>
> 3. to report periodically on automation, employment and ownership
> concentration, so that any instrument adopted can be corrected or repealed
> on the evidence.

**What type of legal act.**

> A Regulation. A complete draft is written, and my present intention is to
> submit it as a draft legal act under Annex II to Regulation (EU) 2019/788,
> together with the Annex II background text. Whether that is wise is one of
> the questions I ask.
>
> In outline it would designate undertakings above objective thresholds on the
> model of Regulation (EU) 2022/1925, and require each to issue, once, a
> non-voting warrant over 3 % of its capital to a common reserve holding for
> all Union citizens. The warrant would crystallise on a liquidity event, on
> distributions to shareholders above a stated share of turnover, or seven
> years after the warrant arises at effective designation.
>
> Nothing is payable in cash and nothing enters any public budget.

**Treaty provisions.**

> Article 114 TFEU as the primary contemplated basis, on the ground that
> divergent national levies and participation schemes for automated production
> are emerging and fragment the internal market.
>
> Article 352 TFEU as the residual basis for any element falling outside
> Article 114.
>
> Article 3(3) TEU and Article 9 TFEU as to the objectives of a highly
> competitive social market economy.
>
> I am aware that Article 114(2) excludes fiscal provisions, and that Article
> 114 requires genuine obstacles or appreciable distortions of competition
> rather than a desirable policy.

**Describe your request.**

> 1. What are the principal risks to registration of the objectives above
> under Article 6(3)(c), taking Article 114 and Article 352 TFEU in turn? I
> would rather have your reading of where this is weakest than confirmation
> that it is arguable.
>
> 2. How does the Commission apply partial registration under Article 6(4)
> where the objectives fall within Union competence but the mechanism set out
> in an accompanying draft act is contested?
>
> 3. Taking it that the Commission examines an initiative as a whole, annexes
> and any draft act included, is there a point at which submitting a complete
> draft act makes registration harder rather than easier?
>
> 4. Does the reasoning in Commission Implementing Decision (EU) 2023/1487 of
> 11 July 2023, registering the initiative on taxing great wealth, read across
> to a case like this one?
>
> I am asking for advice on the text in this form. The draft, the objections
> against it and the review record are published at ownthemachine.eu if they
> are of use.

## What the split cost, and one thing deliberately withheld

The letter's salutation, sign-off and its statement of why the answer matters
did not survive the character caps. Nor did any assertion about what the 2023
wealth-tax registration decision held. A review proposed stating that it was
registered on Articles 115 and 352 TFEU; the same review had earlier given
those articles as 115 and 122 and the decision number as 2023/1498, which is
wrong, and EUR-Lex could not be read to settle it. Question 4 therefore cites
the decision and asks whether it reads across, rather than telling the people
who know that file what it says.

Two sentences of the initiator's own drafting commentary were also cut, both
caught on a read-through rather than by any gate: a note about character
counts, and a line saying which text would go in the registration form. The
questions carry that link already.

## What to do with the answer

The reply bears directly on decomposition rule 5 of
regulation/memorandum/severability.md, which is currently marked as an
assumption rather than a finding. If the answer is that the annex is assessed
on the same footing as the ask, that rule changes and so does what goes in the
registration form. Record the reply and its consequences in
pipeline/EXTERNAL-REVIEWS.md before acting on it.


---

## Response sent, 27 August 2026

Submitted the same day through the request's feedback form (ratings: Very
satisfied / answered: Yes / clear: Yes), after the usual adversarial round:
the first draft was revised because hostile counsel showed four phrases a
hostile reader could quote from the public record as admissions ("not
assumed" reading as a concession that the Article 114 case was ungrounded,
"a genuine gift ... our file had missed" as self-discrediting, the
proportionality sentence as an admission of flaws, and "strengthens the
layer" overclaiming a 1992 soft-law recommendation). The revision passed
the gate on the second round and says no act-type for the 2023 decision at
all, since two reviews have now contradicted each other about it. Verbatim
as sent:

> Dear ECI Forum legal team, thank you for a reply that answered all four
> questions directly, ahead of your own deadline, and without softening the
> difficult parts. Three things in it will shape the file. Your reading
> that registration turns on the goals rather than on the contestability of
> the annexed mechanism answers, for the registration stage, the one
> assumption our drafting had flagged as untested; it is now recorded in
> the project's public repository with your advice's independent and
> non-binding character stated alongside it. The 2023 wealth-tax
> registration decision you cite will be referenced in the memorandum's
> internal-market argument, as you recommend. And Council Recommendation
> 92/443/EEC, which we had not yet cited, now belongs in the file's account
> of Union action on participation under Article 352's predecessor. Your
> harder counsel is taken as seriously: the internal-market case for
> Article 114 will be presented with the evidence the file has assembled
> for it, and the proportionality analysis you advise making upfront is
> already stated on the face of the draft's objections file, where the
> Commission can weigh it before anyone asks. No further question - you
> gave us what we asked for: your reading of where it is weakest. With
> thanks, David Vanheeswijck

Gate 1's first sounding is closed in both directions: their answer in
pipeline/EXTERNAL-REVIEWS.md review 4, our response here.


# SOURCE: own-the-machine/campaign/REGISTRATION-TEXT.md

# ECI registration text

The text that would go into the Commission's registration form, in the
fields and within the limits set by Annex II to Regulation (EU) 2019/788.
Status: DRAFT, not filed. Filing is a Gate 2 action. This exists because
every Gate 1 conversation will ask what the ask actually says, and the
draft Regulation is not that: under Article 6(3)(c) the registration test
is applied to this text.

Two things govern the drafting. First, Article 6(4) allows partial
registration only where part of the initiative "including its main
objectives" survives, so the main objectives here are Layer 0 of
regulation/memorandum/severability.md, an assessment and a proposal, and
the draft Regulation sits in the accompanying-draft slot where trimming
can reach it without touching the ask. Second, Annex II counts the
objectives and the annex in characters **without spaces**.

---

## 1. Title

> Citizens' participation in the productivity gains of hyper-automated production

79 characters, limit 100.

---

## 2. Objectives

We ask the Commission to assess, and to propose instruments ensuring,
the participation of citizens of the Union in the productivity gains of
hyper-automated production, meaning production whose output is
substantially decoupled from employment.

Returns from highly automated production risk concentrating in a few large
undertakings. Divergent national responses to the digital economy can
fragment the internal market; harmonised participation mechanisms merit
assessment.

We therefore ask the Commission:

1. to assess, and to propose harmonised criteria and a procedure for, the
designation of undertakings whose output is substantially decoupled from
employment;

2. to propose mechanisms by which the gains and value of such production
become broadly owned by, or shared with, citizens of the Union;

3. to report periodically on automation, employment and ownership
concentration, so that any instrument adopted can be corrected or
repealed on the evidence.

A complete draft Regulation accompanies this initiative as an
illustration. The objectives, not the draft, are what we ask for.

932 characters without spaces (1089 with), limit 1 100.

---

## 3. Provisions of the Treaties considered relevant

Article 114 TFEU (approximation of laws for the establishment and
functioning of the internal market), as the primary contemplated basis
for designation, transparency and the harmonised participation
mechanism.

Article 352 TFEU, as the residual basis for any element the Commission
considers to fall outside Article 114, in particular the creation of a
Union body holding assets and the individual entitlement.

Article 3(3) TEU and Article 9 TFEU, as to the objectives of a highly
competitive social market economy and of taking social requirements into
account in the Union's policies.

No amendment of the Treaties is sought. The initiative asks the Commission to assess the use of existing bases,
primarily Article 114 TFEU and residually Article 352 TFEU. Reliance on
Article 352 would require a separate act, with Council unanimity and
Parliament's consent. The illustrative draft currently cites Article 114
only; it is not a completed two-act architecture. The accompanying draft
is severable by layer; the Commission decides what, if anything, can be
registered and proposed within its powers.

---

## 4. Annex on the subject, objectives and background

Subject matter. The initiative concerns the distribution of the capital
value produced by highly automated undertakings. Its premise is
empirical, not ideological: where output is substantially decoupled from
employment, the historic channel through which citizens shared in
productivity, namely wages, may not carry all the gains. The initiative
asks the Commission to open a second channel, ownership, and to do so on
harmonised Union rules rather than leaving it to twenty-seven divergent
national answers.

The fragmentation is not hypothetical. Eight Member States operate
digital services taxes at rates between 1,5 % and 7,5 % with thresholds
that differ by orders of magnitude, several more have proposals before
their parliaments, and the resulting patchwork applies different
liabilities to the same cross-border service depending on where its
users happen to be. The European Parliament rejected a robot tax in
February 2017, the question has returned with the large-scale adoption of
artificial intelligence, and no Union instrument occupies the field.

The mechanism we illustrate. Undertakings would be designated on the model of Regulation (EU) 2022/1925:
a rebuttable presumption above objective thresholds, and designation on the
facts below them after a market investigation. Each
designated undertaking would issue, once, a non-voting citizens' capital
warrant entitling a common reserve to subscribe at nominal value for 3 %
of its fully diluted capital, crystallising on the undertaking's first
liquidity event, or earlier where it distributes value to its own
shareholders above a stated share of its turnover from the covered activity, or in any event seven
years after the warrant arises at effective designation. The reserve would hold the resulting shares without votes, board seats or any say in management, insulated in both directions from Union and national
budgets. Citizens of the Union aged 18 or older would hold equal, personal and
non-transferable entitlements to distributions as and when they are
realised, carrying no right of individual cash redemption or sale,
administered through national vehicles.

The participation mechanism is settled in shares; Reserve capital and
citizen distributions remain outside public budgets. The Reserve pays
the shares' nominal value in cash, the undertaking bears valuation costs,
and enforcement fines accrue to the Union budget. No undertaking is required
to sell assets to settle the warrant. The warrant also crystallises at the seven-year long-stop even without
a liquidity event or shareholder extraction. We propose this as a measure
of company law and market regulation; its possible classification as a
fiscal measure remains contested despite its settlement in shares.

Honesty about the difficulty. We do not claim the legal basis is
uncontested. The characterisation of the participation mechanism under
Article 114 is arguable and we have published the argument against it at
full strength, together with the case law relied on by both sides, in a
public memorandum of objections. Our position is that a characterisation
dispute of this kind belongs to the legislative stage, as it did for the
initiative on wealth taxation registered in 2023, and not to the
registration stage, where the test is whether the ask manifestly falls
outside the Commission's powers.

Severability. The ask above is drafted so that it survives trimming. Its
main objectives are an assessment and a proposal, within the Commission's Treaty powers. Whether it can propose particular
elements remains subject to the applicable legal basis. If
the Commission concludes that parts of the accompanying draft exceed
what it could propose, we would prefer partial registration under
Article 6(4) of Regulation (EU) 2019/788 to refusal, with any trimming
applying to the accompanying draft rather than to the objectives.

Evidence and correction. Article 14 requires a published assessment,
including evidence contrary to the draft's assumptions about decoupling.
The Commission would propose amendment or repeal where appropriate;
correction or repeal is not automatic. The complete text, the
objections to it, the evidence base and the record of every adversarial
review it has been through are public at ownthemachine.eu.

3603 characters without spaces (4242 with), limit 5 000.

---

## 5. Draft legal act

Annex II permits organisers to submit a draft legal act. The complete
draft Regulation at regulation/ is submitted in that slot, with the
memorandum of objections and the evidence base referenced but not
submitted, since they are published.

---

Drafting notes (not part of the registration). The title avoids the
campaign name, which is a communications asset and not a description of
the ask. The objectives close by saying which of the two documents is
the ask, so that a registration officer reading only field 2 knows the
draft is illustrative. The annex concedes the legal-basis difficulty
rather than waiting to be caught on it, on the same reasoning as the
Gate 1 letter: the audience has read stronger cases than this one and
discounts a text that claims certainty. The digital services tax figures
are those in evidence/EVIDENCE.md section 8 and carry its sourcing; they
must be re-verified before filing, not before sounding.


# SOURCE: own-the-machine/regulation/STRUCTURE.md

# Provisional structure of the Regulation

Working title: Regulation of the European Parliament and of the Council on
harmonised rules for citizen participation in automated productivity gains
(Citizens' Capital Regulation).

Legal bases: Article 114 TFEU, with Article 352 TFEU as the fallback where
Article 114 does not comfortably reach. Severable layers per DC-6.

| Ch | Articles | Content | Status |
|---|---|---|---|
| I | 1-2 | Subject matter, scope, definitions | drafted |
| II | 3-4 | Designation of covered undertakings; market investigation and review | drafted |
| III | 5-7 | The citizens' capital warrant; independent valuation; safeguards | drafted |
| IV | 8-9 | The European Citizens' Capital Reserve; prohibited holdings and conduct | drafted |
| V | 10-11 | The citizens' entitlement; national vehicles | drafted |
| VI | 12 | Protection of the Reserve and of entitlements | drafted |
| VII | 13-16 | Penalties; monitoring and evaluation; delegation; committee procedure | drafted |
| VIII | 17-18 | Transitional and final provisions | drafted |

Citations and recitals: drafted, see regulation/recitals.md (citations
added 6 September 2026, closing the legal-form finding of 19 August). DC-26,
the explicit scope-and-limits recital, is outstanding and not yet drafted.

Annex I: methodology for counting turnover, fair market value and full-time
equivalents (referenced by Article 3; technical only per JPG G22). Drafted,
regulation/annexes/annex-1-counting.md.

Annex II: methodology for the capital-preservation retention (referenced by
Article 8(4); technical only). Drafted,
regulation/annexes/annex-2-retention.md.

The four tests map: in time = Chapter II; assets not flows = Chapter III;
universal = Chapter V; raid-proof = Chapter VI. Each drafted article carries
non-normative drafting notes after a separator; the notes never enter the
legal text.

## Accompanying documents

| Document | Content | Status |
|---|---|---|
| memorandum/explanatory-memorandum.md | The five-section explanatory memorandum in the Commission's own structure: context; legal basis, subsidiarity and proportionality; evaluations, consultations and impact assessment including the policy-options appraisal; budgetary implications; other elements | drafted |
| memorandum/counter-arguments.md | The objections, at full strength, with answers and the constraints table | drafted |
| memorandum/severability.md | How the instrument decomposes if a layer fails | drafted |
| evidence/ | The sourced, reproducible basis for every quantitative claim | drafted |


# SOURCE: own-the-machine/regulation/annexes/annex-1-counting.md

# Annex I: Methodology for turnover, employment and value

## 1. Union turnover

Annual Union turnover comprises the amounts derived by the undertaking
during the financial year from the sale of products and the provision of
services to undertakings or consumers in the Union, after deduction of
sales rebates and of value added tax and other taxes directly related to
turnover. Turnover is attributed to the Union where the customer is
established or, in the case of consumers, resident in the Union.
Intra-group transactions are excluded. Where the undertaking
comprises linked enterprises, turnover is calculated on a
consolidated basis.

## 2. Turnover of the automated segment

The turnover attributable to the provision of the goods and services
referred to in point (a) of Article 3(1), used for the assessment of that
point and in any market investigation pursuant to Article 4, comprises the
worldwide turnover derived from that provision. Where such goods or services
are sold together with other goods or services for a single consideration,
the consideration is attributed between them on a consistent and documented
basis reflecting their relative stand-alone value.

## 3. Compensation of labour

The annual worldwide compensation of labour of an undertaking comprises
all compensation of employees within the meaning of the European system
of accounts, including social contributions payable by the employer and
share-based compensation measured at grant value, as recorded in accounts
audited in accordance with the law applicable to the undertaking,
calculated on a consolidated basis for the group of linked enterprises,
and averaged over the last two financial years.

The compensation figure excludes artificial increases established by the
Commission under Article 3(8). Genuine remuneration includes increased pay
for existing work; it does not require additional hours or employees.

## 4. Fair market value

Fair market value is determined by reference to the most recent of
the following, adjusted for capital raised or returned since:
(a) the price per share paid in the most recent transaction in which
shares representing at least 2 % of the capital were issued or
transferred for consideration to persons independent of the undertaking,
applied to the fully diluted capital;
(b) an independent valuation prepared in accordance with internationally
accepted valuation standards within the preceding 12 months;
(c) where shares of the undertaking are admitted to trading, the average
market capitalisation over the preceding six months.

## 5. Information accompanying a notification

A notification pursuant to Article 3(3) contains:
(a) the identity of the undertaking and of all linked enterprises;
(b) the calculations referred to in points 1 to 4, with the data and
attribution bases used;
(c) the audited financial statements for the last two financial years;
(d) a description of the goods and services referred to in point (a) of
Article 3(1) which the undertaking provides, and of the automated
cognitive systems on which their provision depends;
(e) the law governing the undertaking and, where that law is the law of a
third country, the measures by which the undertaking intends to give
effect to Article 5.

---

Drafting notes (non-normative). Point 3 measures labour by audited
compensation of employees rather than by headcount, after the 22 August 2026
reviews: a headcount is unpublished and cheaply padded, where payroll is a
single audited line, and under a compensation denominator the contracting-
out of labour raises the ratio towards designation, so the only route down
is direct employment. The anti-avoidance rule for payroll and valuation
gaming lives in Article 3(8) after the form gate found an autonomous command
in an annex (JPG 22). Annex language is descriptive throughout for the same
reason; the obligations flow from the articles that reference it. Point 3 is
drafted so that Article 2(8) can cite it for compensation of labour. Point 2
no longer feeds a quantitative threshold; it serves the qualitative
assessment under Article 3(1)(a) and market investigations, and the
information duty in point 5(b) keeps the segment figures available to the
Commission for that purpose. Point 4 mirrors the practice of growth-equity
valuation without legislating a model. The 2 % floor in point 4(a) excludes
token transfers priced for other reasons.

# SOURCE: own-the-machine/regulation/annexes/annex-2-retention.md

# Annex II: Methodology for the retention preserving real capital

## 1. Retention

The amount to be retained pursuant to Article 8(4) in respect of a
financial year is the amount necessary so that the capital of the
Reserve at the end of that year, measured at fair value, is not lower in
real terms than its capital at the end of the preceding financial year,
after account is taken of:
(a) inflation, measured by the harmonised index of consumer prices for
the Union published by the Commission (Eurostat);
(b) unrealised changes in the fair value of the Reserve's holdings, to
the extent recognised under point 3.

## 2. Distributable amount

The distributable amount for a financial year is the realised
income of the Reserve for that year, comprising dividends, interest,
proceeds of disposals in excess of carrying value and other realised
returns, less the retention under point 1 and less the administrative
costs of the Reserve. Where the retention under point 1 equals or exceeds
realised income, the distributable amount is zero; the shortfall
is carried forward and retained from the realised income of
subsequent years before any distribution.

## 3. Smoothing

For the purposes of point 1, changes in fair value are recognised
evenly over five financial years from the year in which they arise. The
distributable amount for a financial year does not exceed the greater
of:
(a) 125 % of the average of the distributable amounts for the three
preceding financial years; and
(b) 2 % of the capital of the Reserve at the end of that year.

## 4. Cost of executing a payment

The average cost of executing one payment to a holder, for the purposes of
Article 10(6), is the total of the charges levied by national vehicles and
by payment service providers for executing the most recent distribution,
divided by the number of holders paid. Where no distribution has yet been
made, it is the average of the charges quoted to the Reserve by national
vehicles for executing one payment.

## 5. Exclusions

For the purposes of point 2, realised income excludes amounts obtained by
borrowing and the proceeds of disposals of holdings effected for the
purpose of funding a distribution.

---

Drafting note (non-normative). Point 4 was added on 21 August 2026 against
the objection that early distributions would be too small to be worth
transferring, and rewritten the same day. Two figures were rejected. A
floor of EUR 50, as proposed in review, would suppress every distribution
until roughly the fiftieth year on this instrument's own central
assumptions: that is a policy of deferral wearing the costume of an
efficiency measure. A floor of EUR 2 was drafted and then withdrawn
because hostile counsel wrote the headline it hands over, and because a
figure in an annex ages while the cost it stands for moves. What remains
is a ratio: ten times what it costs to make the payment. It is
self-adjusting, it states the actual reason, and there is no number in it
for anyone to quote.

---

Drafting notes (non-normative). This is the Norway spending rule made
operative: real capital is preserved first, only realised income above
preservation is distributed, and point 3's five-year smoothing plus the
125 % collar prevents both a bumper-year blowout and a political demand to
liquidate holdings for a headline payment; the outright prohibition on
funding distributions by borrowing or forced disposal moved to
Article 8(4) after the form gate found an autonomous command in an annex
(JPG 22), and point 4 keeps the arithmetic aligned with it. The
capital-fraction floor in point 3(b) was added on 19 August 2026 after
the public simulator, implementing this Annex exactly as drafted,
exposed a crumb-trap: a collar measured only against a trailing average
that starts near zero suppresses distributions for over a decade even
as capital accumulates. The floor lets distributions scale with the
Reserve while the collar still smooths spikes; realised income remains
the binding ceiling under point 2.
Point 2's carry-forward makes bad years honest instead of deferred. The
methodology enforces DC-14 at the level of arithmetic: early distributions
are small because early realised income is small, and no clause here can
be operated to promise otherwise.


# SOURCE: own-the-machine/regulation/articles/01-subject-matter.md

# Article 1: Subject matter and scope

1. This Regulation lays down harmonised rules ensuring the participation of
citizens of the Union in the capital value created by hyper-automated
undertakings operating in the internal market.

2. The participation referred to in paragraph 1 shall be of such scale
that, on the designations made under Article 3 and the methodology laid
down in Annex II, the aggregate value of the holdings attributable to each
citizen's entitlement is capable of reaching, within one generation of the
first designations and in constant prices, an amount of the order of six
months of the median equivalised disposable income in the Union as
published by the Commission (Eurostat). Distributions under Article 10
shall remain the property income of the holders and shall be governed solely by
Article 8 and Annex II. The Commission shall assess progress against this
objective in each report under Article 14(2), and where the assessment
shows the objective to be manifestly unattainable or manifestly exceeded,
the report shall be accompanied, where appropriate, by a proposal to amend
the percentage laid down in Article 5(2) or the thresholds laid down in
Article 3(2).

3. To that end, this Regulation establishes:
(a) criteria and a procedure for the designation of covered undertakings;
(b) an obligation on covered undertakings to issue citizens' capital
warrants to the European Citizens' Capital Reserve;
(c) the European Citizens' Capital Reserve and the rules governing its
holdings and conduct;
(d) an individual entitlement of citizens of the Union to distributions from
the Reserve, administered through national vehicles;
(e) rules protecting the Reserve and individual entitlements.

4. This Regulation applies to undertakings offering goods or services in the
internal market, irrespective of their place of establishment.

5. This Regulation is without prejudice to Directive (EU) 2016/2341 and to
Regulation (EU) 2019/1238, save as expressly provided in Article 11.

---

Drafting notes (non-normative). Paragraph 3 is the market-access nexus
(DC-10), the DMA and GDPR pattern. Paragraph 4 pre-answers the pension
acquis interface (research checklist item 19). One idea per sentence
throughout per JPG G1.


# SOURCE: own-the-machine/regulation/articles/02-definitions.md

# Article 2: Definitions

For the purposes of this Regulation, the following definitions apply:

(1) 'undertaking' means an entity engaged in an economic activity,
regardless of its legal status and the way in which it is financed,
including all linked enterprises within the meaning of Article 3(3) of the
Annex to Recommendation 2003/361/EC;

(2) 'covered undertaking' means an undertaking designated pursuant to
Article 3;

(3) 'automated cognitive services' means services whose provision depends to
a significant extent on software systems, including artificial intelligence
systems within the meaning of Article 3(1) of Regulation (EU) 2024/1689,
performing tasks that would otherwise require human cognitive labour;

(4) 'citizens' capital warrant' means a financial instrument arising
pursuant to Article 5 which confers the right to subscribe for shares in a
covered undertaking;

(5) 'Reserve' means the European Citizens' Capital Reserve established by
Article 8;

(6) 'liquidity event' means any of the following:
(a) the admission of shares of the covered undertaking to trading on a
regulated market or multilateral trading facility, in the Union or in a
third country;
(b) a change of control of the covered undertaking;
(c) one or more transactions within any period of 12 months by which shares
representing at least 20 % of the capital of the covered undertaking are
transferred for consideration;

(7) 'change of control' means the acquisition, directly or indirectly, of
decisive influence over the covered undertaking within the meaning of
Article 3(2) of Regulation (EC) No 139/2004;

(8) 'compensation of labour' means the annual worldwide compensation of
employees of an undertaking, calculated in accordance with point 3 of
Annex I;

(9) 'fair market value' means the value determined in accordance with
Annex I on the basis of the most recent funding transaction, independent
valuation or observable market price, whichever is most recent;

(10) 'holder' means a natural person in whom an entitlement is vested
pursuant to Article 10;

(11) 'national vehicle' means the body or arrangement designated by a
Member State pursuant to Article 11 to administer entitlements;

(12) 'distribution' means a payment made from the Reserve to holders
pursuant to Article 10;

(13) 'shareholder extraction' means, in respect of a covered undertaking
and a period, the aggregate value transferred by it to its shareholders, to
undertakings within the same group, to persons controlling it and to persons
connected with any of them, a person being connected where the same natural
persons hold, directly or indirectly, the majority of the economic rights in
both, comprising:
(a) dividends and other distributions, consideration paid for the
repurchase or redemption of its own shares, and reductions of capital paid
out;
(b) repayments of principal on debt owed to any such person, and loans made
to and claims acquired on any such person to the extent not repaid or
realised within twelve months;
(c) interest on such debt, and payments for the use of intellectual
property, for management and for other services rendered by any such
person, in each case to the extent that the payment exceeds what would
have been agreed between independent undertakings;

(14) 'automated assets' means the software systems referred to in point (3),
the model parameters, training and inference infrastructure, data sets and
intellectual property rights on which the provision of the goods or services
referred to in Article 3(1)(a) principally depends.

---

Drafting notes (non-normative). Definitions carry no obligations (JPG G14).
Point (3) ties to the AI Act definition rather than inventing one
(acquis-coherence). Point (6)(c)'s 20 % secondary-sale trigger prevents
crystallisation avoidance by staged private sales. Point (8) implements
DC-11 substance-over-form headcount. Points (13) and (14) serve Article 5's second and third crystallisation
triggers and the succession rule: an undertaking that never sells itself
can still pay itself, and the assets that carry the value are nameable.
Point (13)(b) exists because hostile counsel, given the first draft,
answered that it would simply stop paying dividends and take the cash out
as royalties, management fees and intercompany interest instead. The test is therefore value transferred above arm's length, whatever the
payment is called; the arm's-length standard is the one transfer pricing
already uses, so the evidence is the evidence a tax authority would ask
for. Point (b) stands apart from that standard because counsel's second
answer was to lend the money in and take it out again as principal, which
is arm's length in every particular and drains the undertaking all the
same. Repayment to an insider is therefore extraction outright. Counsel's next
answer was to reverse the direction, lending the undertaking's own cash
upstream to the parent and never calling it back, so point (b) covers
lending out as well as paying back: cash that leaves for a related pocket
and stays there for a year is cash that left, whichever way the promissory
note points. This is the numerator for Article 5(3)(a): shareholder
extraction, as defined here, is measured against covered turnover alone.
A paid-in-capital limb was deleted from Article 5(3)(a) after outside
money proved able to inflate it (see the drafting notes to Article 5),
so what money is put in by outsiders no longer matters to the threshold;
only what insiders take out does. 'Fair market value' is needed for
Article 3 designation, not for warrant pricing, which is event-priced.


# SOURCE: own-the-machine/regulation/articles/03-designation.md

# Article 3: Designation of covered undertakings

1. An undertaking shall be designated as a covered undertaking where:
(a) it provides automated cognitive services, or goods or services whose
production depends to a significant extent on automated cognitive systems,
in the internal market;
(b) the economic output of the undertaking is substantially decoupled from
its employment of labour; and
(c) the position referred to in points (a) and (b) is durable.

2. An undertaking shall be presumed to satisfy: (a) point (a) of paragraph
   1, where it achieves an annual Union turnover equal to or above EUR 7,5
   billion, or where its fair market value amounts to at least EUR 75
   billion, and it provides the goods or services referred to in that point
   in at least three Member States; (b) point (b) of paragraph 1, where its
   fair market value equals or exceeds eighty times its annual worldwide
   compensation of labour, each calculated in accordance with Annex I; (c)
   point (c) of paragraph 1, where the thresholds in points (a) and (b) of
   this paragraph were met in each of the last two financial years.

3. Where an undertaking meets all the thresholds laid down in paragraph 2,
it shall notify the Commission thereof within two months after those
thresholds are met, providing the information listed in Annex I. A failure
to notify shall not prevent designation on the basis of the facts
available to the Commission.

4. The Commission shall, without undue delay and at the latest 45 working
days after receiving the complete information referred to in paragraph 3,
designate by decision the undertaking as a covered undertaking.

5. The undertaking may, with its notification, present sufficiently
substantiated arguments demonstrating that, exceptionally, although it
meets all the thresholds in paragraph 2, it does not satisfy the
requirements of paragraph 1. Those arguments shall be taken into account
only where they manifestly call the presumption into question; arguments
based on the definition of the relevant market shall not be taken into
account. Where such arguments require detailed assessment, the Commission
may open a market investigation pursuant to Article 4(1) instead of
designating within the period laid down in paragraph 4.

6. The Commission may designate as a covered undertaking any undertaking
that satisfies the requirements of paragraph 1 without meeting the
thresholds of paragraph 2, following a market investigation conducted
pursuant to Article 4.

7. The obligations laid down in this Regulation shall apply to a covered
undertaking irrespective of whether its shares are admitted to trading, and
designation shall precede any liquidity event wherever the thresholds of
paragraph 2 are met before that event.

8. An undertaking shall not segment, divide, combine or restructure its
   activities, or acquire or dispose of undertakings, where the main purpose
   or one of the main effects thereof is to avoid meeting the thresholds
   laid down in paragraph 2. The Commission shall disregard any such
   arrangement when applying this Regulation, and shall likewise disregard
   any transaction, arrangement or attribution which artificially increases
   the compensation of labour or artificially reduces the fair market value
   referred to in point (b) of paragraph 2. An increase in remuneration for
   genuine work, including an increase without additional hours or employees,
   or a reduction in value supported by an independent transaction or
   valuation satisfying Annex I, shall not be disregarded solely because it
   changes the ratio referred to in that point. The third sentence of this paragraph shall not
   prevent the application of the first sentence to acquisitions, disposals
   or restructuring arrangements.

9. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex I where necessary to
reflect technological and market developments. Those delegated acts shall
not amend the thresholds laid down in paragraph 2.


---

Drafting notes (non-normative). Repair candidate of 7 September 2026.
See proposals/2026-09-07-generational-repairs/README.md for the issue,
constraints, policy choices and review status. Earlier drafting history
is preserved in Git and the immutable review bundles.


# SOURCE: own-the-machine/regulation/articles/04-review-of-designation.md

# Article 4: Market investigation and review of designation

1. The Commission may conduct a market investigation for the purpose of
Article 3(6). It shall conclude the investigation within 12 months by a
decision designating the undertaking or closing the investigation.

2. The Commission shall review each designation at least every three years,
and whenever the covered undertaking so requests on the basis of a
substantial change in the facts on which the designation was based.

3. The Commission shall repeal a designation where the covered undertaking
has not satisfied the requirements of Article 3(1) for two consecutive
financial years. Repeal shall not be granted where the failure to satisfy
those requirements results from an arrangement referred to in Article 3(8). Repeal shall not affect a citizens' capital warrant
already issued, save that a warrant shall lapse five years after repeal if
it has not crystallised by that date.

4. Before adopting a decision under this Article or under Article 3, the
Commission shall communicate its preliminary findings to the undertaking
concerned and give it the opportunity to be heard within a period of not
less than 20 working days.

---

Drafting notes (non-normative). Paragraph 2 mirrors DMA Article 4. Paragraph
3's lapse rule prevents a repealed designation from carrying a perpetual
contingent claim, which proportionality review would punish; five years
balances avoidance (de-designate, then list) against indefiniteness. The
right to be heard in paragraph 4 answers a due-process line of attack before
it is made. Hostile counsel round 2 built a permanent-immunity chain through this
Article (designate, dilute the ratio by acquisition, obtain repeal, wait out
the lapse, spin off and list). Three links are now cut: the acquisition is
an Article 3(8) arrangement and is disregarded across the Regulation, repeal
is unavailable where the change results from such an arrangement, and
Article 5(1) limits the one-warrant rule to the same designation, so
re-designation after a genuine repeal carries a fresh warrant.


# SOURCE: own-the-machine/regulation/articles/05-warrant.md

# Article 5: The citizens' capital warrant

1. A citizens' capital warrant shall arise in favour of the Reserve by
operation of law on the date on which designation of a covered undertaking
takes effect. References in this Article to designation shall mean that effective
date. The covered undertaking shall issue the instrument recording that warrant
within three months of designation. Failure or delay in issuing the
instrument shall not postpone the attachment or crystallisation of the
warrant. No more than one warrant shall arise in respect of the same
designation, without prejudice to paragraphs 11 and 12.

2. The citizens' capital warrant shall entitle the Reserve, upon the first
liquidity event following designation or upon crystallisation under paragraph
3, whichever occurs first, and upon no other occasion, to subscribe at
nominal value for newly issued shares representing 3 % of the fully diluted
capital of the covered undertaking determined immediately before that event
or, in the case of paragraph 3, immediately before the date of
crystallisation.

3. The citizens' capital warrant shall also crystallise, and shall be
exercisable on the same terms, where either of the following occurs before
a liquidity event:
(a) shareholder extraction by the covered undertaking in any period of
three consecutive financial years exceeds 25 % of its turnover from the
goods and services referred to in Article 3(1)(a) over the same period;
(b) seven years have elapsed since the date on which the warrant arose.

For a warrant arising under paragraph 11 or 12, the period referred to in
point (b) shall run from the date on which the warrant of the original
covered undertaking arose. A transfer or a fresh recording instrument
shall not restart that period.

Crystallisation under this paragraph shall take effect on the last day of
the financial year in which the condition is met, and the valuation under
Article 6 shall be performed as at that date.

4. The citizens' capital warrant shall:
(a) confer no voting rights, no rights of information beyond those provided
in this Regulation and no right to participate in the management of the
covered undertaking;
(b) entitle the Reserve to shares which rank, as regards dividends, other
distributions and the proceeds of any sale, liquidation or winding up,
equally with the class of shares ranking most favourably in those respects
among the classes created after the designation of the covered
undertaking, and otherwise equally with its ordinary shares, without
affecting the ranking of claims of creditors;
(c) be incapable of settlement in cash or in assets other than the shares
referred to in paragraph 2;
(d) be non-transferable, save to a successor of the Reserve established by
Union legislative act;
(e) confer no right to require subscription before the first liquidity
 event following designation or crystallisation under paragraph 3,
 whichever occurs first. This point shall not limit any issuance,
 notification, information, valuation or anti-avoidance obligation laid
 down in this Regulation.

Shares subscribed pursuant to the citizens' capital warrant shall be
non-voting for as long as they are held by the Reserve.

5. The right to the subscription referred to in paragraph 2 shall vest by
operation of law at the completion of the liquidity event or on the date of
crystallisation under paragraph 3. The number of shares to be subscribed
shall be determined by the valuation under Article 6, and the subscription
shall be executed accordingly. Where the law
governing the covered undertaking does not give effect to the first
sentence, the covered undertaking shall procure a subscription of
 equivalent effect within the execution period laid down in this paragraph.
 It shall put in place the arrangements necessary to secure that result
 no later than the liquidity event or the date of crystallisation under
 paragraph 3; those arrangements shall provide for the share count to be
 fixed by the valuation under Article 6. The dilution resulting from the subscription shall not
exceed the percentage laid down in paragraph 2. The covered undertaking shall execute the
subscription within 20 working days of the delivery of the valuation
referred to in Article 6, and the Reserve shall pay up the shares in full
in cash at their nominal value upon execution.

6. A covered undertaking shall notify the Reserve and the Commission of any
impending liquidity event no later than the earlier of its public
announcement and 30 working days before its completion. Where an event
cannot reasonably be known by that deadline, the undertaking shall notify
it without undue delay after becoming aware of it, stating the reasons why
earlier notification was not possible. The burden of establishing those
reasons shall rest on the undertaking. A notification shall not be a
condition for crystallisation.

The undertaking shall notify the Reserve and the Commission of
crystallisation under paragraph 3 within five working days of the end of
the relevant financial year. It shall provide its extraction calculation
and supporting management records, without awaiting annual audit, and
correct them without undue delay when audited information is available.
The Commission shall appoint the valuer in time for the deadline in
Article 6(3), using provisional information where necessary. The undertaking
shall provide that valuer with the capital and transaction records needed
for the valuation. Correction of the information shall not postpone the
original crystallisation date or exclude a correction under Article 6(4).

7. Article 49, Article 68(1), (2) and (3), the first subparagraph of
Article 70(2), Article 72 and Article 73 of Directive (EU) 2017/1132, and
any
corresponding provisions of the law of a Member State conferring
pre-emption rights, requiring a decision of the general meeting or
requiring an expert report on consideration, shall not apply to the
issuance of the citizens' capital warrant or to the subscription of
shares pursuant to it. Provisions of the law of a Member State restricting the
proportion, issuance conditions or characteristics of non-voting shares
shall not apply to the extent that they would prevent the issuance or
holding of shares pursuant to this Article.

8. The issuance of the citizens' capital warrant and the issuance, offer
and subscription of shares pursuant to this Article shall not constitute an
offer of securities to the public for the purposes
of Regulation (EU) 2017/1129, and the admission to trading of those shares
shall be exempt from the obligation to publish a prospectus under that
Regulation where shares of the same class are already admitted to trading
on the same regulated market.

9. The valuation of the fully diluted capital for the purposes of paragraphs
2 and 3 shall be performed by an independent valuer appointed in accordance
with Article 6, and shall be open to challenge before the courts in
accordance with Article 7 separately from any other element of the
designation or the event.

10. An arrangement that subordinates, reduces or defeats the economic
participation conferred by this Article shall not be effective as against
the Reserve, which shall be placed in the position it would have occupied
had the arrangement not been made; the arrangement shall remain effective
between the parties to it and as against third parties. In particular, the
issuance of shares ranking ahead of those held or subscribable by the
Reserve, any alteration of the rights attaching to any class of shares, and
any reorganisation of capital shall be of no effect as against the Reserve
to the extent that its main purpose or one of its main effects is to place
the Reserve in a position less favourable than that provided for in
paragraph 4(b).

The first subparagraph shall not apply to an issuance of shares or other
instruments for new consideration in money or money's worth, at arm's
length, to persons who are not members of the same group as the covered
undertaking, do not control it, are not connected with it and are not acting
in concert with any person who controls it, where at the time of the
issuance the covered undertaking is in a likelihood of insolvency within the
meaning of Directive (EU) 2019/1023 or the issuance is necessary to comply
with a prudential requirement under Union law, and only to the extent of the
new consideration provided. To the extent that the preference, ranking or
other advantage conferred by the issuance exceeds the new consideration
provided, the first subparagraph shall apply to the excess. The covered
undertaking shall bear the burden of establishing that the conditions of
this subparagraph are met.

11. Where a covered undertaking transfers automated assets to another
undertaking, whether by sale, contribution, licence, demerger, division or
otherwise, where the transfer, alone or together with related arrangements,
confers in substance the economic benefit of the automated assets on the
transferee, and the transfer is not made at arm's length or the transferee is
a member of the same group or is controlled, directly or indirectly, by
persons who control the covered undertaking, the transferee shall issue to
the Reserve a citizens' capital warrant within three months of the transfer as if
it were a covered undertaking. The warrant shall arise on the date of the
transfer. The obligations of the covered undertaking
under this Article shall continue in respect of the automated assets it
retains. The aggregate of the subscriptions to which the Reserve is entitled
in respect of the same designation, under this paragraph and under paragraph
2, shall not exceed the percentage laid down in paragraph 2 of the combined
fully diluted capital of the covered undertaking and of every transferee, and
the valuation under Article 6 shall determine the subscription in each of
them accordingly.

Paragraphs 2 to 10 and Articles 6, 7 and 13 shall apply to the transferee
as they apply to a covered undertaking. For paragraph 2, references to
designation shall mean the date of transfer; the original date shall
continue to apply to ranking under paragraph 4(b). Where the original warrant has
already crystallised, or its paragraph 3 date has been reached, the
transferee's warrant shall crystallise on the transfer date. The aggregate
cap in the first subparagraph shall take account of shares already
subscribed in respect of that designation.

The obligations of a transferee under this paragraph shall arise irrespective of
whether the transferee meets the conditions laid down in Article 3, and this
paragraph shall apply to any onward transfer of the automated assets by a
transferee as it applies to a transfer by a covered undertaking. For the
purposes of the valuation under Article 6, the value of the fully diluted
capital of the transferee shall reflect the automated assets at the value
they would have had on a transfer at arm's length.

12. Where the automated assets of a covered undertaking are acquired by
another undertaking in or in consequence of insolvency proceedings, a
restructuring procedure, including a procedure under Directive (EU)
2019/1023, or any comparable procedure, and, upon completion, the
transferee is controlled directly or indirectly by persons who controlled
the covered undertaking, or those persons hold, directly or indirectly, the
majority of the economic rights in the transferee, the obligations under
this Article shall attach to
the transferee as if it were the covered undertaking, and the transferee
shall issue a citizens' capital warrant afresh within three months of the
completion of the acquisition. The warrant shall arise on completion of
the acquisition, or on the later acquisition of control referred to in the
second subparagraph. Paragraphs 2 to 10 and Articles 6, 7 and 13 shall
apply to the transferee. The clock, crystallisation on transfer and
aggregate-cap rules in paragraph 11 shall apply correspondingly.

For the purposes of this paragraph, persons acting in concert with those
who controlled the covered undertaking, and persons connected with them,
shall be treated as those persons; and where any of them acquires control
of the transferee, at any time while it holds the automated assets, the
obligations under this Article shall attach to the transferee from the date
of that acquisition.

This paragraph shall not otherwise apply where control of the transferee
is acquired by persons who did not control the covered undertaking, and in
that case the extinguishment of a warrant in such a procedure shall give
rise to no obligation under this Article.


---

Drafting notes (non-normative). Repair candidate of 7 September 2026.
See proposals/2026-09-07-generational-repairs/README.md for the issue,
constraints, policy choices and review status. Earlier drafting history
is preserved in Git and the immutable review bundles.


# SOURCE: own-the-machine/regulation/articles/06-valuation.md

# Article 6: Independent valuation

1. The valuation referred to in Article 5(9) shall be performed by a valuer
who is independent of the covered undertaking, of the Reserve and of any
party to the liquidity event, appointed by the Commission from a list
established after an open call. The Commission shall establish the list and
the criteria and rotation governing appointments from it by means of
implementing acts, adopted in accordance with the examination procedure
referred to in Article 16(2). An individual appointment shall be made by
decision of the Commission in accordance with those criteria and that
rotation, and shall not require that procedure.

2. The valuation shall determine the fully diluted capital of the covered
undertaking immediately before the liquidity event or, in the case of
crystallisation under Article 5(3), immediately before the date of
crystallisation, in accordance with internationally accepted valuation
standards and, where an event itself establishes a price, on the basis of
that price.

3. The valuer shall deliver the valuation within 20 working days of the
completion of the liquidity event or of the date of crystallisation under
Article 5(3). The costs of the valuation shall be borne by the
covered undertaking.

4. Where a court finds, pursuant to Article 7, that the valuation
overstated the fully diluted capital, the Reserve shall transfer back to
the covered undertaking, or cancel, the shares subscribed in excess of the
percentage laid down in Article 5(2). Where a court finds that the
valuation understated it, the covered undertaking shall issue the missing
shares to the Reserve.

5. A challenge to the valuation shall not suspend the liquidity event, the
crystallisation or the subscription.

---

Drafting notes (non-normative). The BRRD pattern (Article 36) adapted:
independent valuer, event-price primacy, ex-post correction rather than
ex-ante blockage. Paragraph 4 makes DC-29 executable in both directions,
which is what converts the safeguard from assertion into machinery, per
Aeris Invest. Paragraph 5 protects transactions from hold-up litigation, the same policy
as resolution law. Round 2 moved delivery to after completion: where the
event itself establishes the price, the valuation is arithmetic on that
price, and demanding it before pricing invited deserved ridicule; legal
effect still attaches at completion under Article 5(5), with execution
following the valuation. The open point on the appointment mechanism was closed on 21 August 2026:
hostile counsel observed that an implementing act under Article 291 TFEU is
an act of general application, that using one for each individual
appointment is the wrong instrument, and that convening a committee for
each would break the 20-day deadline in Article 5(5). The list, the
criteria and the rotation are general and stay in the implementing act; the
appointment itself is administration and is made by decision.


# SOURCE: own-the-machine/regulation/articles/07-safeguards.md

# Article 7: Safeguards and judicial review

1. A challenge to the valuation referred to in Article 6 may be brought,
separately from any challenge to the designation, to the liquidity event or
to the crystallisation under Article 5(3),
before the courts of the Member State in which the covered undertaking has
its registered office or, where it has none in the Union, before the Court
of Justice of the European Union.

2. The dilution borne by the shareholders of a covered undertaking in
consequence of this Regulation shall not exceed the percentage laid down in
Article 5(2), determined on the basis of the valuation under Article 6 as
corrected, where applicable, pursuant to Article 6(4). Where warrants have
been issued by transferees pursuant to Article 5(11), that percentage
shall apply to the dilution borne, taken together, by the shareholders of the
covered undertaking and of every such transferee.

3. This Regulation shall not affect any right of shareholders to
compensation under the law of a Member State against parties other than
the Reserve.

---

Drafting notes (non-normative). The former paragraph restating the Article
263 TFEU remedy was deleted on the form gate's finding that secondary law
must not paraphrase remedies conferred by primary law; standing before the
Court needs no help from us. Paragraph 2 states the quantified ceiling the
proportionality recital relies on: the interference is the stated
percentage, no more, judicially verifiable and correctable in both
directions under Article 6(4). Satisfies DC-29 with Article 6; holders'
remedies sit in Article 12(4).


# SOURCE: own-the-machine/regulation/articles/08-reserve.md

# Article 8: The European Citizens' Capital Reserve

1. The European Citizens' Capital Reserve is established. The Reserve shall
have legal personality and shall enjoy in each Member State the most
extensive legal capacity accorded to legal persons under the law of that
Member State.

2. The Reserve shall hold its assets exclusively for the benefit of
holders. Its assets and income shall not constitute revenue of the Union or
of any Member State and shall not be entered in the general budget of the
Union or in any public budget.

3. The Reserve shall be financed exclusively by the instruments referred to
in Article 5, by the proceeds of their crystallisation and by the returns
on its assets. It shall receive no contribution from, and shall make no
payment to, the general budget of the Union or the budget of any Member
State.

4. The Reserve shall retain from its realised income in each financial year
the amount necessary to preserve the real value of its capital, calculated
in accordance with the methodology laid down in Annex II, and shall make
the remainder available for distribution pursuant to Article 10(6). No
distribution shall be financed by borrowing or by the disposal of holdings
effected for the purpose of the distribution.

5. The Reserve shall state in its accounts, for each financial year, the
amount of tax withheld at source which it was unable to recover, and the
Commission shall address that amount in the report referred to in Article
14(2).

6. The Reserve shall publish annually audited accounts, the valuation of
its holdings and the calculation referred to in paragraph 4.

7. The Reserve shall not be considered an investment firm within the
meaning of Directive 2014/65/EU, an alternative investment fund or an
alternative investment fund manager within the meaning of Directive
2011/61/EU, or an institution for occupational retirement provision within
the meaning of Directive (EU) 2016/2341.

8. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex II where necessary
to preserve the real value of the capital of the Reserve in the light of
market developments.

---

Drafting notes (non-normative). Drafted in response to hostile counsel's
lead attack, the fiscal characterisation of the warrant as a corporate tax.
Paragraphs 2 and 3 make the non-fiscal structure operative rather than
asserted: no value ever becomes public revenue, enters any budget or is
available to any treasury, in either direction. The closest legal cousins
are statutory funded pension schemes, whose compulsory contributions are not
taxes in Union law because they fund segregated property held for
beneficiaries. Sectoral classification under ESA belongs to statisticians
and is deliberately not legislated here. Paragraph 4 is the Norway spending
rule generalised (retain enough to preserve real capital, distribute the
rest), which also enforces DC-14: distributions grow with the portfolio and
start small. Governance, passivity at Reserve level and prohibited conduct
are Article 9, still reserved; the non-voting rule already binds via
Article 5(4). The retention methodology is Annex II, amendable
under the paragraph 8 empowerment via Article 15. Satisfies DC-4, DC-5, DC-14, DC-19 in part, DC-24.


Drafting note on paragraph 5 (non-normative). A first draft permitted the
Reserve to hold third-country assets through national vehicles where that
reduced taxation at source. It was struck on 21 August 2026 after hostile
counsel offered the headline: a Union fund with a statutory mandate to
arrange its affairs for a lower withholding rate, published by the Union
that blacklists other people for the same thing. An instrument whose case
is that capital should be broadly owned cannot codify treaty shopping for
itself. What remains is the duty to publish the tax it could not recover,
which is the part that lets anyone judge the cost.


# SOURCE: own-the-machine/regulation/articles/09-prohibited-conduct.md

# Article 9: Prohibited holdings and conduct of the Reserve

1. The Reserve shall not:
(a) exercise, directly or indirectly, any voting right attached to any
share it holds;
(b) seek or accept representation in the administrative, management or
supervisory bodies of any undertaking;
(c) give instructions, formally or informally, to any undertaking in which
it holds an interest;
(d) acquire an interest in any undertaking otherwise than pursuant to
Article 5, by reinvestment of its income or by prudent diversification of
crystallised holdings;
(e) borrow, save for temporary liquidity purposes not exceeding 2 % of the
value of its assets and save for the payment of subscription amounts under
Article 5(5), which borrowing shall be repaid from the first realised
income of the Reserve;
(f) grant loans or guarantees;
(g) enter into derivative contracts, save for hedging currency risk on
assets it holds.

2. The Reserve shall manage its holdings with the sole objective of
long-term preservation and growth of value for the benefit of holders.

---

Drafting notes (non-normative). The statutory passivity of DC-13 at the
level of the institution, accepting the Bebchuk cost deliberately per
objection 6; the Greek overcorrection is avoided because passivity here
constrains conduct, not the citizens' claim. Points (e) to (g) close the
leverage and derivative channels that would let a future management
financialise the Reserve. Point (d) permits index-style diversification
after crystallisation, the Norwegian practice, without permitting empire
building.


# SOURCE: own-the-machine/regulation/articles/10-entitlement.md

# Article 10: The citizens' entitlement

1. Every citizen of the Union who has attained the age of 18 years shall hold an
entitlement under this Regulation.

2. The entitlement shall arise by operation of law. It shall not be subject to
any condition relating to income, wealth, employment, contribution history
or any other personal circumstance, nor to any application, save
registration for payment purposes with a national vehicle.

3. All entitlements shall be equal. No act of the Union or of a Member State
shall differentiate between holders in the amount distributed per holder in
respect of the same period.

4. The entitlement shall comprise:
(a) the right to an equal share of every distribution declared by the
Reserve in respect of a period during which the holder was living and met
the condition in paragraph 1; and
(b) the right to have undistributed amounts standing to the holder's
account with a national vehicle treated as the holder's property, which
shall be inheritable in accordance with the law applicable to succession.

5. The entitlement referred to in paragraph 4(a) shall be personal to the holder.
It shall be incapable of assignment, pledge, attachment or seizure, and it
shall not be capable of surrender or redemption against payment.

6. The Reserve shall declare a distribution in each calendar year in which
the distributable amount would provide each holder with not less than ten
times the average cost of executing one payment to a holder, calculated in
accordance with Annex II, and in any event not less often than once in
every third calendar year in which the distributable amount is greater
than zero. An amount not distributed by reason of this paragraph
shall be retained, shall form part of the capital of the Reserve and shall
be distributed in the next distribution. Distributions shall be paid
through national vehicles into the individual account of each holder.

7. In each year in which no distribution is declared, the Reserve shall
publish the amount which would have been distributed per holder and the
value of the capital of the Reserve per holder.

---

Drafting notes (non-normative). Paragraphs 1 to 3 are the universality test
with no means test and no committee: acquisition by operation of law closes
every discretionary gate (DC-24). Paragraph 5 answers Estonia: there is no
exit to take, which is stronger than forfeiture, while paragraph 4(b)
preserves the Danish lesson that what has been distributed into a named
account is real, inheritable property (DC-22 as interpreted: the lifetime
unit is per-person and equal across a generation, so it is not heritable;
accrued amounts are). Paragraph 6 keeps DC-14 while answering the objection that paying a few
cents to 350 million accounts spends a disproportionate share of the
payment on making it: the interval lengthens, the money does not
disappear, and it compounds in the Reserve until it is paid. The
three-year backstop is what stops a de minimis from becoming a reason
never to pay; paragraph 7 is DC-31 applied to the years of silence, so
that a citizen who receives nothing is still told what is held for
them.
Open points for the editor, flagged deliberately: whether long-term
resident third-country nationals are included (political choice; Union
citizens only is the current draft), the age threshold, and whether a
minimum retention rule belongs here or in Article 8 (currently Article 8,
reserved).


# SOURCE: own-the-machine/regulation/articles/11-national-vehicles.md

# Article 11: National vehicles

1. Each Member State shall designate, within 12 months of the entry into
force of this Regulation, one or more national vehicles to administer
entitlements. Existing institutions within the meaning of Directive (EU)
2016/2341, providers within the meaning of Regulation (EU) 2019/1238 and
statutory funds may be designated. By way of derogation from Article 7 of
Directive (EU) 2016/2341, an institution designated as a national vehicle
may carry out the account administration and distribution activities
provided for in this Regulation. A provider within the meaning of
Regulation (EU) 2019/1238 designated as a national vehicle shall maintain
holders' accounts separately from any product governed by that Regulation,
and the requirements of that Regulation shall not apply to those accounts.

2. A national vehicle shall:
(a) maintain an individual account in the name of each holder registered
with it;
(b) credit distributions to holders' accounts without deduction other than
charges permitted under paragraph 3;
(c) treat amounts standing to a holder's account as the holder's property
in accordance with Article 10(4)(b);
(d) apply no condition of access other than identity and the condition in
Article 10(1).

3. Charges levied by a national vehicle on holders shall not exceed the
costs actually incurred in administering the accounts and in any event
0,3 % annually of the amounts administered. A Member State may compensate a
national vehicle for verifiable net costs exceeding that ceiling; such
compensation shall not be charged to holders or to the Reserve.

4. Where a Member State has not designated a national vehicle, or where the
designated vehicle does not comply with paragraph 2, a holder residing in
that Member State may register with a national vehicle of another Member
State, which shall not refuse the registration on grounds of residence.
Where a national vehicle registers a holder pursuant to this paragraph, the
Member State of residence of that holder shall reimburse that national
vehicle for verifiable net costs exceeding the ceiling laid down in
paragraph 3.

5. National vehicles shall process personal data in accordance with
Regulation (EU) 2016/679 and only for the purposes of this Regulation.

---

Drafting notes (non-normative). DC-7 and DC-28 as law: Union standards,
national custody, existing rails expressly reusable. Paragraph 3 caps
administration charges because fee extraction is the quiet raid nobody
legislates against; 0,3 % tracks low-cost pension administration.
Paragraph 4 is the sabotage-by-inaction answer: a Member State that refuses
to build the rail cannot thereby disenfranchise its citizens, and
portability follows the PEPP logic. Paragraph 5 grounds the EDPS recital
required by the research checklist.


# SOURCE: own-the-machine/regulation/articles/12-protection.md

# Article 12: Protection of the Reserve and of entitlements

1. The assets of the Reserve and the entitlements of holders shall not be
cancelled, written down, compulsorily redeemed, seized, transferred,
suspended, lent, encumbered or otherwise applied, in whole or in part, for
the benefit of the general budget of the Union, of any Member State or of
any public body, by any act of the Union or of a Member State.

2. The Reserve shall not acquire or hold, directly or indirectly, debt
instruments issued or guaranteed by the Union, by a Member State, by a
regional or local authority of a Member State, by a central bank or by any
body the obligations of which are guaranteed by any of them.

3. This Regulation shall not be interpreted as authorising any authority
of the Union or of a Member State to derogate from paragraphs 1 and 2.

4. Every holder, and every national vehicle acting for its holders, shall
have the right to an effective remedy before a court or tribunal against
any act or omission infringing this Article, in accordance with Article 47
of the Charter of Fundamental Rights of the European Union.

---

Drafting notes (non-normative). Drafted clause by clause against the actual
raid statutes. Paragraph 1's enumerated verbs track the Polish Act of 6
December 2013, Article 23(1), which cancelled units; cancellation is named
first. Paragraph 2 removes the self-dealing channel that made the Polish
raid worth executing, where Article 23(2) took the Treasury bonds first
(DC-19). Paragraph 3 is DC-21: Ireland's NPRF was raided lawfully through
its own emergency machinery, so this instrument has none. Paragraph 3
went through three drafts under the gates. Binding future legislatures
failed round 1; binding the Commission's right of initiative failed round 2
(Article 17 TEU institutional balance); what remains is the one thing an
ordinary Regulation can say, an interpretive rule, with the
assessment-of-holders duty relocated into the Commission's own reporting
under Article 14(4), which is ordinary review-clause territory. The former
Charter-possessions declaration was likewise deleted: secondary law cannot
define the scope of primary law, so that argument lives in the recitals and
the memorandum. Paragraph 4 remains the real lock: it converts the promise into
individual property, so that a future Polish-style statute meets Article 17
Charter litigation by millions of holders rather than a budget-line debate
(the exact channel Poland exploited was that OFE units were claims on the
state; these are not, per paragraph 2). Greece's HCAP is the overcorrection
this chapter avoids: protection is achieved without placing the asset
beyond citizens' reach. Satisfies DC-19, DC-21, DC-22, DC-23 and DC-20 as amended (a Regulation cannot prescribe voting thresholds for future legislatures, so the constraint now demands express amendment, a published independent assessment and honesty about the limits).


# SOURCE: own-the-machine/regulation/articles/13-penalties.md

# Article 13: Penalties

1. The Commission may by decision impose on a covered undertaking or an
undertaking bound under Article 5(11) or (12) fines not
exceeding 10 % of its total worldwide turnover in the preceding financial
year where it finds that the undertaking, intentionally or negligently:
(a) fails to issue the citizens' capital warrant in accordance with
Article 5(1), (11) or (12);
(b) fails to execute or procure the subscription, or to put in place the
arrangements securing it, in accordance with Article 5(5);
(c) fails to notify an event or crystallisation, or to provide or correct
information required under Article 5(6);
(d) supplies incorrect, incomplete or misleading information under
Article 3(3) or Article 4;
(e) circumvents Article 3(8), or fails to comply with a decision adopted
pursuant to that paragraph.

2. The Commission may by decision impose periodic penalty payments not
exceeding 5 % of the average daily worldwide turnover of the undertaking
concerned in the preceding financial year for each day of continued
non-compliance, in order to compel compliance with the obligations
referred to in paragraph 1.

3. Where an undertaking referred to in paragraph 1 that is not established
in the Union
persistently fails to comply with the obligations referred to in points
(a) and (b) of paragraph 1, the Commission may by decision, as a measure
of last resort and for no longer than the non-compliance persists,
prohibit the making available of the goods and services referred to in
point (a) of Article 3(1) on the internal market by that undertaking.

4. In fixing the amount of a fine or periodic penalty payment, the
Commission shall have regard to the gravity, duration and recurrence of
the infringement. Before adopting a decision under this Article, the
Commission shall give the undertaking the opportunity to be heard.

5. The Court of Justice of the European Union shall have unlimited
jurisdiction within the meaning of Article 261 TFEU to review decisions
under this Article and may cancel, reduce or increase the fine or periodic
penalty payment imposed.

6. Fines and periodic penalty payments imposed under this Article shall
accrue to the general budget of the Union. They shall not accrue to the
Reserve.


---

Drafting notes (non-normative). Repair candidate of 7 September 2026.
See proposals/2026-09-07-generational-repairs/README.md for the issue,
constraints, policy choices and review status. Earlier drafting history
is preserved in Git and the immutable review bundles.


# SOURCE: own-the-machine/regulation/articles/14-monitoring-review.md

# Article 14: Monitoring and evaluation

1. The Commission shall monitor, on the basis of data published by the
   European Central Bank, Eurostat and the national statistical institutes:
   (a) the diffusion of automated cognitive systems among undertakings in
   the Union; (b) the distribution of household holdings of equity
   instruments in the Union; (c) the share of value added accruing to labour
   and to capital in the sectors in which covered undertakings operate; (d)
   the number of designations, crystallisations and distributions under this
   Regulation and their amounts; (e) the evolution of the share of Union
   gross value added accruing to compensation of employees, as published by
   the Commission (Eurostat), relative to the year 2025, together with the
   Commission's assessment of the contribution of automated cognitive
   systems to any change in either direction.

2. By 31 December 2032, and every three years thereafter, the Commission
shall evaluate this Regulation and submit a report to the European
Parliament, the Council and the European Economic and Social Committee.

3. The report shall state, on the basis of the indicators in paragraph 1,
whether the premise of this Regulation that gains from automated cognitive
systems accrue disproportionately to the holders of the systems remains
supported by the evidence. Where the report finds that the share of
undertakings referred to in point (a) of paragraph 1 exceeds one quarter
and that neither the indicator in point (b) nor the indicator in point (c)
of that paragraph shows the concentration the premise predicts, the report
shall say so expressly and shall be accompanied, where appropriate, by a
proposal for the amendment or repeal of this Regulation.

4. Where a report under paragraph 2 accompanies or precedes a proposal for
the amendment of Article 5, Article 8, Article 10 or Article 12, it shall
include an independent assessment of the effect of the proposal on the
entitlements of holders.

5. The report shall be published.

---

Drafting notes (non-normative). Paragraph 3 is DC-18, the stated
falsification condition, as an operative reporting duty: the Regulation
instructs its own evaluator to declare its premise unsupported if the
evidence goes the other way, and to propose amendment or repeal. No
instrument in the acquis does this explicitly; it is the Stable's
publish-what-contradicts-us discipline written into law, and the
memorandum should present it as such. The indicators map to the evidence
base: ECB HFCS and DWA for (b), the sectoral accounts for (c).


# SOURCE: own-the-machine/regulation/articles/15-delegation.md

# Article 15: Exercise of the delegation

1. The power to adopt delegated acts is conferred on the Commission subject
to the conditions laid down in this Article.

2. The power to adopt delegated acts referred to in Article 3(9) and
Article 8(8) shall be
conferred on the Commission for a period of five years from the entry into
force of this Regulation. The Commission shall draw up a report in respect
of the delegation of power not later than nine months before the end of
the five-year period. The delegation of power shall be tacitly extended
for periods of an identical duration, unless the European Parliament or
the Council opposes such extension not later than three months before the
end of each period.

3. The delegation of power referred to in Article 3(9) and Article 8(8)
may be revoked at
any time by the European Parliament or by the Council. A decision to
revoke shall put an end to the delegation of the power specified in that
decision. It shall take effect the day following the publication of the
decision in the Official Journal of the European Union or at a later date
specified therein. It shall not affect the validity of any delegated acts
already in force.

4. Before adopting a delegated act, the Commission shall consult experts
designated by each Member State in accordance with the principles laid
down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making.

5. As soon as it adopts a delegated act, the Commission shall notify it
simultaneously to the European Parliament and to the Council.

6. A delegated act adopted pursuant to Article 3(9) or Article 8(8) shall
enter into force
only if no objection has been expressed either by the European Parliament
or by the Council within a period of two months of notification of that
act to the European Parliament and the Council or if, before the expiry of
that period, the European Parliament and the Council have both informed
the Commission that they will not object. That period shall be extended by
two months at the initiative of the European Parliament or of the Council.

---

Drafting notes (non-normative). The standard six-paragraph article, CSDR
Article 67 pattern, verbatim where the convention is fixed. Both
conferrals, Annex I methodology (Article 3(9)) and Annex II methodology
(Article 8(8)), are listed in paragraphs 2, 3 and 6, per the convention
that every conferral is named in each of the three control paragraphs.


# SOURCE: own-the-machine/regulation/articles/16-committee.md

# Article 16: Committee procedure

1. The Commission shall be assisted by a committee. That committee shall be
a committee within the meaning of Regulation (EU) No 182/2011.

2. Where reference is made to this paragraph, Article 5 of Regulation (EU)
No 182/2011 shall apply.

---

Drafting notes (non-normative). Added in round 2 after hostile counsel
found the valuation machinery legally orphaned: Article 6(1) confers an
implementing task with no Article 291 TFEU basis. Standard two-paragraph
comitology article, examination procedure, GDPR-family pattern.


# SOURCE: own-the-machine/regulation/articles/17-transitional.md

# Article 17: Transitional provisions

1. An undertaking that meets the thresholds laid down in Article 3(2) on
the date of entry into force of this Regulation shall make the
notification under Article 3(3) within two months of that date.

2. Where the shares of a covered undertaking were admitted to trading
before the entry into force of this Regulation, that admission shall not
constitute a liquidity event. The citizens' capital warrant of such an
undertaking shall crystallise upon the first liquidity event within the
meaning of point (b) or point (c) of Article 2(6) occurring after its
designation, or upon crystallisation under Article 5(3), whichever occurs
first.

3. A liquidity event completed before the date of general application of
this Regulation shall not give rise to any obligation under Article 5.


---

Drafting notes (non-normative). Repair candidate of 7 September 2026.
See proposals/2026-09-07-generational-repairs/README.md for the issue,
constraints, policy choices and review status. Earlier drafting history
is preserved in Git and the immutable review bundles.


# SOURCE: own-the-machine/regulation/articles/18-final.md

# Article 18: Entry into force and application

1. This Regulation shall enter into force on the twentieth day following
that of its publication in the Official Journal of the European Union.

2. It shall apply from [OP: please insert the date 18 months after the
date of entry into force of this Regulation], with the exception of Articles 3, 4, 6(1), 8(1), 11(1), 15 and 16 and
Article 17(1), which shall apply from the date of entry into force for
preparatory administration. A designation decision adopted during that
period shall take effect on the date of general application. The period
under Article 5(3)(b) and the warrant under Article 5(1) shall arise no
earlier than that date. Liquidity events completed before that date shall
not crystallise a warrant. The Commission shall complete the initial
valuation appointment arrangements before that date.

3. This Regulation shall be binding in its entirety and directly applicable
in all Member States.


---

Drafting notes (non-normative). Repair candidate of 7 September 2026.
See proposals/2026-09-07-generational-repairs/README.md for the issue,
constraints, policy choices and review status. Earlier drafting history
is preserved in Git and the immutable review bundles.


# SOURCE: own-the-machine/regulation/memorandum/counter-arguments.md

# The case against this Regulation

Drafted first, before any article, on the discipline this project inherits: if
the instrument cannot survive this file, we fix the instrument, not the prose.
Each objection is stated in its strongest form, with its best sources. Each
ends with the design consequence it imposes. The consequences accumulate into
the constraints table at the end, which is the checklist the articles must
clear before anything else is written.

Objections marked **CONCEDED** are limits of the instrument that the
memorandum states plainly rather than argues away. That is not a courtesy. It
is what distinguishes a legal proposal from campaign copy, and it is the
entire credibility strategy of this project.

---

## A. Legal

### 1. This is expropriation

**The objection, at full strength.** A statutory requirement that undertakings
issue equity warrants to a public reserve takes property. Article 17 of the
Charter of Fundamental Rights protects the right to own, use and dispose of
lawfully acquired possessions, and permits deprivation only in the public
interest, in cases and under conditions provided for by law, and subject to
fair compensation paid in good time. A compulsory warrant dilutes existing
shareholders with no compensation at all; the dilution is the point. Article
345 TFEU adds that the Treaties shall in no way prejudice the rules in Member
States governing the system of property ownership. The Court has narrowed
Article 345 considerably, but a hostile Legal Service reading has ample
material, and shareholders of affected firms will litigate from day one.

**What it gets right.** A warrant requirement does transfer value from
existing shareholders to the reserve. Pretending dilution is not a taking of
value would be dishonest, and the memorandum must not do it.

**The answer the instrument must give.** Three structural choices, none
optional. First, the warrant must be drafted as a condition of access to the
Single Market for a defined category of undertaking, prospective and
uniform, in the family of regulatory obligations the Court has upheld when
proportionate (capital requirements, universal service obligations, DMA
gatekeeper duties), not as a seizure of existing holdings. Second, it must
apply only above high, objective thresholds, so proportionality review has
something to hold on to. Third, it must carry consideration: the reserve is a
passive, non-controlling holder, the warrant crystallises at the statutory liquidity, extraction or
elapsed-time triggers, and the covered undertaking receives the legal certainty of a single
harmonised regime in place of twenty-seven national experiments. Whether that
consideration is sufficient is the single largest legal risk in the project,
and Gate 1 exists to test it.

Two authorities belong in this file because a hostile reader will bring
them, and because each is less one-sided than it first appears. The first
is Strasbourg's rule that a deprivation without an amount reasonably
related to the value taken is normally disproportionate (James and Others
v United Kingdom, 1986). The same judgment holds, in the same breath, that
legitimate objectives of public interest, and expressly measures of
economic reform or measures designed to achieve greater social justice,
may warrant reimbursement at less than full market value. That is the
authority under which this instrument has to be argued, and it is
available on its terms rather than in spite of them: a 3 % dilution
crystallising at a statutory event, calibrated to a decoupling of
output from labour, is a measure of economic reform if anything is.

The second is Article 345 TFEU. It provides that the Treaties shall in no
way prejudice the rules in Member States governing the system of property
ownership, and the hostile reading is that a mandatory transfer of 3 % of
private enterprise value is a partial socialisation the Union may not
decree. That reading mistakes the addressee. Article 345 preserves the
Member States' freedom to choose between public and private ownership
against the Treaties; it is not a charter of immunity for property against
Union legislation, which is what Article 17 of the Charter governs and
what this memorandum answers under Article 52(1). The Court has read
Article 345 narrowly in precisely that direction, holding that a property
regime chosen by a Member State remains subject to the fundamental
freedoms (Essent, C-105/12 to C-107/12). The instrument leaves every
Member State's system of ownership exactly as it found it: the shares
subscribed are ordinary shares under national company law, held by an
owner with no special rights, and no national rule about who may own what
is displaced.

The drafting research (18 August) settled the architecture to use: BRRD is
the judicially validated template for interfering with equity by act of law
(Kotnik C-526/14, Ledra C-8/15 P, Aeris Invest C-535/22 P), and the
instrument adopts its machinery: an honest interference recital naming
Charter Article 17, a full proportionality recital under Article 52(1) of the Charter, and a
quantified executional safeguard with independent, separately challengeable
valuation. One adaptation is mandatory: BRRD's counterfactual is insolvency,
and a permanent regime cannot lean on crisis reasoning (Dowling C-41/15).
The distinction has to be stated rather than blurred: bank resolution
dilutes shareholders whose shares would be worth nothing in the
counterfactual insolvency, and these undertakings are healthy going
concerns whose shares are worth a great deal. BRRD is therefore borrowed
for its machinery, not for its justification, and this file does not
pretend otherwise; the justification is the one in James and in Hauer, and
it stands or falls on proportionality rather than on a crisis that is not
happening.

One further authority is worth stating precisely, because stated loosely it
would be worth nothing. In Sky Österreich (C-283/11, 22 January 2013) the
Grand Chamber upheld a Union measure requiring holders of exclusive
broadcasting rights to grant competitors access for short news reports,
with compensation capped at the additional costs directly incurred, which
is below what the market would pay. The rights-holders were solvent, there
was no crisis and no counterfactual insolvency. **That case was decided
under Article 16 of the Charter, the freedom to conduct a business, and not
under Article 17.** It is not authority for a taking of equity, and this
file does not offer it as one; hostile counsel would be entitled to
dismantle any such use of it, and would enjoy doing so.

What it does carry is narrower and still useful. This instrument interferes
with Article 16 as well as Article 17, because compelling an undertaking to
issue shares it did not choose to issue is an interference with the conduct
of its business, and the Commission's Legal Service will see both. On that
limb Sky Österreich is directly in point, and it says three things: the
Article 16 freedom is not absolute but must be viewed in relation to its
social function; the Union legislature may set consideration below market
value where the public interest requires it; and the test is the ordinary
Article 52(1) one. The older line supports the same reading of business
interests, which enjoy no protection as mere commercial expectations of
future profit (Nold 4/73). Booker Aquaculture (C-20/00 and C-64/00) is
sometimes cited alongside, and this file does not lean on it: it concerned
the destruction of diseased stock under an animal-health regime, which is a
public-emergency justification this instrument cannot claim.

The Article 17 limb therefore still rests where it rested, on James and on
Hauer, and the honest statement is that no decided case puts a permanent,
non-crisis, uncompensated equity dilution of a healthy undertaking on the
right side of Article 17. That is the largest legal risk in the project and
it is stated as such in the answer above. So
our floor is executional rather than counterfactual: the interference can
never exceed the stated 3 % in execution, its price is set by the
liquidity event itself under an independent and separately challengeable
valuation, and no application of the instrument may take more than the
interference it names. The doctrine underneath is older than any
of this: property in the Union legal order is not an unfettered prerogative
but is protected in its social function, and may be restricted in the
general interest where the restriction is proportionate and leaves the
right's substance intact (Hauer 44/79; Bosphorus C-84/95). The instrument's
restriction is quantified, event-bound and substance-preserving by
construction, which is what those cases require the legislature to show.

**Design consequence.** DC-1: prospective warrant on future value creation at
defined events, never retroactive transfer of existing shares. DC-2: high
group-consolidated thresholds. DC-3: passivity, and crystallisation only at
defined statutory events, never at a discretionary or political one, written
into the instrument itself.

### 2. This is a tax, and the EU may not levy it this way

**The objection, at full strength.** Call it a warrant; it functions as a
levy. Article 114(2) TFEU excludes fiscal provisions from internal market
harmonisation, so if the measure is fiscal in substance the chosen legal base
collapses; the honest bases would be Article 113 or 115, which require
unanimity in Council, which is unobtainable. The Commission has refused ECIs
that drift into own-resources territory, and the Legal Service reads substance,
not labels. The dividend side makes it worse: a recurring payment to every
adult, funded by an obligation on firms, looks like a tax-and-transfer scheme
wearing a corporate-finance costume.

**What it gets right.** The boundary is real and the characterisation battle
decides registrability. This is the objection most likely to kill the full ask
at Gate 1.

**The answer the instrument must give.** The measure must take nothing in
money from any undertaking in any year. No cash flows from firms to the state
at all. The reserve receives instruments, holds them, and distributes returns
on what it owns, exactly as any shareholder does. Dividends to citizens are
property income from an owned portfolio, not the proceeds of a levy: the
Norwegian fund's distributions are not a tax on anyone. The drafting must
police this line everywhere: no revenue-based charges, no minimum payments, no
cash-settlement options that would let the obligation collapse into a fee.
And the ask must be layered so that if the Legal Service still reads it as
fiscal, the severable outer layer (assess and propose instruments for citizen
participation in automated productivity gains) registers on its own.

Recalibration from the drafting research: registration is a lower hurdle
than this objection assumes. The test is "manifestly outside" the
Commission's powers (Reg 2019/788 Art 6(3)(c)), partial registration is
judicially established (C-899/19 P), and the Commission registered the EU
wealth-tax ECI in 2023. The characterisation fight is real but is fought in
Council, after registration. The layering therefore protects the campaign
moment; the warrant-not-levy drafting protects the instrument's life after
it.

**Design consequence.** DC-4: no monetary flow from undertakings; instruments
only. DC-5: distributions defined as property income of the reserve. DC-6:
severable layering for partial registration.

### 3. The Union has no competence to pay citizens a dividend

**The objection, at full strength.** Even if the warrant survives, the
dividend side has no home. The Union budget operates under an own-resources
ceiling; a Union body paying a recurring universal benefit to every adult has
no Treaty basis; social security design is a Member State competence; and
subsidiarity review would ask, fairly, why citizen accounts must be European
at all when Ireland, Denmark and the Netherlands run national systems that
work. Table 29 makes the point against us: pension funding runs from 49.1% in
the Netherlands to 0.0% in France. Systems this different cannot be
harmonised, and should not be.

**What it gets right.** The Union genuinely cannot and should not run
twenty-seven citizens' accounts from Brussels, and the proposal dies at
subsidiarity review if it tries.

**The answer the instrument must give.** Split the instrument along the
competence line. The Union harmonises what is genuinely single-market: which
undertakings issue warrants, on what terms, to what kind of reserve, with what
governance. Custody and distribution federate to Member States through
existing rails: Denmark has LD, Ireland has MyFutureFund, Poland has PPK, the
Netherlands is mid-conversion into individual DC pots. The precedent is PEPP:
a Union framework, national compartments. The Union never touches the money;
it defines the instrument and the minimum standards (universality, lock-up,
raid-proofing) that national implementations must meet.

**Design consequence.** DC-7: Union-level warrant and reserve standards;
Member State custody and payout through existing pension rails. DC-8: minimum
standards, not uniform machinery.

---

## B. Economic

### 4. Firms will pass the cost to consumers, so citizens pay their own dividend

**The objection, at full strength.** The incidence literature on corporate
taxation is unambiguous that legal and economic incidence differ; a
substantial share of corporate burdens lands on workers and consumers. A
warrant obligation raises the cost of operating in Europe; covered firms
reprice; the citizen's dividend arrives net of the citizen's own higher
prices. The scheme is then a circular pump with deadweight loss.

**What it gets right.** Some pass-through of any burden is real and claiming
zero incidence would be amateurish.

**The answer the instrument must give.** Equity dilution has materially
different incidence from a flow charge. A levy on revenue enters marginal cost
and prices directly; a one-time issuance of warrants exercisable at future
liquidity events changes the division of a future capital gain among
shareholders and does not enter this year's marginal cost at all. The firm's
optimal price today is unchanged by who owns claims on its eventual exit
value. Pass-through is not zero, because expected dilution can raise the cost
of capital at the margin, and the memorandum should say so, with the honest
note that this effect is second-order next to any revenue levy, which is
precisely why the instrument is a warrant and not a levy.

**Design consequence.** DC-9 (reinforces DC-4): the obligation must never be
convertible into a flow charge, because the incidence answer depends on it.

### 5. Covered firms will leave, or never come

**The objection, at full strength.** Draghi's report already concedes the
ground: it is too late for the EU to develop systematic challengers to the
major US cloud providers; the US ITK market grows at 12.7% against Germany's
4.1%; only four of the world's top fifty technology companies are European.
Add a warrant obligation and the marginal AI investment goes to London,
Zurich or Austin. Worse, thresholds invite structuring: a revenue-per-employee
test is gamed by pushing headcount into subcontractors, exactly the offshore
structuring Capgemini's numbers already show at scale.

**What it gets right.** Threshold gaming is certain, not possible, and the
competitiveness anxiety is the strongest political headwind in Brussels this
decade.

**The answer the instrument must give.** The obligation attaches to selling
into the Single Market, not to being located in it, exactly as the DMA and
GDPR attach. The empirical record since is that gatekeepers absorbed
designation and stayed, because 450 million high-income consumers are not
optional; the DMA investigations into AWS and Azure did not produce an exit,
they produced compliance teams. Structuring is answered by consolidation:
thresholds computed on group-consolidated figures including contracted-out
labour by economic substance, with the burden on the undertaking to show
otherwise. And the honest concession: at the margin some investment will
route elsewhere, which is a real cost, to be weighed in the memorandum against
the documented cost of the alternative, which is that the gains concentrate
entirely outside Europe anyway. The Synergy history is the exhibit: Europe
declined to regulate its cloud market into openness, and its providers fell
from 29% to 15% of their own home market unregulated.

**Design consequence.** DC-10: market-access nexus, not establishment nexus.
DC-11: group consolidation with substance-over-form headcount rules.

### 6. Warrants on private companies cannot be valued, voted or sold

**The objection, at full strength.** The covered class is dominated by
private undertakings. A reserve holding warrants on private micro-giants
holds paper with no market price, no liquidity and no exit; either it
pressures for early listings, distorting capital markets, or it sits on
unvalued claims for a decade and the dividend it promises cannot be paid.
Meanwhile the governance question is a trap in both directions: a passive
mega-holder is the feeble owner of the Bebchuk critique, and an active one is
a political sovereign shareholder in every major firm. Greece's HCAP shows the
overcorrection: maximal raid-proofing achieved by placing the asset beyond
citizens' reach entirely.

**What it gets right.** All of it. This is the hardest design problem in the
instrument, harder than the legal base.

**The answer the instrument must give.** The warrant is dormant until
crystallisation, whether at a liquidity event (listing, change of control,
or qualifying secondary sale) or, under Article 5(3), where shareholder
extraction exceeds the stated share of covered turnover or seven years
have elapsed since issuance, whichever occurs first. Until then it
requires no valuation, pays nothing and votes nothing; at the
event it converts at the event price, with no discretion. This matches the
book's own window (claim the stake while the asset forms, crystallise when
the market prices it) and removes the valuation and governance problems in
one move: the reserve holds non-voting economic interests, permanently, by
statute, accepting the Bebchuk cost deliberately because the alternative, a
politically voted stake in every large firm, is worse. The dividend in early
years is funded by crystallisations, not by holdings, and the memorandum must
say plainly that the dividend starts small and compounds, Norway-style, and
that anyone promising otherwise is not us. Two-thirds of Norway's fund is
compound return; the honest pitch is the rule, not the first cheque.

One refinement has been considered and rejected. It is put that valuations
of fast-growing private undertakings are volatile enough that disputes over
the dilution ratio could bog the instrument down in litigation, and that an
expedited binding arbitration should therefore sit between the valuer and
the courts. The instrument already answers the problem the proposal aims
at, and the proposal would cost more than it saves. Article 6(5) provides
that a challenge suspends neither the liquidity event nor the subscription,
and Article 6(4) corrects an erroneous valuation afterwards in either
direction, so a dispute delays nobody: this is the resolution-law pattern,
where litigation runs beside the transaction rather than across it. Where
the event itself sets a price, Article 6(2) makes the valuation arithmetic
on that price rather than an opinion about it, which is where volatility
would otherwise enter. And an arbitral tier whose award bound the parties
would meet Article 47 of the Charter on access to a court, and the limits
on conferring discretionary judgement on bodies of the Union; a tier whose
award did not bind them would add a stage without removing one.

**Design consequence.** DC-12: event-triggered crystallisation, no ongoing
valuation. DC-13: permanently non-voting economic interests. DC-14: the
dividend is communicated as compounding from small, never as immediate
income. DC-34: no tier may be inserted between the valuation and the
courts; correction is ex post and the transaction never waits.

---

## C. Empirical

### 7. The European labour share has not fallen, so the diagnosis is wrong

**The objection, at full strength.** AMECO, verified at source: the EU27
adjusted wage share fell 1.2 points in thirty years; Germany's is at a series
high; France is above its 1995 level; compensation of employees was a larger
share of EU output in 2025 than in 2015, 2019 or 2022. The corporate profit
share spike of 2022 has fully reversed to below its 2019 level. The
Regulation's premise, that machine-driven gains are leaving European labour,
is contradicted by the best available aggregate data, and any recital claiming
otherwise is checkable and wrong.

**What it gets right.** Everything it states. This project's own evidence
base established it, and no recital may argue a European labour-share
collapse.

**The answer the instrument must give.** The premise is ownership, not the
wage share. Sixty per cent of euro-area households own their home; eleven per
cent own listed shares; the top decile holds eighty-three per cent of directly
held shares against the bottom half's two; the bottom half's portfolio is
sixty-three per cent housing and three per cent equity. That distribution is
current, verified and undisputed, and it means that however large the
machine's dividend turns out to be, almost no European holds an instrument
that pays it. The Regulation is insurance whose premium is cheapest before
the event: if the mechanism documented at the platform layer (French software
and cloud growing at +8.2% on price increases while the services layer
shrinks; German software at +9.9% against services at +3.1%) reaches the
aggregate labour market, the stake exists; if it never does, citizens own a
diversified claim on European technology, which is not an injury. The
in-time test is the answer to the premature-legislation charge, not a
vulnerability of it.

**Design consequence.** DC-15: recitals argue ownership concentration and
mechanism, never wage-share decline. DC-16: the memorandum presents the
instrument's value under BOTH futures, arrival and non-arrival.

### 8. The best microdata finds nothing for AI to answer for

**The objection, at full strength.** Humlum and Vestergaard, on Danish
registers covering twenty-five thousand workers: precise null effects on
earnings and hours, nothing above two per cent, two years after ChatGPT. The
OECD finds no break in postings for exposed occupations and a flat euro-area
youth gap. The German federal government told the Bundestag there are keine
Hinweise that AI has reduced entry-level chances. Only a fifth of EU firms
with ten or more staff used any AI in 2025. Legislating a permanent
constitutional-grade structure on this evidence is panic dressed as foresight.

**What it gets right.** The nulls are real, well-identified and from the
best registers in Europe. The memorandum cites them in full or loses its
credibility.

**The answer the instrument must give.** Three things, honestly. First, the
nulls measure wages and hours, not ownership: a uniform shift of returns from
labour to capital is structurally invisible to difference-in-differences
designs, which the Danish authors themselves concede (the absence of
measurable labour market effects is not evidence that nothing is happening),
and their working paper's estimate that only three to seven per cent of
productivity gains passed through to earnings vanished from the published
version along with the paper's own title. Second, the diffusion number cuts
both ways: a mechanism used by a fifth of firms has not yet had its
aggregate chance, which is the argument for building the instrument before
rather than after. Third, the memorandum should carry its own falsification
condition, in the open: if adoption passes a quarter of firms and neither
factor shares nor ownership-weighted gains have moved by a defined date, the
accelerationist premise is wrong and the case reduces to the ownership-gap
argument alone, which stands on its own feet. A proposal that states what
would refute it is a different genre from everything else in Brussels, and
that is the point of this project.

**Design consequence.** DC-17: cite the strongest nulls in the memorandum
itself. DC-18: a stated falsification condition with a date.

---

## D. Political

### 9. You are building the next honeypot, and Europe raids honeypots

**The objection, at full strength.** In one article of law, Poland cancelled
51.5% of the units in every member's pension account and took the Treasury
bonds first. Spain drew its reserve fund down 97% and passed the protection
law afterwards. Hungary took the lot. Ireland's NPRF, the closest thing to
this proposal an EU state has built, was liquidated into a bank rescue within
a decade of its creation. Even the Union itself announced InvestAI at 200
billion and reprogrammed existing funds to stage it. The historical base rate
for European states leaving large pools of citizens' capital alone is poor,
and a bigger pool is a bigger prize. Estonia adds the mirror case: given the
claim and the exit simultaneously, a quarter of the fund walked out in a
month, and the leavers earned below the median.

**What it gets right.** This is the book's own chapter 10 thesis returned as
an objection, and it is the strongest political argument in the file. The
raid is not a tail risk; on the European record it is the modal outcome.

**The answer the instrument must give.** Design against the actual statutes,
clause by clause. Against Poland: the reserve may not hold the sovereign debt
of any Member State or of the Union, removing the self-dealing channel that
made OFE worth cancelling. Against Spain: the prohibition on disposal is in
the founding Regulation from day one, not retrofitted, and amendment of the
protection provisions is reserved to express legislative change accompanied
by a published independent assessment of the effect on holders; a Regulation
cannot prescribe voting thresholds or delays for future legislatures, and
pretending otherwise would hand critics the easiest ridicule in the file. Against Ireland: no emergency-use clause of any kind,
because the NPRF's raid was lawful under its own emergency provisions.
Against Estonia: the periodic entitlement is incapable of surrender or
redemption against payment, so there is no exit for a buyout to purchase,
which is the failure Estonia proved; amounts already distributed are the
holder's property, inheritable, the Danish device that held. Against Greece: raid-proofing must never be achieved by removing
the citizen's claim, which is the failure dressed as success. And one honest
sentence the memorandum must contain: no drafting defeats a determined
future sovereign; the design goal is to make the raid loud, slow and
electorally expensive, which is the most any constitution has ever achieved.

**Design consequence.** DC-19: no sovereign debt holdings. DC-20:
entrenchment as friction from day one: express amendment only, a
published independent assessment, and honesty about Treaty limits. DC-21: no
emergency clause. DC-22: individual claims incapable of surrender; distributed amounts owned and inheritable.
DC-23: the raid-resistance claim is stated as friction, never as
impossibility.

### 10. The EU cannot even disburse what it announces

**The objection, at full strength.** The AI Gigafactories call opened
eighteen months after the 200 billion announcement; construction is promised
from 2027; the Commission's sovereign-cloud tender awarded 180 million
against a single hyperscaler's 33.7 billion in Spain. The institutional
metabolism that would operate this Regulation moves at a pace the underlying
economy does not recognise. A citizens' reserve run at that pace would
crystallise warrants years late and distribute nothing for a decade.

**What it gets right.** The disbursement record is accurately damning and
the memorandum gains nothing by disputing it.

**The answer the instrument must give.** Put no Union spending machinery on
the critical path. The obligation runs directly from covered undertakings to
the reserve: warrants issue by operation of law upon crossing the thresholds,
crystallise by operation of law at events, and the reserve's task is custody
and distribution, not procurement. Nothing needs to be built, tendered or
disbursed for the instrument to function; the contrast with InvestAI is the
design, not an embarrassment to it.

**Design consequence.** DC-24: self-executing obligations by operation of
law; no grant, tender or programme machinery anywhere in the instrument.

---

## E. Philosophical

### 11. Everyone gets richer anyway: the consumer surplus answer

**The objection, at full strength.** Nordhaus estimated that innovators
capture around two per cent of the social value of their innovations; the
rest diffuses to consumers through falling prices and new possibilities. The
steam engine made everyone richer without a single citizen holding a warrant
on Boulton and Watt. If AI follows the pattern, the ownership question is a
distraction: the gains arrive in everyone's basket regardless of whose name
is on the equity.

**What it gets right.** Consumer surplus is real, large and the main channel
through which technology has historically raised living standards. The book
concedes it; the memorandum must too.

**The answer the instrument must give.** Two facts sit beside the diffusion
story without contradicting it. First, the lag: British real wages stagnated
for roughly half a century after Watt while output exploded, and the
broadening arrived through unions, franchise and factory legislation, not
through prices alone; the people who lived inside the pause did not get those
decades back, and whoever owned the mine did not wait. An instrument claimed
at the door is the difference between experiencing the pause with and without
an asset. Second, the stock and the flow are different questions: cheaper
consumption and concentrated wealth are compatible, and the euro area
currently demonstrates the combination, with record employment beside an
ownership distribution of eighty-three against two. The dividend does not
obstruct diffusion; it adds an ownership channel beside the price channel.

**Design consequence.** DC-25: the memorandum affirms consumer surplus and
positions the instrument as additive to it, never as a correction of a
falsehood.

### 12. A dividend buys neither status nor purpose

**The objection, at full strength.** Positional goods reprice against any
universal transfer: give everyone more and the house in the right street
costs more. And income without work solves rent, not Tuesday afternoon: the
structure, standing and belonging that employment supplies as a by-product
are not in the reserve's gift. The proposal oversells what capital income can
do for a displaced person.

**What it gets right. CONCEDED in full.** These are the book's own chapters
11 and 13 and they bind its regulation exactly as they bind its argument.

**What the memorandum must therefore say.** The instrument's scope statement,
prominently: this Regulation addresses the distribution of machine-generated
capital income and nothing else. It does not promise status, purpose,
meaning or the best table, and any campaign material that implies otherwise
is wrong by the proposal's own text.

**Design consequence.** DC-26: an explicit scope-and-limits recital.

### 13. This is universal basic income with extra steps

**The objection, at full strength.** Strip the corporate finance and a
citizen receives a recurring unconditional payment from a public body. That
is UBI, a policy the electorate has weighed repeatedly and cheaply funded
versions of which already failed to collect even an ECI's signatures. The
warrant machinery is complexity added to disguise a transfer as a return.

**What it gets right.** The payment is indeed unconditional and universal,
and the family resemblance is real at the point of receipt.

**The answer the instrument must give.** The difference is not in the
receiving but in the standing. A benefit is a flow from the annual budget,
renegotiated annually, cancellable by simple majority, funded by a shrinking
wage base; the account here is property, in the citizen's name, inheritable,
funded by returns on assets the citizen collectively owns. Poland could
cancel account units by statute precisely because they held claims on the
state itself; Denmark's LD has paid for forty-six years because it holds
market assets in named accounts. The tagline is the answer in six words:
capital for all, so the dividend follows. The order is the argument.

**Design consequence.** DC-27 (reinforces DC-22): named, inheritable
individual accounts, so the UBI comparison fails on legal form, not on
rhetoric.

### 14. Pensions already do this; use them

**The objection, at full strength.** Europe already possesses the machinery
for broad capital ownership: the Netherlands has just moved 605 billion into
individual DC entitlements, Sweden's premium pension has compounded at 5.35%
real since 2000, and the American case shows retirement accounts spreading
equity to 58% of households without any statutory warrant. Build pensions,
not novelties.

**What it gets right.** The delivery rails exist, work and are trusted, and
any design that ignores them is wasteful.

**The answer the instrument must give.** Pensions convert wages into
ownership, and the wage is the input this transition erodes; every pension
vehicle in Europe assumes an employer and a payroll deduction, which is
exactly the assumption chapter 6 shows failing. The funded share of accrued
pension wealth is 7.8% in Belgium and 0.0% in France: the rails reach the
employed of the funded countries and no one else. The warrant severs the
funding source from the wage: the reserve's returns flow into precisely
those national account rails (DC-7) whether or not the citizen ever held a
payroll job. Pensions are the pipe; this is a new source feeding it.

**Design consequence.** DC-28 (reinforces DC-7): distribution through
existing national pension rails; the novelty is confined to the funding
source, where it is necessary.

---

### 15. A euro a year is an insult, not a policy

**The objection, at full strength.** Run the instrument's own simulator
on cautious assumptions and it pays a citizen a euro or two a year for
its first decade. No rational person values that; no voter campaigns
for it; no journalist resists the headline. The apparatus is grotesquely
disproportionate to its payload: a new Union body, a designation regime,
valuation machinery, comitology, penalties reaching 10 % of worldwide
turnover, all to deliver less than the price of a coffee. Worse, the
project's own honesty doctrine forbids promising more. An initiative
that must, by its own rules, tell every signer "you will not feel this
for twenty years" has chosen a message no mass campaign has ever won
with. Basic income at least promises the rent.

**What it gets right.** The early flow is genuinely small, and the
campaign is structurally barred from inflating it. The collection risk
is real: deferred rewards lose to immediate ones on every doorstep.

**The answer the instrument must give.** Three parts. First, small cash distributions do not by themselves show
that the automation economy is small or that the premise has failed. A
large ownership stake can produce little realised income. Article 14's
specified indicators and review process test the premise; dividend size
alone does not. The generational capital objective and the availability of
cash income need to be assessed separately. Second, the claim can only be
bought early. The Danish worker's frozen 1978 instalment of DKK 4 368,
pointless money at the time, is DKK 119 506 today; two thirds of
Norway's fund is compound return, not oil. The alternative timing,
claiming the stake after the gains are visible and the owners
entrenched, is expropriation and politically impossible. The euro buys
the certificate, and the certificate is the point. Third, the stock
outruns the flow: on the same cautious assumptions the Reserve stands
at roughly EUR 400 of owned capital behind every citizen by year
thirty, before any single year's payout impresses. A campaign that
shows the payout without the stake is misdescribing its own
instrument.

**Design consequence.** This objection is why DC-14 exists (never lead
with an early-year figure), why Article 14(3) carries the falsification
condition on its face, and why Annex II distributes income and never
principal. It adds two mechanical rules of its own: wherever a
per-citizen payout figure is shown, the per-citizen stake in the
Reserve is shown beside it (DC-31); and where a year's distributable
amount would be too small to be worth transferring, the interval
lengthens rather than the money vanishing, subject to a hard backstop of
one distribution in every three years and a duty to publish what was not
paid (DC-40). The threshold is a ratio to the cost of making the payment,
not a figure: a number in an annex ages, and hands a headline to anyone
who wants one.

### 16. This is a golden share, and the Court strikes golden shares down

**The objection, at full strength.** For twenty years the Court has
dismantled every special public equity position in the internal market.
Commission v Germany (C-112/05) struck the Volkswagen Law because voting
caps and a blocking minority gave public authorities influence exceeding
their investment and thereby deterred direct investment; the Portuguese,
French, Italian, British and Dutch golden shares fell the same way under
what is now Article 63 TFEU. A Union-chartered Reserve holding a statutory
3 % of every covered undertaking is a golden share cast as a regulation: a
permanent state-adjacent shareholder no investor chose, planted in the
capital structure of every frontier firm, deterring exactly the
cross-border investment Article 63 protects. Article 345's neutrality about
systems of ownership did not save the Volkswagen Law and will not save
this. The deterrence is not hypothetical: every venture round in a covered
undertaking now prices a mandatory future dilution.

**What it gets right.** The dilution is real and investors will price it,
and any position that carried control-flavoured rights would fall exactly
as Volkswagen fell. The golden-share cases are the controlling
jurisprudence for any public equity position, and the instrument must be
drafted against them, not around them.

**The answer the instrument must give.** The golden-share line condemns one
thing: special rights of control disproportionate to investment, voting
caps, blocking minorities, approval vetoes, board seats, the machinery by
which a state steers a company it does not own. The instrument constructs
the exact inverse, in the articles rather than in assurances. The Reserve's
holding carries no vote, ever (Articles 5(4)(a) and 9(1)(a)); no board
presence (Article 9(1)(b)); no instructions (Article 9(1)(c)); no
acquisitions beyond the warrant and index-style diversification (Article
9(1)(d)); no leverage or derivatives that would make it a strategic actor
(Article 9(1)(e) to (g)). What remains is pure economic participation, the
position of any passive minority holder, which is the position Norway's
fund holds at comparable scale across European listed undertakings without
an Article 63 case ever being brought. What the case law demands of any
restriction that survives, the instrument answers on its face:
non-discrimination (identical treatment of Union and third-country
undertakings under Article 3), an overriding general interest stated in the
recitals, and proportionality carried by the fixed 3 %, the independent and
separately justiciable valuation (Articles 5(9), 6 and 7) and the Article
52(1) balance. And unlike every struck golden share, this is not a Member
State reserving national influence against integration: it is a uniform
Union rule for the whole internal market, and its uniformity removes the
divergence that national participation schemes would create. The honest
residue is that mandatory future dilution is itself a cost investors will
price; objection 4 prices it, and proportionality, not denial, is the
defence.

**Design consequence.** DC-13's permanent non-voting rule and Article 9's
conduct prohibitions are this objection's answer in law. What they cannot
do is bind a future legislature, and this memorandum does not pretend
otherwise: the drafting of Article 12(3) records that binding future
legislatures failed the gates in an earlier round, and an attempt on 21
August 2026 to give the rule operative force in that paragraph was
abandoned because hostile counsel preferred it present, reading it as a
Union-law command that the Reserve be stripped of the protective class
rights Article 5(4)(b) gives it. What stands is a design rule binding this
instrument and anyone amending it: economic participation is the maximum,
and no control right, veto or governance privilege attaches to the
Reserve's holdings (DC-32). It is a commitment the text keeps, not a lock
the text can impose.

### 17. You are seizing equity in companies Europe does not govern

**The objection, at full strength.** The warrant obligation reaches
undertakings incorporated in Delaware or Singapore, whose shares sit
offshore and whose systems are built offshore, because their services are
used in the Union. Public international law lets the Union regulate foreign
conduct only where it has immediate, substantial and foreseeable effects in
the internal market (Gencor T-102/96; Intel C-413/14 P), and even then it
regulates conduct, not ownership: no effects-doctrine case has ever
required a foreign parent to dilute its own capital. Third-country
governments will treat a compulsory 3 % subscription in their champions as
expropriation by regulation, answerable under investment treaties and
trade commitments, and they will retaliate. The Union would be claiming a
power it would never concede to others: a foreign statute demanding 3 % of
a European champion's equity as the price of serving that market.

**What it gets right.** A warrant on a foreign parent whose only Union link
is that its website resolves would overreach and would deserve to lose. The
nexus must be economic substance in the Union, not accessibility.
Retaliation is a real cost and reciprocity a real argument.

**The answer the instrument must give.** Four structural choices, all
already in the articles. First, the trigger is Union commerce, not Union
accessibility: designation requires provision in the internal market with
EUR 7,5 billion of annual Union turnover in at least three Member States
(Article 3(2)(a)), an economic-presence test far above any effects-doctrine
threshold, and the rents being shared are by construction rents drawn from
Union users. Second, the undertaking is the group: 'undertaking'
consolidates linked enterprises (Article 2(1)), the single-economic-unit
principle of Union competition law (Akzo Nobel C-97/08 P), so no thin
Union subsidiary can shield the parent to which the automated services'
value actually accrues. Third, the mechanism respects foreign company law
rather than purporting to override it: for undertakings governed by
third-country law the subscription is an obligation of result (Article
5(5)), enforced through Article 13 as a condition of continuing access to
the internal market, the architecture of every market-access condition the
Union already imposes, and the company-law derogations of Article 5(7)
reach Member State law only. Fourth, the condition is universal: Union
undertakings bear it identically, so a treaty claim or trade panel has no
discrimination to hold on to, and reciprocity runs in the instrument's
favour, because a Union that asserts the principle accepts it from others.

On the practical incidence the objection now has a concrete answer rather
than an abstract one. Under the designation test of Article 3(2)(b) as
amended, the undertakings presumptively designated on August 2026 figures
span the United States, Taiwan and, near the threshold, the Union itself
(evidence/designation-count.md), so the measure's first-years incidence is
no longer a set consisting exclusively of undertakings of one third
country, and the universality of the condition is visible in the
designated set itself rather than asserted about a hypothetical one.

**Design consequence.** DC-10's market-access nexus and DC-2's group
consolidation are this objection's answers in law. It adds one rule of its
own: for undertakings governed by third-country law, the warrant is an
obligation of result enforced as a market-access condition, never a
purported override of foreign company law (DC-33).

### 18. Corporate structuring will simply route around all of this

**The objection, at full strength.** Every mechanism in this Regulation
assumes a moment at which value becomes visible, and corporate law exists
to move that moment. A hyper-automated undertaking is the ideal escape
artist: it needs little capital, so it need never list; it generates cash,
so it can pay its founders through decades of dividends, leveraged
recapitalisations and selective buybacks while the warrant sits dormant
for ever. If it must eventually deal, it deals in a capital stack the
Reserve does not sit in: seed through Series G preferred with two- and
three-times participating liquidation preferences, so that a sale
distributes everything to preferred holders and the Reserve's three per
cent of common is worth precisely nothing. If the trigger still nears, the
group demerges: model weights, training infrastructure and user base
migrate to an unlisted sister, and what floats is a low-margin European
storefront. If all else fails, a friendly private credit fund converts
debt to equity in a preventive restructuring, old equity is extinguished
by court order, and the same people own the same models through a new
company the following morning. Meanwhile the shares the Reserve does hold
in third-country parents are taxed at source at rates it cannot reclaim,
because a supranational body resident nowhere has no treaty to invoke.
Each of these is ordinary practice, not abuse; the instrument is a
crystallisation event in a world that has spent forty years learning to
avoid events.

**What it gets right.** All of it. An instrument that hangs on a single
trigger will be routed around by people who structure for a living, and a
regulation that says so only in its recitals has conceded the point. The
answers below are additions the file did not have; they came from outside
review and the memorandum says so.

**The answer the instrument must give.** Close the timing, the ranking,
the perimeter and the exit, and be honest where the closure is partial.

Timing first: the warrant no longer waits on a sale. Article 5(3) makes
it crystallise where shareholder extraction over three consecutive years
exceeds 25 % of the undertaking's turnover from the covered activity, which
is the point at which staying private has become a way of paying oneself
rather than a way of building; and in any event on the seventh anniversary of issuance,
whatever the undertaking has or has not done. An undertaking may still
stay private for ever. It may no longer stay private and be paid.

Ranking second: Article 5(4)(b) entitles the Reserve to shares ranking,
for dividends and for the proceeds of any sale or liquidation, equally
with the most favourably ranking class created after designation, and with
ordinary shares otherwise. Three per cent of a common tranche standing
behind a three-times participating preference is not three per cent of
anything, and the instrument now says which three per cent it means,
without taking from investors the preference they actually paid for before
designation. Article 5(10) makes any reorganisation whose main purpose or
effect is to put the Reserve below where that paragraph places it
ineffective as against the Reserve, while leaving it good between the
parties to it.

Perimeter third: Article 5(11) requires the transferee to issue a warrant
of its own where automated assets go to an affiliate or a commonly
controlled entity or leave at less than arm's length, and leaves the
transferor bound in respect of what it retains. The aggregate across the
covered undertaking and every transferee is capped at the stated
percentage of their combined capital, so that closing this route cannot
turn into a multiplier on a group that divides itself. Article 2(14) names what may not be
walked out of the door: model parameters, training and inference
infrastructure, data sets, the intellectual property the service depends
on. This is the succession logic of merger control rather than an
invention.

Exit fourth: Article 5(12) reattaches the obligation where the automated
assets emerge from insolvency or a restructuring under Directive (EU)
2019/1023 into an entity controlled by the same people, or in which those
people hold the majority of the economic rights, and requires a warrant to
be issued afresh within three months. A genuine failure still extinguishes the
Reserve's holding, as it extinguishes every shareholder's, because the
Reserve is an owner and owners bear that. What it does not do is bless the
version where the owners survive and only the obligation dies.

And the honest partial: source taxation. A Union regulation cannot confer
on the Reserve a treaty benefit that a third country has not granted, and
a body resident nowhere may be withheld against at the full statutory
rate. Two answers were drafted and struck. Instructing the Commission to
negotiate with third countries would have commanded a prerogative that
Article 218 TFEU places elsewhere. Permitting the Reserve to route its
holdings so as to reduce the rate would have written treaty shopping into
an instrument whose entire case is that capital should be broadly owned
and should pay what it owes; hostile counsel had the headline ready, and
was right to have it. What survives is Article 8(5): the Reserve
publishes each year the tax it could not reclaim, and the Commission
answers for it in the Article 14 report. That is a smaller answer than the
problem, and it is the honest one. A leak reported annually is a leak the
campaign can be judged on; a leak nobody measures only grows.

One route counsel kept and the instrument deliberately leaves open. An
undertaking may borrow heavily from lenders who are nobody's relation, pay
them market interest, and arrive at the long-stop worth less than it would
have been unlevered. That is not extraction and the definition should not
pretend otherwise: the money goes to strangers, not to insiders, and the
founders are poorer by exactly the same proportion as the Reserve. Every
shareholder in a leveraged company owns a smaller claim on a larger
balance sheet, and an instrument that took 3 % of the equity cannot also
insist the equity be unencumbered. What the file must not do is confuse
that with the routes above, where value leaves for pockets that are the
same pockets. Leverage is a risk the Reserve takes as an owner; extraction
is a transfer the Regulation stops.

**Design consequence.** DC-35: crystallisation triggers on extraction and on
time, not only on a sale. DC-36: subject to the rescue carve-out, the
Reserve's shares rank with the most favoured class created after the
designation, leaving earlier preferences untouched, and subordinating
arrangements are ineffective as against the Reserve. DC-37: the transferee
issues its own warrant over its own capital; the transferor stays bound for
the automated assets it retains, and the aggregate across them never exceeds
the stated percentage of their combined capital. DC-38: unrecoverable source
taxation is published annually; the instrument does not direct the Reserve
to arrange its holdings to reduce it. DC-39: the obligation reattaches where
the same owners reacquire the assets out of a restructuring.

### 19. Sweden tried this and could not even legislate it

**The objection, at full strength.** This mechanism is not new and it has
already failed, in the one country most likely to have carried it. The
Meidner plan, endorsed by the Swedish trade union confederation's congress
in 1976, required profitable undertakings to issue new shares worth 20 % of
their annual profits to collectively held funds, year after year, until
those funds held a majority of the shares. That is this instrument's
mechanism: a compulsory issuance of new equity to a collective holder,
settled in shares rather than cash, calibrated to the undertaking's own
prosperity.

It did not survive its own drafting. By the time the Riksdag legislated in
1983, the compulsory share issuance had been abandoned and replaced with a
levy on profits and on the wage sum, capped in aggregate and limited to
holdings of no more than 8 % of any one undertaking. The design converted,
under political pressure and before enactment, into precisely the thing this
memorandum spends Article 8 and objection 2 insisting this instrument is
not: a tax. Then Swedish business mobilised against even the diluted version
on a scale without modern parallel, with a demonstration on 4 October 1983
that drew between 75 000 and 100 000 people where the organisers had
expected 5 000, and repeated it annually until a change of government
abolished the funds in 1991, against minimal resistance from the movement
that had proposed them.

The reading is unkind and it is available to anyone who knows the file. In
the most union-friendly advanced economy in the world, at the peak of
organised labour's power, with a sympathetic government, the compulsory
issuance of equity to a collective fund proved unlegislatable, converted
into a fiscal measure at the drafting stage, and was repealed within eight
years by the first government that wanted to. A drafter who does not know
this has not done the reading. A drafter who knows it and omits it is
hiding it.

**What it gets right.** Almost all of it, as history. The mechanism is the
same family. The conversion to a levy is real and is the sharpest available
evidence for objection 2's characterisation attack, because it shows
experienced legislators reaching for the fiscal instrument when the
equity instrument became politically impossible. The 1991 abolition is a
genuine instance of the raid this instrument drafts Chapter VI against, and
it belongs beside Poland, Spain and Ireland in the evidence base rather
than being left out because it is inconvenient. The mobilisation is a real
prediction about what happens when capital reads a proposal of this kind
as a transfer of control.

**The answer the instrument must give.** Three differences, each of which
maps onto a specific reason the Swedish design failed, and none of which is
cosmetic.

First, terminus. Meidner's funds were designed to accumulate without limit
until ownership changed hands, and its author said so; that was the point,
not a side effect. This instrument takes 3 % of fully diluted capital once,
per designation, with the aggregate across an undertaking and every
transferee capped at that same percentage under Article 5(11) and Article
7(2). There is no path from this instrument to control, because the
arithmetic does not permit one. An opponent who says otherwise is arguing
against a different proposal.

Second, control. The Swedish funds voted, and they were run by the unions.
The scholarship on the defeat is consistent that the mobilisation was about
who would govern the companies rather than about the money, and the 8 %
ceiling was itself an attempt to answer that fear. The Reserve holds
non-voting shares under Article 5(4)(a), is forbidden by Article 9 from
seeking or exercising influence, and DC-32 makes economic participation the
maximum. The constituency that made 1983 possible was employers who
believed they were being nationalised in instalments. That belief cannot be
formed about an instrument that cannot vote.

Third, beneficiary. The Swedish funds accrued to a labour movement, which
made them a party question in a two-party fight. This instrument's
distributions accrue equally to every citizen of the Union under Article 10,
including the shareholders and the employees of the designated undertakings
themselves. That does not make opposition impossible. It makes "them
against us" harder to draw.

What this file will not claim is that the differences make the political
economy safe. They do not. The honest position is that Sweden shows the
mechanism can be legislated only if it is visibly bounded, visibly
powerless as to control, and visibly universal in who it pays, and that a
proposal failing any of those three has a documented way of dying. This
instrument is drafted to satisfy all three, and objection 4 already prices
the residual political risk rather than denying it.

**Design consequence.** DC-41: the instrument must be bounded, without votes
or control rights, and universal in who it pays, all three at once, because
the Swedish precedent shows that failing any one of them is sufficient to
lose. The word to avoid is passive. The Reserve does assert claims: Article
5(4)(b) fixes its rank and Article 5(10) makes subordinating arrangements
ineffective against it, and an opponent will call that anything but passive.
The defensible claim is narrower: the Reserve holds no votes, appoints no
one, and has no say in the management of the undertaking. Even that is not
the end of it. Hostile counsel makes the further point that a rank the
undertaking cannot subordinate constrains how it raises distressed or
preference capital, since new money normally demands seniority, and calls
that a veto over capital structure in substance. It is not a governance
right and Article 5(10) leaves the arrangement effective between the parties
to it. It was, all the same, a constraint on financing that the word passive
would conceal, and it is now answered in the text rather than carried: the
second subparagraph of Article 5(10) lets genuinely new money rank ahead of
the Reserve, at arm's length, from persons unconnected with the undertaking
and its controllers, while the undertaking is in a likelihood of insolvency
or must meet a prudential requirement, and only to the extent of the new
consideration provided. Rescuers are paid before the Reserve; engineered
seniority beyond the new money is still caught, because that is where the
abuse lives, and the undertaking bears the burden of proof. DC-42: the wage-
earner funds belong in the evidence base as a raid precedent and in this
file as an objection, stated before an opponent states it.


### 20. Taking the voteless shares hands control to the people you named as the problem

**The objection, at full strength.** The instrument takes three per cent of
the economic value and none of the votes. The arithmetic of that is not
neutral. Before the warrant, the existing holders own all of the capital and
cast all of the votes; after it they own ninety-seven per cent of the capital
and still cast all of the votes. Their control per euro of their own money has
gone up, by about three per cent, and the Union has handed it to them. A file
whose diagnosis is that the ownership of productive capital is too narrow
responds by creating the largest permanently voteless shareholder in Europe
and widening, at every covered undertaking, precisely the wedge between
cash-flow rights and control rights that corporate-governance scholarship
identifies as the most reliable predictor of minority expropriation and
unaccountable management. The founders of the frontier firms already hold
control through dual-class structures on minority economic stakes. This gives
them more of it, for free, by statute.

The legitimation point is worse than the arithmetic. Once the Union itself
accepts voteless equity as the form its own citizens' participation takes, no
Union institution can coherently object to dual-class listings, loyalty shares
or any other separation of ownership from control. The instrument does not
merely tolerate the wedge; it endorses it, in a Regulation, on behalf of
450 million people.

**What it gets right.** The mechanical claim is exactly true and this file
should not pretend otherwise: non-voting shares raise the relative voting
weight of every voting share, and the raise here is real. If the diagnosis
were about who controls firms rather than about who receives the returns to
capital, the instrument would be answering a question it did not ask, and
answering it in the wrong direction.

**The answer the instrument must give.** Not that this is the wrong lens. An
earlier draft of this passage called the governance reading a category error,
on the ground that the instrument's claim is distributional. Four review
gates rejected that in the same terms, and they were right: an instrument
that alters the ratio of cash-flow rights to control rights at every
undertaking it touches is a governance instrument in effect, whatever it is
in intention, and it is properly judged on its effects. The answer below
concedes the effect and defends the choice.

The choice was between three positions and the file has taken the least bad
one. A Reserve with votes proportionate to its stake is a politically
directed shareholding in every frontier firm in the internal market: it is
objection 9's honeypot with a lever attached, and objection 16's golden
share, which the Court has struck down in every form it has taken since
Commission v Germany (C-112/05). A Reserve with no stake at all abandons the
distributional claim entirely. A Reserve with economic participation and no
control accepts a real governance cost in exchange for the only position that
survives Article 63 and the golden-share line. Article 5(4)(a) and Article
9(1)(a) to (c) put that beyond the drafter's later convenience, and DC-43
keeps any successor honest about it.

On magnitude, one comparison and its limits. Three per cent of enlarged
capital raises the remaining holders' voting weight by roughly one
thirty-second of itself, and buy-back programmes of that order run routinely
at the undertakings this instrument covers without anyone calling them a
transfer of control. That comparison is offered for size and for nothing
else, and it does not survive being pushed further: a buy-back is elective,
is executed for consideration and returns cash to the holders whose weight
rises, whereas this is compulsory, is subscribed at nominal value and returns
nothing to them. Reviewers were right to say the two are not alike in kind.
They are alike in the one respect the paragraph uses them for, which is how
much the voting weight of a remaining share actually moves.

On legitimation, the objection lands and is only partly answered. Voteless
shares are not this instrument's invention: Union company law has permitted
them for decades and every Member State provides for them, so the Reserve
takes a class the market already trades. But the Union has lately been
legislating in the other direction, adding safeguards around multiple-vote
structures precisely because the separation of ownership from control is
understood to be a hazard, and a Regulation that plants a permanent voteless
block in every covered undertaking sits uneasily beside that. The honest
statement is that the instrument spends some of the Union's authority on the
proposition that economic participation without control is a legitimate form
of ownership, and that the price is real. It is paid deliberately, because
the alternative is a Union holding votes in the undertakings it regulates,
and this file would rather defend a wedge than defend that.

The precise interaction with the Union's multiple-vote share legislation is
recorded as an open acquis interface point rather than argued here from a
citation this file has not yet verified, and it joins the acquis
interface points already recorded on the list before filing.

**Design consequence.** The instrument's claim is distributional and no
amendment gives the Reserve votes without arguing itself as a different
instrument, but the governance effect is conceded and defended rather than
disclaimed (DC-43). The relative voting effect on existing holders is stated
with its size, and the buy-back comparison is confined to magnitude with its
disanalogy stated in the same breath (DC-44).


### 21. Why three per cent, and not one, or ten

**The objection, at full strength.** The number is asserted. Nowhere in this
file is it derived. Article 52(1) of the Charter permits a limitation on the
right to property only where it is necessary and genuinely meets an objective
of general interest, and necessity is the question a bare figure cannot
answer: if three per cent achieves the objective, one per cent is the less
intrusive means and the measure fails; if one per cent does not achieve it,
the file has not shown why three does. The reviewing court will ask the
legislature to show its work, as it asked in every proportionality case worth
citing, and this file will hand it a round number that sits comfortably below
the level at which the objection "you are nationalising them" becomes easy to
make. That is a political calibration wearing the clothes of a legal one, and
the Commission's Legal Service will see it on the first reading. Every other
number in the instrument is tied to something: the thresholds in Article 3 to
measurable quantities, the seven-year long stop to the observed interval
between designation and realisation. The one number that determines how much
is taken is tied to nothing.

**What it gets right.** All of it. This is the weakest load-bearing point in
the file, and no quality of drafting anywhere else repairs it. It would be
worse than useless to answer it here with a derivation invented to fit a
figure already chosen: that is precisely the vice the objection names, and a
reviewer who caught it would be entitled to discount everything else in this
memorandum.

**The answer the instrument must give.** The objection is correct, and the
attempt to answer it produced something worse than a missing derivation: a
demonstration that no derivation of the kind a court would want can be
produced at all while Article 1 stands as drafted.

The published model is linear in the percentage. Annex II's arithmetic, as
implemented in the simulator on the campaign site, accumulates the Reserve's
capital by adding the warrant percentage of each crystallising flow, and
every distribution downstream is a fraction of that capital. Doubling the
percentage doubles the dividend at every horizon and halving it halves it,
exactly, in every scenario the simulator offers. The computation is set out
in evidence/warrant-percentage.md and anyone can rerun it. There is no
threshold, no kink and no discontinuity anywhere on the curve, which means
there is no percentage at which the instrument starts working and below which
it does not.

That is fatal to the obvious defence. Necessity under Article 52(1) asks
whether a less intrusive measure would achieve the objective. If the
objective is Article 1's, the participation of citizens in the capital value
created by hyper-automated undertakings, then one per cent achieves it, and
so does one tenth of one per cent, because each produces participation and
the Article states no quantity that participation must reach. An opponent
does not even need to argue that three per cent is too much. They need only
observe that a smaller figure achieves the stated objective, and the
necessity limb fails on the instrument's own words.

So the defect is not in this memorandum, and it cannot be repaired here. It
is in Article 1. An instrument that interferes with Article 17 of the Charter
and states its objective qualitatively has left the necessity limb with
nothing to be tested against, and no amount of argument about three per cent
substitutes for that. Either the objective acquires a quantity against which
a percentage can be measured, or the Article 52(1) defence rests on the
proportionality limb alone, which asks only whether the burden is excessive
and to which the answer is the ceiling rather than the floor.

The ceiling is where the file's defence honestly sits today. A percentage
large enough to strip existing holders of the substance of their property
crosses from a regulation of use into a deprivation. Hauer (44/79) is the
authority for the distinction itself and for the proposition that the right
to property may be regulated in the general interest; it concerned a
temporary restriction on planting vines and is not authority for a
compulsory transfer of equity, and this file does not offer it as one. James
and Others v United Kingdom (1986) is cited for the same distinction and for
nothing further: the taking there was accompanied by compensation, so it is
authority about where the line runs and not about what may be taken without
paying for it. Objection 1 carries that argument and its honest residue,
which is that no decided case places a permanent, non-crisis, uncompensated
dilution of a healthy undertaking on the right side of the line. Three per
cent is comfortably below any plausible deprivation ceiling. Being below a
ceiling is a proportionality argument, not a necessity argument, and this
file will not dress one as the other.

That repair has now been made, and this passage records both the repair
and its honest limit. Article 1(2) states the objective as an ownership
position: holdings per citizen of the order of six months of the median
equivalised disposable income in the Union, in constant prices, within a
generation of the first designations. On the published model and the
amended designation test of Article 3(2)(b), the aggregate designated
value is of the order of EUR 20 trillion on August 2026 figures
(evidence/designation-count.md), and the stake per adult within a
generation is about EUR 8 400 at three per cent, EUR 5 600 at two and
EUR 2 800 at one (evidence/sizing-the-ask.md). Six months of median
equivalised disposable income is of the order of EUR 9 000. Three per
cent is therefore the smallest integer percentage capable of approaching
the stated objective, one per cent manifestly cannot, and the necessity
limb of Article 52(1) has, for the first time, a quantity to test
against, published, reproducible, and revisited at every Article 14
report, where the same clause that could raise the percentage on the
evidence is the clause that lowers it.

The honest limit is the circularity a reviewer will point out and this
file states first: with a linear model, any target-percentage pair is
arguable, so the target itself is not derived, it is chosen, openly, in
the enacting terms. That is not a defect the drafting can remove; it is
what a legislative objective is. The case law requires a stated objective
and a reasoned relationship between the measure and it, not an objective
that derives itself, and no instrument's does. What this file no longer
does is assert a percentage against no objective at all.

**Design consequence.** The percentage is derived as the minimum integer
consistent with the objective stated in Article 1(2), on a published and
reproducible model, and the circularity inherent in choosing the target is
stated rather than concealed (DC-45). Article 1(2) carries the quantified
objective, assessed in each Article 14 report in both directions, and the
derivation is revisited whenever the designated set or the model moves
(DC-46).


## The constraints table

The articles are drafted against this table. A draft that violates a DC fails
review regardless of its prose.

| DC | Constraint | Source objection |
|---|---|---|
| DC-1 | Prospective warrants on future value; never retroactive transfer | 1 |
| DC-2 | High, objective, group-consolidated thresholds | 1, 5, 17 |
| DC-3 | Statutory passivity; crystallisation only at defined statutory events, never at a discretionary or political one | 1, 6 |
| DC-4 | No monetary flow from undertakings; instruments only | 2, 4 |
| DC-5 | Distributions are property income of the reserve | 2 |
| DC-6 | Severable layering for partial ECI registration | 2 |
| DC-7 | Union warrant standards; Member State custody via pension rails | 3, 14 |
| DC-8 | Minimum standards, not uniform machinery | 3 |
| DC-9 | Obligation never convertible into a flow charge | 4 |
| DC-10 | Market-access nexus, not establishment nexus | 5, 17 |
| DC-11 | Substance-over-form headcount consolidation | 5 |
| DC-12 | Event-triggered crystallisation; no ongoing valuation | 6 |
| DC-13 | Permanently non-voting economic interests | 6, 16 |
| DC-14 | Dividend communicated as compounding from small | 6 |
| DC-15 | Recitals argue ownership and mechanism, never wage-share decline | 7 |
| DC-16 | Value stated under both futures | 7 |
| DC-17 | Strongest nulls cited in the memorandum itself | 8 |
| DC-18 | Stated falsification condition with a date | 8 |
| DC-19 | No sovereign debt holdings | 9 |
| DC-20 | Entrenchment from day one: express amendment only, published independent assessment, honesty about Treaty limits | 9 |
| DC-21 | No emergency clause | 9 |
| DC-22 | Individual claims incapable of surrender or seizure; distributed amounts owned and inheritable | 9, 13 |
| DC-23 | Raid resistance claimed as friction, never impossibility | 9 |
| DC-24 | Self-executing by operation of law; no programme machinery | 10 |
| DC-25 | Consumer surplus affirmed; instrument additive to it | 11 |
| DC-26 | Explicit scope-and-limits recital | 12 |
| DC-27 | UBI distinction carried by legal form | 13 |
| DC-28 | Funding-source novelty only; existing rails for delivery | 14 |
| DC-29 | Interference capped at the stated percentage in execution; independent, separately challengeable valuation; judicial review | 1 |
| DC-30 | Essential elements (trigger, reserve ownership, entitlement, interference) in the articles, never delegated | 1 |
| DC-31 | Wherever a per-citizen payout figure is shown, the per-citizen stake in the Reserve is shown beside it | 15 |
| DC-32 | Economic participation is the maximum: no control right, veto or governance privilege attaches to the Reserve's holdings, binding this instrument and anyone amending it, without pretending to bind a future legislature | 16 |
| DC-33 | For third-country-law undertakings the warrant is an obligation of result as a market-access condition, never an override of foreign company law | 17 |
| DC-34 | No tier between valuation and the courts; correction is ex post and the transaction never waits | 6 |
| DC-35 | Crystallisation triggers on shareholder extraction and on time, not only on a sale | 18 |
| DC-36 | The Reserve's shares rank with the most favoured class created after the designation, leaving earlier preferences untouched; subordinating arrangements are ineffective against the Reserve, save for new money at arm's length from unconnected persons in rescue, to the extent of the new consideration | 18 |
| DC-37 | The transferee issues its own warrant over its own capital; the transferor stays bound for what it retains, and the aggregate across them never exceeds the stated percentage of their combined capital | 18 |
| DC-38 | Unrecoverable source taxation published annually; the Reserve is not directed to arrange its holdings to reduce it | 18 |
| DC-39 | The obligation reattaches where the same owners reacquire the assets out of a restructuring | 18 |
| DC-40 | Below a de minimis the distribution interval lengthens; it never becomes a reason not to pay | 15 |
| DC-41 | Bounded, without votes or control rights, and universal in who it pays: the Swedish wage-earner funds show that failing any one of the three is enough to lose. The Reserve does assert claims as to rank and against subordination; what it never acquires is votes, board seats or any say in management | 19 |
| DC-42 | The wage-earner funds are stated as an objection here and as a raid precedent in the evidence base, before an opponent states them | 19 |
| DC-43 | The claim is distributional and no amendment gives the Reserve votes without arguing itself as a different instrument; the governance effect on remaining holders is conceded and defended, never disclaimed as the wrong lens | 20 |
| DC-44 | The relative voting effect on existing holders is stated with its size, not left for an opponent to compute, and any comparison drawn to buy-backs is confined to magnitude with its disanalogy stated alongside | 20 |
| DC-45 | The percentage is the minimum integer consistent with the objective stated in Article 1(2), derived on a published, reproducible model; the circularity of choosing the target is stated, never concealed | 21 |
| DC-46 | Article 1(2) carries the quantified objective, assessed in each Article 14 report in both directions; the derivation is revisited whenever the designated set or the model moves | 21 |

## Status

Objections are OPEN until the articles answer them, save where noted below;
12 is CONCEDED by scope. Objection 18 was added on 21 August 2026 from an
external review of corporate-structuring routes around the instrument.
Unlike objections 16 and 17, it did not find the answers already in the
articles: it describes five routes. Four of them are now closed by
amendments to Articles 2 and 5. The fifth, source taxation, prompted an
amendment to Article 8 but is not closed, and the answer to that objection
says so: publication is a smaller answer than the problem. A sixth item,
borrowing at arm's length, was considered and deliberately left open,
because it is not the extraction the objection is about. It is the first objection in
this file whose answer had to be written rather than cited.

Objections 16 and 17 were added on 20 August 2026 from an external
challenge (the Article 63 golden-share line; qualified-effects overreach);
their answers were already in Articles 3, 5(5) and 9, which is what
drafting against the table is for, and the residue they add is DC-32 and
DC-33.
Objection 1 carries the largest legal risk and objection 6 the largest design
risk. Gate 1's admissibility letter still leads with objections 1 and 2, but
recalibrated by the drafting research: registration is the lower hurdle
(manifestly-outside test, partial registration, the registered wealth-tax
ECI), so the letter tests the characterisation for the Council stage, not for
the register.

Objection 2's fiscal reading has now been reached independently by three
readers: hostile counsel on 27 August 2026, the ECI Forum's advisers on 27
August 2026 and an ECI veteran on 5 September 2026 (pipeline/EXTERNAL-REVIEWS.md,
review 5). The objection is unchanged; what changes is its status, from an
adversary's argument to the ordinary reader's first impression, which the
presentation, not the drafting, must now answer.


# SOURCE: own-the-machine/regulation/memorandum/explanatory-memorandum.fr.md

<!-- Traduction de courtoisie. Le texte anglais fait foi ; en cas de divergence, l'anglais prévaut. Source: explanatory-memorandum.md -->

# Exposé des motifs

Accompagnant le projet de règlement du Parlement européen et du Conseil relatif à des règles harmonisées concernant la participation des citoyens aux gains de productivité automatisés.

Le présent exposé des motifs suit la structure que la Commission utilise pour ses propres propositions. Il est rédigé par des citoyens, non par la Commission, et n'est pas obligatoire : le règlement (UE) 2019/788 permet à une initiative citoyenne de joindre un projet d'acte juridique et n'exige rien de ce type. Il existe parce que les questions auxquelles les services de la Commission devraient répondre au sujet de cet instrument méritent qu'on y réponde avant qu'elles ne soient posées, et parce qu'un dossier qui ne peut y répondre n'est pas prêt à faire l'objet de suites. Lorsqu'une réponse n'existe pas encore, le présent exposé des motifs l'indique plutôt que de remplir la rubrique.

---

## 1. Contexte de la proposition

### 1.1 Motivation et objectifs de la proposition

Les systèmes cognitifs automatisés commencent à produire des résultats à une échelle qui ne requiert plus une quantité correspondante de travail humain. Lorsqu'un tel découplage se produit, les revenus de la production reviennent aux détenteurs du capital qui incorpore l'automatisation, et la part revenant aux citoyens sous forme de salaires diminue parallèlement à la part du travail.

Le problème auquel le présent règlement entend remédier n'est pas ce résultat en soi, qui relève de multiples instruments, mais un problème plus restreint relevant de la compétence de l'Union: la propriété du capital dans lequel se concentrent ces rendements est extrêmement restreinte, et les États membres ont commencé à y réagir de manière isolée, par des prélèvements nationaux divergents, des mécanismes de participation et des propositions visant à taxer la production automatisée. Ces divergences fragmentent le marché intérieur précisément pour les entreprises qui exercent leurs activités à l'échelle de l'ensemble de celui-ci.

L'objectif est énoncé et quantifié à l'article 1er, paragraphe 2: la participation des citoyens de l'Union à la valeur en capital créée par la production hyperautomatisée, à une échelle où les avoirs sous-jacents au droit de chaque citoyen atteignent un montant de l'ordre de six mois de revenu disponible équivalent médian dans l'Union dans le délai d'une génération à compter des premières désignations.

### 1.2 Cohérence avec les dispositions existantes dans le domaine d'action

L'architecture de désignation suit le règlement (UE) 2022/1925 (règlement sur les marchés numériques): critères qualitatifs cumulatifs, seuils quantitatifs établissant une présomption réfragable, autonotification, voie de désignation en deçà des seuils fondée sur les faits et pouvoir anti-contournement. Il s'agit d'une réutilisation délibérée d'une structure que le législateur de l'Union a déjà adoptée et que la Cour n'a pas remise en cause.

L'articulation avec le droit des sociétés est rédigée sous la forme d'une dérogation expresse et étroite à la directive (UE) 2017/1132 plutôt que d'une primauté générale, suivant ainsi la formule de l'acquis en matière de résolution. L'articulation avec le régime des prospectus constitue une exemption expresse au titre du règlement (UE) 2017/1129. L'article 1er, paragraphe 5, préserve la directive (UE) 2016/2341 et le règlement (UE) 2019/1238, sous réserve des dispositions de l'article 11.

Les questions ouvertes relatives à l’acquis sont indiquées à la section 5.4 ; l’annonce antérieure d’une liste de cinq points est retirée. Elles sont recensées plutôt que résolues, ce qui reflète fidèlement l'état d'avancement.

### 1.3 Cohérence avec les autres politiques de l'Union

L'instrument retient des fonds propres sans droit de vote et ne confère aucun droit de gouvernance, ce qui le maintient hors du champ couvert par la jurisprudence de la Cour relative aux participations publiques spécifiques (Commission c. Allemagne, C-112/05, et jurisprudence ultérieure). Ce choix a un coût, examiné à l'objection 20: les actions sans droit de vote augmentent le poids de vote relatif des détenteurs restants, et l'Union a récemment légiféré en sens inverse sur les structures d'actions à droits de vote multiples dans la directive (UE) 2024/2810. L'interaction avec cette directive constitue un point d'articulation ouvert et non résolu.

Aucune disposition du présent règlement ne crée de ressource propre de l'Union, et aucun élément n'entre dans le budget de l'Union. Il s'agit d'une contrainte de conception et non d'une propriété accessoire: voir section 4.

---

## 2. Base juridique, subsidiarité et proportionnalité

### 2.1 Base juridique

La base juridique est exposée par couche, et non selon un centre de gravité
unique pour l'ensemble de l'acte, car des procédures législatives
incompatibles ne peuvent être fusionnées en une seule base (Dioxyde de
titane, C-300/89) et parce qu'une argumentation unitaire concéderait la
qualification de la couche la plus faible aux opposants à la couche la plus
forte. La note sur la divisibilité expose ces couches; la règle de
décomposition no 3 impose ce traitement. L'article 114 du TFUE sous-tend le
régime de désignation, les obligations de transparence et le warrant: des
règles adressées à des entreprises opérant sur l'ensemble du marché
intérieur, éliminant les divergences que des prélèvements nationaux
distincts sur la participation et l'automatisation créent déjà. La
Commission a enregistré une initiative reposant sur cette même logique de
divergence en terrain au moins aussi contesté : l'initiative de 2023 sur
l'imposition des grandes fortunes, par la décision (UE) 2023/1487. L'avis
indépendant obtenu par l'intermédiaire du Forum de l'ICE le 27 août 2026,
consigné dans pipeline/EXTERNAL-REVIEWS.md et qui ne lie personne, interprète cette décision de la même manière et recommande de la citer ici. L'article 352 du
TFUE sous-tend les éléments que l'article 114 ne couvre pas, à savoir
l'établissement de la Réserve en tant qu'organisme au niveau de l'Union et
le droit individuel des citoyens. Cette base n'est pas un terrain vierge
pour la participation : le Conseil a agi sur la participation des
travailleurs salariés aux bénéfices et aux résultats de l'entreprise par la
recommandation 92/443/CEE, adoptée sur le prédécesseur de l'article 352. Une
recommandation ne crée aucune compétence et le présent exposé des motifs n'en revendique aucune ; ce qu'elle établit est plus étroit et utile : l'Union a
déjà traité la participation aux résultats de l'entreprise comme une
question de niveau européen sur cette base. Ces éléments sont rédigés de
manière à être séparables, précisément pour que l'unanimité qu'ils
requièrent ne puisse prendre en otage les couches fondées sur l'article 114,
et pour qu'un enregistrement partiel ou une annulation partielle élague
l'instrument plutôt que de le détruire.

Le préambule du projet cite uniquement l'article 114. La procédure législative ordinaire de cet article et l'unanimité du Conseil avec approbation du Parlement prévue à l'article 352 ne constituent pas une procédure unique. Si l'article 114 ne permet pas de porter les chapitres IV à VI, ceux-ci nécessiteraient un règlement distinct du Conseil fondé sur l'article 352. Cette architecture à deux actes n'est pas achevée ; le document relatif à la séparabilité en expose la stratégie, sans prétendre qu'elle a déjà été adoptée.

L'article 114, paragraphe 2, du TFUE exclut les dispositions fiscales, et la
question de qualification qui en découle constitue le risque juridique le
plus sérieux que comporte le présent instrument. Elle est exposée dans toute
sa force et traitée à l'objection 2, et c'est dans cette objection, et non
dans le présent exposé des motifs, que se trouve l'argumentation. En résumé:
l'obligation porte sur un actif et non sur un flux, est payable en actions
et jamais en numéraire, ne finance aucun budget, ne transite par aucun
trésor public et ne confère aucune recette à l'Union. L'avis du Forum de
l'ICE du 27 août 2026 mentionne l'article 115 du TFUE comme base
envisageable si cette qualification venait à échouer ; il est consigné ici,
non retenu. L'article 115 n'exclut pas les dispositions fiscales, mais,
selon l'analyse des conseillers eux-mêmes, il exige la même lecture
d'harmonisation que l'article 114 tout en abandonnant le vote à la majorité
qualifiée, et la rédaction par couches intègre déjà l'unanimité là où elle
est inévitable.

### 2.2 Choix de l'instrument

Un règlement, et non une directive, pour trois raisons. L'obligation s'attache à un nombre restreint d'entreprises opérant sur l'ensemble du marché intérieur, et une transposition dans vingt-sept régimes nationaux reproduirait exactement les divergences que la mesure a pour objet d'éliminer. Le warrant doit avoir un contenu identique dans chaque État membre car une entreprise donnée émet un instrument unique auprès d'une Réserve unique. Et le droit est détenu directement par les citoyens à l'encontre d'un organisme de l'Union, ce qui exige une applicabilité directe plutôt que des mesures nationales d'exécution. Le chapitre V confie l'administration des droits à des véhicules nationaux, ce qui constitue le lieu approprié et autorisé pour les variations nationales.

### 2.3 Subsidiarité

L'objectif ne peut pas être atteint de manière suffisante par les États membres agissant séparément, car les entreprises concernées opèrent sur l'ensemble du marché intérieur et des mesures nationales créeraient précisément la divergence que le règlement élimine. Un régime national de participation s'appliquerait à des entreprises dont la valeur découle d'une activité à l'échelle de l'Union, ce qui, soit manquerait sa cible, soit produirait vingt-sept prétentions incompatibles sur le même capital. Le considérant 34 en contient la formulation formelle.

### 2.4 Proportionnalité

L'ingérence dans le droit de propriété au titre de l'article 17 de la Charte est réelle et n'est pas minimisée dans ce dossier. La proportionnalité est assurée par cinq caractéristiques de la rédaction: le pourcentage est fixe et faible; la créance s'attache prospectivement dès la désignation à une souscription calculée sur l'ensemble du capital à la cristallisation, y compris la valeur antérieure; elle se cristallise lors d'un événement de liquidité, d'un prélèvement qualifiant ou de l'échéance légale de sept ans; l'évaluation est indépendante et susceptible de recours distinct au titre des articles 6 et 7; et la détention ne confère aucun droit de vote, aucun siège au conseil d'administration et aucun pouvoir de direction.

Sur le volet de la nécessité, le présent exposé des motifs prend acte d'une limite plutôt que de revendiquer un point fort. L'article 1er, paragraphe 2, énonce désormais un objectif chiffré, et trois pour cent constitue le plus petit pourcentage entier qui s'en approche selon le modèle publié, de sorte que la nécessité peut pour la première fois être démontrée à partir d'une quantité définie plutôt que simplement affirmée. Toutefois, le modèle étant linéaire par rapport au pourcentage, la cible elle-même est choisie plutôt que déduite. L'objection 21 expose ce point de manière exhaustive, y compris sa circularité, avant qu'un réviseur ne le fasse.

---

## 3. Résultats des évaluations ex post, des consultations des parties prenantes et des analyses d'impact

### 3.1 Évaluations ex post

Néant. Il n'existe aucun instrument de l'Union en vigueur dans ce domaine susceptible d'être évalué.

### 3.2 Consultation des parties prenantes

Aucune consultation formelle n'a été menée, et aucune n'aurait pu l'être : il s'agit d'un projet citoyen et aucune institution n'a procédé à une consultation à son sujet. Affirmer que « les parties prenantes ont été consultées » serait faux, et le présent exposé des motifs ne l'affirmera pas.

Ce qui existe en lieu et place est un examen contradictoire, mené sur le texte à chaque étape et publié dans son intégralité : six points de contrôle couvrant la forme juridique, le respect des contraintes, la base juridique, l'analyse contradictoire hostile, la cohérence avec l'acquis et la fidélité de structure, chaque verdict étant consigné, y compris les échecs, ainsi qu'un registre public consignant ce que chaque cycle a modifié et ce qui a été refusé, motifs à l'appui. Vingt et une objections sont formulées sous leur forme la plus rigoureuse et reçoivent une réponse, plusieurs d'entre elles étant fatales si elles étaient fondées, et au moins deux options de conception complètes ont été écartées au cours de ce processus avant d'atteindre le stade de la publication.

Cela ne remplace pas la consultation des personnes qu'un instrument lierait, et le présent exposé des motifs ne le présente pas comme tel. C'est ce qu'un dossier peut accomplir avant d'avoir qualité pour consulter quiconque. Une demande relative à la recevabilité est en cours d'examen auprès du forum de l'initiative citoyenne européenne.

### 3.3 Analyse d'impact

Aucune analyse d'impact formelle au titre des lignes directrices pour une meilleure réglementation n'a été effectuée, et une initiative citoyenne n'est pas tenue d'en réaliser une. Ce qui suit constitue l'analyse existante, sous la forme utilisée par ces lignes directrices, en précisant ses limites.

**Options stratégiques envisagées.**

*Option 0, absence d'action de l'Union.* Les États membres continuent de légiférer séparément sur les prélèvements sur l'automatisation et les régimes de participation. Les divergences s'accentuent, les entreprises concernées sont confrontées à vingt-sept régimes ou à aucun, et la question de la propriété reçoit une réponse nationale là où elle ne peut trouver de réponse qu'à l'échelle à laquelle opèrent les entreprises. Il s'agit du scénario de référence par rapport auquel les autres options sont évaluées, et c'est l'option que l'examen contradictoire identifie systématiquement comme étant la plus sûre pour le législateur de l'Union et la pire pour l'objectif visé.

*Option 1, une taxe sur la production automatisée ou sur les jetons d'inférence.* Il s'agit de la famille concurrente directe : des propositions législatives de ce type existent dans des pays tiers, y compris une proposition déposée aux États-Unis en août 2026 prévoyant un taux progressif à mesure que le chômage augmente. Elle permet de lever des fonds plus tôt et en montants plus élevés au cours des premières décennies, ce que le warrant ne fait pas. Elle a été rejetée pour deux motifs de fond, et une troisième observation est consignée séparément car elle ne doit pas être confondue avec un motif. Premièrement, il s'agit d'un flux et non d'un actif, de sorte que les citoyens reçoivent un transfert plutôt qu'une détention, et la distinction entre une prestation et une participation constitue la thèse centrale du présent instrument : un transfert est renégocié annuellement et annulable à la majorité simple, une détention constitue une propriété. Deuxièmement, et pour la même raison, elle peut être abrogée par la majorité qui l'adopte, ce que l'historique des ponctions documenté dans le corpus de données probantes montre qu'il ne s'agit pas d'un risque théorique. L'observation distincte est qu'un prélèvement sur la consommation ou sur la production relève sans ambiguïté du domaine fiscal et exigerait l'unanimité en vertu de l'article 113 du TFUE. Il s'agit là d'une conséquence de la nature d'un tel instrument, et non d'un motif de lui préférer le présent instrument, et le présent exposé des motifs ne la présente pas comme telle. La thèse de la propriété est antérieure à toute question de compétence et demeurerait identique si les deux voies requéraient la même majorité. Le lecteur est fondé à mettre à l'épreuve cette affirmation au regard des quatre critères énoncés dans GOVERNANCE.md, qui ont été adoptés avant le choix de toute base juridique et qui rejettent les instruments fondés sur les flux selon leurs propres termes. La comparaison complète, y compris les ordres de grandeur, est publiée sous evidence/token-taxes.md.

*Option 2, un fonds souverain de l'Union capitalisé par le budget.* Cela nécessite des fonds dont l'Union ne dispose pas, entre en concurrence directe avec toutes les autres lignes budgétaires et aboutit à un fonds détenu par l'Union plutôt que par les citoyens, ce qui va à l'encontre de l'objectif d'appropriation et expose les actifs précisément à l'historique de ponctions documenté dans le corpus de données probantes.

*Option 3, une participation assortie de droits de vote.* Une Réserve détenant des actions avec droit de vote conférerait à l'Union une influence sur les entreprises qu'elle régule. Option rejetée : il s'agit du pot de miel assorti d'un levier de l'objection 9 et de l'action spécifique de l'objection 16, que la Cour a invalidée sous toutes ses formes.

*Option 4, le warrant de capital citoyen, privilégiée.* Sans droit de vote, pourcentage fixe, prospective, se cristallisant selon les trois déclencheurs légaux, payable uniquement en actions. Elle est retenue parce qu'elle est la seule option identifiée qui transfère la propriété plutôt que des revenus et qui transforme l'abrogation en expropriation : un législateur futur peut toujours s'en saisir, mais il doit le faire au titre d'une privation de propriété, dans le respect de l'article 17 et de l'article 52, paragraphe 1, de la Charte, plutôt qu'en modifiant une ligne budgétaire. La règle DC-23 énonce le principe qui sous-tend ce choix, selon lequel la résistance aux ponctions constitue une friction et jamais une impossibilité, et le présent exposé des motifs ne revendique rien de plus qu'une friction.

**Incidences économiques.** Les entreprises désignées subissent une dilution de trois pour cent de leur capital, en une seule fois, se cristallisant lors de leur propre événement de liquidité, lors d'un prélèvement au profit des actionnaires supérieur au seuil fixé ou à l'échéance butoir de sept ans, la première occurrence étant retenue, de sorte que le calendrier leur appartient uniquement jusqu'à ce que l'échéance butoir soit atteinte. Les investisseurs intégreront dans les prix la dilution future obligatoire dès la désignation, ce qui constitue un coût réel examiné à l'objection 4. Neuf entreprises sont présumées désignées sur la base des chiffres d'août 2026, pour une valeur combinée d'environ 20,5 billions d'euros ; le calcul figure sous evidence/designation-count.md. Cette estimation datée n'est pas une liste fermée : les notifications futures, la désignation sous les seuils et les obligations des cessionnaires restent applicables selon les articles 3 et 5. À titre de comparaison : les entreprises les plus à forte intensité capitalistique dépendantes de la main-d'œuvre observées atteignent un ratio valeur/masse salariale compris entre trente et quarante, pour un seuil fixé à quatre-vingts.

**Incidences sociales.** L'objectif est une participation durable et égale au capital constitué sur une génération, conformément au livre publié et à l'article 1er, paragraphe 2. Le droit naît pour les citoyens de l'Union âgés de 18 ans ou plus, avec inscription aux fins du paiement conformément à l'article 10. Les distributions disponibles sont égales selon cet article ; aucun paiement positif ni aucune hausse annuelle ne sont garantis. Une plus-value latente ne constitue pas un revenu disponible en espèces. Le simulateur présente des scénarios conditionnels avec le capital par personne à côté du paiement ; il ne modélise pas intégralement la trésorerie, les coûts ou l'éligibilité. La proposition ne garantit pas le remplacement immédiat d'un revenu.

**Incidences environnementales.** Évaluées comme non significatives, au regard du principe consistant à « ne pas causer de préjudice important » et de l'obligation de cohérence prévue à l'article 6, paragraphe 4, du règlement (UE) 2021/1119 (la loi européenne sur le climat), plutôt qu'écartées d'emblée. L'instrument ne réglemente ni ce qu'une entreprise produit, ni la manière dont elle le produit, ni l'énergie qu'elle utilise. Il transfère une part de propriété et ne génère aucune activité physique, aucune infrastructure, aucun transport et aucun changement dans les décisions de production, de sorte qu'aucun des six objectifs environnementaux n'est affecté négativement par une disposition opérationnelle quelconque. Les canaux méritant d'être mentionnés sont indirects et sont cités ici afin que le lecteur puisse les soupeser plutôt que de les découvrir. Premièrement, les entreprises désignées comprennent des exploitants d'infrastructures informatiques à forte intensité énergétique, et le règlement n'augmente ni ne restreint cette consommation ; il est neutre à cet égard, ce qui constitue un constat d'absence d'effet et non la revendication d'un avantage. Deuxièmement, une Réserve détenant des participations dans de telles entreprises acquiert une exposition à leur risque de transition, que son obligation de préservation du capital au titre de l'annexe II l'oblige à gérer ; l'article 9 lui interdit d'utiliser cette détention pour orienter la conduite d'une quelconque entreprise, sur le plan environnemental ou autre. Troisièmement, les distributions aux citoyens constituent des revenus du patrimoine d'une ampleur précisée ailleurs dans le présent exposé des motifs, trop faible au cours des décennies concernées pour produire un effet mesurable sur la consommation. Aucun avantage environnemental positif n'est revendiqué, et aucune évaluation de la pérennité climatique au titre de la boîte à outils pour une meilleure réglementation n'a été réalisée. Au vu des éléments disponibles, l'instrument est neutre pour l'environnement par conception.

**Droits fondamentaux.** L'article 17 (propriété) est concerné par l'obligation d'émission et examiné en détail ci-dessus ainsi qu'à l'objection 1. L'article 16 (liberté d'entreprise) est concerné par l'imposition de l'émission. L'article 41 (bonne administration) est concerné par les décisions individuelles de désignation au titre de l'article 3 et par les enquêtes de marché au titre de l'article 4, et est garanti par le droit d'être entendu sur les conclusions préliminaires de la Commission prévu à l'article 4, paragraphe 4, par les délais de décision fixes et par l'obligation de motivation. L'article 47 (recours effectif et tribunal impartial) est concerné par ces mêmes décisions une fois adoptées, par l'évaluation indépendante contraignante au titre des articles 6 et 7 et par les sanctions au titre de l'article 13 ; il est garanti par un contrôle juridictionnel complet devant la Cour de justice, et l'article 7 rend l'évaluation justiciable séparément afin qu'un litige sur la valeur n'ait pas à être intégré dans un litige relatif à la désignation. Les articles 20 et 21 (égalité et non-discrimination) sont concernés par les critères de seuil de l'article 3, paragraphe 2, qui s'appliquent de manière identique aux entreprises de l'Union et des pays tiers. L'article 8 (protection des données à caractère personnel) est concerné par la gestion des droits et traité au considérant 33 et à l'article 11, paragraphe 5. L'article 34 de la Charte (sécurité sociale et aide sociale) est mentionné dans le considérant relatif à la Charte en tant qu'élément de contexte, non comme fondement.

**Incidence budgétaire** : voir section 4.

### 3.4 Adéquation de la réglementation et simplification

Les notifications, la désignation et la réfutation suivent l'article 3. Les entreprises désignées et les cessionnaires assujettis émettent également les instruments, fournissent les informations et évaluations et exécutent les souscriptions selon les articles 5 et 6. Les États membres et véhicules nationaux ont les obligations de l'article 11. Le chiffre d'affaires et les rémunérations reposent sur des données auditées ; la juste valeur de marché suit la méthode de transaction, d'évaluation ou de prix de marché de l'annexe I et peut nécessiter une mesure supplémentaire. L'article 3, paragraphe 8, corrigé protège les augmentations de rémunération d'un travail réel existant ; les acquisitions restent soumises à sa règle distincte fondée sur les effets.

### 3.5 Ce dont la présente section ne peut se prévaloir

Il n'y a eu aucune consultation des entreprises qui seraient désignées, aucune modélisation macroéconomique au-delà du simulateur publié, aucun avis du comité d'examen de la réglementation, et aucune évaluation réalisée par des professionnels de la discipline. Chaque énoncé quantitatif ci-dessus repose sur les quatre notes de données probantes et sur le modèle publié, tous reproductibles, aucun n'ayant fait l'objet d'un audit. Le lecteur qui s'appuie sur le présent exposé des motifs doit le considérer comme un projet rigoureusement testé et non comme une analyse d'impact.

---

## 4. Incidence budgétaire

Le warrant est un instrument obligatoire de propriété réglé en actions, et non un prélèvement périodique sur la production ou le revenu. Sa qualification juridique reste contestée comme indiqué à la section 2.1. La Réserve paie en espèces la valeur nominale et peut emprunter à cette fin selon l'article 9, paragraphe 1, point e). Les entreprises supportent les coûts d'évaluation ; les amendes de l'article 13 reviennent au budget de l'Union. Les États membres administrent les véhicules, peuvent compenser les coûts selon l'article 11, paragraphe 3, et doivent rembourser les coûts transfrontières qualifiants selon le paragraphe 4. Il serait donc inexact de nier toute conséquence pour les recettes ou dépenses publiques.

L'administration de la Commission, la conservation et l'audit de la Réserve, les évaluations et les comptes nationaux nécessitent des ressources. Les comparaisons dans evidence/administrative-cost.md sont des estimations sans devis, et non des engagements d'effectifs ou une fiche financière de la Commission. Elles n'établissent pas le coût de la gouvernance proposée. L'article 11, paragraphe 3, plafonne les frais des véhicules aux coûts réels et, en tout état de cause, à 0,3 % par an des montants administrés. Ce plafond ne rend pas l'administration gratuite. Le modèle de référence proposé distingue coûts, dette de souscription, préservation du capital et sommes allouées ; il ne constitue pas encore l'annexe II.

Une proposition de la Commission nécessiterait une fiche financière législative et un plan de financement initial vérifié. Les restrictions relatives aux contributions budgétaires à la Réserve demeurent ; l'autorisation d'emprunter pour la souscription ne garantit pas un prêteur. L'automatisation peut réduire le travail courant sans supprimer conservation, sécurité, audit ou responsabilité juridique. Le dossier de corrections comprend une proposition explicite d'administration et des options comptables à examiner, sans modifier l'objectif publié de propriété sur une génération.

## 5. Autres éléments

### 5.1 Plans de mise en œuvre et suivi

L'article 14 oblige la Commission à suivre la diffusion des systèmes cognitifs automatisés, la détention d'actions par les ménages, les parts du travail et du capital dans la valeur ajoutée au sein des secteurs concernés, le fonctionnement même du règlement ainsi que l'évolution, à la hausse comme à la baisse, de la part du travail dans l'Union par rapport à 2025. Elle doit procéder à une évaluation et présenter un rapport au plus tard le 31 décembre 2032, puis tous les trois ans.

La condition de réfutabilité constitue la disposition inhabituelle et procède d'un choix délibéré. L'article 14, paragraphe 3, oblige le rapport à indiquer expressément les cas où les éléments de preuve ne corroborent pas la prémisse même du règlement, et à proposer une modification ou une abrogation. L'article 1er, paragraphe 2, oblige ce même rapport à évaluer si l'objectif quantifié est manifestement hors d'atteinte ou manifestement dépassé, et à proposer de modifier le pourcentage ou les seuils, à la hausse comme à la baisse. Un règlement reposant sur une affirmation empirique réfutable se doit de comporter son propre test.

### 5.2 Documents explicatifs

L'ensemble du dossier est public : le dispositif, les considérants, les annexes, le présent exposé des motifs, la note relative aux contre-arguments, la note relative à la divisibilité, la base de données probantes ainsi que chaque avis d'examen, y compris ceux auxquels le texte n'a pas satisfait. L'historique de rédaction constitue un journal des modifications public.

### 5.3 Explication détaillée des dispositions spécifiques

Le chapitre Ier (articles 1er à 2) énonce l'objet, l'objectif quantifié et les définitions. Le chapitre II (articles 3 à 4) procède à la désignation des entreprises couvertes sur la base de critères qualitatifs cumulatifs assortis d'une présomption quantitative réfragable, et prévoit des enquêtes de marché ainsi qu'un réexamen. Le chapitre III (articles 5 à 7) crée le warrant de capital citoyen, ses événements de cristallisation, y compris le déclencheur du prélèvement au profit des actionnaires et l'échéance butoir de sept ans, l'évaluation indépendante et les garanties. Le chapitre IV (articles 8 à 9) institue la Réserve et limite le vote, la direction, les acquisitions et les emprunts. L'article 9 autorise certains réinvestissements, diversifications et emprunts ; la proposition distincte de gouvernance n'est pas encore adoptée. Le chapitre V (articles 10 à 11) crée le droit individuel du citoyen et son administration par l'intermédiaire de véhicules nationaux. Le chapitre VI (article 12) protège la Réserve et les droits. Le chapitre VII (articles 13 à 16) prévoit les sanctions, le suivi, les délégations de pouvoir et la procédure de comité. Le chapitre VIII (articles 17 à 18) contient les dispositions transitoires et l'entrée en vigueur. L'annexe I définit la méthodologie de calcul ; l'annexe II, l'arithmétique de rétention et de distribution.

La note relative à la divisibilité précise la manière dont l'instrument se décompose en cas d'invalidation d'une partie, en quatre niveaux, de sorte qu'un enregistrement partiel ou une annulation partielle élague l'instrument au lieu de le détruire.

### 5.4 Points ouverts, énoncés plutôt que dissimulés

- L’interaction avec la directive (UE) 2024/2810 sur les structures à actions à votes multiples ; les autres questions relatives à l’acquis nécessitent une liste vérifiée.
- Les nominations de la Réserve, son financement initial, les émetteurs juridiques, les périodes de paiement et la spécification comptable proposée dans proposals/2026-09-07-generational-repairs/.
- La question de savoir si un critère par segment d'activité devrait être réintroduit en tant que seconde présomption à l'article 3, paragraphe 2, en cas de constatation d'une dilution par acquisition antérieure à la désignation.
- La question de savoir si l'instrument doit s'étendre à la fabrication de semi-conducteurs, ce que le volet qualitatif et la réfutation prévue à l'article 3, paragraphe 5, laissent actuellement à décider au cas par cas.

Chacun de ces points est consigné dans le registre d'examen ou dans les notes de rédaction, avec le raisonnement qui a conduit à le laisser ouvert.


# SOURCE: own-the-machine/regulation/memorandum/explanatory-memorandum.md

# Explanatory memorandum

Accompanying the draft Regulation of the European Parliament and of the
Council on harmonised rules for citizen participation in automated
productivity gains.

This memorandum follows the structure the Commission uses for its own
proposals. It is written by citizens, not by the Commission, and it is not
required: Regulation (EU) 2019/788 permits a citizens' initiative to attach
a draft legal act and asks nothing of this kind. It exists because the
questions the Commission's services would have to answer about this
instrument are worth answering before they are asked, and because a file
that cannot answer them is not ready to be acted on. Where an answer does
not exist yet, this memorandum says so rather than filling the heading.

---

## 1. Context of the proposal

### 1.1 Reasons for and objectives of the proposal

Automated cognitive systems are beginning to produce output at a scale that
does not require a corresponding quantity of human labour. Where that
decoupling occurs, the returns to production accrue to the holders of the
capital that embodies the automation, and the share reaching citizens
through wages falls with the labour share.

The problem this Regulation addresses is not that outcome in itself, which
is a matter for many instruments, but a narrower one within the Union's
competence: the ownership of the capital in which those returns
concentrate is extremely narrow, and Member States have begun to respond
separately, with divergent national levies, participation schemes and
proposals for taxing automated output. Those divergences fragment the
internal market for exactly the undertakings that operate across all of
it.

The objective is stated and quantified in Article 1(2): participation of
citizens of the Union in the capital value created by hyper-automated
production, at a scale where the holdings behind each citizen's entitlement
reach the order of six months of median equivalised disposable income in the
Union within a generation of the first designations.

### 1.2 Consistency with existing provisions in the policy area

The designation architecture follows Regulation (EU) 2022/1925 (the Digital
Markets Act): cumulative qualitative criteria, quantitative thresholds
giving rise to a rebuttable presumption, self-notification, a
below-threshold designation route on the facts, and an anti-circumvention
power. That is a deliberate reuse of a structure the Union legislature has
already adopted and the Court has not disturbed.

The company-law interface is drafted as express, narrow derogation from
Directive (EU) 2017/1132 rather than as general override, following the
formula of the resolution acquis. The prospectus interface is an express
exemption under Regulation (EU) 2017/1129. Article 1(5) preserves Directive
(EU) 2016/2341 and Regulation (EU) 2019/1238 save as Article 11 provides.

Open acquis questions are identified in section 5.4; the earlier claim of an enumerated five-item list is withdrawn.
They are recorded rather than resolved, which is the honest state.

### 1.3 Consistency with other Union policies

The instrument takes non-voting equity and confers no governance right,
which keeps it outside the field the Court's case law on special public
shareholdings occupies (Commission v Germany, C-112/05, and the line
following it). That choice has a cost, examined at objection 20: voteless
shares raise the relative voting weight of the remaining holders, and the
Union has lately legislated in the other direction on multiple-vote share
structures in Directive (EU) 2024/2810. The interaction with that Directive
is an open interface point, not a resolved one.

Nothing in this Regulation creates a Union own resource, and nothing enters
the Union budget. That is a design constraint, not an incidental property:
see section 4.

---

## 2. Legal basis, subsidiarity and proportionality

### 2.1 Legal basis

The legal basis is stated by layer, not as a single centre of gravity for
the whole act, because incompatible legislative procedures cannot be fused
into one basis (Titanium Dioxide, C-300/89) and because a unitary argument
would concede the weakest layer's characterisation to the strongest layer's
opponents. The severability memorandum sets the layers out; decomposition
rule 3 requires this treatment. Article 114 TFEU carries the designation
regime, the transparency obligations and the warrant: rules addressed to
undertakings operating across the whole internal market, removing the
divergence that separate national participation and automation levies are
already creating. The Commission has registered an initiative resting on
that same divergence logic over comparably contested ground: the 2023
wealth-tax initiative, by Decision (EU) 2023/1487. The independent advice
obtained through the ECI Forum on 27 August 2026, recorded in
pipeline/EXTERNAL-REVIEWS.md and binding on nobody, reads that decision the
same way and recommends citing it here. Article 352 TFEU carries the
elements Article 114 does not reach, namely the establishment of the Reserve
as a Union-level body and the individual entitlement of citizens. That basis
is not untrodden ground for participation: the Council acted on the
participation of employed persons in profits and enterprise results by
Recommendation 92/443/EEC, adopted on Article 352's predecessor. A
recommendation creates no power and this memorandum claims none from it;
what it establishes is narrower and useful, that the Union has treated
participation in enterprise results as a Union-level concern under this
basis before. Those elements are drafted to be severable precisely so that
the unanimity they require cannot hold the Article 114 layers hostage, and
so that partial registration or partial annulment trims the instrument
rather than destroying it.

The preamble of the draft cites Article 114 alone. A single act cannot
carry two legislative procedures: Article 352 requires unanimity in the
Council and the consent of the Parliament where Article 114 requires the
ordinary legislative procedure, and the legal-form and legal-basis gates of
6 September 2026 (pipeline/reviews) confirmed that a citation scoped by
chapter is not an available form. The Reserve, the entitlement and their
protection, Chapters IV to VI, are therefore drafted so that, if Article
114 is held not to reach them, they can be enacted as a separate Council
Regulation on Article 352 with the warrant regime unchanged. That is the
form Layer 3 of the severability memorandum provides for, and it is what
the registration
text's reference to Article 352 contemplates.

Article 114(2) excludes fiscal provisions, and the characterisation question
that follows is the most serious legal risk this instrument carries. It is
stated at full strength and answered at objection 2, and that objection, not
this memorandum, is where the argument lives. The short form: the obligation
takes an asset and not a flow, is payable in shares and never in cash, funds
no budget, passes through no treasury and confers no revenue on the Union.
The ECI Forum's advice of 27 August 2026 notes Article 115 TFEU as a
conceivable basis if that characterisation were to fail; it is recorded
here, not adopted. Article 115 does not exclude fiscal provisions, but on
the advisers' own analysis it demands the same harmonisation reading as
Article 114 while surrendering qualified majority voting, and the layered
drafting already prices unanimity in where it is unavoidable.

### 2.2 Choice of the instrument

A Regulation, and not a Directive, for three reasons. The obligation
attaches to a small number of undertakings operating across the entire
internal market, and transposition into twenty-seven national regimes
would reproduce exactly the divergence the measure exists to remove. The
warrant must have identical content in every Member State because a single
undertaking issues one instrument to one Reserve. And the entitlement is
held directly by citizens against a Union body, which requires direct
applicability rather than national implementing law. Chapter V leaves the
administration of entitlements to national vehicles, which is where
national variation belongs and is permitted.

### 2.3 Subsidiarity

The objective cannot be sufficiently achieved by Member States acting
separately, because the undertakings concerned operate across the entire
internal market and national measures would create the very divergence the
Regulation removes. A national participation scheme would apply to
undertakings whose value arises from Union-wide activity, which either
under-reaches or produces twenty-seven incompatible claims on the same
capital. Recital 34 carries the formal statement.

### 2.4 Proportionality

The interference with the right to property under Article 17 of the Charter
is real and is not minimised in this file. Proportionality is carried by
five features of the drafting: the percentage is fixed and small; the
claim attaches prospectively at designation to a subscription measured
against the whole capital at crystallisation, including earlier value; it
crystallises on a liquidity event, qualifying extraction or the statutory
seven-year long-stop; the valuation is independent and separately justiciable under
Articles 6 and 7; and the holding confers no vote, no board seat
and no direction of management.

On the necessity limb, this memorandum records a limit rather than claiming
a strength. Article 1(2) now states a quantified objective, and three per
cent is the smallest integer percentage that approaches it on the published
model, so necessity can for the first time be argued from a stated quantity
rather than asserted. But the model is linear in the percentage, so the
target itself is chosen rather than derived. Objection 21 sets this out in
full, including the circularity, before a reviewer does.

---

## 3. Results of ex-post evaluations, stakeholder consultations and impact assessments

### 3.1 Ex-post evaluations

None. There is no existing Union instrument in this field to evaluate.

### 3.2 Stakeholder consultations

No formal consultation has been held, and none could be: this is a citizens'
draft and no institution has consulted on it. Saying "stakeholders were
consulted" would be false and this memorandum will not say it.

What exists instead is adversarial review, run against the text at every
stage and published in full: six review gates covering legal form,
constraint compliance, legal basis, hostile counsel, acquis coherence and
layer fidelity, with every verdict committed including the failures, and a
public ledger recording what each round changed and what was refused with
reasons. Twenty-one objections are stated at their strongest and answered,
several of them fatal-if-true, and at least two whole design alternatives
were killed in that process before reaching publication.

That is not a substitute for consulting the people an instrument would
bind, and this memorandum does not present it as one. It is what a file can
do before it has standing to consult anybody. A registrability enquiry is
pending with the European Citizens' Initiative Forum.

### 3.3 Impact assessment

No formal impact assessment under the Better Regulation guidelines has been
carried out, and a citizens' initiative is not required to carry one. What
follows is the analysis that does exist, in the form those guidelines use,
with its limits stated.

**Policy options considered.**

*Option 0, no Union action.* Member States continue to legislate separately
on automation levies and participation schemes. The divergence grows, the
undertakings concerned face twenty-seven regimes or none, and the ownership
question is answered nationally where it can only be answered at the scale
the undertakings operate. This is the baseline against which the others are
measured, and it is the option hostile review consistently identifies as
the safest for the Union legislature and the worst for the objective.

*Option 1, a tax on automated output or on tokens of inference.* This is the
live competing family: legislative proposals of this kind exist in third
countries, including one introduced in the United States in August 2026 with
a rate that escalates as unemployment rises. It raises money sooner and in
larger amounts in the early decades, which the warrant does not. It was
rejected on two substantive grounds, and a third observation is recorded
separately because it must not be mistaken for a reason. First, it is a flow
and not an asset, so citizens receive a transfer rather than a holding, and
the distinction between a benefit and a stake is the entire thesis of this
instrument: a transfer is renegotiated annually and cancellable by simple
majority, a holding is property. Second, and for the same reason, it is
repealable by the majority that enacts it, which the raid history in the
evidence base shows is not a theoretical risk. The separate observation is
that a consumption or output levy is unambiguously fiscal and would require
unanimity under Article 113 TFEU. That is a consequence of what such an
instrument is, not a reason for preferring this one, and this memorandum
does not offer it as one. The ownership thesis is prior to any competence
question and would be the same if both routes required the same majority. A
reader is entitled to test that claim against the four tests in
GOVERNANCE.md, which were adopted before any legal basis was chosen and
which reject flow-based instruments on their own terms. The full comparison,
including the magnitudes, is published at evidence/token-taxes.md.

*Option 2, a Union sovereign wealth fund capitalised from the budget.* This
requires the money the Union does not have, competes directly with every
other budget line, and produces a fund owned by the Union rather than by
citizens, which fails the ownership objective and exposes the assets to
exactly the raid history the evidence base documents.

*Option 3, a voting stake.* A Reserve holding voting shares would give the
Union influence over the undertakings it regulates. Rejected: it is
objection 9's honeypot with a lever attached and objection 16's golden
share, which the Court has struck down in every form it has taken.

*Option 4, the citizens' capital warrant, preferred.* Non-voting, fixed
percentage, prospective, crystallising at the three statutory triggers,
payable only in shares. It is chosen because it is the only option
identified that transfers ownership rather than income and converts repeal
into expropriation: a future legislature can still take it, but it must do
so as a taking of property, meeting Article 17 and Article 52(1) of the
Charter, rather than by amending a budget line. DC-23 states the rule this
reflects, that raid resistance is friction and never impossibility, and this
memorandum does not claim more than friction.

**Economic impacts.** The designated undertakings bear a dilution of three
per cent of capital, once, crystallising on their own liquidity event, on
shareholder extraction above the stated threshold, or at the seven-year long
stop, whichever comes first, so the timing is theirs only until the long
stop reaches it. Investors will price mandatory future dilution from
designation onward, which is a real cost and is examined at objection 4.
Nine undertakings are presumptively designated on August 2026 figures, with
roughly EUR 20,5 trillion of combined value; the calculation is at
evidence/designation-count.md. This dated estimate is not a closed list: future notifications,
below-threshold designation and transferee obligations also apply as
provided in Articles 3 and 5. The scale comparison remains informative: the most capital-intensive labour-reliant undertakings
observed reach a value-to-payroll ratio in the thirties, against a threshold
of eighty.

**Social impacts.** The objective is lasting, equal participation in capital
built over one generation, as expressed in the published book and Article
1(2). The entitlement arises for Union citizens aged 18 or over, with
registration for payment purposes under Article 10. Available distributions
are equal under that Article; neither a positive payment nor an increase
from one year to the next is guaranteed. Capital appreciation alone is not
spendable income. The simulator shows conditional scenarios with the stake
beside the payout; it is not a complete cash, cost or eligibility model.
The proposal does not establish a current income-replacement guarantee.

**Environmental impacts.** Assessed as not significant, against the do no
significant harm principle and the consistency duty in Article 6(4) of
Regulation (EU) 2021/1119 (the European Climate Law), rather than dismissed.
The instrument regulates neither what an undertaking produces, nor how, nor
what energy it uses. It transfers a share of ownership and creates no
physical activity, no infrastructure, no transport and no change in any
production decision, so none of the six environmental objectives is
adversely affected by any operative provision. The channels worth naming are
indirect and are named here so that a reader can weigh them rather than
discover them. First, the designated undertakings include operators of
energy-intensive computing infrastructure, and the Regulation neither
increases nor restrains that consumption; it is neutral to it, which is a
statement of no effect and not a claim of benefit. Second, a Reserve holding
equity in such undertakings acquires an exposure to their transition risk,
which its capital-preservation duty under Annex II obliges it to manage;
Article 9 forbids it from using that holding to direct any undertaking's
conduct, environmental or otherwise. Third, distributions to citizens are
property income of a magnitude stated elsewhere in this memorandum, too
small in the relevant decades to produce a measurable consumption effect. No
positive environmental benefit is claimed, and no climate-proofing
assessment under the Better Regulation toolbox has been carried out. On the
evidence available the instrument is environmentally neutral by
construction.

**Fundamental rights.** Article 17 (property) is engaged by the issuance
obligation and examined at length above and at objection 1. Article 16
(freedom to conduct a business) is engaged by compelling issuance. Article
41 (good administration) is engaged by the individual designation decisions
under Article 3 and the market investigations under Article 4, and is served
by the right to be heard on the Commission's preliminary findings in Article
4(4), by the fixed decision deadlines and by the duty to state reasons.
Article 47 (effective remedy and fair trial) is engaged by those same
decisions once taken, by the binding independent valuation under Articles 6
and 7 and by the penalties under Article 13; it is served by full judicial
review before the Court of Justice, and Article 7 makes the valuation
separately justiciable so that a dispute about value need not be carried
inside a dispute about designation. Articles 20 and 21 (equality and non-
discrimination) are engaged by the threshold criteria in Article 3(2), which
apply identically to Union and third-country undertakings. Article 8
(protection of personal data) is engaged by the administration of
entitlements and addressed in recital 33 and Article 11(5). Article 34 of
the Charter (social security and social assistance) is referenced in the
Charter recital as context, not as a basis.

**Budgetary implications**: see section 4.

### 3.4 Regulatory fitness and simplification

Threshold notifications, designation and rebuttal follow Article 3.
Designated undertakings and bound transferees also issue instruments,
provide information and valuations, and execute subscriptions under
Articles 5 and 6. Member States and national vehicles have Article 11 duties.
Turnover and remuneration use audited records; fair market value follows
Annex I's transaction, valuation or market-price methodology and may require
additional measurement. Genuine pay rises for existing work are protected
under the repaired Article 3(8), while acquisitions remain subject to its
separate effects-based rule.

### 3.5 What this section cannot claim

There has been no consultation of the undertakings that would be
designated, no macroeconomic modelling beyond the published simulator, no
Regulatory Scrutiny Board opinion, and no assessment by anyone who does
this professionally. Every quantitative statement above rests on the four
evidence notes and the published model, all reproducible, none audited. A
reader relying on this memorandum should treat it as a well-tested draft
and not as an impact assessment.

---

## 4. Budgetary implications

The warrant is a mandatory ownership instrument settled in shares, not a
periodic charge on production or income. Its legal characterisation remains
contested as set out in section 2.1. The Reserve pays nominal subscription
amounts in cash and may borrow for that purpose under Article 9(1)(e).
Undertakings bear valuation costs; Article 13 fines accrue to the Union
budget. Member States administer national vehicles, may compensate costs
under Article 11(3), and must reimburse qualifying cross-border costs under
Article 11(4). The proposal therefore cannot be described as having no
public revenue or expenditure consequences.

Commission administration, Reserve custody and audit, independent
valuations and national account administration require resources. The
comparisons in evidence/administrative-cost.md are unquoted estimates, not
staffing commitments or a Commission financial statement. They do not
establish the cost of the proposed governance design. Article 11(3) limits
vehicle charges to actual costs and in any event 0,3 % annually of amounts
administered. That cap does not make administration free. The proposed
reference ledger distinguishes costs, subscription debt, capital
preservation and money allocated to holders; it is not yet Annex II.

A Commission proposal would need a legislative financial statement and a
verified start-up funding plan. The Reserve's restrictions on budget
contributions remain; permitted subscription borrowing is not a promise of
a lender. Automation can reduce routine work but does not remove custody,
security, audit or legal responsibility. The repair package includes an
explicit administration proposal and accounting alternatives for review,
without changing the published generational ownership objective.

---

## 5. Other elements

### 5.1 Implementation plans and monitoring

Article 14 obliges the Commission to monitor the diffusion of automated
cognitive systems, household equity holdings, the labour and capital shares
of value added in the sectors concerned, the Regulation's own operation,
and the evolution of the Union labour share against 2025 in either
direction. It must evaluate and report by 31 December 2032 and every three
years thereafter.

The falsification condition is the unusual part and is deliberate. Article
14(3) obliges the report to state expressly where the evidence does not
support the Regulation's own premise, and to propose amendment or repeal.
Article 1(2) obliges the same report to assess whether the quantified
objective is manifestly unattainable or manifestly exceeded, and to propose
amending the percentage or the thresholds in either direction. A regulation
resting on a falsifiable empirical claim should carry its own test.

### 5.2 Explanatory documents

The whole file is public: the enacting terms, the recitals, the annexes,
this memorandum, the counter-arguments memorandum, the severability
memorandum, the evidence base and every review verdict including the ones
the text failed. The drafting history is a public commit log.

### 5.3 Detailed explanation of the specific provisions

Chapter I (Articles 1 to 2) states the subject matter, the quantified
objective and the definitions. Chapter II (Articles 3 to 4) designates
covered undertakings on cumulative qualitative criteria with a rebuttable
quantitative presumption, and provides for market investigation and review.
Chapter III (Articles 5 to 7) creates the citizens' capital warrant, its
crystallisation events including the extraction trigger and the seven-year
long stop, the independent valuation and the safeguards. Chapter IV
(Articles 8 to 9) establishes the Reserve and restricts voting, direction, acquisitions
and borrowing. Article 9 permits specified reinvestment, diversification
and borrowing; the separate governance candidate has not yet been adopted. Chapter V (Articles
10 to 11) creates the individual entitlement and its administration through
national vehicles. Chapter VI (Article 12) protects the Reserve and the
entitlements. Chapter VII (Articles 13 to 16) provides penalties,
monitoring, delegation and committee procedure. Chapter VIII (Articles 17
to 18) contains the transitional provisions and entry into force. Annex I
carries the counting methodology; Annex II the retention and distribution
arithmetic.

The severability memorandum sets out how the instrument decomposes if a
part fails, in four layers, so that partial registration or partial
annulment trims rather than destroys.

### 5.4 Open points, stated rather than concealed

- The interaction with Directive (EU) 2024/2810 on multiple-vote share
  structures; remaining acquis questions require their own verified ledger.
- Reserve appointment, start-up finance, legal issuer and payment-period
  rules, and the proposed accounting specification in
  proposals/2026-09-07-generational-repairs/.
- Whether a segment-level limb should return as a second presumption in
  Article 3(2) if pre-designation dilution by acquisition is observed.
- Whether the instrument should reach semiconductor fabrication at all,
  which the qualitative limb and the Article 3(5) rebuttal currently leave
  to be decided case by case.

Each of these is on the record in the review ledger or the drafting notes
with the reasoning that left it open.


# SOURCE: own-the-machine/regulation/memorandum/severability.md

# Severability layering

How the instrument decomposes when institutions start cutting, and what
each cut costs. This document is strategy, not law: it binds the drafters
and the campaign, and the layer-fidelity gate reviews the articles against
it. It exists because the legal-basis gate's standing finding is real: the
complete instrument's centre of gravity is contestable, and the honest
response is to know in advance which parts stand on which legal basis, and
what the ask becomes at each stage of trimming.

## The four layers

### Layer 0: the question (survives everything)

The ask that survives any trimming, including partial registration of a
European Citizens' Initiative under the settled case law allowing it:

> The Commission is asked to assess, and to propose instruments for,
> the participation of citizens of the Union in the productivity gains of
> hyper-automated production, including designation criteria for
> undertakings whose output is substantially decoupled from employment,
> and mechanisms by which the gains of such production become broadly
> owned.

Nothing in Layer 0 requires any particular legal basis, because it asks
for an assessment and a proposal, which is what an initiative may ask.
Registration of Layer 0 is the Gate 1 floor: if the Commission will not
register even this, the project's premise about the legal channel fails
and the kill criterion in campaign/GATES.md applies.

### Layer 1: designation and transparency (Article 114 TFEU, comfortable)

Articles 1 to 4, 14, 16, 18, with Annex I; penalties limited to the
notification and information duties; recitals 1 to 8, 30 to 32, 34 to 36.

A regulation that designates hyper-automated undertakings on harmonised
criteria, makes the designation public, and reports on adoption,
employment effects and ownership concentration. It harmonises exactly the
thing Member States are starting to do divergently, on the DMA's own
architecture, and it carries the falsification condition. No warrant, no
Reserve, no entitlement.

This layer is defensible under Article 114 on the DMA precedent with no
novel doctrine. It is also, standing alone, worth having: designation
plus the Article 14 evidence base is what every subsequent instrument,
Union or national, would build on.

### Layer 2: the warrant (Article 114 TFEU, contested; fallback 352)

Articles 5 to 7, 13 in full, 15, 17, with the company-law derogations and
the valuation machinery; recitals 9 to 20, 29.

The obligation to issue the citizens' capital warrant, crystallising on
the first liquidity event, on shareholder extraction above the stated
share of covered turnover or on the seven-year long-stop, whichever comes
first, with the BRRD-pattern safeguards. The Article
114 case: it removes the incentive for divergent national levies and
participation schemes (recital 1), harmonises the company-law derogations
the subscription needs, and secures the level playing field between Union
and third-country undertakings. The attack (legal-basis gate, first run):
the centre of gravity is redistribution, not market-building, and
Article 114(2) excludes fiscal provisions; the controlling line is Tobacco
Advertising (C-376/98), which demands genuine obstacles or appreciable
distortions, not a desirable policy. The defence rests on the
non-fiscal structure being real (Article 8's insulation, settlement in
shares only), not asserted, and on recital 1's divergence record being
genuine.

If the characterisation fails, this layer moves to Article 352: unanimity
in Council, consent of the Parliament. That is a political mountain, and
this document says so rather than pretending otherwise.

### Layer 3: the Reserve and the entitlement (Article 352 TFEU, honestly)

Articles 8 to 12, with Annex II; recitals 21 to 28, 33.

The Reserve as a new Union-level body holding assets for citizens, the
universal entitlement arising by operation of law, national vehicles, the
raid-proofing. Creating a new body with legal personality and a direct
Union-to-citizen property relationship is where Article 114 is weakest and
where the subsidiarity objection concentrates. The body-creation precedents
cut both ways: Article 114 has sustained Union bodies that serve
harmonisation (ENISA, C-217/04; ESMA's intervention powers, C-270/12), but a
new legal form standing apart from national laws required what is now
Article 352 (the European Cooperative Society, C-436/03), and a Reserve
owing citizens a direct property relationship resembles the second more than
the first. The honest position: Layer 3 is drafted to be defensible under
Article 352, and its unanimity requirement is priced in. The campaign's
answer to "you will never get unanimity" is the wealth-tax precedent: the
fight is meant for the Council, in public, on the record. The basis itself
has carried participation before: Council Recommendation 92/443/EEC, on the
promotion of participation by employed persons in profits and enterprise
results, was adopted on Article 352's predecessor, a reference supplied by
the ECI Forum's advice of 27 August 2026 (pipeline/EXTERNAL-REVIEWS.md,
review 4). A recommendation confers no power; it shows the terrain is not
untrodden.

## Decomposition rules

1. Every layer must function with the layers above it struck. Layer 1
   without Layers 2 and 3 is a designation-and-evidence regulation.
   Layers 1 and 2 without Layer 3 would park crystallised shares with an
   independent depositary pending a distribution instrument; that escrow
   amendment is not in the draft, because in the draft the Reserve
   exists, but it is the prepared answer if Layer 3 is severed in
   legislative procedure, and no article may be drafted in a way that
   forecloses it.
2. No article may create a dependency downward on a higher-numbered
   layer's existence, other than Layer 2's delivery of shares to the
   Reserve, for which point 1's escrow is the severance answer.
3. The memorandum must argue each layer's basis separately. A single
   centre-of-gravity argument for the whole instrument concedes the
   weakest layer's characterisation to the strongest layer's opponents.
4. At Council stage, concessions run top down: Layer 3 is conceded to a
   separate instrument before Layer 2 is weakened, and Layer 2 is
   conceded to Article 352 procedure before Layer 1 is abandoned.
   Nothing in Layer 1 is conceded; it is the floor above Layer 0.
5. The ECI registration ask is Layer 0 as primary request with the full
   Regulation annexed as the suggested instrument, so that partial
   registration, if the Commission insists on it, trims the annex and
   not the ask.

**This rule was an assumption until 27 August 2026; it is now a finding,
within the limits of its source.** The ECI Forum's legal advice service,
answering questions 2 and 3 of campaign/GATE1-LETTER.md (reply of 27 August
2026, recorded verbatim in pipeline/EXTERNAL-REVIEWS.md, review 4), states
that if the goals comply with the ECI Regulation the initiative must be
registered "regardless of the mechanism described in your proposed legal
act", that the mechanism's contestability "is not a relevant consideration
for the registration", and that a full draft act may be provided where it
shows the proposal falls within the Commission's competence. The contrary
reading surfaced on 21 August, that the annex enlarges what is assessed, did
not survive the question. The limits: the advice is independent, expressly
non-binding on the Commission, and a finding about the registration stage
only; it says nothing about how the annex fares in legislative procedure,
which is what rules 1 to 4 are for.

## What this costs and why it is worth it

Layering is a concession in advance, and hostile readers will quote it as
lack of confidence. The alternative is a monolith that dies whole at its
weakest point, which is how most redistributive proposals at Union level
have died. The book's own analysis is that the mechanism matters more
than the vehicle: designation and evidence (Layer 1) create the factual
record; the warrant (Layer 2) is the mechanism; the Reserve (Layer 3) is
one distribution architecture among several possible. Losing Layer 3 to
an intergovernmental or successor instrument loses elegance, not the
point.


# SOURCE: own-the-machine/regulation/recitals.md

# Recitals

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 114 thereof,

Having regard to the proposal from the European Commission,

After transmission of the draft legislative act to the national parliaments,

Having regard to the opinion of the European Economic and Social Committee,

Acting in accordance with the ordinary legislative procedure,

Whereas:

(1) The internal market comprises an area without internal frontiers in
which the free movement of goods, services, persons and capital is ensured.
The conditions under which highly automated undertakings operate in the
internal market are increasingly the subject of divergent national
initiatives, including proposals for levies on automated production,
national social-dividend schemes and mandatory employee-participation
regimes extended to undertakings with few employees. Such divergence
creates fragmentation, distorts competition and gives undertakings an
incentive to locate activities according to regulatory exposure rather
than economic merit. That this is the pattern rather than a
possibility is established by the taxation of digital activity, where
the absence of a Union measure was followed by unilateral national
taxes in eight Member States, at rates, on bases and with
thresholds that do not correspond, so that the same undertaking falls
inside one national regime and outside its neighbour's on identical
revenue. Harmonised rules at Union level are therefore necessary, and
are more effective before national answers multiply than after.

(2) Advances in artificial intelligence and related automation
technologies enable a new category of undertaking: one which attains very
substantial turnover and market value while engaging very little human
labour in production. Such undertakings are lawful, productive and often
beneficial. Their emergence is nevertheless economically unprecedented,
because the mechanisms by which productivity gains have historically been
diffused through the population, above all wages and the broad taxation of
labour income, presuppose that production requires labour at scale.

(3) Where output is substantially decoupled from employment, the gains
from automation accrue by default to a narrow base of shareholders. No
existing instrument of Union law addresses the resulting concentration of
capital ownership. Competition law addresses conduct, not ownership;
Regulation (EU) 2022/1925 addresses the contestability of digital markets;
Regulation (EU) 2024/1689 addresses the safety of artificial intelligence
systems. This Regulation complements those instruments by addressing the
distribution of the ownership of automated production itself.

(4) The appropriate response is not a tax on the flows of automated
production. Taxes on flows burden activity year by year, are borne in part
by consumers and employees, depend on annual political renewal and treat
the gains of automation as public revenue to be spent. The response chosen
by this Regulation operates on assets instead: a limited, one-time right
to subscribe for equity in the most labour-decoupled undertakings, held in
a common reserve for the benefit of all Union citizens. An equity stake
participates in gains only where gains exist, imposes no recurring burden
on production and converts the automation dividend into broadly held
capital rather than public expenditure.

(5) This Regulation addresses the distribution of the capital value
created by hyper-automated production and does not purport to regulate
employment, wages, taxation as such, or the internal organisation of
undertakings beyond what the citizens' capital warrant requires. It does
not promise status, purpose, meaning or the other goods that employment
supplies as a by-product, and nothing in this Regulation, and no material
presenting it, should be read as making such a promise. Its object is
narrower and more precise than that: a broadly held equity stake in the
value that automation creates, and nothing beyond it. That object is
stated in Article 1 with its scale: an ownership position for each
citizen measured against a published statistic of Union living
standards, reached within a generation, so that the necessity of the
percentage laid down in Article 5 can be assessed against a stated
objective and revisited on the evidence. The stake is the objective;
distributions remain the property income that follows from ownership
and are not the purpose of the obligation.

(6) So that the obligations laid down in this Regulation apply only to
undertakings in which the decoupling of output from labour is extreme,
durable and of Union significance, undertakings should be designated on the
basis of objective qualitative criteria, accompanied by quantitative
thresholds giving rise to a rebuttable presumption. That architecture, which
follows the model of Regulation (EU) 2022/1925, provides legal certainty for
undertakings while preserving the ability of the Commission to designate on
the facts and to disregard arrangements whose main purpose or effect is the
avoidance of designation. Designation should be capable of preceding any
liquidity event and of applying irrespective of admission to trading,
because the warrant attaches to value at its formation and a contrary rule
would let an undertaking place itself beyond the Regulation by remaining
private; and arrangements whose main purpose or effect is the avoidance of
designation should be disregarded, while genuine increases in remuneration
for work should remain recognised. Acquisitions should remain subject to
the separate effects-based rule. Small and
medium-sized enterprises generally fall below the presumptive thresholds;
below-threshold designation and transferee rules remain applicable.

(7) The quantitative thresholds should capture only undertakings of very
substantial scale whose market valuation stands in a proportion to their
expenditure on human labour that has no precedent among labour-intensive
undertakings. Compensation of labour is the appropriate measure of the
labour actually engaged, because it is recorded in audited accounts and
cannot be increased without genuine payment for genuine work, so that an
undertaking reduces its decoupling ratio only by remunerating labour,
which is consistent with the objectives of this Regulation. The ratio
laid down in this Regulation is fixed in its own terms, so that an
undertaking can establish its position from audited remuneration and turnover records together with
the valuation evidence specified in Annex I: it exceeds by a margin of more than double the highest ratios
observed among capital-intensive undertakings whose value remains
explained by their expenditure on labour, and by an order of magnitude
the prevailing ratio among large undertakings admitted to trading in the
Union. That ratio should be reviewed under Article 14. For the same
reasons the thresholds should be assessed at the level of the group of linked enterprises, the single
economic unit to which the value of the automated services accrues.

(8) Designation should follow a notification by the undertaking itself
within a fixed period, with a decision of the Commission within a fixed
period thereafter. Arguments against the presumption should be taken into
account only where they manifestly call it into question, and arguments
based on the definition of the relevant market should not be taken into
account, since designation does not depend on a finding of market power.
Where a designation is repealed, a warrant not yet crystallised should
lapse after five years, ensuring legal certainty for the undertaking while
preserving for a reasonable period the rights acquired by the Reserve.

(9) The citizens' capital warrant should be modest, precise and singular:
a right to subscribe, at nominal value, for shares representing 3 % of the
fully diluted capital of the covered undertaking, once per designation.
The warrant should confer no voting rights and no influence over
management, so that neither the Union nor any public authority obtains
control or direction of any undertaking by virtue of this Regulation. This
Regulation therefore leaves untouched the rules in Member States governing
the system of property ownership and does not effect any transfer of any
undertaking to public ownership.

(10) The warrant should crystallise upon the first liquidity event
following designation: an admission to trading, a change of control or a
substantial secondary sale. It should also crystallise, on the same terms
and before any liquidity event, where the covered undertaking extracts
value to its own shareholders above the threshold this Regulation sets
for that purpose, or where seven years have elapsed since the warrant was
issued. Attaching the public stake to the point at which the
undertaking's own choices, or the mere elapse of that period, make value
claimable keeps the warrant dormant until one of those points is reached
and interferes with no going concern before it is. For the same reason,
an admission to trading which occurred before the entry into force of
this Regulation should not constitute a liquidity event, and this
Regulation should not apply to a liquidity event or other crystallising
event completed before its date of general application.
The contingent claim should arise at effective designation so that documentary delay cannot move the first qualifying event outside it. Transfers retaining the original economic participation should not restart the statutory period. Extraction and elapsed-time crystallisation should be reported using available records without waiting for annual audit.


(11) Shareholder extraction above the threshold this Regulation sets for
that purpose should crystallise the warrant on the same footing as a
liquidity event, because in substance it is the same event. A liquidity
event realises value for the shareholders of a covered undertaking by
converting an unrealised stake into cash or its equivalent; extraction
realises the same value by a different route, distributing it directly to
those shareholders without any sale of the undertaking itself. An
instrument that crystallised only on a sale, an admission to trading or a
comparable transaction would depend on the form the owners of a covered
undertaking choose for taking value out of it, and owners able to achieve
the same result by dividend, buy-back or capital reduction would have
every reason to choose that form instead. The extraction trigger closes
that route, without altering the liquidity-event trigger in any other
respect.

(12) The seven-year long-stop answers a case the liquidity-event and
extraction triggers do not reach: an undertaking that remains privately
held indefinitely, keeps its distributions to shareholders below the
extraction threshold, and so never crystallises the warrant at all, while
its value continues nonetheless to accrue for the benefit of those
shareholders. Absent a long-stop, such an undertaking could defeat the
objective of this Regulation by the simple expedient of staying private
and patient. The long-stop is the answer to that possibility, and it is
proportionate under Article 52(1) of the Charter of Fundamental Rights of
the European Union: it is quantified in years rather than left to
discretion, it is known to the undertaking from the moment of its
designation, and it is subject to the same independent valuation and the
same separate right of challenge before the courts that apply to
crystallisation at a liquidity event.

(13) The warrant should be incapable of settlement in cash. It confers an
entitlement to shares and to nothing else. It is accordingly not a levy,
not a charge on turnover or profit and not revenue of any public
authority, and it is so designed that no payment obligation towards any
budget can arise from it. In excluding settlement in money, the
prohibition restricts the freedom of the undertaking to structure the
discharge of its obligation; that restriction is justified and
proportionate, because it confines the interference to capital ownership
and keeps the undertaking's operating liquidity untouched, which a cash
alternative would not.

(14) Undertakings within the scope of this Regulation include undertakings
governed by the law of third countries which meet the thresholds through
their activity in the internal market. Equal treatment and the level
playing field require that such undertakings assume obligations of
equivalent effect. The obligations laid down in this Regulation attach
only where activity in the internal market meets the thresholds laid down
in it, so that their application to such undertakings rests on the
immediate, substantial and foreseeable effects of their conduct within
the internal market and not on the mere accessibility of their services.
Where the law governing an undertaking does not give
effect to the subscription right, the undertaking should be required to
procure a subscription of equivalent effect as an obligation of result,
without prejudice to the company law of its incorporation, and compliance
should be secured through the enforcement powers laid down in this Regulation,
including, as a last resort, the power to prohibit the making available of
the relevant goods and services on the internal market.
Equivalent-effect arrangements should exist by crystallisation while execution follows the independent valuation, including where the governing company law does not give effect to Union statutory vesting.


(15) The issuance of shares pursuant to a citizens' capital warrant
requires derogations from certain provisions of Directive (EU) 2017/1132
of the European Parliament and of the Council concerning pre-emption
rights and the consideration for issued shares. Comparable derogations,
adopted in the general interest, form part of the established acquis in
the field of bank recovery and resolution. Because the shares subscribed
by the Reserve are non-voting for as long as it holds them, provisions of
the law of a Member State that restrict the proportion, issuance
conditions or characteristics of non-voting shares should not apply to the
extent that they would prevent the issuance or holding of those shares. The derogations provided for in this Regulation
are strictly limited to what the execution of the subscription requires,
and they are necessary: an issuance that existing shareholders could
pre-empt, that could be made conditional on a resolution of the general
meeting, or that a Member State's non-voting-share rules could block
outright, could not perform the function this Regulation assigns to it.

(16) The shares subscribed pursuant to the citizens' capital warrant
should rank, for the Reserve, equally with the most favourable class of
shares created after the covered undertaking's designation, and otherwise
equally with its ordinary shares, without affecting the ranking of any
creditor. Ranking the Reserve behind classes created after designation
would let the interference be diluted by the covered undertaking's own
subsequent choices; ranking it above every class, including preference
shares subscribed and paid for before designation, would take from those
earlier investors the protection they bargained and paid for, which this
Regulation does not do. Equal ranking with the most favourable class
created after designation, and no disturbance of the claims of creditors,
confines the interference to what the warrant is: an equity interest, not
a priority claim.

(17) The obligations laid down in this Regulation would be of little
value if they could be routed around by an arrangement that subordinates
the Reserve's participation, by moving the automated assets on which a
covered undertaking's designation rests into another entity, or by the
extinguishment of the warrant in an insolvency or restructuring procedure
engineered or exploited by the same persons who controlled the covered
undertaking. An arrangement that subordinates, reduces or defeats the
Reserve's participation should accordingly be ineffective as against the
Reserve, while remaining effective between the parties to it and as
against third parties, so that anti-avoidance is achieved without
unwinding transactions to which the Reserve was not a party. Where a
covered undertaking transfers its automated assets to another undertaking
otherwise than at arm's length, or to a member of its own group or a
person who controls it or is controlled by it, the obligations laid down
in this Regulation should attach to the transferee as if it were the
covered undertaking, so that the assets which carry the value cannot be
moved beyond the warrant's reach while the covered undertaking that
issued it remains bound in respect of what it retains. Anti-avoidance
should not become a multiplier: a group that divides its automated assets
among several entities should owe the same share of its capital as one
that does not, and the stated percentage should therefore apply to the
dilution borne by the shareholders of the covered undertaking and of every
transferee taken together, and not separately to each of them. Where those assets are instead
acquired in an insolvency or restructuring procedure and control of the
transferee ends up, directly or indirectly, with the persons who
controlled the covered undertaking, or with persons acting in concert or
connected with them, the same obligations should reattach to the
transferee, because no genuine change of ownership has in substance
occurred. That reattachment should not extend to a transferee controlled
by persons who did not control the covered undertaking: a genuine sale to
unconnected purchasers in insolvency or restructuring is the ordinary
operation of that law, not an avoidance of this Regulation, and should be
left to run its course without the obligations of this Regulation
attaching to it.

(18) This Regulation interferes with the right to property of the
shareholders of covered undertakings, whose holdings are diluted upon
crystallisation. That interference is provided for by law, genuinely meets
an objective of general interest recognised by the Union and respects the
essence of the right to property: it is a one-time dilution, capped at a
stated percentage, borne at a statutory crystallisation event
of undertakings whose value derives from an unprecedented decoupling of
output from labour. The Court of Justice has consistently held that the
right to property is not absolute and that its exercise may be regulated
where regulation is proportionate to a legitimate aim of general
interest. The interference effected by this Regulation is quantified,
foreseeable from designation and less intrusive than measures already
upheld in the field of bank resolution. Subscription at nominal
value rather than by gratuitous transfer keeps the mechanism within the
forms of company law while ensuring that the interference is the stated
dilution and nothing more; requiring the Reserve to pay a market price
would demand public expenditure this Regulation is designed not to need
and would convert a mechanism of ownership into a budgetary one. The fair balance rests also on
what the covered undertaking receives: a single harmonised regime of
access to the internal market in place of divergent national levies and
participation schemes, and the legal certainty of an interference fixed
in advance in amount and in moment.

(19) Proportionality further requires safeguards. The dilution borne by
shareholders is capped by this Regulation and verified by an independent
valuation, which is challengeable separately from the transaction it
accompanies and correctable in both directions. The safeguard the
valuation secures is that the interference can never exceed the stated
percentage in execution: the dilution is capped, its price is set by the
event that crystallises it, and no application of this Regulation may take
from shareholders more than the interference it names. That executional
ceiling, not a crisis counterfactual, is what keeps the interference
proportionate in a permanent regime. Neither designation nor
crystallisation suspends, conditions or unwinds any transaction. Every
decision taken under this Regulation is subject to effective judicial
protection in accordance with Article 47 of the Charter of Fundamental
Rights of the European Union.

(20) Where a liquidity event itself establishes a price, a valuation
delivered in advance of the event would be conjecture about a number the
event is about to produce. The independent valuation should therefore be
delivered promptly after completion, while the legal effect of the
subscription attaches at completion and its execution follows delivery of
the valuation.

(21) The European Citizens' Capital Reserve should hold the warrants and
the shares arising from them exclusively for the benefit of holders. Its
assets and income are not public revenue: they should not enter the
general budget of the Union or any national budget, and no payment should
flow between the Reserve and any budget in either direction. In this the
Reserve resembles a statutory funded pension scheme, whose assets are held
for beneficiaries and are not at the disposal of any treasury, rather than
a fund of the Union. The insulation of the Reserve from public finances is
not an administrative preference but a constitutive feature: it is what
makes this Regulation a mechanism of ownership rather than of taxation.

(22) Income from holdings in undertakings governed by the law of a third
country may be taxed at source in that country at rates which the Reserve,
being resident in no State, may be unable to reduce by treaty. The remedy, where there is one, lies in
international agreements, which are concluded in accordance with the
procedures laid down in the Treaties and which this Regulation neither
prejudges nor requires. This Regulation does not direct the Reserve to
arrange its holdings so as to reduce taxation in a third country; an
instrument founded on the proposition that capital should be broadly owned
is in no position to legislate its own treaty shopping. What this
Regulation can do, and does, is oblige the Reserve to report each year the
amount it was unable to recover, so that the cost is known rather than
assumed away.

(23) The Reserve should exercise no votes,
seek no influence over the management of any undertaking and pursue no
industrial policy. Its function is to hold and to distribute, not to
direct. The mandatory presence of the Reserve in the capital of covered
undertakings restricts the free movement of capital. That restriction is
justified: it serves the general interest set out in these recitals, it
applies without distinction to undertakings and investors of the Union
and of third countries, and it is proportionate precisely because the
statutory passivity of the Reserve withholds from it every attribute of
special control that has led the Court of Justice to censure public
shareholdings. A holding which can neither vote nor veto nor instruct
exerts no public influence for an investor to fear.

(24) The Reserve should retain from its income what is necessary to
preserve the real value of its capital and distribute the remainder. That
rule, drawn from the practice of long-horizon sovereign funds, means
distributions grow with the portfolio and compound across decades. It also
means distributions begin modestly. This Regulation makes no promise of
substantial early payments and should not be presented as making one; its
horizon is generational.

(25) Every citizen of the Union who has reached the age of 18 years should
hold an equal entitlement in the Reserve by operation of law, without
application, means test or condition. Universality is design, not
generosity: a means-tested entitlement would divide the population into
contributors and recipients, invite perpetual contestation of the boundary
and convert an ownership stake into a welfare payment. An equal
entitlement held by all is defensible by all.

(26) The entitlement should be personal. It should be incapable of
transfer, assignment, pledge, attachment, surrender or redemption, so that
it cannot be bought out of the hands of those it serves, whether by
markets, by creditors or by the holder's own moment of hardship. That
restriction on the alienability of the entitlement is a justified and
proportionate limitation under Article 52(1) of the Charter and respects
the essence of the right, since it attaches to the underlying entitlement
only, while amounts distributed are the holder's property, freely usable
and inheritable, and it is necessary so that the objective of durable,
broadly held capital ownership is not defeated by immediate liquidation.

(27) Member States should administer entitlements through national
vehicles, since Member States hold the civil registries and payment
infrastructure that administration requires. Administration fees should be
capped and entitlements portable, so that the quality of a Member State's
administration cannot diminish the substance of a citizen's entitlement.
The cap on fees limits the freedom of designated vehicles to set prices;
that limitation is necessary and proportionate to prevent the erosion of
the entitlement by administrative costs. The administration of
entitlements is a service of general economic interest, and the cap is
compatible with the freedom to conduct a business on the conditions
Article 106(2) TFEU attaches to such services and proportionate under
Article 52(1) of the Charter; Member States remain free
to compensate designated vehicles for verifiable net costs above the cap.

(28) The history of pooled public assets is a history of raids. The assets
of the Reserve should therefore be protected by enumerated prohibitions on
lending, guarantee, transfer and encumbrance in favour of public
authorities, and the Reserve should not acquire sovereign debt, so that it
cannot become a captive purchaser of the obligations of any government.
The exclusion of sovereign debt is a rule of portfolio governance internal
to the Reserve, securing its independence, and restricts no movement of
capital by any other person. An
ordinary regulation cannot bind future legislatures, and this Regulation
does not pretend otherwise; what it can do is ensure that no derogation
from these protections arises by interpretation, and that any future
weakening would need to be enacted expressly, in public, informed by the
independent assessment its reporting provisions require.

(29) Penalties for non-compliance should be effective, proportionate and
dissuasive, and set at a level meaningful to undertakings of the scale
designated. Fines and periodic penalty payments should accrue to the
general budget of the Union and not to the Reserve, so that the body
holding assets for citizens never acquires a financial interest in the
punishment of undertakings. Where an undertaking governed by the law of a
third country persistently refuses to comply with its core obligations,
the Commission should be empowered, as a measure of last resort and
subject to proportionality, to prohibit the making available of the
relevant goods and services on the internal market, since no other means
of enforcement reaches an undertaking with no assets in the Union. Such a
prohibition restricts the freedom to conduct a business recognised by
Article 16 of the Charter of Fundamental Rights of the European Union, and
should accordingly remain available only where no less restrictive measure
can secure compliance, for as long as the refusal persists and no longer.
So conditioned, the prohibition respects the essence of that freedom: it
is temporary, reversible on compliance and confined to the goods and
services concerned, and it leaves the undertaking's activity outside the
internal market untouched.
Execution and notification duties, including those of bound transferees, should be expressly enforceable; sanctions should remain proportionate to the gravity and circumstances of each breach.


(30) The premise of this Regulation, that automation at the designated
scale durably decouples output from labour and concentrates ownership, is
an empirical claim, and empirical claims can prove wrong. The Commission
should monitor adoption, employment effects and ownership concentration,
and where the evidence does not support the premise, should state so
expressly and propose amendment or repeal. A regulation founded on a
falsifiable claim should carry its own test. The same monitoring should
extend to the share of value added accruing to labour in the Union as a
whole, in both directions: where that share declines, the evidence
informs the assessment under Article 1 of whether the participation
secured remains adequate to its objective, and where it does not
decline, the same assessment asks whether the obligations imposed remain
justified at their level, so that the indicator moves no obligation of
any undertaking but disciplines the instrument itself.

(31) In order to keep the methodologies for counting turnover, employment
and value, and for calculating the retention necessary to preserve the
real capital of the Reserve, aligned with technological and market
developments, the power to adopt acts in accordance with Article 290 of
the Treaty on the Functioning of the European Union should be delegated to
the Commission in respect of amendments to Annexes I and II. The essential
elements of this Regulation, including the designation criteria, the
percentage and terms of the warrant, the entitlement and its protections,
are laid down in the enacting terms and are not subject to delegation. It
is of particular importance that the Commission carry out appropriate
consultations during its preparatory work, including at expert level, and
that those consultations be conducted in accordance with the principles
laid down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making. In particular, to ensure equal participation in the
preparation of delegated acts, the European Parliament and the Council
receive all documents at the same time as Member States' experts, and
their experts systematically have access to meetings of Commission expert
groups dealing with the preparation of delegated acts.

(32) In order to ensure uniform conditions for the implementation of this
Regulation as regards the establishment of the list of independent valuers
and their appointment, implementing powers should be conferred on the
Commission. Those powers should be exercised in accordance with Regulation
(EU) No 182/2011 of the European Parliament and of the Council.

(33) The administration of entitlements involves the processing of
personal data, limited to what the identification of holders and the
execution of distributions require. That processing is necessary for the
performance of a task carried out in the public interest, and no data
beyond those fields should be collected or retained. Regulation (EU)
2016/679 applies to such processing. Consultation of the European Data Protection Supervisor under
Article 42(1) of Regulation (EU) 2018/1725 belongs to the preparation of
a Commission proposal. [The proposing institution is to insert the
consultation date and opinion reference; no consultation is claimed here.]

(34) Since the objective of this Regulation, namely to ensure on the basis
of harmonised rules that the gains of hyper-automated production in the
internal market are broadly owned, cannot be sufficiently achieved by the
Member States, because the undertakings concerned operate across the
entire internal market and national measures would create the very
divergence this Regulation removes, but can rather, by reason of its scale
and effects, be better achieved at Union level, the Union may adopt
measures, in accordance with the principle of subsidiarity as set out in
Article 5 of the Treaty on European Union. In accordance with the
principle of proportionality as set out in that Article, this Regulation
does not go beyond what is necessary in order to achieve that objective.

(35) This Regulation respects the fundamental rights and observes the
principles recognised by the Charter of Fundamental Rights of the European
Union, in particular Articles 16, 17, 20, 34 and 47 thereof, concerning
respectively the freedom to conduct a business, the right to property,
equality before the law, social security and social assistance, and the
right to an effective remedy and to a fair trial.

(36) Application of the substantive obligations of this Regulation should
be deferred so that undertakings, Member States and the Commission can
prepare, while the notification obligation applies from entry into force
so that the first designations can take effect at general application.
Preparatory notifications, hearings and appointment arrangements should precede general application. Early designation decisions should become effective only at general application, with no capture of liquidity events already completed,

HAVE ADOPTED THIS REGULATION:

---

Drafting notes (non-normative). Recitals use 'should' throughout and
impose nothing (JPG guideline 10). Each recital carries weight the
enacting terms need: (4) is the assets-not-flows doctrine; (5) is the
DC-26 scope-and-limits recital answering objection 12, conceded in full;
(10) the in-time doctrine and the answer to retroactivity, with (11) and
(12) justifying the extraction and long-stop triggers added to Article
5(3); (13) and (21) the fiscal characterisation defence; (9) the Article
345 TFEU answer; (15) and (18) the BRRD-pattern property-interference
justification, with (19) and (20) the safeguards, and (16) and (17) the
ranking and anti-avoidance rules added to Article 5(4)(b) and 5(10) to
(12); (24) the DC-14 honesty rule; (25) the universality argument; (28)
the honest limits of entrenchment after the round-1 and round-2 findings;
(30) the falsification condition, which is DC-18; (31) carries
the standard Better Law-Making language including the equal-access
sentence the Parliament expects; (34) is the standard subsidiarity
formula. The final recital ends with a comma by convention, leading into
the enacting formula.


# SOURCE: own-the-machine/evidence/EVIDENCE.md

# The evidence

A draft law owes its readers three things: the evidence for its premise,
the evidence against it, and the numbers it refuses to use. This page
carries all three. Every figure was verified at source, not relayed from
commentary; assembled 18 August 2026, extended 19 August 2026, corrections
welcome by pull request.

The Regulation's premise is stated in its own recitals and tested by its
own Article 14: hyper-automated production decouples output from labour
at the level of the firm, the gains concentrate in whoever owns the
platform, and the ownership of productive capital in Europe is too
narrow for those gains to reach citizens by themselves. Each section
below maps to a part of that premise, and section 3 records what the
European evidence does not show, because the instrument is designed
around that honesty.

## 1. Ownership is narrow

The condition the instrument answers: Europeans own homes and pension
promises, not productive capital.

- **In the euro area, 60 % of households own their home and 11 % own
  shares in a company.** Belgium 67 against 13. Italy 75 against 4.
  Greece 68 against 1. *ECB Household Finance and Consumption Survey,
  wave 5, 2023 reference year, published June 2026.* Same file, same
  population, same survey.
- **The richest tenth of euro-area households own 83 % of directly held
  shares; the poorest half own 2 %.** Italy: 93 against 0,5. *ECB
  Distributional Wealth Accounts, 2025-Q4.* Caveat to state: every DWA
  observation is an ECB estimate.
- **The bottom half of euro-area households hold 63 % of their assets
  as housing and 3 % as equity.** Belgium: 76 % housing, 2 % equity.
  *ECB DWA, 2025-Q4.* The premise as one row of a table.
- **The typical Dutch household is worth EUR 135 500, or EUR 23 000
  once the house is taken away.** *CBS 83834NED, 1 January 2024*, tax
  registers, not a survey. State the pension exclusion first.
- **Belgian households have accrued EUR 1 740 bn of pension claims and
  own EUR 136 bn of it.** About 92 % is a promise from future
  taxpayers. *OECD/Eurostat Table 29, 2021.* Netherlands 49 % funded;
  France 0,0 %.
- **Danish households hold pension assets worth 206 % of national
  output; German households hold 6 %.** *OECD, 2024.* Caveat: the
  German figure excludes Direktzusage book reserves.

## 2. The gains concentrate at the platform

Why Article 3 designates what it designates: where production is
automated, the price that holds is the licence price, and the volume
that falls is the hours.

- **European cloud companies tripled their revenue in seven years and
  their share of their own home market still fell from 29 % to 15 %,**
  because the market grew sixfold. Amazon, Microsoft and Google take
  70 % of a EUR 61 bn European market; SAP and Deutsche Telekom hold
  about 2 % each. *Synergy Research Group, 24 July 2025.* Completed
  revenue history, not a forecast.
- **France 2025: services firms -1,8 %, technology consulting -2,5 %,
  software and cloud +8,2 %,** in the trade body's own words "surtout
  de la hausse des tarifs", with budget increases "absorbée par les
  évolutions des plateformes cloud". *Numeum/PAC, December 2025.*
- **Germany 2026: IT services +3,1 %, software +9,9 %, cloud software
  +21,9 %, AI platforms +75,8 %.** *Bitkom/IDC, August 2026.*
- **Germany produces a third more software and IT services in real
  terms than five years ago, with the ICT vacancy rate down from 6,3 %
  to 2,5 %.** Production volume index 99,2 (2021-Q1) to 134,0
  (2026-Q1). *Eurostat, verified against the API.*
- **In Germany and France the whole job market is back at pre-pandemic
  levels while software-developer postings sit at half.** Germany 50,6
  against 104,5; France 51,1 against 100,0 (February 2020 = 100).
  *Indeed Hiring Lab, 7 August 2026.* The control group is built in.
- **Hays Germany: fees +3 % while volumes fell 9 %.** *Hays plc H1 and
  Q4 FY26, audited and listed.* **Belgium: project-sourcing revenue
  +0,4 % while billable hours fell 3,4 %** (*Federgon*).
  **Netherlands: the seconded rate rose 3,3 % to EUR 71,32 while
  seconded FTE fell 9,3 %** (*VvDN, self-reported trade body*).

## 3. What the evidence does not show

The instrument is built around three facts that cut against the loudest
versions of the automation story, and it does not need those versions.

- **There is no European labour-share collapse.** The EU27 labour share
  moved about one point in thirty years; Germany's is at a series high;
  the Dutch series (81,4 % in 1995 to 70,6 % in 2025) has risen three
  years running. Anyone resting a law on a collapsing labour share
  loses the argument in Europe, so this law does not.
- **Aggregate displacement is not yet demonstrable.** The EU27
  employment rate is at a record 76,3 %; ICT specialists rose from
  3,5 % to 5,0 % of employment; compensation of employees was 48,09 %
  of EU27 GDP in 2025, above 2015, 2019 and 2022. Danish register data
  on ~25 000 workers finds precise nulls two years after ChatGPT
  (*Humlum and Vestergaard*); the German federal government formally
  finds "keine Hinweise" of junior displacement (*Bundestag Drucksache
  21/3722, 19 January 2026*). Same technology, opposite choices:
  Publicis added roughly 5 800 staff in the year WPP shed 9 389.
- **The mechanism has not diffused far.** Only 19,95 % of EU firms with
  ten or more employees used any AI in 2025. The serious claim is a
  forecast about a mechanism, not a report about the past.

This is why the Regulation claims nothing in the past tense. Designation
under Article 3 requires demonstrated decoupling at the level of the
firm, not an economy-wide story; the warrant under Article 5 takes
nothing until gains actually crystallise; and Article 14(3) carries the
falsification condition on its face: if automation spreads without the
decoupling and concentration the premise asserts, the Commission must
report that the premise is unsupported and propose amendment or repeal.
A law founded on an empirical claim should carry its own test.

## 4. What happens to pooled claims

Why Chapter VI of the Regulation looks the way it does: the history of
pooled public assets in Europe is a history of raids, and the history of
individual claims is better.

- **Poland, one line of law: 51,5 % of the money in every citizen's
  pension account cancelled on a named day.** *Act of 6 December 2013,
  Dz.U. 2013 poz. 1717, Article 23(1).* Article 23(2) took the Treasury
  bonds first, so the state could retire its own debt. The raid is not
  a hypothesis; it is a statute, and Article 12 of this Regulation is
  drafted against its enumerated verbs.
- **Spain's pension reserve fund fell 97 %,** from EUR 66,8 bn (2011)
  to EUR 2,1 bn, cumulative withdrawals EUR 80,3 bn. The law protecting
  it was passed in 2023, after it was empty.
- **Ireland's National Pensions Reserve Fund held over EUR 21 bn at the
  end of 2007. Its discretionary portfolio was EUR 7,1 bn when the fund
  was wound up seven years later,** the difference having been directed
  into the recapitalisation of Allied Irish Banks and Bank of Ireland,
  EUR 10 bn of it converted to cash and placed on deposit with those
  same banks in April 2011 before being invested in them that July. The
  assets passed to the Ireland Strategic Investment Fund on 22 December
  2014 and the fund's own mandate ended with it. *NTMA, National
  Pensions Reserve Fund Commission Annual Report 2014; NTMA valuation of
  the Discretionary Portfolio at 21 December 2014; National Treasury
  Management Agency (Amendment) Act 2014.* Hungary's -75,9 % is the
  other benchmark. These are the strongest cases against this
  Regulation's own mechanism, and they are why the Reserve's protections
  are operative articles rather than promises.
- **Sweden abolished its wage-earner funds in 1991, eight years after
  creating them, on a change of government.** The funds were legislated in
  1983 as five regional bodies financed by a levy on profits and on the wage
  sum, holding no more than 8 % of any one undertaking. They were the
  diluted survivor of the 1976 Meidner plan, which would have required
  profitable undertakings to issue new shares worth 20 % of annual profits
  to collectively held funds until those funds held a majority; the
  compulsory issuance was abandoned before the Riksdag ever voted on it. A
  centre-right government wound the funds up in 1991 with little resistance
  from the movement that had proposed them. This is the closest precedent
  anywhere to the mechanism in Article 5, and it is the strongest case
  against it, which is why objection 19 states it rather than the evidence
  base burying it.
- **Estonia proves a claim is necessary but not sufficient.** When the
  second pillar went voluntary in January 2021, 149 083 people took out
  EUR 1,32 bn in a single month; leavers averaged age 41 with
  EUR 8 468, earning slightly below the national average. That is why
  the entitlement in Article 10 is incapable of surrender: a claim that
  can be bought out of a citizen's hands will be, cheapest first.
- **A Danish worker's frozen 1978 pay rise of DKK 4 368 is worth
  DKK 119 506 tax-free today,** about 27 times over 46 years, in an
  account with the worker's name on it. *Lønmodtagernes Dyrtidsfond, at
  31 December 2025.* Deferred income converted into owned capital: the
  closest existing instrument to what this Regulation builds.
- **Two-thirds of Norway's fund was never oil:** NOK 15 210 bn of
  NOK 22 683 bn is compound return. The answer to "we have no oil" is
  that Norway largely does not either, any more; it has a rule, and
  Annex II is that rule made law.
- **Across Europe's development and reserve funds, citizens hold no
  individual claim at all**: Invest-NL, the Nationaal Groeifonds,
  COFIDES, SEPI, Spain's FRSS, Portugal's BPF and FEFSS, Greece's
  Growth Fund, Finland's Solidium, Bpifrance, Italy's CDP, Slovenia's
  SDH, Poland's PFR, Ireland's FIF, ICNF and ISIF. No account, no unit,
  no inheritable right. Individual claims exist only in pension
  vehicles, which is the gap Article 10 closes.

## 5. What we will not cite

Numbers that circulate in this debate, checked and retired, including
some that would have helped us.

- **"The OECD says only 9 % of jobs are automatable."** Superseded by
  Nedelkoska and Quintini (WP 202, 2018): 14 % above 70 % probability,
  another 32 % between 50 and 70.
- **"Bruegel found AI exposure correlated with employment growth."**
  Misattributed (it is OECD WP 265, and equivocal). Bruegel's own
  European result is negative: one extra robot per thousand workers
  cuts the employment rate 0,16 to 0,20 points.
- **European cloud share "27 % to 13 %".** Wrong; it is 29 % to 15 %.
- **Klarna as "700 people replaced by AI".** A hiring freeze plus 15 to
  20 % annual attrition; "700 agents" was a chat-volume calculation.
- **"SAP cut 10 000 jobs for AI."** Headcount rose in both years.
- **The 160 000 telecom job losses as an AI story.** The sector's own
  assessment: "this dramatic shrinkage owes very little to AI"; the
  same operators shed over 380 000 between 2014 and 2022.
- **Job-board causation claims** (entry-level postings "down 32 % since
  ChatGPT" and similar): windows containing the entire rate-tightening
  cycle, asserted as AI effects by parties selling recruitment
  products.

## 6. Measurement traps

- **Three defensible labour-share measures differ by up to 19 points.**
  Italy 2024: unadjusted 39,4 %, adjusted 58,3 %. Never quote one
  without naming it.
- **WID, HFCS and DWA figures must never share a table**: different
  units and methods. The Dutch top-10 % share is 44,8, 52,0 or 56,1
  depending on which you pick.
- **Every major European household-wealth statistic excludes
  pensions**, which inverts the ranking and makes the Netherlands and
  Denmark look asset-poor.
- **Norway's wage share is a gas-price denominator effect**; do not use
  it. **Germany has a hard series break at 1991**; never splice.
- **Eurostat ICT vacancy data stop at 2025-Q4** while price and
  employment series run into 2026; the legs are not aligned in time.

## 7. The long horizon

The Reserve is an instrument built for a horizon politics rarely
rewards, so this page states plainly what fifty years do, and what they
do not.

- **Alaska has paid every resident a dividend for 44 consecutive
  years.** The Permanent Fund holds more than USD 86 bn for about
  740 000 residents, roughly USD 116 000 of fund capital per resident;
  a resident collecting every dividend from 1982 to 2016 received
  USD 37 027 in total. *Alaska Permanent Fund Corporation; Alaska
  Department of Revenue, dividend table.* No legislature has touched
  the principal in half a century, because every citizen had a reason
  to defend it.
- **Alaska also shows the failure mode.** Since 2016 the dividend has
  been set by annual political bargain; the statutory formula remains
  in law and is simply not followed, and the 2025 dividend of
  USD 1 000 is the smallest in the programme's history once adjusted
  for inflation. A distribution rule in ordinary statute is capturable
  by a budget fight. That is why the rule here is Annex II of the
  Regulation itself, why the entitlement is an operative article, and
  why the Commission reports on the formula rather than sets it.
- **The AI-value forecasts stay out of the premise.** PwC puts
  artificial intelligence at USD 15,7 tn of global product by 2030;
  Goldman Sachs at about USD 7 tn over a decade; McKinsey at USD 2,6
  to 4,4 tn a year. These are forecasts of a mechanism, with error
  bars measured in trillions, and section 5's discipline applies: this
  Regulation does not rest on them. They appear in one place only, as
  labelled scenario inputs to the public simulator, beside a sceptic
  setting that assumes almost nothing.
- **What the arithmetic of Annex II does with fifty years.** Run
  cautiously (EUR 150 bn of covered revenue at designated firms,
  Norway-class real returns), the simulator's central curve reaches a stake of roughly
  EUR 1 200 of Reserve capital per citizen and a dividend of roughly
  EUR 47 a year by year fifty; run at the forecasts above, roughly
  EUR 10 000 and EUR 370, in constant 2026 euros: a fund on the scale
  Norway's rule built. Both curves spend their first decade
  indistinguishable from zero. That is the design: Annex II preserves
  capital before it distributes, and the stake compounds while the
  payout waits. If neither curve materialises, Article 14(3) obliges
  the Commission to report that the premise failed and to propose
  amendment or repeal.

## 8. The fragmentation is not hypothetical

Article 114 TFEU carries this Regulation only if divergent national rules
obstruct the internal market or distort competition appreciably, and
*Tobacco Advertising* (C-376/98) means that has to be shown rather than
asserted. It can be shown, because the Union has already watched it happen
once in the same economic domain.

- **Eight Member States tax digital activity unilaterally, at rates from
  1,5 % to 7,5 %, on bases that do not match.** Austria 5 % on online
  advertising alone; Denmark 2 % with a 3 % surcharge on streaming;
  France 3 % on digital interfaces, targeted advertising and the
  transmission of user data, with a reduced 1,2 % band; Hungary 7,5 %,
  currently suspended to nil through June 2026; Italy 3 %, having
  removed its global-turnover threshold; Poland 1,5 % and 3 % on
  audiovisual media and advertising; Portugal 4 % and 1 % on video and
  on-demand platforms; Spain 3 % on advertising and the sale of user
  data. *Tax Foundation Europe, digital services taxes in Europe, 2026.*
- **The entry thresholds differ by four orders of magnitude,** from
  HUF 100 million in Hungary and EUR 3 million in Spain to EUR 25
  million in France and Austria and EUR 1 billion of group turnover in
  Poland. The same undertaking is inside one national regime and outside
  its neighbour's on the same revenue.
- **Six more Member States have proposed or announced such taxes without
  adopting them:** Belgium, Czechia, Germany, Latvia, Slovakia and
  Slovenia. Roughly half of European OECD members have announced,
  proposed or implemented one. *Same source.*
- **The sequence is the point.** A Union-level measure was attempted and
  did not pass; Member States then legislated alone, and the fragmented
  landscape the Commission had hoped to avoid is what the internal
  market now has. Nothing about the next round is different: the
  European Parliament rejected a robot tax in February 2017 (the
  Delvaux report), the proposal has returned in the current debate on
  large-scale AI adoption, and no Union instrument occupies the field.
- **What the comparison does and does not establish.** It does not show
  that automation levies are coming; it shows what Member States do when
  a new form of value appears in the internal market and the Union does
  not act, and that they do it at incompatible rates, on incompatible
  bases, with incompatible thresholds. That is the obstacle this
  Regulation forecloses by harmonising the trigger, the instrument and
  the vehicle before twenty-seven answers exist rather than after.

---

Working notes for the three research strands sit in this directory;
they carry the full sourcing trail. Dispute a number by opening an
issue or a pull request: a figure that does not survive contact with
its source comes off this page and goes into section 5.


# SOURCE: own-the-machine/evidence/designation-count.md

# How many undertakings would actually be designated

Objection 21 established that the warrant percentage cannot be derived while
Article 1 states its objective qualitatively, and that quantifying that
objective requires knowing the size of the thing the instrument reaches. This
file answers that question as far as public data allows, and the answer is
smaller and stranger than the drafting assumes.

Figures are as at August 2026 and converted at the 2026 average rate of
EUR 1 = USD 1.1624, that is USD 1 = EUR 0.8604. Sources are listed at the
end. Every figure here is from a published source; none is estimated by this
file except where it says so.

## The test that decides everything

Article 3(2)(a) is easily met by any large technology undertaking: EUR 7,5
billion of Union turnover **or** EUR 75 billion of fair market value, in at
least three Member States. It excludes almost nobody of interest.

Article 3(2)(b) is the whole test in practice: turnover from the automated
provision, divided by full-time equivalents engaged in that provision, must
equal or exceed **EUR 5 million**.

## What the incumbents look like

Group-level revenue per employee, which is the only basis public accounts
support:

| Undertaking | Revenue / employee (USD) | In EUR | Passes 3(2)(b)? |
|---|---|---|---|
| Nvidia (FY2026) | 5.14 m | 4.42 m | **No**, at group level |
| Apple | ~2.5 m | ~2.15 m | No |
| Meta | ~2.5 m | ~2.15 m | No |
| Alphabet | ~2.2 m | ~1.89 m | No |
| Microsoft | ~1.08 m | ~0.93 m | No |
| Amazon | ~0.41 m | ~0.35 m | No |

**Not one of them passes.** Microsoft misses by a factor of five, Amazon by a
factor of fourteen. This is not a marginal result that better data would
overturn.

Nvidia is the interesting case and it is genuinely knife-edge. Fiscal 2026:
USD 215,9 billion of revenue and 42 000 employees, which is USD 5,14 million
each, or EUR 4,42 million, below the threshold. But the test is not group
level: it is the automated segment. Data Center revenue was USD 193,74
billion. If two thirds of the workforce is attributable to that provision,
the ratio is roughly EUR 5,7 million and Nvidia is designated; if
substantially more of the workforce is attributable, or once contracted
labour is counted, it is not. **The published accounts do not contain the
number that decides it.**

## What actually gets designated

| Undertaking | Revenue (annualised) | Headcount | Per head (EUR) | Valuation |
|---|---|---|---|---|
| Anthropic | ~USD 47 bn | ~2 300 to 5 000 | 8,1 m to 17,6 m | ~USD 965 bn |
| OpenAI | ~USD 40 bn | ~4 500 | ~7,6 m | ~USD 852 bn |

Both clear Article 3(2)(b) by a factor of between one and a half and three
and a half, and both clear the market-value limb of 3(2)(a) by an order of
magnitude.

So on today's figures the designated set is **two undertakings, possibly
three**, and it does not contain a single one of the firms most people
picture when they read this Regulation.

## Four things this changes

**1. The instrument does not reach big tech. It reaches the labs.** The
threshold selects for revenue concentrated in very few hands, which is the
signature of a pure-play model, not of an integrated firm that also runs
shops, devices, logistics and a sales force. Whether that is the intended
target is a policy question this file has never explicitly answered, and it
should, because the answer determines whether EUR 5 million is the right
number or whether the test should be shaped differently.

**2. Objection 17 stops being hypothetical.** A designated set of OpenAI,
Anthropic and possibly Nvidia is a set of United States undertakings. The
objection that the Union is seizing equity in companies it does not govern is
no longer a thing an opponent might say; it is a description of the measure's
practical incidence in its first years. Nothing in the drafting is wrong
about this, but the memorandum currently answers the objection in the
abstract, and it can now be answered concretely or not at all.

**3. The number that decides designation is not published and the
undertaking controls it.** Annex I point 3 counts employees, agency workers,
subcontracted labour, and anyone whose work supports the automated systems,
including development, maintenance, supervision and support. For an AI
laboratory that includes contracted data annotation, which is a large and
unpublished workforce. If OpenAI's counted full-time equivalents are 13 000
rather than 4 500, its ratio falls to about EUR 2,6 million and it is not
designated at all. The whole regime therefore turns on a figure no outsider
can compute and that the undertaking assembles itself. Article 3(3) requires
self-notification and Article 4 provides a market investigation, so the
architecture anticipates a dispute; what it does not do is make the trigger
externally verifiable.

**4. The breadth of Annex I point 3 runs against designation, not for it.**
Recital text justifies counting labour in substance as necessary to prevent
avoidance "by fragmentation or subcontracting, which a form-based count would
invite". The mechanics appear to run the other way. Because 3(2)(b) is a
minimum ratio, an undertaking escapes designation by having its counted
labour go **up**, and counting subcontractors makes it go up. Under a
payroll-only count, moving work to contractors would reduce headcount, raise
the ratio and make designation more likely, not less. Fragmentation is a real
avoidance route but it operates on the size thresholds in 3(2)(a) and is
addressed separately by Article 3(8). This file records the mismatch as a
question for the next drafting pass rather than as a settled defect, because
it may reflect an intent the recital states imprecisely rather than an error
in the rule.

## What it means for the Article 1 objective

Aggregate fair market value of the two undertakings that clearly qualify is
about USD 1,82 trillion, or roughly EUR 1,56 trillion. Three per cent of that
is about EUR 47 billion of eventual Reserve capital, before any
crystallisation has occurred and before any growth or contraction in the set.
Spread across roughly 350 million adults that is about EUR 134 of stake each,
not of income, and it arrives only as and when those undertakings' own owners
realise value.

That is the order of magnitude a quantified objective in Article 1 has to be
written against. It is also the number that makes objection 15, that a euro a
year is an insult, a live question rather than a rhetorical one, and it is why
the designated set mattering only two or three undertakings wide is a finding
about the instrument's ambition and not merely about its arithmetic.

## Confidence and what would change it

The incumbent result is robust: the misses are by factors of two to fourteen,
and no plausible revision of segment attribution closes that. The lab result
is robust on revenue and valuation and fragile on headcount, which is the one
input that is both decisive and poorly sourced. The Nvidia result is not
robust in either direction and should be treated as unresolved.

What would sharpen this: segment-level employment disclosure, which does not
exist; a defensible estimate of contracted annotation labour at the two labs;
and a view on whether the instrument intends to reach integrated firms at all,
which is a drafting decision rather than a data question.

## Sources

- NVIDIA fiscal 2026 results, revenue and headcount:
  https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-fourth-quarter-and-fiscal-2026
  and NVIDIA Form 10-K FY2026,
  https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm
- NVIDIA Data Center segment revenue:
  https://bullfincher.io/companies/nvidia-corporation/revenue-by-segment
- Revenue per employee across the large technology undertakings:
  https://www.trueup.io/revenue-per-employee
- Revenue per employee at the AI laboratories, and the caution that Anthropic
  and OpenAI recognise revenue on different bases:
  https://epoch.ai/data-insights/revenue-per-employee-ai-companies
- AI revenue and valuation leaderboard:
  https://aibusiness.vc/startups/ai-revenue-leaderboard
- Headcount estimates: https://www.makerstations.io/anthropic-employee-statistics/
  and https://www.makerstations.io/openai-employee-statistics/
- 2026 average EUR/USD rate:
  https://www.exchange-rates.org/exchange-rate-history/eur-usd-2026

Compiled 22 August 2026. Headcount figures for private undertakings are
estimates published by third parties, not audited disclosures, and are the
weakest input here.


# SOURCE: own-the-machine/evidence/warrant-percentage.md

# The warrant percentage: what the model can and cannot justify

Objection 21 asks why the warrant is three per cent and not one or ten. This
file records the computation behind the answer, because the answer turns on a
property of the published model rather than on a judgement, and anyone should
be able to check it.

## What was computed

The simulator on the campaign site implements the Annex II arithmetic as
amended on 19 August 2026: real-capital retention, a three-year smoothing
collar floored at 2 % of capital, no leverage, constant euros, a fifty-year
horizon, designated value crystallising as a continuing flow. The warrant
percentage enters it in exactly one place, as the share of each crystallising
flow that is added to the Reserve's capital.

The model was rerun with that percentage as a free parameter, across the three
scenarios the simulator itself offers: its default, its sceptic preset and its
forecast preset. Euro figures are annual distribution per adult citizen, in
constant euros, on 350 million adults.

| Scenario | 0.5 % | 1 % | 2 % | 3 % | 5 % | 10 % |
|---|---|---|---|---|---|---|
| default, year 20 | 0.59 | 1.18 | 2.35 | 3.53 | 5.88 | 11.75 |
| default, year 50 | 7.89 | 15.77 | 31.54 | 47.32 | 78.86 | 157.72 |
| sceptic, year 50 | 0.49 | 0.97 | 1.94 | 2.91 | 4.86 | 9.71 |
| forecast, year 50 | 61.69 | 123.39 | 246.78 | 370.16 | 616.94 | 1233.88 |

## The result

The model is exactly linear in the percentage. Trebling it trebles the
distribution at every horizon in every scenario, to four decimal places, and
the same holds for the accumulated stake. There is no threshold, no kink and
no discontinuity anywhere on the curve.

This is not a defect in the model. It is what the arithmetic of a
capital-preserving fund fed by a proportional share of a flow must do. But it
has a consequence the memorandum has to state: **no percentage can be derived
from the dividend side.** There is no figure at which the instrument starts
working and below which it does not, so no figure can be shown to be the
minimum necessary to make it work.

## Why that matters legally

Necessity under Article 52(1) of the Charter asks whether a less intrusive
measure would achieve the objective. Article 1 states the objective
qualitatively: the participation of citizens in the capital value created by
hyper-automated undertakings. One per cent produces participation. So does
one tenth of one per cent. An opponent therefore does not need to argue that
three per cent is excessive; they need only observe that a smaller figure
achieves the objective as the instrument states it.

The conclusion recorded in objection 21 is that this is a defect in Article 1
rather than in the memorandum, and that it is repaired by giving the objective
a quantity a percentage can be tested against, not by arguing harder about
three per cent.

## Reproducing it

Port the fifty-year loop from the site repository's
`src/scripts/simulator.ts`, replace the literal `0.03` with a parameter, and
run it over the three presets in the same file. The presets are: default
(revenue EUR 150bn, lag 7 years, real return 4 %, growth 5 %), sceptic (50,
15, 2, 0) and forecast (600, 5, 4, 8). Nothing else in the model changes.

Computed 22 August 2026 against simulator.ts as at site commit e1b0974.


# SOURCE: own-the-machine/evidence/sizing-the-ask.md

# Is three per cent enough to matter, and what would be

Historical sizing comparison: parts of this note analyse an earlier
threshold design, not the current presumptive set. Current designation
figures are in evidence/designation-count.md. The new accounting reference
is a proposal and does not recalibrate the percentage in this historical
exercise.

Companion to evidence/designation-count.md and to objection 21. That note
established that the warrant percentage cannot be derived while Article 1
states its objective qualitatively. This one asks what a quantified objective
would have to say, by working backwards from what the instrument can actually
deliver.

Nothing here is a forecast. The assumptions are named and varied, and the
model is twenty lines of arithmetic anyone can rerun.

## First, a comparison that has to be retired

The Norwegian fund is the reference everyone reaches for, and it does not
survive contact with the population.

| | fund per person | annual payment |
|---|---|---|
| Norway GPFG (>USD 2tn, 5,5m people) | ~EUR 313 000 | funds the state budget |
| Alaska Permanent Fund (~USD 80bn, 740k) | ~EUR 93 000 | EUR 860 in 2026 |

To give 350 million adults a Norway-sized stake would take about **EUR 110
trillion**, which is more than the entire world equity market. Per-capita
sovereign wealth at Norwegian or Alaskan levels is arithmetically unavailable
at Union scale, and this file should stop anyone reaching for the comparison,
including its own supporters. Norway is not a target. Alaska, at EUR 860 a
year to every resident, is a realistic one, and it is the benchmark used
below because it is a real universal dividend that has survived forty years
of politics.

## The model

The Reserve holds the warrant percentage of the capital of designated
undertakings, so its capital is that percentage of the aggregate value of the
designated set. Distributions are constrained by Annex II; 2,5 % real is used
here. Assumptions: world equity at about EUR 108 trillion today growing 4 %
real, so EUR 519 trillion in forty years; EU compensation of employees at
EUR 8,9 trillion today, 48 % of GDP per Eurostat, growing 1,5 % real to
EUR 16,1 trillion; 30 % of that displaced in the scenario the instrument
exists for.

## What three per cent delivers

Annual distribution per adult, in constant euros, at year forty:

| designated set | at 3 % | at 10 % | at 25 % |
|---|---|---|---|
| earlier two-undertaking threshold scenario | EUR 3 | EUR 11 | EUR 28 |
| 10 % of world equity | EUR 111 | EUR 370 | EUR 926 |
| 25 % of world equity | EUR 278 | EUR 926 | EUR 2 315 |
| 40 % of world equity | EUR 444 | EUR 1 481 | EUR 3 704 |

And as a share of the displaced labour income the instrument exists to
answer, at three per cent: 0,0 % on today's designated set, 0,8 % if
designated undertakings reach a tenth of world equity, 2,0 % at a quarter,
3,2 % at forty per cent.

## The two honest conclusions

**Three per cent is about half an Alaska dividend in the best scenario, and
nothing at all in the current one.** At forty per cent of world equity, which
is a world transformed, three per cent yields EUR 444 a year. That is a real
sum and it is not a replacement for wages, and this file should never again
be read as implying otherwise. Objection 15 already concedes the dividend
starts small; the number above is how small it stays.

**The scope of designation matters far more than the percentage.** Moving
from today's designated set to a quarter of world equity multiplies the
result by roughly three hundred. Moving from three per cent to ten multiplies
it by three and a third. The threshold in Article 3(2)(b), which
the earlier counting exercise designated two undertakings and
misses every incumbent, is therefore the single most consequential number in
the instrument, and it is not the one anybody argues about.

That reverses the usual order of the debate. **Fix the threshold and three
per cent becomes defensible. Leave the threshold as it is and no percentage
saves the instrument**, because three per cent of almost nothing and
twenty-five per cent of almost nothing are both almost nothing.

## Working backwards

What a warrant would have to be to hit a stated target, at year forty:

| target | Reserve capital needed | if designated = 10 % | = 25 % | = 40 % |
|---|---|---|---|---|
| Alaska-equivalent, EUR 860/yr | EUR 12,0 tn | 23,2 % | 9,3 % | 5,8 % |
| EUR 2 000/yr | EUR 28,0 tn | 54,0 % | 21,6 % | 13,5 % |
| replace 25 % of displaced labour income | EUR 48,4 tn | 93,4 % | 37,4 % | 23,4 % |

The last row is the one to read twice. Replacing even a quarter of displaced
labour income is out of reach at any percentage this instrument could
survive, in any scenario. **That objective must not be written into Article
1, and no material presenting this Regulation should imply it.** The first
row is reachable: an Alaska-equivalent universal dividend needs a warrant
between roughly six and nine per cent if designation reaches a substantial
share of the capital that automation creates.

## What this gives Article 1, and the tension it exposes

Objection 21 said the necessity limb of Article 52(1) has nothing to test
against. It now has something. Once Article 1 states a target of the form
"distributions of the order of X per citizen per year within Y years, in the
conditions the Regulation is drafted for", the table above answers the
question a court asks: whether a lower percentage would achieve it. That is a
derivation, from a published model, reviewable under Article 14.

The tension it exposes is real and belongs in the memorandum rather than in a
drawer. The percentage that makes the instrument meaningful is larger than
the percentage that makes it easy to defend under Article 17 of the Charter.
Objection 1 already records that no decided case places a permanent,
non-crisis, uncompensated dilution of a healthy undertaking on the right side
of the deprivation line, and three per cent sits comfortably below any
plausible ceiling precisely because it is small. Six to nine per cent does
not sit as comfortably. This file cannot have both the easy Article 17
argument and the meaningful dividend, and it should say which it is choosing
rather than leaving a reader to discover the trade-off themselves.

## Sensitivity

The result is not sensitive to the growth assumption in any way that changes
the conclusion: at 2 % real growth rather than 4 %, every figure falls by
about half and the ranking is unchanged. It is highly sensitive to the
designated share, which is the point of the second conclusion. The
distribution rate of 2,5 % is the Annex II constraint and moving it between
2 % and 3 % moves the outputs by a fifth.

## Sources

- Norges Bank Investment Management, half-year report 2026:
  https://www.nbim.no/en/news-and-insights/reports/2026/half-year-report-2026/
- Alaska Permanent Fund dividend 2026:
  https://thealaskastory.com/alaskans-permanent-fund-dividend-now-set-at-1200-for-2026/
- Eurostat, compensation of employees at 48,0 % of EU GDP in 2025:
  https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Annual_national_accounts_-_evolution_of_the_income_components_of_GDP
- EUR/USD 2026 average:
  https://www.exchange-rates.org/exchange-rate-history/eur-usd-2026

Computed 22 August 2026. The world-equity figure and the displacement share
are the weakest inputs and are scenario parameters, not measurements.


# SOURCE: own-the-machine-site/content/en/about.md

## What this is

An open-source draft EU Regulation intended to let citizens of the Union
participate in the capital value created by hyper-automated production,
prepared as the basis for a possible European Citizens' Initiative. The
legal text, its memorandum, its objections and every review verdict
live in a public repository; this site renders them.

## Not an EU document

This is a citizens' proposal. It is not published by, endorsed by,
affiliated with or reviewed by the European Union, the European
Commission, the European Parliament or any other Union institution,
body, office or agency. It has no legal force. It is drafted in the
conventions of Union legislation because a proposal meant to be
assessed by those institutions should arrive in the form they read; the
form is a courtesy to the reader, never a claim of authority. The site
carries no EU emblem, and the seal it does carry belongs to this
project alone.

## Who

Initiated by David Vanheeswijck (Belgium). The drafting method uses
adversarial AI review under the editor's responsibility; every verdict
and disposition is on the [ledger](/law/ledger). An organisers' group
of at least seven eligible EU citizens living in seven different Member States will be constituted
if the project passes its own gates.

## Who publishes this

Responsible for this site and for the draft it renders: David
Vanheeswijck, Belgium. Write to
[hello@ownthemachine.eu](mailto:hello@ownthemachine.eu); that address
reaches the editor, and everything substantive about the text belongs
in the open, as an [issue or pull
request](https://github.com/ownthemachine/own-the-machine) on the
repository, where the answer can be read by everyone the draft
concerns.

The same person is the controller for the little data this site
occasions, described below.

## Declared interest

The draft grew out of a book by its initiator. The campaign takes
nothing from the book's sales and does not link to it, and every
argument here can be checked without buying anything. That is not the
whole of it. Attention paid to this campaign is attention that can
reach the book, and the author is the same person, so the interest is
real whether or not a link exists. It is declared here to be weighed,
not because it has been designed away.

## The gates

The campaign proceeds only through published gates with kill criteria:
registrability soundings before constitution, constitution before
filing, registration before collection. Independent, non-binding Forum
advice arrived on 27 August 2026; an ECI veteran responded on 5 September.
Neither response constitutes registration or institutional approval.
Organiser recruitment continues. If a gate fails, this page will say
so and the repository stays up as a public good.

## Funding

No organisation, no bank account, no donations and no third-party money of
any kind. Nobody has been paid, and nobody has worked on this for payment.

Saying "none" would be the easier answer and it would not be true. This
site costs something to run and the initiator pays it personally: the
domain, object storage and edge delivery at Scaleway in France, and the API
calls the review gates consume. No campaign-specific third-party funding or support is recorded as of
6 September 2026. Standard platform services on ordinary terms, including
GitHub and Cloudflare, are disclosed below.

Regulation (EU) 2019/788 obliges a registered initiative to name every
source giving more than EUR 500 in a year and to keep that declaration
current while signatures are collected. The obligation starts at
registration. The declaration starts now, in campaign/FUNDING.md, which
also carries the rules adopted in advance about what will never be
accepted.

## Your data

This site sets no cookies, runs no analytics scripts and loads nothing
from third parties. There is no consent banner because there is
nothing to consent to.

What is nonetheless processed, stated plainly rather than claimed away:
any server that answers a request sees the address it came from, so the
host keeps short-lived technical logs, including IP addresses, to
deliver the pages and to defend against abuse. That is the whole of it;
those logs are not read for any other purpose, are not combined with
anything, are not sold and are not shared. If you switch this site
between paper and plate, that choice is written into your own browser's
storage and never leaves it.

Anyone in the Union may ask what is held about them, and may complain
to a supervisory authority; in Belgium that is the Data Protection
Authority. When signing opens, it happens on the European Commission's
own collection system under Regulation (EU) 2019/788, not here.

## Where this site lives

The pages you are reading are stored in Scaleway Object Storage in the
Paris region and served from Scaleway's own network. Scaleway is a
French company; the files, the cache and the certificate are European.

Two parts are not, and a campaign about European ownership should say
which: the domain's DNS is answered by Cloudflare, a United States
company, though no page content passes through it, and the source
repository is hosted on GitHub, also American. The one exception in
the serving path is www.ownthemachine.eu, which is a redirect to this
site and carries no content of its own.

Nothing here depends on any of that remaining true. The site is a
static build of a public repository: it can be rebuilt and served from
anywhere, by anyone, in minutes.

## Where the review runs

The automated gate verdicts are produced by models; external human feedback
is recorded separately. The compute
that produced it has a jurisdiction of its own. Until 23 August 2026
the gates ran through OpenRouter, an American router. The pipeline uses Requesty's European endpoint. EU hosting, zero retention
and no training use remain the default requirements. For the public or intended-for-publication, non-sensitive material
Fable 5.1 reviews introduced on 6 September 2026, the editor may permit, explicitly for each run, the router-reported 30-day retention while retaining EU hosting and no training
use. That exception excludes private correspondence, non-public personal data
and sensitive unpublished material; public author attribution may appear.

The runner does not take that on trust. Before it spends a token it
reads the router's own record of where the model runs and what becomes
of the text, and refuses to start if the model is absent or fails the
requirements selected for that run. Retention exceptions must be explicit;
they do not change the default checks. Whatever it read is written
into the review record, so each verdict carries the evidence rather
than the assurance.

One distinction is worth keeping sharp, because it is the distinction
this proposal is about. Hosted in Europe is not built in Europe. The
models are American, running on European infrastructure under European
rules, and of what this endpoint offers only Mistral is a European
laboratory. A campaign about who owns the machine should say plainly
that it does not yet run on one Europe owns.

## Accessibility

Target: WCAG 2.1 AA, with the WCAG 2.2 focus-appearance and target-size
criteria adopted early. The site is keyboard-complete and respects
reduced-motion preferences. Found a barrier?
[Open an issue](https://github.com/ownthemachine/own-the-machine-site/issues).


# SOURCE: own-the-machine-site/content/en/brief.md

## The ask

We are preparing an initiative asking the Commission to assess and propose
instruments for citizens to share in gains from hyper-automated production.
The [registration objectives](/law/registration) are the request; the 3 %
warrant Regulation illustrates one mechanism. Neither has been registered.

## How the illustrative draft works

- **Designation.** The Commission assesses durable decoupling of production
  from employment. Thresholds create a rebuttable presumption; investigation
  can also lead to designation below them.
- **Warrant.** Within three months of designation, a company issues a
  non-voting warrant for shares representing 3 % of fully diluted capital,
  subscribed at nominal value, subject to Article 5's cap.
- **Triggers.** The first liquidity event, shareholder extraction above the
  Article 5 threshold, or the seven-year long-stop triggers subscription.
  Settlement is in shares; it does not itself produce cash for payouts.
- **Entitlement.** EU citizens aged 18 or older would share equally in
  declared distributions. The right cannot be sold, pledged or redeemed.
  No means test; registration with a national vehicle is needed for payment.
  Available income determines distributions, which may be zero.

## Legal basis

Articles 114 and 352 TFEU are proposed, contested bases. Article 352 requires
unanimity. Registration would not approve the draft's legality or guarantee
its adoption; partial registration may change what can proceed.

## The central objection

The share obligation might be classified as a fiscal measure. Settlement in
shares outside public budgets does not settle that question. The
[objections](/law/objections) explain the challenge and the project's response.
Protections against diversion cannot prevent all future legislative changes.

## Status: 6 September 2026

No filing, registration or signature collection. The Forum advised on
27 August; an ECI veteran responded on 5 September. Both are independent
feedback, not institutional approval. Recruitment continues. The initiator
pays hosting and review costs; no organisation or donations are recorded.

## Take part

Ask questions or help organise via [take part](/join), privately or publicly.
Interest is not a signature or commitment to file. The statutory group needs
eligible EU citizens living in seven Member States, not seven nationalities.


# SOURCE: own-the-machine-site/content/en/contribute.md

The draft improves the way open source improves: in public, by pull
request, against stated criteria. Three repositories:

- [own-the-machine](https://github.com/ownthemachine/own-the-machine):
  the law, its memorandum, the review ledger (CC BY-SA 4.0).
- [own-the-machine-tools](https://github.com/ownthemachine/own-the-machine-tools):
  the review gates and linter (MIT).
- [own-the-machine-site](https://github.com/ownthemachine/own-the-machine-site):
  this site (AGPL-3.0).

## The merge criteria

Every change to the legal text must survive four tests: it claims
assets, not flows; it reaches every citizen equally; it does not weaken legal protection against diversion;
and it establishes the claim while capital forms, before crystallisation.
Mechanical constraints (the DC table in the
[objections](/law/objections)) apply before merge. Substantive changes run
all six adversarial gates; prose changes run legal form and layer fidelity;
editorial changes run the linter. Verdicts and editorial dispositions are
recorded publicly. A pull request that weakens a protection does not merge
under the published governance rules.

## Ways in

- **Argue.** Take on an objection, or raise a new one at full strength.
  The strongest contribution is the attack we have not answered.
- **Draft.** Improve an article against the Joint Practical Guide
  conventions; the linter and gates will meet you.
- **Translate.** Languages are promoted from machine-translated to
  human-verified one page at a time; native readers are the bottleneck.
- **Build.** The site and tools are ordinary open source with issues
  waiting.


# SOURCE: own-the-machine-site/content/en/faq.md

## What is this, in one sentence?

A proposal for citizens to share in the gains of highly automated production,
with an illustrative draft EU law creating a common fund that holds company
shares and pays equal distributions to adult EU citizens.

## Do I get money? How much, and when?

There is no benefit to claim today. Under the draft, every EU citizen aged
18 or older would have an equal right to distributions when declared. The
entitlement cannot be sold, pledged or redeemed; payment requires
registration with a national vehicle. Amounts depend on the fund's realised
income after costs and retention rules and could be zero. The draft's
long-term capital objective is an objective, not a guaranteed balance or
income. The [simulator](/simulator) explores assumptions, including continued
new company stakes; it is not a forecast of your payments. Article 10(6)
requires annual distribution when the amount per holder reaches ten times
the average payment cost, and at least once in every third calendar year
with a positive distributable amount. Small unpaid amounts roll forward;
a payment every year is not guaranteed.

## Is this a tax?

The draft is designed as equity participation: covered companies issue shares
to a common Reserve rather than making cash contributions to a public budget.
Whether EU law would nevertheless classify it as a fiscal measure is
contested. The independent ECI Forum advice identifies that risk, and the
[objections](/law/objections) give the argument and the project's response.

## Which companies would be covered?

The Commission would assess whether production depends significantly on
automated cognitive systems and is durably decoupled from employment. A
rebuttable presumption applies when the draft's thresholds are met: at least
EUR 7.5 billion in annual EU turnover or EUR 75 billion in value, activity in
at least three Member States, and a value at least eighty times worldwide
labour compensation, sustained for two financial years. A company may rebut
the presumption. The Commission may also designate a company below those
thresholds after investigation. The thresholds are indicators, not proof
that a business operates without people.

## Will this kill jobs, or drive innovation away?

Those effects need independent assessment. A 3 % share obligation could
affect investment, prices and business decisions, even without a cash levy.
The draft uses labour compensation in its designation test and includes
anti-avoidance rules, so hiring more people is not an automatic exemption.
It provides monitoring and review; it cannot promise that there will be no
unwanted effects.

## Will companies simply leave the EU?

The draft applies to covered activity in the internal market regardless of
where a company is established. Moving a headquarters would not by itself
remove the obligation. Companies could still change services, investment or
market participation. Cross-border enforceability and proportionality are
contested questions; the size of the EU market does not settle them.

## Who controls the fund? Can politicians raid it?

The Reserve's shares would carry no votes or management rights. Article 12
prohibits diversion to public budgets and gives holders a court remedy.
These are legal barriers, not a guarantee that future legislators cannot
change the law. The personal entitlement is a right to declared
distributions, not an individually redeemable portfolio of company shares.

## What if AI stays small and the transformation never comes?

Fewer qualifying companies or lower returns could mean a small fund and
little or no income. Article 14 requires the Commission to assess the
evidence and, where appropriate, propose amendment or repeal. The draft
does not automatically switch itself off, and its administrative and company
obligations are not costless even if the gains disappoint.

## When does a company have to issue the shares?

The claim arises at effective designation; the company documents it within three months. The warrant
crystallises on the first liquidity event, earlier shareholder extraction
above 25 % of covered turnover over three consecutive financial years, or
the seven-year long-stop from the claim arising. Article 5 sets the precise
rules. A private company cannot avoid the backstop simply by staying private.
Shares entering the fund do not guarantee immediate cash distributions.

## What do I have to do now?

There is nothing to sign yet. You can read the proposal, ask questions,
volunteer or discuss becoming an organiser on the [take part](/join) page.
The site has no mailing list and does not collect statements of support.
If the initiative is registered and collection opens, the site will link to
the Commission's official signing system. One million valid statements and
the required national thresholds secure consideration and a response, not
automatic adoption of the illustrative law.

## Who is behind this, and who pays for it?

David Vanheeswijck initiated the project and pays its hosting and AI review
costs. As of 6 September 2026, no constituted organisation or third-party
funding is recorded. The [about](/about) page names the editor and discloses
the connection to his book. The review ledger distinguishes model reviews
from external feedback; neither is an EU institutional endorsement.


# SOURCE: own-the-machine-site/content/en/join.md

## Where this actually stands

As of 6 September 2026, no version has been filed or registered with the
Commission and no statements of support are being collected. Check the
[versions](/law/versions) page for the registration record. Organiser
recruitment is under way; interest does not mean the statutory group is
already constituted.

The ECI Forum supplied independent, non-binding advice on 27 August, and an
ECI veteran responded on 5 September. The public record includes the
questions raised and the project's responses. This is external feedback,
not approval by the Commission. The project still needs independent scrutiny
and people willing to take responsibility for its next stage.

## Ways to help

**Question the proposal.** Read the draft and raise a specific objection.
Public [issues and pull requests](https://github.com/ownthemachine/own-the-machine/issues)
make the discussion available to everyone. Private questions are welcome too.

**Help organise.** Express interest in the founding group, native-language
review, explaining the proposal or practical coordination. You do not need
to be a programmer or agree with every article to start a conversation.

**Connect an organisation.** Introductions, independent review and concrete
commitments of time or publication support can help establish whether a
campaign is feasible. An introduction does not imply an endorsement.

## What being an organiser means

The statutory group needs at least seven EU citizens old enough to vote in
European Parliament elections and living in at least seven different Member
States. Seven different nationalities are not required. MEPs do not count
towards the minimum. The group appoints a representative and substitute;
organisers' names are published in the Commission's register. The
[official rules](https://citizens-initiative.europa.eu/how-it-works_en)
govern eligibility and responsibilities.

Expressing interest now is not agreeing to file. Before committing, the
group must agree its objectives, responsibilities, funding arrangements and
remaining legal risks. The published gates still apply. Signing a registered
initiative would support its registered objectives; the detailed Regulation
is an illustrative mechanism, not an already adopted law.

## How to get in touch

Write to [hello@ownthemachine.eu](mailto:hello@ownthemachine.eu), or open a
public issue if you prefer a public discussion. Both routes are welcome.
For an organiser enquiry, it helps to state your Member State of residence,
what you could contribute and your questions. No identity document is needed
to express interest, and none should be posted in a public issue.

## What happens to what you send

A GitHub issue is public. An email reaches the editor; it is not added to a
mailing list, forwarded or published without your agreement. There is no
mailing list or donation form. Contact is used to answer the enquiry, not
to send unsolicited campaign messages. See [about](/about) for the controller
and your rights. Any later change to these arrangements must be explained
before it takes effect.


# SOURCE: own-the-machine-site/content/en/press.md

## What this is

Own the Machine is an open-source draft EU Regulation accompanying a proposed
European Citizens' Initiative. The proposed objectives ask the Commission to
assess and propose mechanisms for citizens to participate in productivity
gains from hyper-automated production. The detailed 3 % warrant mechanism is
illustrative; nothing has been registered or adopted.

## Boilerplate, free to reuse

Own the Machine proposes broader citizen participation in the gains of
highly automated production. Its illustrative draft would create a common
Reserve holding non-voting company shares and equal, non-transferable rights
to distributions for EU citizens aged 18 or older. Payments would depend on
available income and could be zero. The text, objections and review history
are public at ownthemachine.eu. No EU institution endorses the initiative.

## The numbers and their limits

- The draft's rebuttable quantitative presumption combines EUR 75 billion
  in value or EUR 7.5 billion in EU turnover, activity in at least three
  Member States, and value at least eighty times worldwide labour
  compensation, sustained for two financial years. Investigation can also
  lead to designation below the thresholds.
- A warrant arises at effective designation and is documented within three months. It crystallises
  at the first liquidity event, shareholder extraction exceeding 25 % of
  covered turnover over three consecutive financial years, or the seven-year
  backstop after the claim arises. Article 5 sets the precise conditions and cap.
- The warrant entitles the Reserve to subscribe at nominal value for shares
  representing 3 % of fully diluted capital. Share issuance is not cash
  income available for immediate distribution.
- The draft's capital objective is of the order of six months of median equivalised
  disposable income in the EU per citizen within a generation. It is an objective,
  not a guaranteed result; projections rely on uncertain assumptions about
  company coverage, new stakes, returns and costs.

Use the current [evidence](/evidence) and [legal text](/law) for definitions
and dated estimates. The simulator shows conditional scenarios, not a
forecast, confidence interval or personal entitlement valuation.

## Status, as of 6 September 2026

No filing, registration or signature collection. The ECI Forum supplied
independent, non-binding advice on 27 August; an ECI veteran replied on
5 September. Organiser recruitment and further scrutiny continue under the
published gates. No constituted organising group is recorded. A statutory
group needs eligible EU citizens living in seven different Member States,
not necessarily seven different nationalities.

## Legal and practical limits

The design uses shares and keeps assets outside public budgets. Its possible
fiscal classification and proposed Treaty bases remain contested; the Forum
advice is not Commission approval. Legal protections against diversion cannot
guarantee that future legislators never amend the rules. The Reserve would
have no voting or management rights. The individual entitlement could not be
sold, pledged or redeemed; payment would require registration with a national
vehicle. Success as an ECI would secure consideration and a response, not
automatic enactment of this Regulation.

## Assets and contact

- Public text and source material are available without buying anything.
  The initiator's interest in his book is disclosed on [about](/about).
- Social preview images are available under ownthemachine.eu/og/ in the
  five website languages.
- PDF and EPUB downloads on the [law page](/law) identify the draft version.
- Text is CC BY-SA 4.0; the website and tools are open source.
- Contact: [hello@ownthemachine.eu](mailto:hello@ownthemachine.eu).
  David Vanheeswijck answers; there is no press office or guaranteed reply time.


# SOURCE: own-the-machine-site/content/en/sign.md

## Current status

No version is registered and there is nothing to sign for this initiative
today. The status box and [versions](/law/versions) page carry the registration
record. An expression of interest is not an official statement of support.

## How signing works

If collection opens, this site will link to the initiative's page on the
Commission's Central Online Collection System. That is the only online
collection system for newly registered ECIs. Official paper forms are also
permitted; this campaign has not opened paper collection. Follow the
Commission's privacy information for the precise handling of signing data.
This website will not host its own signature form.

## Who can sign

EU citizens can sign once per initiative, wherever they live, if they meet
the minimum signing age for their nationality. That is generally the age for
European Parliament voting; some Member States allow ECI support from age
16 separately. Consult the Commission's current
[eligibility and data requirements](https://citizens-initiative.europa.eu/data-requirements_en).
The draft fund's proposed age of 18 is separate from signing eligibility.

## What information is needed

The official form specifies the information required for your Member State
of nationality. This may include an identification-document number or
personal identification number. Some countries support electronic identity.
Use the official form's instructions; do not send identity documents to
this campaign or put personal signing information in public discussions.

## What one million means

Success requires one million valid statements of support and minimum totals
in at least seven Member States within the twelve-month collection period.
For initiatives registered on or after 16 July 2024, thresholds are calculated
using the total number of MEPs, currently 720: Belgium's is 15,840. Consult
the [official threshold table](https://citizens-initiative.europa.eu/thresholds_en)
for the current figures. Submitted counts remain subject to verification.

Success leads to examination and a reasoned Commission response, not an
automatic referendum result or adoption of the draft. The proposed
[registration objectives](/law/registration) are the request; the Regulation
illustrates a possible mechanism. See the
[official process](https://citizens-initiative.europa.eu/how-it-works_en).

## During collection

The registered text will be fixed and published beside the living draft,
with differences visible under the [versions](/law/versions) rules. The
Commission's system offers optional initiative updates after signing; the
organisers can send these through that system without receiving subscribers'
email addresses. This site's no-list policy is separate from that official
option. Collection dates and the official link will appear only once confirmed.

## Before collection

Read the [one-page summary](/brief), consider the [objections](/law/objections)
and use [take part](/join) to ask questions or help organise. Nobody needs to
buy the book, provide an identity document or pay to evaluate the proposal.


# SOURCE: own-the-machine-site/content/en/versions.md

## Is the text on this site the text you would be signing?

The box above answers that, and it is the only place on this site where the
answer is recorded. It is read at build time from a single file in the
repository, so it cannot quietly fall out of step with the truth by being
forgotten in an edit somewhere. This page explains what the answer means,
and what happens to the text on the day it changes.

## What registration changes

A European citizens' initiative is registered on a fixed text. From the day
the Commission registers one, the annex as registered is what a citizen is
asked to sign, and it cannot be amended afterwards. That requirement is a
good one: a million people should be signing the same sentence.

It sits awkwardly with how this draft is written. The text improves because
it is attacked, and the attacking would not stop the day a form is filed. So
two things have to be true at once, and visible at once:

- the **registered text** is fixed, and is what anyone signed;
- the **living draft** carries on, because the Commission's eventual answer
  should meet the best version of the argument rather than whichever version
  happened to be ready on the filing date.

The failure this page is built to prevent is the ordinary one: a site that
keeps editing its text while people sign something else, and a screenshot six
months later showing that the two do not match.

## The rule, written before it is needed

From the day of registration:

1. The filed text is copied, word for word, into a directory that is never
   edited again. A correction is a new version, never a change to the old
   one.
2. Every page rendering the living draft says that it is the living draft,
   and reaches the registered text in one click.
3. Where the two differ, the difference is published as a diff you can read
   for yourself. Nobody here gets to tell you the change was minor.
4. The frozen text is authoritative for what was signed. The living draft is
   authoritative for nothing at all until it is filed in its turn.

These rules are in [GOVERNANCE.md](https://github.com/ownthemachine/own-the-machine/blob/main/GOVERNANCE.md)
in the repository, adopted on 21 August 2026, which is well before there is
anything to freeze. The timing is the point. A rule about what may be done
to a text that people have signed is worth very little if it is written
after you already know what you would like to change.

## How this page knows

The status above is not typed into this page. It is read at build time from
[versions/REGISTERED.json](https://github.com/ownthemachine/own-the-machine/blob/main/versions/REGISTERED.json)
in the repository, which is the single place the answer is recorded. If that
file ever says something different from this page, the file is right and this
page is a bug.
