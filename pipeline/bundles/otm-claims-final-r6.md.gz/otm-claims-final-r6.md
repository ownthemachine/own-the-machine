# Claim corrections and automation-first campaign plan, 6 September 2026

Review scope: changes to public explanatory copy, registration prose, distribution guidance, the proposed campaign operating plan and reviewer tooling. No enacting article, recital, definition, threshold was amended. The simulator display floor was corrected to allow zero; the economic calculation is unchanged. Complete normative source is supplied below as reference. Assess the changed prose against it, not as a request to redesign the instrument. Report pre-existing normative issues separately from changes required to correct this package; do not claim the whole law is cleared by a prose review. Flag genuine remaining overclaims, risks from the changes, or unsupported source inferences. No legal change should be inferred from an explanatory edit.

Model configuration: live Requesty catalogue on 6 September listed vertex/claude-fable-5.1@eu (EU, retention 30 days, no training). No gpt-6-astra family was listed. Fable is explicitly authorised for this public-material exception; Astra is supported as a profile but must not be claimed to have run. No private correspondence, non-public personal data or credentials are in this bundle. Public external-review excerpts are already in the public repository.

ECI facts checked against current Commission guidance: a million valid statements, thresholds in at least seven Member States, eligible EU-citizen organisers resident in seven Member States (not seven nationalities); Belgium 15,840 under current thresholds; twelve-month collection; starting within six months after registration; official central online system, paper permitted; success requires a reasoned response and does not compel legislation. Official sources: https://citizens-initiative.europa.eu/how-it-works_en ; https://citizens-initiative.europa.eu/thresholds_en ; https://citizens-initiative-forum.europa.eu/document/central-online-collection-system_en . The campaign plan's budgets and conversion counts are explicit scenarios, not supplier quotes or evidence of actual support. The initiator has clarified that he supplies engineering/automation, with volunteer partners; salaried staffing is not required by this plan.



# SOURCE: own-the-machine/GOVERNANCE.md

# Governance: how an open-source law changes

This repository is public. Every rule here is written for that fact:
strangers proposing amendments to a draft statute, in public, with the
history permanent.

## Roles

- **Editor:** David Vanheeswijck, until a campaign organisation exists and
  formally assumes the role. The editor merges; nobody else does, including
  automated tooling.
- **Reviewers:** anyone. Review rounds run by the team are committed to
  pipeline/reviews/ so outside reviewers can see the standard applied.
- **Contributors:** anyone, via issues and pull requests. No CLA; the
  licences (LICENSING.md) are the contract.

## The merge criteria

Two layers, both mandatory. Prose quality is judged last, not first.

**Substantive: the four tests.** A change fails review by definition if it
makes the instrument
1. less about assets and more about flows,
2. less universal (any means test, any discretionary gate),
3. less raid-proof (weakening entrenchment, adding emergency clauses,
   permitting sovereign self-dealing), or
4. later (moving obligations past the formation of the gains).

**Mechanical: the constraints table.** Every PR touching regulation/ must
state which DCs from regulation/memorandum/counter-arguments.md it touches.
A draft that violates a DC is rejected regardless of drafting quality. A PR
arguing a DC itself is wrong must amend the counter-arguments file first, in
the same PR, and survives only if the underlying objection is answered at
least as well as before.

## Change classes

| Class | Examples | Required before merge |
|---|---|---|
| Editorial | typo, punctuation, layout | editor's read |
| Prose | recital wording, memorandum text | legal-form gate + editor |
| Substantive | any enacting term, any threshold, any definition | full pipeline (all six gates) + editor |
| Constitutional | the four tests, the DC table, this file | full pipeline + public issue open ≥14 days + editor |

### The 14-day window assumes a public, and there is not one yet

The constitutional window was written for a repository people read. This one
is public but unannounced, and nobody has been asked to look at it. Running
a 14-day comment period against that audience produces no comments and then
treats the silence as ratification, which is a worse outcome than not
running it: it manufactures a legitimacy this project has not earned and
would have to defend later.

So the window runs from the first outreach, not from the merge. Until this
draft has been put in front of people who were invited to argue with it:

- constitutional changes may be merged by the editor on the full pipeline
  alone, and are **provisional**;
- each one is listed below as it is made;
- at first outreach every provisional change re-opens together, for the full
  14 days, and anything unable to survive that is reverted.

Provisional constitutional changes, pending the window:

- 21 August 2026: "Versions: the freeze at registration", added below.
- 22 August 2026: objections 20 and 21 and constraints DC-43 to DC-46 in
  regulation/memorandum/counter-arguments.md.
- 22 August 2026, second entry: the designation-ratio package. Article
  3(2)(b) redesignated on fair market value against audited compensation
  of labour; Annex I point 3 rewritten accordingly; Article 1(2)
  quantified objective; Article 14(1)(e) labour-share indicator; recitals
  5, 6, 7 and 30 amended; DC-45 and DC-46 restated. Two prior designs
  were killed in gate review before this one; the record is in
  pipeline/reviews/2026-08-22-designation-ratio.md. DC-46 records that Article 1's
  objective needs quantifying before filing, which is the largest open
  drafting item this file has; the reasoning is in
  pipeline/reviews/2026-08-22-objections-20-21.md.

This clause is itself provisional under its own terms.

## Process

1. Open an issue describing the change and which objections (1-18) it
   relates to. Drafting starts in the issue, not the PR.
2. PR from a branch; template requires: DCs touched, change class, gates run,
   review files added under pipeline/reviews/.
3. Gates run per class (pipeline/README.md). Verdicts are committed, PUBLISH
   and REVISE alike. A REVISE with a written editor disposition can merge;
   silent overrides cannot.
4. Editor merges with a message stating what the change does to the
   instrument, not what it does to the text.

## Versions: the freeze at registration

Everything above describes a living draft. Registration under Regulation
(EU) 2019/788 changes that, and this repository has to change with it.
From the moment an initiative is registered, the annex as registered is
what citizens are asked to sign, and it cannot be amended. A draft that
keeps moving while signatures are collected against a fixed text is not
transparency; it is a gap between what was signed and what is published,
and it would rightly be read that way.

The rule is adopted here before there is anything to freeze, so that it
cannot later be written to suit a convenience.

1. **On the day of registration the filed text is frozen.** It is copied
   verbatim into versions/, with the commit it was taken from, the date of
   filing and the Commission's decision. Nothing in that directory is ever
   edited afterwards. A correction to a frozen version is a new frozen
   version, never an edit of the old one.
2. **versions/REGISTERED.json is the machine-readable state.** It names the
   registered version or records that there is none. The site reads that
   file and reports what it finds; no page states the answer from memory.
3. **The living draft continues, and says so on every page.** Work does not
   stop at registration, because the Commission's response is argued
   against the best version of the case, not the filed one. Every page
   rendering the living draft carries the distinction plainly, and the
   registered text is reachable in one click from any of them.
4. **Divergence is published, not characterised.** Where the living draft
   and the registered text differ, the difference is a diff a reader can
   read for themselves, never a claim about how minor it is.
5. **The frozen text is authoritative for what was signed. The living draft
   is authoritative for nothing until it is itself filed.**

Before registration, which is where this project stands, the state is
simply that no version is registered and the whole repository is a draft.

## Transparency rules

- No force-pushes to main, ever, once public. History is the product.
- Every review round, including failed ones, is committed.
- Editor dispositions that decline a finding are written into the review
  file, as in the wider project's practice.
- The site's public ledger is rendered from the review files and release
  notes: outcomes and dispositions are the public story; prompts and tooling
  remain inspectable in the tools repository.
- Funding and support are declared in campaign/FUNDING.md, and the
  declaration is kept current from now rather than from the moment
  Regulation (EU) 2019/788 makes it compulsory. "None" is not an
  acceptable answer while anyone is paying for anything.


# SOURCE: own-the-machine/pipeline/README.md

# The legislation pipeline

The strictest gate set in the project, because the artefact is a draft
statute that professionals must be unable to dismiss on form, and because
the repo is public: the pipeline is part of the credibility, visible to
every reader.

Inherited from the book project's hard-won lessons: reviewers get FULL
document context, never fragments; every round is committed, PUBLISH and
REVISE alike; declined findings carry a written editor disposition; and the
automated gate is trusted on rule violations, never on whether a sentence
lands. The final read is always human.

## The six gates

Run in this order; later gates assume earlier ones passed. **The runner, the
six gate prompts and the linter live in the
[own-the-machine-tools](https://github.com/ownthemachine/own-the-machine-tools)
repository (MIT)**: machinery there, so this repository stays the civic
artefact: the law, its evidence, its governance and the ledger of its own
evolution. Review OUTPUTS are committed here under pipeline/reviews/,
because a verdict on a statute is part of the statute's history.

| # | Gate | Catches | Suggested model tier |
|---|---|---|---|
| 1 | Legal form | Joint Practical Guide violations, powers architecture, DMA threshold pattern, memorandum skeleton | fast |
| 2 | DC compliance | violations of the 30-row constraints table | fast |
| 3 | Legal basis and rights | Art. 114/173 reasoning, subsidiarity, proportionality, Charter Art. 17, Art. 345 | strongest available |
| 4 | Hostile counsel | how a litigator for covered undertakings, or the Legal Service, kills the text | strongest available |
| 5 | Acquis coherence | collisions with company law, Prospectus, IORP II, PEPP, DMA definitions | strong |
| 6 | Layer fidelity | drift between the articles, the memorandum and the plain-language layer | fast |

Before any gate: the linter from the tools repo (mechanical checks; free; no
excuse to skip).

## Which gates when

- Editorial changes: lint only.
- Prose changes: lint + gates 1 and 6.
- Substantive changes: lint + all six.
- Constitutional changes: all six plus the 14-day public issue
  (GOVERNANCE.md).

## Review file convention, and what the public actually sees

Review files live at pipeline/reviews/YYYY-MM-DD-<gate>-<slug>.md and open
with front matter the site can render:

    gate: hostile-counsel
    target: regulation/articles/03-designation.md
    commit: <sha>
    verdict: REVISE
    disposition: merged-with-fixes | declined (reason) | pending
    date: 2026-09-04

The campaign site renders a public ledger of the law's evolution from these
files and from release notes: what changed, what prompted it, what review
found, how the editor disposed of it, with a diff link. That ledger, not
this tooling, is the public story. The prompts and runner stay inspectable
here, because the repo is open and hiding machinery reads worse than owning
it, but the product is a law that shows its work, not a showcase of the
workshop.

## Status

All six gates are operational. DRAFTING-RULES.md was completed from the
legislative-drafting research on 18 August (source record with all URLs:
research-drafting-2026-08-18.md); the legal-form gate now enforces the Joint
Practical Guide, the DMA Article 3 threshold pattern, the BRRD property
architecture and the Commission's memorandum skeleton.


# SOURCE: own-the-machine/pipeline/DRAFTING-RULES.md

# Drafting rules

Distilled 18 August 2026 from the legislative-drafting research
(pipeline/research-drafting-2026-08-18.md carries the full findings and
sources). These rules are operative: the legal-form gate enforces them, and a
draft violating them is not "stylistically imperfect", it is the first
dismissal the institutions will reach for.

## The three acts on the desk

1. **DMA, Regulation (EU) 2022/1925**, Articles 2, 3, 4, 17, 49, 53 and the
   Annex: the complete threshold, presumption, notification, designation,
   rebuttal and review machine. Our micro-giant designation chapter follows
   it almost line for line.
2. **BRRD, Directive 2014/59/EU**, recitals 13, 49-51, 88, 120-124, 130-131;
   Articles 34, 36, 47, 59-62, 73-75, 85: the only judicially validated
   architecture for diluting or extinguishing equity by act of law (Kotnik
   C-526/14, Ledra C-8/15 P, Dowling C-41/15, Aeris Invest C-535/22 P). Our
   property-rights chapter.
3. **AI Act package**, COM(2021) 206 plus Regulation (EU) 2024/1689 Articles
   51-52 and 97: the current-generation explanatory memorandum to copy
   structurally, and a second example of presumption thresholds kept
   technology-proof by delegated act.

Do NOT cite Regulation 2022/1854 (the solidarity contribution) as validated
precedent: its characterisation defence is untested (T-802/22 outcome not
final) and its emergency logic is unavailable to a permanent instrument. Use
its surplus-only base design and review clauses as drafting aids only.

## Structure (Joint Practical Guide, 2nd ed. 2015)

- Title, citations, recitals, enacting terms, annexes. Enacting-terms order:
  subject matter and scope; definitions; rights and obligations; powers;
  procedure; transitional and final provisions. Articles numbered
  continuously across chapters.
- One idea per sentence. Ambiguity papering over disagreement gets read
  restrictively by the Court (C-6/98 ARD).
- A Regulation applies directly: draft obligations on the addressee ("Every
  covered undertaking shall...") never "Member States shall ensure", except
  where a duty is genuinely the Member State's.
- Enacting terms command in the present indicative "shall". Recitals reason
  with "should" and contain zero normative content (JPG G10; C-162/97
  Nilsson: recitals cannot derogate from articles). Nothing normative may
  live only in a recital; every obligation needs a motivating recital, in
  the order of the provisions.
- All definitions in Article 2, none containing an obligation, every defined
  term used with exactly one meaning and no synonyms.
- Cross-references minimal, precise, intelligible without lookup. Annexes
  technical only: no new right or obligation may live in an annex.
- Mandatory reasoning (Art 296 TFEU) for derogations, exceptions,
  retroactivity and provisions prejudicial to particular interests; the JPG's
  model subsidiarity recital has gaps that MUST be filled case by case:
  unfilled boilerplate is itself a recognised defect.

## Powers architecture (Arts 290/291 TFEU)

- Essential elements stay in the articles, reviewably (C-355/10): for us the
  warrant trigger, the reserve's ownership structure, the dividend
  entitlement and the interference with shareholders are essential and may
  never be delegated.
- Delegated acts supplement or amend non-essential elements (threshold
  methodology, annex counting rules); implementing acts make individual
  designation decisions and templates (C-427/12; Reg 182/2011 comitology).
- Use the standard six-paragraph "Exercise of the delegation" article
  (CSDR Art 67 pattern) and the standard delegated-acts and comitology
  recitals with the 2016 IIA expert-consultation language.

## Thresholds (the DMA Article 3 model, followed exactly)

Cumulative qualitative test in paragraph 1; quantitative rebuttable
presumption in paragraph 2 with each metric mapped to one qualitative limb in
the recitals; self-notification within a deadline; designation decision
within a deadline; rebuttal only by "sufficiently substantiated arguments"
that "manifestly put into question" the presumption, with market-definition
economics excluded; below-threshold designation via market investigation;
review of designations at least every three years. Numbers in the article,
counting methodology in an annex, adjustment by tightly conditioned
delegated act.

## Property rights (the BRRD formula, adapted)

- An honest interference recital naming Charter Article 17 (BRRD recital 13
  model) plus a full Article 52(1) proportionality recital (recital 49
  model) plus the standard Charter recital naming Articles 17, 16, 47 and 34
  (recital 130 model).
- A quantified no-worse-off safeguard with independent valuation,
  compensation mechanism and separately challengeable valuation (BRRD Arts
  36, 73-75; upheld in Aeris Invest). ADAPTATION REQUIRED: BRRD's
  counterfactual is insolvency; ours must be market-consistent (no
  shareholder worse off than under an equivalent market-terms issuance),
  because a permanent regime cannot lean on crisis reasoning (Dowling's
  limit).
- Express, clearly and narrowly defined derogations from Directive (EU)
  2017/1132 pre-emption and capital-increase rules and from SRD 2007/36
  (BRRD recitals 120-124 formula). Silent conflict with company law reads as
  amateurism.
- A judicial-review article (BRRD Art 85; Charter Art 47).

## Interfaces the articles must write explicitly

Prospectus exemption (Reg 2017/1129: the warrant is a transferable
security); the reserve is not an AIF (AIFMD 2011/61); CRR own-funds
interaction; IORP II and PEPP interface preserving Member State social
competence; an EDPS recital for pension-rail data processing (Art 42(1) Reg
2018/1725); distinguish the golden-shares case law under Art 345 TFEU.

## The explanatory memorandum

Reproduce the Commission's five-section skeleton exactly, numbering
included (verified against COM(2021) 206): 1 context; 2 legal basis,
subsidiarity, proportionality, choice of instrument; 3 evaluations,
consultations, impact assessment, with a fundamental-rights subsection;
4 budgetary implications; 5 other elements including article-by-article
explanation. Annex a completed subsidiarity grid (COM(2018) 703). Our
evidence base substitutes for the impact assessment and must be presented
as such; Parliament uses EPRS added-value assessments for this and an ECI
has no equivalent, so the memorandum does that work itself.

## Monitoring and review

A monitoring article that generates the data, then: "By [date], and every
three years thereafter, the Commission shall evaluate this Regulation and
report to the European Parliament, the Council and the European Economic and
Social Committee", closing with measures "which may include legislative
proposals" (DMA Art 53 pattern). Pair with the falsification condition
(DC-18), which is our addition to the genre.

## The characterisation ladder

The single highest-stakes drafting decision: Art 114 (internal market,
centre of gravity per C-376/98 Tobacco Advertising: disparities alone are
not enough, the measure must genuinely improve the internal market's
functioning), falling back Art 115 (unanimity), Art 352 (unanimity plus
consent), with fatal drift being Art 311 own resources. Registration is NOT
where this fight happens: the test there is "manifestly outside" the
Commission's powers (Reg 2019/788 Art 6(3)(c)), partial registration is
judicially established (C-899/19 P), and the EU wealth-tax ECI was
registered in 2023. The characterisation fight comes in Council. Draft every
ask severable, each with its own defensible basis.

## The strategic rule

No outsider text has ever been enacted as written. Draft so the mechanics
(thresholds, designation, no-worse-off safeguard, review cycle) survive
transplantation into a Commission-rewritten shell. Form buys the hearing;
severability buys survival; the mechanics are the legacy.


# SOURCE: own-the-machine/regulation/STRUCTURE.md

# Provisional structure of the Regulation

Working title: Regulation of the European Parliament and of the Council on
harmonised rules for citizen participation in automated productivity gains
(Citizens' Capital Regulation).

Legal bases: Article 114 TFEU, with Article 352 TFEU as the fallback where
Article 114 does not comfortably reach. Severable layers per DC-6.

| Ch | Articles | Content | Status |
|---|---|---|---|
| I | 1-2 | Subject matter, scope, definitions | drafted |
| II | 3-4 | Designation of covered undertakings; market investigation and review | drafted |
| III | 5-7 | The citizens' capital warrant; independent valuation; safeguards | drafted |
| IV | 8-9 | The European Citizens' Capital Reserve; prohibited holdings and conduct | drafted |
| V | 10-11 | The citizens' entitlement; national vehicles | drafted |
| VI | 12 | Protection of the Reserve and of entitlements | drafted |
| VII | 13-16 | Penalties; monitoring and evaluation; delegation; committee procedure | drafted |
| VIII | 17-18 | Transitional and final provisions | drafted |

Citations and recitals: drafted, see regulation/recitals.md (citations
added 6 September 2026, closing the legal-form finding of 19 August). DC-26,
the explicit scope-and-limits recital, is outstanding and not yet drafted.

Annex I: methodology for counting turnover, fair market value and full-time
equivalents (referenced by Article 3; technical only per JPG G22). Drafted,
regulation/annexes/annex-1-counting.md.

Annex II: methodology for the capital-preservation retention (referenced by
Article 8(4); technical only). Drafted,
regulation/annexes/annex-2-retention.md.

The four tests map: in time = Chapter II; assets not flows = Chapter III;
universal = Chapter V; raid-proof = Chapter VI. Each drafted article carries
non-normative drafting notes after a separator; the notes never enter the
legal text.

## Accompanying documents

| Document | Content | Status |
|---|---|---|
| memorandum/explanatory-memorandum.md | The five-section explanatory memorandum in the Commission's own structure: context; legal basis, subsidiarity and proportionality; evaluations, consultations and impact assessment including the policy-options appraisal; budgetary implications; other elements | drafted |
| memorandum/counter-arguments.md | The objections, at full strength, with answers and the constraints table | drafted |
| memorandum/severability.md | How the instrument decomposes if a layer fails | drafted |
| evidence/ | The sourced, reproducible basis for every quantitative claim | drafted |


# SOURCE: own-the-machine/regulation/annexes/annex-1-counting.md

# Annex I: Methodology for turnover, employment and value

## 1. Union turnover

Annual Union turnover comprises the amounts derived by the undertaking
during the financial year from the sale of products and the provision of
services to undertakings or consumers in the Union, after deduction of
sales rebates and of value added tax and other taxes directly related to
turnover. Turnover is attributed to the Union where the customer is
established or, in the case of consumers, resident in the Union.
Intra-group transactions are excluded. Where the undertaking
comprises linked enterprises, turnover is calculated on a
consolidated basis.

## 2. Turnover of the automated segment

The turnover attributable to the provision of the goods and services
referred to in point (a) of Article 3(1), used for the assessment of that
point and in any market investigation pursuant to Article 4, comprises the
worldwide turnover derived from that provision. Where such goods or services
are sold together with other goods or services for a single consideration,
the consideration is attributed between them on a consistent and documented
basis reflecting their relative stand-alone value.

## 3. Compensation of labour

The annual worldwide compensation of labour of an undertaking comprises
all compensation of employees within the meaning of the European system
of accounts, including social contributions payable by the employer and
share-based compensation measured at grant value, as recorded in accounts
audited in accordance with the law applicable to the undertaking,
calculated on a consolidated basis for the group of linked enterprises,
and averaged over the last two financial years.

Compensation paid under arrangements whose main purpose or effect is to
raise the undertaking's compensation of labour without a corresponding
supply of labour to the undertaking shall be disregarded. Article 3(8)
applies.

## 4. Fair market value

Fair market value is determined by reference to the most recent of
the following, adjusted for capital raised or returned since:
(a) the price per share paid in the most recent transaction in which
shares representing at least 2 % of the capital were issued or
transferred for consideration to persons independent of the undertaking,
applied to the fully diluted capital;
(b) an independent valuation prepared in accordance with internationally
accepted valuation standards within the preceding 12 months;
(c) where shares of the undertaking are admitted to trading, the average
market capitalisation over the preceding six months.

## 5. Information accompanying a notification

A notification pursuant to Article 3(3) contains:
(a) the identity of the undertaking and of all linked enterprises;
(b) the calculations referred to in points 1 to 4, with the data and
attribution bases used;
(c) the audited financial statements for the last two financial years;
(d) a description of the goods and services referred to in point (a) of
Article 3(1) which the undertaking provides, and of the automated
cognitive systems on which their provision depends;
(e) the law governing the undertaking and, where that law is the law of a
third country, the measures by which the undertaking intends to give
effect to Article 5.

---

Drafting notes (non-normative). Point 3 measures labour by audited
compensation of employees rather than by headcount, after the 22 August 2026
reviews: a headcount is unpublished and cheaply padded, where payroll is a
single audited line, and under a compensation denominator the contracting-
out of labour raises the ratio towards designation, so the only route down
is direct employment. The anti-avoidance rule for payroll and valuation
gaming lives in Article 3(8) after the form gate found an autonomous command
in an annex (JPG 22). Annex language is descriptive throughout for the same
reason; the obligations flow from the articles that reference it. Point 3 is
drafted so that Article 2(8) can cite it for compensation of labour. Point 2
no longer feeds a quantitative threshold; it serves the qualitative
assessment under Article 3(1)(a) and market investigations, and the
information duty in point 5(b) keeps the segment figures available to the
Commission for that purpose. Point 4 mirrors the practice of growth-equity
valuation without legislating a model. The 2 % floor in point 4(a) excludes
token transfers priced for other reasons.

# SOURCE: own-the-machine/regulation/annexes/annex-2-retention.md

# Annex II: Methodology for the retention preserving real capital

## 1. Retention

The amount to be retained pursuant to Article 8(4) in respect of a
financial year is the amount necessary so that the capital of the
Reserve at the end of that year, measured at fair value, is not lower in
real terms than its capital at the end of the preceding financial year,
after account is taken of:
(a) inflation, measured by the harmonised index of consumer prices for
the Union published by the Commission (Eurostat);
(b) unrealised changes in the fair value of the Reserve's holdings, to
the extent recognised under point 3.

## 2. Distributable amount

The distributable amount for a financial year is the realised
income of the Reserve for that year, comprising dividends, interest,
proceeds of disposals in excess of carrying value and other realised
returns, less the retention under point 1 and less the administrative
costs of the Reserve. Where the retention under point 1 equals or exceeds
realised income, the distributable amount is zero; the shortfall
is carried forward and retained from the realised income of
subsequent years before any distribution.

## 3. Smoothing

For the purposes of point 1, changes in fair value are recognised
evenly over five financial years from the year in which they arise. The
distributable amount for a financial year does not exceed the greater
of:
(a) 125 % of the average of the distributable amounts for the three
preceding financial years; and
(b) 2 % of the capital of the Reserve at the end of that year.

## 4. Cost of executing a payment

The average cost of executing one payment to a holder, for the purposes of
Article 10(6), is the total of the charges levied by national vehicles and
by payment service providers for executing the most recent distribution,
divided by the number of holders paid. Where no distribution has yet been
made, it is the average of the charges quoted to the Reserve by national
vehicles for executing one payment.

## 5. Exclusions

For the purposes of point 2, realised income excludes amounts obtained by
borrowing and the proceeds of disposals of holdings effected for the
purpose of funding a distribution.

---

Drafting note (non-normative). Point 4 was added on 21 August 2026 against
the objection that early distributions would be too small to be worth
transferring, and rewritten the same day. Two figures were rejected. A
floor of EUR 50, as proposed in review, would suppress every distribution
until roughly the fiftieth year on this instrument's own central
assumptions: that is a policy of deferral wearing the costume of an
efficiency measure. A floor of EUR 2 was drafted and then withdrawn
because hostile counsel wrote the headline it hands over, and because a
figure in an annex ages while the cost it stands for moves. What remains
is a ratio: ten times what it costs to make the payment. It is
self-adjusting, it states the actual reason, and there is no number in it
for anyone to quote.

---

Drafting notes (non-normative). This is the Norway spending rule made
operative: real capital is preserved first, only realised income above
preservation is distributed, and point 3's five-year smoothing plus the
125 % collar prevents both a bumper-year blowout and a political demand to
liquidate holdings for a headline payment; the outright prohibition on
funding distributions by borrowing or forced disposal moved to
Article 8(4) after the form gate found an autonomous command in an annex
(JPG 22), and point 4 keeps the arithmetic aligned with it. The
capital-fraction floor in point 3(b) was added on 19 August 2026 after
the public simulator, implementing this Annex exactly as drafted,
exposed a crumb-trap: a collar measured only against a trailing average
that starts near zero suppresses distributions for over a decade even
as capital accumulates. The floor lets distributions scale with the
Reserve while the collar still smooths spikes; realised income remains
the binding ceiling under point 2.
Point 2's carry-forward makes bad years honest instead of deferred. The
methodology enforces DC-14 at the level of arithmetic: early distributions
are small because early realised income is small, and no clause here can
be operated to promise otherwise.


# SOURCE: own-the-machine/regulation/articles/01-subject-matter.md

# Article 1: Subject matter and scope

1. This Regulation lays down harmonised rules ensuring the participation of
citizens of the Union in the capital value created by hyper-automated
undertakings operating in the internal market.

2. The participation referred to in paragraph 1 shall be of such scale
that, on the designations made under Article 3 and the methodology laid
down in Annex II, the aggregate value of the holdings attributable to each
citizen's entitlement is capable of reaching, within one generation of the
first designations and in constant prices, an amount of the order of six
months of the median equivalised disposable income in the Union as
published by the Commission (Eurostat). Distributions under Article 10
remain the property income of the holders and are governed solely by
Article 8 and Annex II. The Commission shall assess progress against this
objective in each report under Article 14(2), and where the assessment
shows the objective to be manifestly unattainable or manifestly exceeded,
the report shall be accompanied, where appropriate, by a proposal to amend
the percentage laid down in Article 5(2) or the thresholds laid down in
Article 3(2).

3. To that end, this Regulation establishes:
(a) criteria and a procedure for the designation of covered undertakings;
(b) an obligation on covered undertakings to issue citizens' capital
warrants to the European Citizens' Capital Reserve;
(c) the European Citizens' Capital Reserve and the rules governing its
holdings and conduct;
(d) an individual entitlement of citizens of the Union to distributions from
the Reserve, administered through national vehicles;
(e) rules protecting the Reserve and individual entitlements.

4. This Regulation applies to undertakings offering goods or services in the
internal market, irrespective of their place of establishment.

5. This Regulation is without prejudice to Directive (EU) 2016/2341 and to
Regulation (EU) 2019/1238, save as expressly provided in Article 11.

---

Drafting notes (non-normative). Paragraph 3 is the market-access nexus
(DC-10), the DMA and GDPR pattern. Paragraph 4 pre-answers the pension
acquis interface (research checklist item 19). One idea per sentence
throughout per JPG G1.


# SOURCE: own-the-machine/regulation/articles/02-definitions.md

# Article 2: Definitions

For the purposes of this Regulation, the following definitions apply:

(1) 'undertaking' means an entity engaged in an economic activity,
regardless of its legal status and the way in which it is financed,
including all linked enterprises within the meaning of Article 3(3) of the
Annex to Recommendation 2003/361/EC;

(2) 'covered undertaking' means an undertaking designated pursuant to
Article 3;

(3) 'automated cognitive services' means services whose provision depends to
a significant extent on software systems, including artificial intelligence
systems within the meaning of Article 3(1) of Regulation (EU) 2024/1689,
performing tasks that would otherwise require human cognitive labour;

(4) 'citizens' capital warrant' means a financial instrument issued
pursuant to Article 5 which confers the right to subscribe for shares in a
covered undertaking;

(5) 'Reserve' means the European Citizens' Capital Reserve established by
Article 8;

(6) 'liquidity event' means any of the following:
(a) the admission of shares of the covered undertaking to trading on a
regulated market or multilateral trading facility, in the Union or in a
third country;
(b) a change of control of the covered undertaking;
(c) one or more transactions within any period of 12 months by which shares
representing at least 20 % of the capital of the covered undertaking are
transferred for consideration;

(7) 'change of control' means the acquisition, directly or indirectly, of
decisive influence over the covered undertaking within the meaning of
Article 3(2) of Regulation (EC) No 139/2004;

(8) 'compensation of labour' means the annual worldwide compensation of
employees of an undertaking, calculated in accordance with point 3 of
Annex I;

(9) 'fair market value' means the value determined in accordance with
Annex I on the basis of the most recent funding transaction, independent
valuation or observable market price, whichever is most recent;

(10) 'holder' means a natural person in whom an entitlement is vested
pursuant to Article 10;

(11) 'national vehicle' means the body or arrangement designated by a
Member State pursuant to Article 11 to administer entitlements;

(12) 'distribution' means a payment made from the Reserve to holders
pursuant to Article 10;

(13) 'shareholder extraction' means, in respect of a covered undertaking
and a period, the aggregate value transferred by it to its shareholders, to
undertakings within the same group, to persons controlling it and to persons
connected with any of them, a person being connected where the same natural
persons hold, directly or indirectly, the majority of the economic rights in
both, comprising:
(a) dividends and other distributions, consideration paid for the
repurchase or redemption of its own shares, and reductions of capital paid
out;
(b) repayments of principal on debt owed to any such person, and loans made
to and claims acquired on any such person to the extent not repaid or
realised within twelve months;
(c) interest on such debt, and payments for the use of intellectual
property, for management and for other services rendered by any such
person, in each case to the extent that the payment exceeds what would
have been agreed between independent undertakings;

(14) 'automated assets' means the software systems referred to in point (3),
the model parameters, training and inference infrastructure, data sets and
intellectual property rights on which the provision of the goods or services
referred to in Article 3(1)(a) principally depends.

---

Drafting notes (non-normative). Definitions carry no obligations (JPG G14).
Point (3) ties to the AI Act definition rather than inventing one
(acquis-coherence). Point (6)(c)'s 20 % secondary-sale trigger prevents
crystallisation avoidance by staged private sales. Point (8) implements
DC-11 substance-over-form headcount. Points (13) and (14) serve Article 5's second and third crystallisation
triggers and the succession rule: an undertaking that never sells itself
can still pay itself, and the assets that carry the value are nameable.
Point (13)(b) exists because hostile counsel, given the first draft,
answered that it would simply stop paying dividends and take the cash out
as royalties, management fees and intercompany interest instead. The test is therefore value transferred above arm's length, whatever the
payment is called; the arm's-length standard is the one transfer pricing
already uses, so the evidence is the evidence a tax authority would ask
for. Point (b) stands apart from that standard because counsel's second
answer was to lend the money in and take it out again as principal, which
is arm's length in every particular and drains the undertaking all the
same. Repayment to an insider is therefore extraction outright. Counsel's next
answer was to reverse the direction, lending the undertaking's own cash
upstream to the parent and never calling it back, so point (b) covers
lending out as well as paying back: cash that leaves for a related pocket
and stays there for a year is cash that left, whichever way the promissory
note points. This is the numerator for Article 5(3)(a): shareholder
extraction, as defined here, is measured against covered turnover alone.
A paid-in-capital limb was deleted from Article 5(3)(a) after outside
money proved able to inflate it (see the drafting notes to Article 5),
so what money is put in by outsiders no longer matters to the threshold;
only what insiders take out does. 'Fair market value' is needed for
Article 3 designation, not for warrant pricing, which is event-priced.


# SOURCE: own-the-machine/regulation/articles/03-designation.md

# Article 3: Designation of covered undertakings

1. An undertaking shall be designated as a covered undertaking where:
(a) it provides automated cognitive services, or goods or services whose
production depends to a significant extent on automated cognitive systems,
in the internal market;
(b) the economic output of the undertaking is substantially decoupled from
its employment of labour; and
(c) the position referred to in points (a) and (b) is durable.

2. An undertaking shall be presumed to satisfy: (a) point (a) of paragraph
   1, where it achieves an annual Union turnover equal to or above EUR 7,5
   billion, or where its fair market value amounts to at least EUR 75
   billion, and it provides the goods or services referred to in that point
   in at least three Member States; (b) point (b) of paragraph 1, where its
   fair market value equals or exceeds eighty times its annual worldwide
   compensation of labour, each calculated in accordance with Annex I; (c)
   point (c) of paragraph 1, where the thresholds in points (a) and (b) of
   this paragraph were met in each of the last two financial years.

3. Where an undertaking meets all the thresholds laid down in paragraph 2,
it shall notify the Commission thereof within two months after those
thresholds are met, providing the information listed in Annex I. A failure
to notify shall not prevent designation on the basis of the facts
available to the Commission.

4. The Commission shall, without undue delay and at the latest 45 working
days after receiving the complete information referred to in paragraph 3,
designate by decision the undertaking as a covered undertaking.

5. The undertaking may, with its notification, present sufficiently
substantiated arguments demonstrating that, exceptionally, although it
meets all the thresholds in paragraph 2, it does not satisfy the
requirements of paragraph 1. Those arguments shall be taken into account
only where they manifestly call the presumption into question; arguments
based on the definition of the relevant market shall not be taken into
account. Where such arguments require detailed assessment, the Commission
may open a market investigation pursuant to Article 4(1) instead of
designating within the period laid down in paragraph 4.

6. The Commission may designate as a covered undertaking any undertaking
that satisfies the requirements of paragraph 1 without meeting the
thresholds of paragraph 2, following a market investigation conducted
pursuant to Article 4.

7. The obligations laid down in this Regulation shall apply to a covered
undertaking irrespective of whether its shares are admitted to trading, and
designation shall precede any liquidity event wherever the thresholds of
paragraph 2 are met before that event.

8. An undertaking shall not segment, divide, combine or restructure its
   activities, or acquire or dispose of undertakings, where the main purpose
   or one of the main effects thereof is to avoid meeting the thresholds
   laid down in paragraph 2. The Commission shall disregard any such
   arrangement when applying this Regulation, and shall likewise disregard
   any transaction, arrangement or attribution the main purpose or one of
   the main effects of which is to increase the compensation of labour, or
   to reduce the fair market value, referred to in point (b) of paragraph 2.

9. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex I where necessary to
reflect technological and market developments. Those delegated acts shall
not amend the thresholds laid down in paragraph 2.

---

Drafting notes (non-normative). Architecture is DMA Article 3, deliberately:
cumulative qualitative limbs (paragraph 1), mapped quantitative presumption
(paragraph 2), self-notification with facts-available fallback (3),
deadline-bound designation (4), cabined rebuttal excluding market-definition
economics (5), below-threshold route (6). Paragraph 7 is the in-time test as
an operative rule. Paragraph 8 keeps thresholds in the article per DC-30 and
C-355/10: only the counting methodology is delegable. EUR 7,5 and 75 billion
mirror magnitudes the Union legislature has already accepted as marking
gateway scale. Numbers use the EU decimal comma. Satisfies DC-2, DC-10,
DC-11, DC-30.

Paragraph 2(b) history, which matters. The first design used turnover per
full-time equivalent on the automated segment; research of 22 August 2026
(evidence/designation-count.md) showed it designated two undertakings,
missed every integrated incumbent by factors of two to fourteen, turned on
an unpublished self-computed headcount, and inverted the anti-avoidance
incentive. The replacement, fair market value against audited compensation
of labour at a fixed ratio of eighty, computes from two audited figures and
makes direct employment the only route down. It is group-consolidated,
which reopens on paper the acquisition-dilution escape (buy payroll to
dilute the ratio) that the original segment basis was chosen to close.
The route is closed differently now, by three provisions in conjunction:
paragraph 8's disregard power is effects-based ("one of the main
effects"), so it reaches an acquisition whose commercial logic is genuine
but whose main effect is staying under the ratio, which purpose-based
abuse doctrine (Halifax, Cadbury Schweppes) would not; Article 4(3)
repeals a designation only for failure of the QUALITATIVE criteria of
paragraph 1 over two years, never for the presumption ratio alone, and
refuses repeal where the failure results from a paragraph 8 arrangement;
and paragraph 6 designates on the facts below the presumption. Open
points for the editor: the two-year durability window (DMA uses three);
whether fair market value alone suffices for point (a) given pre-revenue
frontier undertakings; and whether a segment limb should return as a
second presumption if pre-designation dilution is observed in practice.


# SOURCE: own-the-machine/regulation/articles/04-review-of-designation.md

# Article 4: Market investigation and review of designation

1. The Commission may conduct a market investigation for the purpose of
Article 3(6). It shall conclude the investigation within 12 months by a
decision designating the undertaking or closing the investigation.

2. The Commission shall review each designation at least every three years,
and whenever the covered undertaking so requests on the basis of a
substantial change in the facts on which the designation was based.

3. The Commission shall repeal a designation where the covered undertaking
has not satisfied the requirements of Article 3(1) for two consecutive
financial years. Repeal shall not be granted where the failure to satisfy
those requirements results from an arrangement referred to in Article 3(8). Repeal shall not affect a citizens' capital warrant
already issued, save that a warrant shall lapse five years after repeal if
it has not crystallised by that date.

4. Before adopting a decision under this Article or under Article 3, the
Commission shall communicate its preliminary findings to the undertaking
concerned and give it the opportunity to be heard within a period of not
less than 20 working days.

---

Drafting notes (non-normative). Paragraph 2 mirrors DMA Article 4. Paragraph
3's lapse rule prevents a repealed designation from carrying a perpetual
contingent claim, which proportionality review would punish; five years
balances avoidance (de-designate, then list) against indefiniteness. The
right to be heard in paragraph 4 answers a due-process line of attack before
it is made. Hostile counsel round 2 built a permanent-immunity chain through this
Article (designate, dilute the ratio by acquisition, obtain repeal, wait out
the lapse, spin off and list). Three links are now cut: the acquisition is
an Article 3(8) arrangement and is disregarded across the Regulation, repeal
is unavailable where the change results from such an arrangement, and
Article 5(1) limits the one-warrant rule to the same designation, so
re-designation after a genuine repeal carries a fresh warrant.


# SOURCE: own-the-machine/regulation/articles/05-warrant.md

# Article 5: The citizens' capital warrant

1. Within three months of its designation, a covered undertaking shall issue
to the Reserve a citizens' capital warrant. It shall not be required to
issue more than one such warrant in respect of the same designation.

2. The citizens' capital warrant shall entitle the Reserve, upon the first
liquidity event following issuance or upon crystallisation under paragraph
3, whichever occurs first, and upon no other occasion, to subscribe at
nominal value for newly issued shares representing 3 % of the fully diluted
capital of the covered undertaking determined immediately before that event
or, in the case of paragraph 3, immediately before the date of
crystallisation.

3. The citizens' capital warrant shall also crystallise, and shall be
exercisable on the same terms, where either of the following occurs before
a liquidity event:
(a) shareholder extraction by the covered undertaking in any period of
three consecutive financial years exceeds 25 % of its turnover from the
goods and services referred to in Article 3(1)(a) over the same period;
(b) seven years have elapsed since the issuance of the warrant.

Crystallisation under this paragraph shall take effect on the last day of
the financial year in which the condition is met, and the valuation under
Article 6 shall be performed as at that date.

4. The citizens' capital warrant shall:
(a) confer no voting rights, no rights of information beyond those provided
in this Regulation and no right to participate in the management of the
covered undertaking;
(b) entitle the Reserve to shares which rank, as regards dividends, other
distributions and the proceeds of any sale, liquidation or winding up,
equally with the class of shares ranking most favourably in those respects
among the classes created after the designation of the covered
undertaking, and otherwise equally with its ordinary shares, without
affecting the ranking of claims of creditors;
(c) be incapable of settlement in cash or in assets other than the shares
referred to in paragraph 2;
(d) be non-transferable, save to a successor of the Reserve established by
Union legislative act;
(e) impose no obligation on the covered undertaking prior to a liquidity
event other than the notification obligation in paragraph 6.

Shares subscribed pursuant to the citizens' capital warrant shall be
non-voting for as long as they are held by the Reserve.

5. The right to the subscription referred to in paragraph 2 shall vest by
operation of law at the completion of the liquidity event or on the date of
crystallisation under paragraph 3. The number of shares to be subscribed
shall be determined by the valuation under Article 6, and the subscription
shall be executed accordingly. Where the law
governing the covered undertaking does not give effect to the first
sentence, the covered undertaking shall take all measures necessary to
procure a subscription of equivalent effect no later than the completion of
the liquidity event or, in the case of crystallisation under paragraph 3,
no later than three months after the date of crystallisation. The dilution resulting from the subscription shall not
exceed the percentage laid down in paragraph 2. The covered undertaking shall execute the
subscription within 20 working days of the delivery of the valuation
referred to in Article 6, and the Reserve shall pay up the shares in full
in cash at their nominal value upon execution.

6. A covered undertaking shall notify the Reserve and the Commission of any
impending liquidity event no later than the earlier of its public
announcement and 30 working days before its completion.

7. Article 49, Article 68(1), (2) and (3), the first subparagraph of
Article 70(2), Article 72 and Article 73 of Directive (EU) 2017/1132, and
any
corresponding provisions of the law of a Member State conferring
pre-emption rights, requiring a decision of the general meeting or
requiring an expert report on consideration, shall not apply to the
issuance of the citizens' capital warrant or to the subscription of
shares pursuant to it. Provisions of the law of a Member State restricting the
proportion, issuance conditions or characteristics of non-voting shares
shall not apply to the extent that they would prevent the issuance or
holding of shares pursuant to this Article.

8. The issuance of the citizens' capital warrant and the issuance, offer
and subscription of shares pursuant to this Article shall not constitute an
offer of securities to the public for the purposes
of Regulation (EU) 2017/1129, and the admission to trading of those shares
shall be exempt from the obligation to publish a prospectus under that
Regulation where shares of the same class are already admitted to trading
on the same regulated market.

9. The valuation of the fully diluted capital for the purposes of paragraphs
2 and 3 shall be performed by an independent valuer appointed in accordance
with Article 6, and shall be open to challenge before the courts in
accordance with Article 7 separately from any other element of the
designation or the event.

10. An arrangement that subordinates, reduces or defeats the economic
participation conferred by this Article shall not be effective as against
the Reserve, which shall be placed in the position it would have occupied
had the arrangement not been made; the arrangement shall remain effective
between the parties to it and as against third parties. In particular, the
issuance of shares ranking ahead of those held or subscribable by the
Reserve, any alteration of the rights attaching to any class of shares, and
any reorganisation of capital shall be of no effect as against the Reserve
to the extent that its main purpose or one of its main effects is to place
the Reserve in a position less favourable than that provided for in
paragraph 4(b).

The first subparagraph shall not apply to an issuance of shares or other
instruments for new consideration in money or money's worth, at arm's
length, to persons who are not members of the same group as the covered
undertaking, do not control it, are not connected with it and are not acting
in concert with any person who controls it, where at the time of the
issuance the covered undertaking is in a likelihood of insolvency within the
meaning of Directive (EU) 2019/1023 or the issuance is necessary to comply
with a prudential requirement under Union law, and only to the extent of the
new consideration provided. To the extent that the preference, ranking or
other advantage conferred by the issuance exceeds the new consideration
provided, the first subparagraph applies to the excess. The covered
undertaking shall bear the burden of establishing that the conditions of
this subparagraph are met.

11. Where a covered undertaking transfers automated assets to another
undertaking, whether by sale, contribution, licence, demerger, division or
otherwise, where the transfer, alone or together with related arrangements,
confers in substance the economic benefit of the automated assets on the
transferee, and the transfer is not made at arm's length or the transferee is
a member of the same group or is controlled, directly or indirectly, by
persons who control the covered undertaking, the transferee shall issue to
the Reserve a citizens' capital warrant in accordance with paragraph 1 as if
it were a covered undertaking, and the obligations of the covered undertaking
under this Article shall continue in respect of the automated assets it
retains. The aggregate of the subscriptions to which the Reserve is entitled
in respect of the same designation, under this paragraph and under paragraph
2, shall not exceed the percentage laid down in paragraph 2 of the combined
fully diluted capital of the covered undertaking and of every transferee, and
the valuation under Article 6 shall determine the subscription in each of
them accordingly.

The obligations of a transferee under this paragraph arise irrespective of
whether the transferee meets the conditions laid down in Article 3, and this
paragraph applies to any onward transfer of the automated assets by a
transferee as it applies to a transfer by a covered undertaking. For the
purposes of the valuation under Article 6, the value of the fully diluted
capital of the transferee shall reflect the automated assets at the value
they would have had on a transfer at arm's length.

12. Where the automated assets of a covered undertaking are acquired by
another undertaking in or in consequence of insolvency proceedings, a
restructuring procedure, including a procedure under Directive (EU)
2019/1023, or any comparable procedure, and, upon completion, the
transferee is controlled directly or indirectly by persons who controlled
the covered undertaking, or those persons hold, directly or indirectly, the
majority of the economic rights in the transferee, the obligations under
this Article shall attach to
the transferee as if it were the covered undertaking, and the transferee
shall issue a citizens' capital warrant afresh within three months of the
completion of the acquisition.

For the purposes of this paragraph, persons acting in concert with those
who controlled the covered undertaking, and persons connected with them,
shall be treated as those persons; and where any of them acquires control
of the transferee, at any time while it holds the automated assets, the
obligations under this Article shall attach to the transferee from the date
of that acquisition.

This paragraph shall not otherwise apply where control of the transferee
is acquired by persons who did not control the covered undertaking, and in
that case the extinguishment of a warrant in such a procedure shall give
rise to no obligation under this Article.

---

Drafting notes (non-normative). The paragraph 7 enumeration was verified
against the consolidated Directive (CELEX 02017L1132-20220812, capital
chapter unamended since) on 19 August 2026 and mirrors Article 84(3) of
the Directive itself, the BRRD-inserted list of exactly the provisions
that block a by-operation-of-law issuance: Article 72(4) makes a general
meeting the only lawful route to disapply pre-emption, which is why the
whole of Article 72 is disapplied; the expert-report rule for increases
is the first subparagraph of Article 70(2), not Article 49 alone.
Articles 45, 46, 47, 69 and 71 need no derogation: subscription at
nominal is not below nominal, and paragraph 5 now provides full cash
payment on execution, satisfying Article 69 expressly. Article 85 equal
treatment is complied with, not derogated from: the dilution falls on
all shareholders pro rata. The capital chapter binds only the public
company forms in Annex I of the Directive (Article 44(1)); for private
forms the Member-State-law limb of paragraph 7 does the same work. The chapter is the assets-not-flows test as
law. Paragraph 4(c) is DC-4 and DC-9 verbatim: the obligation can never
collapse into a fee, which also carries the incidence answer (objection 4).
Dormancy until the event is DC-12; permanent non-voting is DC-13; operation
of law is DC-24. Paragraph 7 uses the BRRD recitals 120-124 formula of
express, narrow company-law derogation; silence there would be read as
amateurism (research checklist 18). Paragraph 8 writes the prospectus
exemption (checklist 19). Paragraph 9 carries DC-29's execution safeguard:
the interference is the stated 3 %, justified in the recitals under Article
52(1) of the Charter on the BRRD model; the safeguard guarantees the
percentage cannot be exceeded in execution and that valuation is independent
and separately justiciable (Aeris Invest pattern). 3 % is deliberately far
below employee-option pools and bail-in scales; proportionality lives partly
in that number. Paragraph 5's third sentence answers hostile counsel's
extraterritoriality attack: for undertakings governed by third-country law
the mechanism is an obligation of result enforced through Article 13
penalties as a condition of market access, the DMA pattern, rather than a
purported override of foreign company law; paragraph 7 accordingly reaches
Member State law only. The necessity limit formerly stated in paragraph 7
moves to the recital motivating it, per JPG G12. Paragraphs 3, 4(b) and 10 to 12 were added on 21 August 2026 against an
external structuring review, and rewritten the same day against hostile
counsel's answer to them. The extraction trigger no longer measures against
fair market value, because counsel undertook to place a fraction of a share
with a friendly fund at an invented valuation a week before the period
opened and so set the denominator out of reach; it now measures against
covered turnover and against capital actually paid in, neither of which can
be inflated without paying for it. Paragraph 4(b) equalises the Reserve
with the most favourable class of shares rather than raising it above every
class, and says expressly that it does not touch creditors, because a rule
that leapfrogged the creditor hierarchy would have been struck down and
would have deserved to be. Paragraph 10 renders a subordinating arrangement
ineffective against the Reserve alone rather than void against the world,
which is how anti-avoidance is done without unwinding third parties who had
nothing to do with it. Two further answers followed the same exchange.
Point 4(b) equalises the Reserve only with classes created after
designation, because a rule that placed it alongside a two-times
participating preference bought and paid for years earlier would take from
those investors the thing they paid for, which is the expropriation this
instrument spends objection 1 denying; against classes engineered after
designation it still bites, and that is where the abuse lives. The paid-in capital limb was deleted altogether at the next pass. It had
been narrowed to exclude money contributed by the group itself, and counsel
answered by having a friendly outside syndicate subscribe ten billion of
low-yield preferred, raising the threshold to ten billion and licensing the
founders to take out nine. A threshold with two limbs joined by "or" is
governed by whichever limb is easier to inflate, so what remains is the one
that cannot be: turnover from the covered activity, which no undertaking
raises without earning it. The seven-year long-stop stands behind it in any
event. For the same reason the reattachment in paragraph 12 lost its
three-year window, which counsel correctly read as a date to wait for. Counsel then took 49 % of
the votes and 90 % of the economics, which is not control, so both this
paragraph and the definition of extraction now follow the majority of the
economic rights as well as control: a person who takes the money is a person the rule is about, whoever holds
the votes. Paragraph 11 stopped attaching the obligation "in proportion to
the value transferred", which counsel rightly called inoperable against an
indivisible equity: the transferee now issues its own warrant over its own
capital and the transferor keeps its own, which needs no arithmetic and is
proportionate because three per cent of a small company is a small
thing; paragraph 11's second subparagraph was added
immediately afterwards, because hostile counsel demonstrated that the first
draft reattached the obligation to entities controlled by any pre-procedure
creditor and so expropriated the rescuers of a genuinely failing
undertaking. The rule now catches the survival of the same controllers,
which is the abuse, and leaves ordinary insolvency alone, which is not.

Three amendments of 25 August 2026, each closing a point the memorandum had
listed as open, each through three adversarial rounds. Paragraph 10's second
subparagraph answers the distressed-capital constraint objection 18 carried:
new money at arm's length from unconnected persons in likelihood of
insolvency ranks ahead, only to the extent of the new consideration, and the
excess of any preference over that consideration falls back under the first
subparagraph, so a ten-times preference on rescue money shields one times
the money and no more. Counsel's claim that a ranking is binary and cannot
have an excess is wrong on the instrument's own terms: preferences are
stated in multiples of an amount, and the carve-out never voids the excess
between the parties, it only keeps it off the Reserve's three per cent.
Paragraph 11 gained a substance gate after counsel showed an ordinary
internal software licence conscripting a subsidiary: the trigger now
requires that the transfer confer in substance the economic benefit of the
automated assets. The sub-threshold question is answered in the second
subparagraph: thresholds do not matter for a transferee, because the
trigger is the tainted transfer and not scale; the paragraph follows onward
transfers; and the valuation of the transferee's capital reflects the
assets at arm's-length value, so a shell cannot be cheap. Two blueprints
counsel priced highly fail on their own facts and are recorded here so the
next reader need not re-litigate them: the arm's-length split to an
unconnected vehicle leaves the full consideration inside the covered
undertaking, where the existing warrant sits on it, and the transferee's
future growth is new value formed outside, reachable by its own designation;
and the apportionment under the aggregate cap follows the Article 6
valuations of each entity, which is arithmetic on values, not an accounting
consolidation. Open points for the editor:
whether 3 % is the right rate (the simulator parameter), treatment of
undertakings already listed at designation (transitional provision in
Chapter VIII), anti-avoidance for pre-event asset-stripping (Article 6), and
the Article 13 penalty scale that makes the obligation of result credible
for third-country groups.


# SOURCE: own-the-machine/regulation/articles/06-valuation.md

# Article 6: Independent valuation

1. The valuation referred to in Article 5(9) shall be performed by a valuer
who is independent of the covered undertaking, of the Reserve and of any
party to the liquidity event, appointed by the Commission from a list
established after an open call. The Commission shall establish the list and
the criteria and rotation governing appointments from it by means of
implementing acts, adopted in accordance with the examination procedure
referred to in Article 16(2). An individual appointment shall be made by
decision of the Commission in accordance with those criteria and that
rotation, and shall not require that procedure.

2. The valuation shall determine the fully diluted capital of the covered
undertaking immediately before the liquidity event or, in the case of
crystallisation under Article 5(3), immediately before the date of
crystallisation, in accordance with internationally accepted valuation
standards and, where an event itself establishes a price, on the basis of
that price.

3. The valuer shall deliver the valuation within 20 working days of the
completion of the liquidity event or of the date of crystallisation under
Article 5(3). The costs of the valuation shall be borne by the
covered undertaking.

4. Where a court finds, pursuant to Article 7, that the valuation
overstated the fully diluted capital, the Reserve shall transfer back to
the covered undertaking, or cancel, the shares subscribed in excess of the
percentage laid down in Article 5(2). Where a court finds that the
valuation understated it, the covered undertaking shall issue the missing
shares to the Reserve.

5. A challenge to the valuation shall not suspend the liquidity event, the
crystallisation or the subscription.

---

Drafting notes (non-normative). The BRRD pattern (Article 36) adapted:
independent valuer, event-price primacy, ex-post correction rather than
ex-ante blockage. Paragraph 4 makes DC-29 executable in both directions,
which is what converts the safeguard from assertion into machinery, per
Aeris Invest. Paragraph 5 protects transactions from hold-up litigation, the same policy
as resolution law. Round 2 moved delivery to after completion: where the
event itself establishes the price, the valuation is arithmetic on that
price, and demanding it before pricing invited deserved ridicule; legal
effect still attaches at completion under Article 5(5), with execution
following the valuation. The open point on the appointment mechanism was closed on 21 August 2026:
hostile counsel observed that an implementing act under Article 291 TFEU is
an act of general application, that using one for each individual
appointment is the wrong instrument, and that convening a committee for
each would break the 20-day deadline in Article 5(5). The list, the
criteria and the rotation are general and stay in the implementing act; the
appointment itself is administration and is made by decision.


# SOURCE: own-the-machine/regulation/articles/07-safeguards.md

# Article 7: Safeguards and judicial review

1. A challenge to the valuation referred to in Article 6 may be brought,
separately from any challenge to the designation, to the liquidity event or
to the crystallisation under Article 5(3),
before the courts of the Member State in which the covered undertaking has
its registered office or, where it has none in the Union, before the Court
of Justice of the European Union.

2. The dilution borne by the shareholders of a covered undertaking in
consequence of this Regulation shall not exceed the percentage laid down in
Article 5(2), determined on the basis of the valuation under Article 6 as
corrected, where applicable, pursuant to Article 6(4). Where warrants have
been issued by transferees pursuant to Article 5(11), that percentage
applies to the dilution borne, taken together, by the shareholders of the
covered undertaking and of every such transferee.

3. This Regulation shall not affect any right of shareholders to
compensation under the law of a Member State against parties other than
the Reserve.

---

Drafting notes (non-normative). The former paragraph restating the Article
263 TFEU remedy was deleted on the form gate's finding that secondary law
must not paraphrase remedies conferred by primary law; standing before the
Court needs no help from us. Paragraph 2 states the quantified ceiling the
proportionality recital relies on: the interference is the stated
percentage, no more, judicially verifiable and correctable in both
directions under Article 6(4). Satisfies DC-29 with Article 6; holders'
remedies sit in Article 12(4).


# SOURCE: own-the-machine/regulation/articles/08-reserve.md

# Article 8: The European Citizens' Capital Reserve

1. The European Citizens' Capital Reserve is established. The Reserve shall
have legal personality and shall enjoy in each Member State the most
extensive legal capacity accorded to legal persons under the law of that
Member State.

2. The Reserve shall hold its assets exclusively for the benefit of
holders. Its assets and income shall not constitute revenue of the Union or
of any Member State and shall not be entered in the general budget of the
Union or in any public budget.

3. The Reserve shall be financed exclusively by the instruments referred to
in Article 5, by the proceeds of their crystallisation and by the returns
on its assets. It shall receive no contribution from, and shall make no
payment to, the general budget of the Union or the budget of any Member
State.

4. The Reserve shall retain from its realised income in each financial year
the amount necessary to preserve the real value of its capital, calculated
in accordance with the methodology laid down in Annex II, and shall make
the remainder available for distribution pursuant to Article 10(6). No
distribution shall be financed by borrowing or by the disposal of holdings
effected for the purpose of the distribution.

5. The Reserve shall state in its accounts, for each financial year, the
amount of tax withheld at source which it was unable to recover, and the
Commission shall address that amount in the report referred to in Article
14(2).

6. The Reserve shall publish annually audited accounts, the valuation of
its holdings and the calculation referred to in paragraph 4.

7. The Reserve shall not be considered an investment firm within the
meaning of Directive 2014/65/EU, an alternative investment fund or an
alternative investment fund manager within the meaning of Directive
2011/61/EU, or an institution for occupational retirement provision within
the meaning of Directive (EU) 2016/2341.

8. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex II where necessary
to preserve the real value of the capital of the Reserve in the light of
market developments.

---

Drafting notes (non-normative). Drafted in response to hostile counsel's
lead attack, the fiscal characterisation of the warrant as a corporate tax.
Paragraphs 2 and 3 make the non-fiscal structure operative rather than
asserted: no value ever becomes public revenue, enters any budget or is
available to any treasury, in either direction. The closest legal cousins
are statutory funded pension schemes, whose compulsory contributions are not
taxes in Union law because they fund segregated property held for
beneficiaries. Sectoral classification under ESA belongs to statisticians
and is deliberately not legislated here. Paragraph 4 is the Norway spending
rule generalised (retain enough to preserve real capital, distribute the
rest), which also enforces DC-14: distributions grow with the portfolio and
start small. Governance, passivity at Reserve level and prohibited conduct
are Article 9, still reserved; the non-voting rule already binds via
Article 5(4). The retention methodology is Annex II, amendable
under the paragraph 8 empowerment via Article 15. Satisfies DC-4, DC-5, DC-14, DC-19 in part, DC-24.


Drafting note on paragraph 5 (non-normative). A first draft permitted the
Reserve to hold third-country assets through national vehicles where that
reduced taxation at source. It was struck on 21 August 2026 after hostile
counsel offered the headline: a Union fund with a statutory mandate to
arrange its affairs for a lower withholding rate, published by the Union
that blacklists other people for the same thing. An instrument whose case
is that capital should be broadly owned cannot codify treaty shopping for
itself. What remains is the duty to publish the tax it could not recover,
which is the part that lets anyone judge the cost.


# SOURCE: own-the-machine/regulation/articles/09-prohibited-conduct.md

# Article 9: Prohibited holdings and conduct of the Reserve

1. The Reserve shall not:
(a) exercise, directly or indirectly, any voting right attached to any
share it holds;
(b) seek or accept representation in the administrative, management or
supervisory bodies of any undertaking;
(c) give instructions, formally or informally, to any undertaking in which
it holds an interest;
(d) acquire an interest in any undertaking otherwise than pursuant to
Article 5, by reinvestment of its income or by prudent diversification of
crystallised holdings;
(e) borrow, save for temporary liquidity purposes not exceeding 2 % of the
value of its assets and save for the payment of subscription amounts under
Article 5(5), which borrowing shall be repaid from the first realised
income of the Reserve;
(f) grant loans or guarantees;
(g) enter into derivative contracts, save for hedging currency risk on
assets it holds.

2. The Reserve shall manage its holdings with the sole objective of
long-term preservation and growth of value for the benefit of holders.

---

Drafting notes (non-normative). The statutory passivity of DC-13 at the
level of the institution, accepting the Bebchuk cost deliberately per
objection 6; the Greek overcorrection is avoided because passivity here
constrains conduct, not the citizens' claim. Points (e) to (g) close the
leverage and derivative channels that would let a future management
financialise the Reserve. Point (d) permits index-style diversification
after crystallisation, the Norwegian practice, without permitting empire
building.


# SOURCE: own-the-machine/regulation/articles/10-entitlement.md

# Article 10: The citizens' entitlement

1. Every citizen of the Union who has attained the age of 18 years shall hold an
entitlement under this Regulation.

2. The entitlement shall arise by operation of law. It shall not be subject to
any condition relating to income, wealth, employment, contribution history
or any other personal circumstance, nor to any application, save
registration for payment purposes with a national vehicle.

3. All entitlements shall be equal. No act of the Union or of a Member State
shall differentiate between holders in the amount distributed per holder in
respect of the same period.

4. The entitlement shall comprise:
(a) the right to an equal share of every distribution declared by the
Reserve in respect of a period during which the holder was living and met
the condition in paragraph 1; and
(b) the right to have undistributed amounts standing to the holder's
account with a national vehicle treated as the holder's property, which
shall be inheritable in accordance with the law applicable to succession.

5. The entitlement referred to in paragraph 4(a) shall be personal to the holder.
It shall be incapable of assignment, pledge, attachment or seizure, and it
shall not be capable of surrender or redemption against payment.

6. The Reserve shall declare a distribution in each calendar year in which
the distributable amount would provide each holder with not less than ten
times the average cost of executing one payment to a holder, calculated in
accordance with Annex II, and in any event not less often than once in
every third calendar year in which the distributable amount is greater
than zero. An amount not distributed by reason of this paragraph
shall be retained, shall form part of the capital of the Reserve and shall
be distributed in the next distribution. Distributions shall be paid
through national vehicles into the individual account of each holder.

7. In each year in which no distribution is declared, the Reserve shall
publish the amount which would have been distributed per holder and the
value of the capital of the Reserve per holder.

---

Drafting notes (non-normative). Paragraphs 1 to 3 are the universality test
with no means test and no committee: acquisition by operation of law closes
every discretionary gate (DC-24). Paragraph 5 answers Estonia: there is no
exit to take, which is stronger than forfeiture, while paragraph 4(b)
preserves the Danish lesson that what has been distributed into a named
account is real, inheritable property (DC-22 as interpreted: the lifetime
unit is per-person and equal across a generation, so it is not heritable;
accrued amounts are). Paragraph 6 keeps DC-14 while answering the objection that paying a few
cents to 350 million accounts spends a disproportionate share of the
payment on making it: the interval lengthens, the money does not
disappear, and it compounds in the Reserve until it is paid. The
three-year backstop is what stops a de minimis from becoming a reason
never to pay; paragraph 7 is DC-31 applied to the years of silence, so
that a citizen who receives nothing is still told what is held for
them.
Open points for the editor, flagged deliberately: whether long-term
resident third-country nationals are included (political choice; Union
citizens only is the current draft), the age threshold, and whether a
minimum retention rule belongs here or in Article 8 (currently Article 8,
reserved).


# SOURCE: own-the-machine/regulation/articles/11-national-vehicles.md

# Article 11: National vehicles

1. Each Member State shall designate, within 12 months of the entry into
force of this Regulation, one or more national vehicles to administer
entitlements. Existing institutions within the meaning of Directive (EU)
2016/2341, providers within the meaning of Regulation (EU) 2019/1238 and
statutory funds may be designated. By way of derogation from Article 7 of
Directive (EU) 2016/2341, an institution designated as a national vehicle
may carry out the account administration and distribution activities
provided for in this Regulation. A provider within the meaning of
Regulation (EU) 2019/1238 designated as a national vehicle shall maintain
holders' accounts separately from any product governed by that Regulation,
and the requirements of that Regulation shall not apply to those accounts.

2. A national vehicle shall:
(a) maintain an individual account in the name of each holder registered
with it;
(b) credit distributions to holders' accounts without deduction other than
charges permitted under paragraph 3;
(c) treat amounts standing to a holder's account as the holder's property
in accordance with Article 10(4)(b);
(d) apply no condition of access other than identity and the condition in
Article 10(1).

3. Charges levied by a national vehicle on holders shall not exceed the
costs actually incurred in administering the accounts and in any event
0,3 % annually of the amounts administered. A Member State may compensate a
national vehicle for verifiable net costs exceeding that ceiling; such
compensation shall not be charged to holders or to the Reserve.

4. Where a Member State has not designated a national vehicle, or where the
designated vehicle does not comply with paragraph 2, a holder residing in
that Member State may register with a national vehicle of another Member
State, which shall not refuse the registration on grounds of residence.
Where a national vehicle registers a holder pursuant to this paragraph, the
Member State of residence of that holder shall reimburse that national
vehicle for verifiable net costs exceeding the ceiling laid down in
paragraph 3.

5. National vehicles shall process personal data in accordance with
Regulation (EU) 2016/679 and only for the purposes of this Regulation.

---

Drafting notes (non-normative). DC-7 and DC-28 as law: Union standards,
national custody, existing rails expressly reusable. Paragraph 3 caps
administration charges because fee extraction is the quiet raid nobody
legislates against; 0,3 % tracks low-cost pension administration.
Paragraph 4 is the sabotage-by-inaction answer: a Member State that refuses
to build the rail cannot thereby disenfranchise its citizens, and
portability follows the PEPP logic. Paragraph 5 grounds the EDPS recital
required by the research checklist.


# SOURCE: own-the-machine/regulation/articles/12-protection.md

# Article 12: Protection of the Reserve and of entitlements

1. The assets of the Reserve and the entitlements of holders shall not be
cancelled, written down, compulsorily redeemed, seized, transferred,
suspended, lent, encumbered or otherwise applied, in whole or in part, for
the benefit of the general budget of the Union, of any Member State or of
any public body, by any act of the Union or of a Member State.

2. The Reserve shall not acquire or hold, directly or indirectly, debt
instruments issued or guaranteed by the Union, by a Member State, by a
regional or local authority of a Member State, by a central bank or by any
body the obligations of which are guaranteed by any of them.

3. This Regulation shall not be interpreted as authorising any authority
of the Union or of a Member State to derogate from paragraphs 1 and 2.

4. Every holder, and every national vehicle acting for its holders, shall
have the right to an effective remedy before a court or tribunal against
any act or omission infringing this Article, in accordance with Article 47
of the Charter of Fundamental Rights of the European Union.

---

Drafting notes (non-normative). Drafted clause by clause against the actual
raid statutes. Paragraph 1's enumerated verbs track the Polish Act of 6
December 2013, Article 23(1), which cancelled units; cancellation is named
first. Paragraph 2 removes the self-dealing channel that made the Polish
raid worth executing, where Article 23(2) took the Treasury bonds first
(DC-19). Paragraph 3 is DC-21: Ireland's NPRF was raided lawfully through
its own emergency machinery, so this instrument has none. Paragraph 3
went through three drafts under the gates. Binding future legislatures
failed round 1; binding the Commission's right of initiative failed round 2
(Article 17 TEU institutional balance); what remains is the one thing an
ordinary Regulation can say, an interpretive rule, with the
assessment-of-holders duty relocated into the Commission's own reporting
under Article 14(4), which is ordinary review-clause territory. The former
Charter-possessions declaration was likewise deleted: secondary law cannot
define the scope of primary law, so that argument lives in the recitals and
the memorandum. Paragraph 4 remains the real lock: it converts the promise into
individual property, so that a future Polish-style statute meets Article 17
Charter litigation by millions of holders rather than a budget-line debate
(the exact channel Poland exploited was that OFE units were claims on the
state; these are not, per paragraph 2). Greece's HCAP is the overcorrection
this chapter avoids: protection is achieved without placing the asset
beyond citizens' reach. Satisfies DC-19, DC-21, DC-22, DC-23 and DC-20 as amended (a Regulation cannot prescribe voting thresholds for future legislatures, so the constraint now demands express amendment, a published independent assessment and honesty about the limits).


# SOURCE: own-the-machine/regulation/articles/13-penalties.md

# Article 13: Penalties

1. The Commission may by decision impose on a covered undertaking fines not
exceeding 10 % of its total worldwide turnover in the preceding financial
year where it finds that the undertaking, intentionally or negligently:
(a) fails to issue the citizens' capital warrant in accordance with
Article 5(1);
(b) fails to take the measures required by the third sentence of
Article 5(5);
(c) fails to notify a liquidity event in accordance with Article 5(6);
(d) supplies incorrect, incomplete or misleading information under
Article 3(3) or Article 4;
(e) circumvents Article 3(8), or fails to comply with a decision adopted
pursuant to that paragraph.

2. The Commission may by decision impose periodic penalty payments not
exceeding 5 % of the average daily worldwide turnover of the covered
undertaking in the preceding financial year for each day of continued
non-compliance, in order to compel compliance with the obligations
referred to in paragraph 1.

3. Where a covered undertaking that is not established in the Union
persistently fails to comply with the obligations referred to in points
(a) and (b) of paragraph 1, the Commission may by decision, as a measure
of last resort and for no longer than the non-compliance persists,
prohibit the making available of the goods and services referred to in
point (a) of Article 3(1) on the internal market by that undertaking.

4. In fixing the amount of a fine or periodic penalty payment, the
Commission shall have regard to the gravity, duration and recurrence of
the infringement. Before adopting a decision under this Article, the
Commission shall give the undertaking the opportunity to be heard.

5. The Court of Justice of the European Union shall have unlimited
jurisdiction within the meaning of Article 261 TFEU to review decisions
under this Article and may cancel, reduce or increase the fine or periodic
penalty payment imposed.

6. Fines and periodic penalty payments imposed under this Article shall
accrue to the general budget of the Union. They shall not accrue to the
Reserve.

---

Drafting notes (non-normative). The scales are the DMA's, deliberately
familiar. Paragraph 3 is the market-access teeth that make the obligation
of result credible for third-country groups (hostile counsel, kill 2),
bounded as last resort and duration-limited for proportionality. Paragraph
6 matters more than it looks: penalty revenue flowing to the Reserve would
hand critics the fiscal characterisation on a plate and give the Reserve an
enforcement interest; sending fines to the general budget like every other
competition-family fine keeps the Reserve clean under Article 8(3), and the
carve-out is stated expressly so the two provisions cannot be read against
each other.


# SOURCE: own-the-machine/regulation/articles/14-monitoring-review.md

# Article 14: Monitoring and evaluation

1. The Commission shall monitor, on the basis of data published by the
   European Central Bank, Eurostat and the national statistical institutes:
   (a) the diffusion of automated cognitive systems among undertakings in
   the Union; (b) the distribution of household holdings of equity
   instruments in the Union; (c) the share of value added accruing to labour
   and to capital in the sectors in which covered undertakings operate; (d)
   the number of designations, crystallisations and distributions under this
   Regulation and their amounts; (e) the evolution of the share of Union
   gross value added accruing to compensation of employees, as published by
   the Commission (Eurostat), relative to the year 2025, together with the
   Commission's assessment of the contribution of automated cognitive
   systems to any change in either direction.

2. By 31 December 2032, and every three years thereafter, the Commission
shall evaluate this Regulation and submit a report to the European
Parliament, the Council and the European Economic and Social Committee.

3. The report shall state, on the basis of the indicators in paragraph 1,
whether the premise of this Regulation that gains from automated cognitive
systems accrue disproportionately to the holders of the systems remains
supported by the evidence. Where the report finds that the share of
undertakings referred to in point (a) of paragraph 1 exceeds one quarter
and that neither the indicator in point (b) nor the indicator in point (c)
of that paragraph shows the concentration the premise predicts, the report
shall say so expressly and shall be accompanied, where appropriate, by a
proposal for the amendment or repeal of this Regulation.

4. Where a report under paragraph 2 accompanies or precedes a proposal for
the amendment of Article 5, Article 8, Article 10 or Article 12, it shall
include an independent assessment of the effect of the proposal on the
entitlements of holders.

5. The report shall be published.

---

Drafting notes (non-normative). Paragraph 3 is DC-18, the stated
falsification condition, as an operative reporting duty: the Regulation
instructs its own evaluator to declare its premise unsupported if the
evidence goes the other way, and to propose amendment or repeal. No
instrument in the acquis does this explicitly; it is the Stable's
publish-what-contradicts-us discipline written into law, and the
memorandum should present it as such. The indicators map to the evidence
base: ECB HFCS and DWA for (b), the sectoral accounts for (c).


# SOURCE: own-the-machine/regulation/articles/15-delegation.md

# Article 15: Exercise of the delegation

1. The power to adopt delegated acts is conferred on the Commission subject
to the conditions laid down in this Article.

2. The power to adopt delegated acts referred to in Article 3(9) and
Article 8(8) shall be
conferred on the Commission for a period of five years from the entry into
force of this Regulation. The Commission shall draw up a report in respect
of the delegation of power not later than nine months before the end of
the five-year period. The delegation of power shall be tacitly extended
for periods of an identical duration, unless the European Parliament or
the Council opposes such extension not later than three months before the
end of each period.

3. The delegation of power referred to in Article 3(9) and Article 8(8)
may be revoked at
any time by the European Parliament or by the Council. A decision to
revoke shall put an end to the delegation of the power specified in that
decision. It shall take effect the day following the publication of the
decision in the Official Journal of the European Union or at a later date
specified therein. It shall not affect the validity of any delegated acts
already in force.

4. Before adopting a delegated act, the Commission shall consult experts
designated by each Member State in accordance with the principles laid
down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making.

5. As soon as it adopts a delegated act, the Commission shall notify it
simultaneously to the European Parliament and to the Council.

6. A delegated act adopted pursuant to Article 3(9) or Article 8(8) shall
enter into force
only if no objection has been expressed either by the European Parliament
or by the Council within a period of two months of notification of that
act to the European Parliament and the Council or if, before the expiry of
that period, the European Parliament and the Council have both informed
the Commission that they will not object. That period shall be extended by
two months at the initiative of the European Parliament or of the Council.

---

Drafting notes (non-normative). The standard six-paragraph article, CSDR
Article 67 pattern, verbatim where the convention is fixed. Both
conferrals, Annex I methodology (Article 3(9)) and Annex II methodology
(Article 8(8)), are listed in paragraphs 2, 3 and 6, per the convention
that every conferral is named in each of the three control paragraphs.


# SOURCE: own-the-machine/regulation/articles/16-committee.md

# Article 16: Committee procedure

1. The Commission shall be assisted by a committee. That committee shall be
a committee within the meaning of Regulation (EU) No 182/2011.

2. Where reference is made to this paragraph, Article 5 of Regulation (EU)
No 182/2011 shall apply.

---

Drafting notes (non-normative). Added in round 2 after hostile counsel
found the valuation machinery legally orphaned: Article 6(1) confers an
implementing task with no Article 291 TFEU basis. Standard two-paragraph
comitology article, examination procedure, GDPR-family pattern.


# SOURCE: own-the-machine/regulation/articles/17-transitional.md

# Article 17: Transitional provisions

1. An undertaking that meets the thresholds laid down in Article 3(2) on
the date of entry into force of this Regulation shall make the
notification under Article 3(3) within two months of that date.

2. Where the shares of a covered undertaking were admitted to trading
before the entry into force of this Regulation, that admission shall not
constitute a liquidity event. The citizens' capital warrant of such an
undertaking shall crystallise upon the first liquidity event within the
meaning of point (b) or point (c) of Article 2(6) occurring after its
designation, or upon crystallisation under Article 5(3), whichever occurs
first.

3. A liquidity event completed before the entry into force of this
Regulation shall not give rise to any obligation under Article 5.

---

Drafting notes (non-normative). Round 2 rewrote paragraph 2 after hostile
counsel correctly attacked the forced 12-month crystallisation of
already-listed undertakings as an uncompensated taking on an arbitrary
date, which also contradicted the instrument's own in-time doctrine. The
rule is now uniform and purely prospective: a pre-existing admission is not
an event; the warrant of an already-listed undertaking waits, dormant, for
the next genuine liquidity event (change of control or a qualifying 20 %
transfer), exactly as every other warrant does. This Article does not
disapply Article 5(3), so the extraction trigger and the seven-year
long-stop in that paragraph continue to run from issuance, exactly as for
every other warrant. There is accordingly no escape by never having
another liquidity event: absent one, the warrant of an already-listed
undertaking crystallises in any event no later than seven years after
issuance, and sooner if extraction is used to strip it in the meantime.
Paragraph 3 is the express non-retroactivity rule (JPG 10.14).


# SOURCE: own-the-machine/regulation/articles/18-final.md

# Article 18: Entry into force and application

1. This Regulation shall enter into force on the twentieth day following
that of its publication in the Official Journal of the European Union.

2. It shall apply from [OP: please insert the date 18 months after the
date of entry into force of this Regulation], with the exception of
Article 3(3), Article 11(1) and Article 17(1), which shall apply from the
date of entry into force of this Regulation.

3. This Regulation shall be binding in its entirety and directly applicable
in all Member States.

---

Drafting notes (non-normative). The 18-month application delay gives the
designation machinery and national vehicles time to exist; Article 11(1)
runs from entry into force so the rails are built during the delay, not
after it. Paragraph 3 is the standard closing formula for a Regulation.


# SOURCE: own-the-machine/regulation/memorandum/counter-arguments.md

# The case against this Regulation

Drafted first, before any article, on the discipline this project inherits: if
the instrument cannot survive this file, we fix the instrument, not the prose.
Each objection is stated in its strongest form, with its best sources. Each
ends with the design consequence it imposes. The consequences accumulate into
the constraints table at the end, which is the checklist the articles must
clear before anything else is written.

Objections marked **CONCEDED** are limits of the instrument that the
memorandum states plainly rather than argues away. That is not a courtesy. It
is what distinguishes a legal proposal from campaign copy, and it is the
entire credibility strategy of this project.

---

## A. Legal

### 1. This is expropriation

**The objection, at full strength.** A statutory requirement that undertakings
issue equity warrants to a public reserve takes property. Article 17 of the
Charter of Fundamental Rights protects the right to own, use and dispose of
lawfully acquired possessions, and permits deprivation only in the public
interest, in cases and under conditions provided for by law, and subject to
fair compensation paid in good time. A compulsory warrant dilutes existing
shareholders with no compensation at all; the dilution is the point. Article
345 TFEU adds that the Treaties shall in no way prejudice the rules in Member
States governing the system of property ownership. The Court has narrowed
Article 345 considerably, but a hostile Legal Service reading has ample
material, and shareholders of affected firms will litigate from day one.

**What it gets right.** A warrant requirement does transfer value from
existing shareholders to the reserve. Pretending dilution is not a taking of
value would be dishonest, and the memorandum must not do it.

**The answer the instrument must give.** Three structural choices, none
optional. First, the warrant must be drafted as a condition of access to the
Single Market for a defined category of undertaking, prospective and
uniform, in the family of regulatory obligations the Court has upheld when
proportionate (capital requirements, universal service obligations, DMA
gatekeeper duties), not as a seizure of existing holdings. Second, it must
apply only above high, objective thresholds, so proportionality review has
something to hold on to. Third, it must carry consideration: the reserve is a
passive, non-controlling holder, the warrant crystallises only at liquidity
events, and the covered undertaking receives the legal certainty of a single
harmonised regime in place of twenty-seven national experiments. Whether that
consideration is sufficient is the single largest legal risk in the project,
and Gate 1 exists to test it.

Two authorities belong in this file because a hostile reader will bring
them, and because each is less one-sided than it first appears. The first
is Strasbourg's rule that a deprivation without an amount reasonably
related to the value taken is normally disproportionate (James and Others
v United Kingdom, 1986). The same judgment holds, in the same breath, that
legitimate objectives of public interest, and expressly measures of
economic reform or measures designed to achieve greater social justice,
may warrant reimbursement at less than full market value. That is the
authority under which this instrument has to be argued, and it is
available on its terms rather than in spite of them: a 3 % dilution
crystallising at a moment of realised gain, calibrated to a decoupling of
output from labour, is a measure of economic reform if anything is.

The second is Article 345 TFEU. It provides that the Treaties shall in no
way prejudice the rules in Member States governing the system of property
ownership, and the hostile reading is that a mandatory transfer of 3 % of
private enterprise value is a partial socialisation the Union may not
decree. That reading mistakes the addressee. Article 345 preserves the
Member States' freedom to choose between public and private ownership
against the Treaties; it is not a charter of immunity for property against
Union legislation, which is what Article 17 of the Charter governs and
what this memorandum answers under Article 52(1). The Court has read
Article 345 narrowly in precisely that direction, holding that a property
regime chosen by a Member State remains subject to the fundamental
freedoms (Essent, C-105/12 to C-107/12). The instrument leaves every
Member State's system of ownership exactly as it found it: the shares
subscribed are ordinary shares under national company law, held by an
owner with no special rights, and no national rule about who may own what
is displaced.

The drafting research (18 August) settled the architecture to use: BRRD is
the judicially validated template for interfering with equity by act of law
(Kotnik C-526/14, Ledra C-8/15 P, Aeris Invest C-535/22 P), and the
instrument adopts its machinery: an honest interference recital naming
Charter Article 17, a full proportionality recital under Article 52(1) of the Charter, and a
quantified executional safeguard with independent, separately challengeable
valuation. One adaptation is mandatory: BRRD's counterfactual is insolvency,
and a permanent regime cannot lean on crisis reasoning (Dowling C-41/15).
The distinction has to be stated rather than blurred: bank resolution
dilutes shareholders whose shares would be worth nothing in the
counterfactual insolvency, and these undertakings are healthy going
concerns whose shares are worth a great deal. BRRD is therefore borrowed
for its machinery, not for its justification, and this file does not
pretend otherwise; the justification is the one in James and in Hauer, and
it stands or falls on proportionality rather than on a crisis that is not
happening.

One further authority is worth stating precisely, because stated loosely it
would be worth nothing. In Sky Österreich (C-283/11, 22 January 2013) the
Grand Chamber upheld a Union measure requiring holders of exclusive
broadcasting rights to grant competitors access for short news reports,
with compensation capped at the additional costs directly incurred, which
is below what the market would pay. The rights-holders were solvent, there
was no crisis and no counterfactual insolvency. **That case was decided
under Article 16 of the Charter, the freedom to conduct a business, and not
under Article 17.** It is not authority for a taking of equity, and this
file does not offer it as one; hostile counsel would be entitled to
dismantle any such use of it, and would enjoy doing so.

What it does carry is narrower and still useful. This instrument interferes
with Article 16 as well as Article 17, because compelling an undertaking to
issue shares it did not choose to issue is an interference with the conduct
of its business, and the Commission's Legal Service will see both. On that
limb Sky Österreich is directly in point, and it says three things: the
Article 16 freedom is not absolute but must be viewed in relation to its
social function; the Union legislature may set consideration below market
value where the public interest requires it; and the test is the ordinary
Article 52(1) one. The older line supports the same reading of business
interests, which enjoy no protection as mere commercial expectations of
future profit (Nold 4/73). Booker Aquaculture (C-20/00 and C-64/00) is
sometimes cited alongside, and this file does not lean on it: it concerned
the destruction of diseased stock under an animal-health regime, which is a
public-emergency justification this instrument cannot claim.

The Article 17 limb therefore still rests where it rested, on James and on
Hauer, and the honest statement is that no decided case puts a permanent,
non-crisis, uncompensated equity dilution of a healthy undertaking on the
right side of Article 17. That is the largest legal risk in the project and
it is stated as such in the answer above. So
our floor is executional rather than counterfactual: the interference can
never exceed the stated 3 % in execution, its price is set by the
liquidity event itself under an independent and separately challengeable
valuation, and no application of the instrument may take more than the
interference it names. The doctrine underneath is older than any
of this: property in the Union legal order is not an unfettered prerogative
but is protected in its social function, and may be restricted in the
general interest where the restriction is proportionate and leaves the
right's substance intact (Hauer 44/79; Bosphorus C-84/95). The instrument's
restriction is quantified, event-bound and substance-preserving by
construction, which is what those cases require the legislature to show.

**Design consequence.** DC-1: prospective warrant on future value creation at
defined events, never retroactive transfer of existing shares. DC-2: high
group-consolidated thresholds. DC-3: passivity, and crystallisation only at
defined statutory events, never at a discretionary or political one, written
into the instrument itself.

### 2. This is a tax, and the EU may not levy it this way

**The objection, at full strength.** Call it a warrant; it functions as a
levy. Article 114(2) TFEU excludes fiscal provisions from internal market
harmonisation, so if the measure is fiscal in substance the chosen legal base
collapses; the honest bases would be Article 113 or 115, which require
unanimity in Council, which is unobtainable. The Commission has refused ECIs
that drift into own-resources territory, and the Legal Service reads substance,
not labels. The dividend side makes it worse: a recurring payment to every
adult, funded by an obligation on firms, looks like a tax-and-transfer scheme
wearing a corporate-finance costume.

**What it gets right.** The boundary is real and the characterisation battle
decides registrability. This is the objection most likely to kill the full ask
at Gate 1.

**The answer the instrument must give.** The measure must take nothing in
money from any undertaking in any year. No cash flows from firms to the state
at all. The reserve receives instruments, holds them, and distributes returns
on what it owns, exactly as any shareholder does. Dividends to citizens are
property income from an owned portfolio, not the proceeds of a levy: the
Norwegian fund's distributions are not a tax on anyone. The drafting must
police this line everywhere: no revenue-based charges, no minimum payments, no
cash-settlement options that would let the obligation collapse into a fee.
And the ask must be layered so that if the Legal Service still reads it as
fiscal, the severable outer layer (assess and propose instruments for citizen
participation in automated productivity gains) registers on its own.

Recalibration from the drafting research: registration is a lower hurdle
than this objection assumes. The test is "manifestly outside" the
Commission's powers (Reg 2019/788 Art 6(3)(c)), partial registration is
judicially established (C-899/19 P), and the Commission registered the EU
wealth-tax ECI in 2023. The characterisation fight is real but is fought in
Council, after registration. The layering therefore protects the campaign
moment; the warrant-not-levy drafting protects the instrument's life after
it.

**Design consequence.** DC-4: no monetary flow from undertakings; instruments
only. DC-5: distributions defined as property income of the reserve. DC-6:
severable layering for partial registration.

### 3. The Union has no competence to pay citizens a dividend

**The objection, at full strength.** Even if the warrant survives, the
dividend side has no home. The Union budget operates under an own-resources
ceiling; a Union body paying a recurring universal benefit to every adult has
no Treaty basis; social security design is a Member State competence; and
subsidiarity review would ask, fairly, why citizen accounts must be European
at all when Ireland, Denmark and the Netherlands run national systems that
work. Table 29 makes the point against us: pension funding runs from 49.1% in
the Netherlands to 0.0% in France. Systems this different cannot be
harmonised, and should not be.

**What it gets right.** The Union genuinely cannot and should not run
twenty-seven citizens' accounts from Brussels, and the proposal dies at
subsidiarity review if it tries.

**The answer the instrument must give.** Split the instrument along the
competence line. The Union harmonises what is genuinely single-market: which
undertakings issue warrants, on what terms, to what kind of reserve, with what
governance. Custody and distribution federate to Member States through
existing rails: Denmark has LD, Ireland has MyFutureFund, Poland has PPK, the
Netherlands is mid-conversion into individual DC pots. The precedent is PEPP:
a Union framework, national compartments. The Union never touches the money;
it defines the instrument and the minimum standards (universality, lock-up,
raid-proofing) that national implementations must meet.

**Design consequence.** DC-7: Union-level warrant and reserve standards;
Member State custody and payout through existing pension rails. DC-8: minimum
standards, not uniform machinery.

---

## B. Economic

### 4. Firms will pass the cost to consumers, so citizens pay their own dividend

**The objection, at full strength.** The incidence literature on corporate
taxation is unambiguous that legal and economic incidence differ; a
substantial share of corporate burdens lands on workers and consumers. A
warrant obligation raises the cost of operating in Europe; covered firms
reprice; the citizen's dividend arrives net of the citizen's own higher
prices. The scheme is then a circular pump with deadweight loss.

**What it gets right.** Some pass-through of any burden is real and claiming
zero incidence would be amateurish.

**The answer the instrument must give.** Equity dilution has materially
different incidence from a flow charge. A levy on revenue enters marginal cost
and prices directly; a one-time issuance of warrants exercisable at future
liquidity events changes the division of a future capital gain among
shareholders and does not enter this year's marginal cost at all. The firm's
optimal price today is unchanged by who owns claims on its eventual exit
value. Pass-through is not zero, because expected dilution can raise the cost
of capital at the margin, and the memorandum should say so, with the honest
note that this effect is second-order next to any revenue levy, which is
precisely why the instrument is a warrant and not a levy.

**Design consequence.** DC-9 (reinforces DC-4): the obligation must never be
convertible into a flow charge, because the incidence answer depends on it.

### 5. Covered firms will leave, or never come

**The objection, at full strength.** Draghi's report already concedes the
ground: it is too late for the EU to develop systematic challengers to the
major US cloud providers; the US ITK market grows at 12.7% against Germany's
4.1%; only four of the world's top fifty technology companies are European.
Add a warrant obligation and the marginal AI investment goes to London,
Zurich or Austin. Worse, thresholds invite structuring: a revenue-per-employee
test is gamed by pushing headcount into subcontractors, exactly the offshore
structuring Capgemini's numbers already show at scale.

**What it gets right.** Threshold gaming is certain, not possible, and the
competitiveness anxiety is the strongest political headwind in Brussels this
decade.

**The answer the instrument must give.** The obligation attaches to selling
into the Single Market, not to being located in it, exactly as the DMA and
GDPR attach. The empirical record since is that gatekeepers absorbed
designation and stayed, because 450 million high-income consumers are not
optional; the DMA investigations into AWS and Azure did not produce an exit,
they produced compliance teams. Structuring is answered by consolidation:
thresholds computed on group-consolidated figures including contracted-out
labour by economic substance, with the burden on the undertaking to show
otherwise. And the honest concession: at the margin some investment will
route elsewhere, which is a real cost, to be weighed in the memorandum against
the documented cost of the alternative, which is that the gains concentrate
entirely outside Europe anyway. The Synergy history is the exhibit: Europe
declined to regulate its cloud market into openness, and its providers fell
from 29% to 15% of their own home market unregulated.

**Design consequence.** DC-10: market-access nexus, not establishment nexus.
DC-11: group consolidation with substance-over-form headcount rules.

### 6. Warrants on private companies cannot be valued, voted or sold

**The objection, at full strength.** The covered class is dominated by
private undertakings. A reserve holding warrants on private micro-giants
holds paper with no market price, no liquidity and no exit; either it
pressures for early listings, distorting capital markets, or it sits on
unvalued claims for a decade and the dividend it promises cannot be paid.
Meanwhile the governance question is a trap in both directions: a passive
mega-holder is the feeble owner of the Bebchuk critique, and an active one is
a political sovereign shareholder in every major firm. Greece's HCAP shows the
overcorrection: maximal raid-proofing achieved by placing the asset beyond
citizens' reach entirely.

**What it gets right.** All of it. This is the hardest design problem in the
instrument, harder than the legal base.

**The answer the instrument must give.** The warrant is dormant until
crystallisation, whether at a liquidity event (listing, change of control,
or qualifying secondary sale) or, under Article 5(3), where shareholder
extraction exceeds the stated share of covered turnover or seven years
have elapsed since issuance, whichever occurs first. Until then it
requires no valuation, pays nothing and votes nothing; at the
event it converts at the event price, with no discretion. This matches the
book's own window (claim the stake while the asset forms, crystallise when
the market prices it) and removes the valuation and governance problems in
one move: the reserve holds non-voting economic interests, permanently, by
statute, accepting the Bebchuk cost deliberately because the alternative, a
politically voted stake in every large firm, is worse. The dividend in early
years is funded by crystallisations, not by holdings, and the memorandum must
say plainly that the dividend starts small and compounds, Norway-style, and
that anyone promising otherwise is not us. Two-thirds of Norway's fund is
compound return; the honest pitch is the rule, not the first cheque.

One refinement has been considered and rejected. It is put that valuations
of fast-growing private undertakings are volatile enough that disputes over
the dilution ratio could bog the instrument down in litigation, and that an
expedited binding arbitration should therefore sit between the valuer and
the courts. The instrument already answers the problem the proposal aims
at, and the proposal would cost more than it saves. Article 6(5) provides
that a challenge suspends neither the liquidity event nor the subscription,
and Article 6(4) corrects an erroneous valuation afterwards in either
direction, so a dispute delays nobody: this is the resolution-law pattern,
where litigation runs beside the transaction rather than across it. Where
the event itself sets a price, Article 6(2) makes the valuation arithmetic
on that price rather than an opinion about it, which is where volatility
would otherwise enter. And an arbitral tier whose award bound the parties
would meet Article 47 of the Charter on access to a court, and the limits
on conferring discretionary judgement on bodies of the Union; a tier whose
award did not bind them would add a stage without removing one.

**Design consequence.** DC-12: event-triggered crystallisation, no ongoing
valuation. DC-13: permanently non-voting economic interests. DC-14: the
dividend is communicated as compounding from small, never as immediate
income. DC-34: no tier may be inserted between the valuation and the
courts; correction is ex post and the transaction never waits.

---

## C. Empirical

### 7. The European labour share has not fallen, so the diagnosis is wrong

**The objection, at full strength.** AMECO, verified at source: the EU27
adjusted wage share fell 1.2 points in thirty years; Germany's is at a series
high; France is above its 1995 level; compensation of employees was a larger
share of EU output in 2025 than in 2015, 2019 or 2022. The corporate profit
share spike of 2022 has fully reversed to below its 2019 level. The
Regulation's premise, that machine-driven gains are leaving European labour,
is contradicted by the best available aggregate data, and any recital claiming
otherwise is checkable and wrong.

**What it gets right.** Everything it states. This project's own evidence
base established it, and no recital may argue a European labour-share
collapse.

**The answer the instrument must give.** The premise is ownership, not the
wage share. Sixty per cent of euro-area households own their home; eleven per
cent own listed shares; the top decile holds eighty-three per cent of directly
held shares against the bottom half's two; the bottom half's portfolio is
sixty-three per cent housing and three per cent equity. That distribution is
current, verified and undisputed, and it means that however large the
machine's dividend turns out to be, almost no European holds an instrument
that pays it. The Regulation is insurance whose premium is cheapest before
the event: if the mechanism documented at the platform layer (French software
and cloud growing at +8.2% on price increases while the services layer
shrinks; German software at +9.9% against services at +3.1%) reaches the
aggregate labour market, the stake exists; if it never does, citizens own a
diversified claim on European technology, which is not an injury. The
in-time test is the answer to the premature-legislation charge, not a
vulnerability of it.

**Design consequence.** DC-15: recitals argue ownership concentration and
mechanism, never wage-share decline. DC-16: the memorandum presents the
instrument's value under BOTH futures, arrival and non-arrival.

### 8. The best microdata finds nothing for AI to answer for

**The objection, at full strength.** Humlum and Vestergaard, on Danish
registers covering twenty-five thousand workers: precise null effects on
earnings and hours, nothing above two per cent, two years after ChatGPT. The
OECD finds no break in postings for exposed occupations and a flat euro-area
youth gap. The German federal government told the Bundestag there are keine
Hinweise that AI has reduced entry-level chances. Only a fifth of EU firms
with ten or more staff used any AI in 2025. Legislating a permanent
constitutional-grade structure on this evidence is panic dressed as foresight.

**What it gets right.** The nulls are real, well-identified and from the
best registers in Europe. The memorandum cites them in full or loses its
credibility.

**The answer the instrument must give.** Three things, honestly. First, the
nulls measure wages and hours, not ownership: a uniform shift of returns from
labour to capital is structurally invisible to difference-in-differences
designs, which the Danish authors themselves concede (the absence of
measurable labour market effects is not evidence that nothing is happening),
and their working paper's estimate that only three to seven per cent of
productivity gains passed through to earnings vanished from the published
version along with the paper's own title. Second, the diffusion number cuts
both ways: a mechanism used by a fifth of firms has not yet had its
aggregate chance, which is the argument for building the instrument before
rather than after. Third, the memorandum should carry its own falsification
condition, in the open: if adoption passes a quarter of firms and neither
factor shares nor ownership-weighted gains have moved by a defined date, the
accelerationist premise is wrong and the case reduces to the ownership-gap
argument alone, which stands on its own feet. A proposal that states what
would refute it is a different genre from everything else in Brussels, and
that is the point of this project.

**Design consequence.** DC-17: cite the strongest nulls in the memorandum
itself. DC-18: a stated falsification condition with a date.

---

## D. Political

### 9. You are building the next honeypot, and Europe raids honeypots

**The objection, at full strength.** In one article of law, Poland cancelled
51.5% of the units in every member's pension account and took the Treasury
bonds first. Spain drew its reserve fund down 97% and passed the protection
law afterwards. Hungary took the lot. Ireland's NPRF, the closest thing to
this proposal an EU state has built, was liquidated into a bank rescue within
a decade of its creation. Even the Union itself announced InvestAI at 200
billion and reprogrammed existing funds to stage it. The historical base rate
for European states leaving large pools of citizens' capital alone is poor,
and a bigger pool is a bigger prize. Estonia adds the mirror case: given the
claim and the exit simultaneously, a quarter of the fund walked out in a
month, and the leavers earned below the median.

**What it gets right.** This is the book's own chapter 10 thesis returned as
an objection, and it is the strongest political argument in the file. The
raid is not a tail risk; on the European record it is the modal outcome.

**The answer the instrument must give.** Design against the actual statutes,
clause by clause. Against Poland: the reserve may not hold the sovereign debt
of any Member State or of the Union, removing the self-dealing channel that
made OFE worth cancelling. Against Spain: the prohibition on disposal is in
the founding Regulation from day one, not retrofitted, and amendment of the
protection provisions is reserved to express legislative change accompanied
by a published independent assessment of the effect on holders; a Regulation
cannot prescribe voting thresholds or delays for future legislatures, and
pretending otherwise would hand critics the easiest ridicule in the file. Against Ireland: no emergency-use clause of any kind,
because the NPRF's raid was lawful under its own emergency provisions.
Against Estonia: the periodic entitlement is incapable of surrender or
redemption against payment, so there is no exit for a buyout to purchase,
which is the failure Estonia proved; amounts already distributed are the
holder's property, inheritable, the Danish device that held. Against Greece: raid-proofing must never be achieved by removing
the citizen's claim, which is the failure dressed as success. And one honest
sentence the memorandum must contain: no drafting defeats a determined
future sovereign; the design goal is to make the raid loud, slow and
electorally expensive, which is the most any constitution has ever achieved.

**Design consequence.** DC-19: no sovereign debt holdings. DC-20:
entrenchment as friction from day one: express amendment only, a
published independent assessment, and honesty about Treaty limits. DC-21: no
emergency clause. DC-22: individual claims incapable of surrender; distributed amounts owned and inheritable.
DC-23: the raid-resistance claim is stated as friction, never as
impossibility.

### 10. The EU cannot even disburse what it announces

**The objection, at full strength.** The AI Gigafactories call opened
eighteen months after the 200 billion announcement; construction is promised
from 2027; the Commission's sovereign-cloud tender awarded 180 million
against a single hyperscaler's 33.7 billion in Spain. The institutional
metabolism that would operate this Regulation moves at a pace the underlying
economy does not recognise. A citizens' reserve run at that pace would
crystallise warrants years late and distribute nothing for a decade.

**What it gets right.** The disbursement record is accurately damning and
the memorandum gains nothing by disputing it.

**The answer the instrument must give.** Put no Union spending machinery on
the critical path. The obligation runs directly from covered undertakings to
the reserve: warrants issue by operation of law upon crossing the thresholds,
crystallise by operation of law at events, and the reserve's task is custody
and distribution, not procurement. Nothing needs to be built, tendered or
disbursed for the instrument to function; the contrast with InvestAI is the
design, not an embarrassment to it.

**Design consequence.** DC-24: self-executing obligations by operation of
law; no grant, tender or programme machinery anywhere in the instrument.

---

## E. Philosophical

### 11. Everyone gets richer anyway: the consumer surplus answer

**The objection, at full strength.** Nordhaus estimated that innovators
capture around two per cent of the social value of their innovations; the
rest diffuses to consumers through falling prices and new possibilities. The
steam engine made everyone richer without a single citizen holding a warrant
on Boulton and Watt. If AI follows the pattern, the ownership question is a
distraction: the gains arrive in everyone's basket regardless of whose name
is on the equity.

**What it gets right.** Consumer surplus is real, large and the main channel
through which technology has historically raised living standards. The book
concedes it; the memorandum must too.

**The answer the instrument must give.** Two facts sit beside the diffusion
story without contradicting it. First, the lag: British real wages stagnated
for roughly half a century after Watt while output exploded, and the
broadening arrived through unions, franchise and factory legislation, not
through prices alone; the people who lived inside the pause did not get those
decades back, and whoever owned the mine did not wait. An instrument claimed
at the door is the difference between experiencing the pause with and without
an asset. Second, the stock and the flow are different questions: cheaper
consumption and concentrated wealth are compatible, and the euro area
currently demonstrates the combination, with record employment beside an
ownership distribution of eighty-three against two. The dividend does not
obstruct diffusion; it adds an ownership channel beside the price channel.

**Design consequence.** DC-25: the memorandum affirms consumer surplus and
positions the instrument as additive to it, never as a correction of a
falsehood.

### 12. A dividend buys neither status nor purpose

**The objection, at full strength.** Positional goods reprice against any
universal transfer: give everyone more and the house in the right street
costs more. And income without work solves rent, not Tuesday afternoon: the
structure, standing and belonging that employment supplies as a by-product
are not in the reserve's gift. The proposal oversells what capital income can
do for a displaced person.

**What it gets right. CONCEDED in full.** These are the book's own chapters
11 and 13 and they bind its regulation exactly as they bind its argument.

**What the memorandum must therefore say.** The instrument's scope statement,
prominently: this Regulation addresses the distribution of machine-generated
capital income and nothing else. It does not promise status, purpose,
meaning or the best table, and any campaign material that implies otherwise
is wrong by the proposal's own text.

**Design consequence.** DC-26: an explicit scope-and-limits recital.

### 13. This is universal basic income with extra steps

**The objection, at full strength.** Strip the corporate finance and a
citizen receives a recurring unconditional payment from a public body. That
is UBI, a policy the electorate has weighed repeatedly and cheaply funded
versions of which already failed to collect even an ECI's signatures. The
warrant machinery is complexity added to disguise a transfer as a return.

**What it gets right.** The payment is indeed unconditional and universal,
and the family resemblance is real at the point of receipt.

**The answer the instrument must give.** The difference is not in the
receiving but in the standing. A benefit is a flow from the annual budget,
renegotiated annually, cancellable by simple majority, funded by a shrinking
wage base; the account here is property, in the citizen's name, inheritable,
funded by returns on assets the citizen collectively owns. Poland could
cancel account units by statute precisely because they held claims on the
state itself; Denmark's LD has paid for forty-six years because it holds
market assets in named accounts. The tagline is the answer in six words:
capital for all, so the dividend follows. The order is the argument.

**Design consequence.** DC-27 (reinforces DC-22): named, inheritable
individual accounts, so the UBI comparison fails on legal form, not on
rhetoric.

### 14. Pensions already do this; use them

**The objection, at full strength.** Europe already possesses the machinery
for broad capital ownership: the Netherlands has just moved 605 billion into
individual DC entitlements, Sweden's premium pension has compounded at 5.35%
real since 2000, and the American case shows retirement accounts spreading
equity to 58% of households without any statutory warrant. Build pensions,
not novelties.

**What it gets right.** The delivery rails exist, work and are trusted, and
any design that ignores them is wasteful.

**The answer the instrument must give.** Pensions convert wages into
ownership, and the wage is the input this transition erodes; every pension
vehicle in Europe assumes an employer and a payroll deduction, which is
exactly the assumption chapter 6 shows failing. The funded share of accrued
pension wealth is 7.8% in Belgium and 0.0% in France: the rails reach the
employed of the funded countries and no one else. The warrant severs the
funding source from the wage: the reserve's returns flow into precisely
those national account rails (DC-7) whether or not the citizen ever held a
payroll job. Pensions are the pipe; this is a new source feeding it.

**Design consequence.** DC-28 (reinforces DC-7): distribution through
existing national pension rails; the novelty is confined to the funding
source, where it is necessary.

---

### 15. A euro a year is an insult, not a policy

**The objection, at full strength.** Run the instrument's own simulator
on cautious assumptions and it pays a citizen a euro or two a year for
its first decade. No rational person values that; no voter campaigns
for it; no journalist resists the headline. The apparatus is grotesquely
disproportionate to its payload: a new Union body, a designation regime,
valuation machinery, comitology, penalties reaching 10 % of worldwide
turnover, all to deliver less than the price of a coffee. Worse, the
project's own honesty doctrine forbids promising more. An initiative
that must, by its own rules, tell every signer "you will not feel this
for twenty years" has chosen a message no mass campaign has ever won
with. Basic income at least promises the rent.

**What it gets right.** The early flow is genuinely small, and the
campaign is structurally barred from inflating it. The collection risk
is real: deferred rewards lose to immediate ones on every doorstep.

**The answer the instrument must give.** Three parts. First, the smallness
is calibration, not failure: the instrument's size tracks the
phenomenon's size by construction. Three per cent of little is little,
taken from almost no one, and in that world Article 14(3) obliges the
Commission to report that the premise failed and to propose amendment
or repeal; a permanently small dividend is the falsification condition
firing, not the policy limping. The dividend is only ever small in the
world where the problem is also small. Second, the claim can only be
bought early. The Danish worker's frozen 1978 instalment of DKK 4 368,
pointless money at the time, is DKK 119 506 today; two thirds of
Norway's fund is compound return, not oil. The alternative timing,
claiming the stake after the gains are visible and the owners
entrenched, is expropriation and politically impossible. The euro buys
the certificate, and the certificate is the point. Third, the stock
outruns the flow: on the same cautious assumptions the Reserve stands
at roughly EUR 400 of owned capital behind every citizen by year
thirty, before any single year's payout impresses. A campaign that
shows the payout without the stake is misdescribing its own
instrument.

**Design consequence.** This objection is why DC-14 exists (never lead
with an early-year figure), why Article 14(3) carries the falsification
condition on its face, and why Annex II distributes income and never
principal. It adds two mechanical rules of its own: wherever a
per-citizen payout figure is shown, the per-citizen stake in the
Reserve is shown beside it (DC-31); and where a year's distributable
amount would be too small to be worth transferring, the interval
lengthens rather than the money vanishing, subject to a hard backstop of
one distribution in every three years and a duty to publish what was not
paid (DC-40). The threshold is a ratio to the cost of making the payment,
not a figure: a number in an annex ages, and hands a headline to anyone
who wants one.

### 16. This is a golden share, and the Court strikes golden shares down

**The objection, at full strength.** For twenty years the Court has
dismantled every special public equity position in the internal market.
Commission v Germany (C-112/05) struck the Volkswagen Law because voting
caps and a blocking minority gave public authorities influence exceeding
their investment and thereby deterred direct investment; the Portuguese,
French, Italian, British and Dutch golden shares fell the same way under
what is now Article 63 TFEU. A Union-chartered Reserve holding a statutory
3 % of every covered undertaking is a golden share cast as a regulation: a
permanent state-adjacent shareholder no investor chose, planted in the
capital structure of every frontier firm, deterring exactly the
cross-border investment Article 63 protects. Article 345's neutrality about
systems of ownership did not save the Volkswagen Law and will not save
this. The deterrence is not hypothetical: every venture round in a covered
undertaking now prices a mandatory future dilution.

**What it gets right.** The dilution is real and investors will price it,
and any position that carried control-flavoured rights would fall exactly
as Volkswagen fell. The golden-share cases are the controlling
jurisprudence for any public equity position, and the instrument must be
drafted against them, not around them.

**The answer the instrument must give.** The golden-share line condemns one
thing: special rights of control disproportionate to investment, voting
caps, blocking minorities, approval vetoes, board seats, the machinery by
which a state steers a company it does not own. The instrument constructs
the exact inverse, in the articles rather than in assurances. The Reserve's
holding carries no vote, ever (Articles 5(4)(a) and 9(1)(a)); no board
presence (Article 9(1)(b)); no instructions (Article 9(1)(c)); no
acquisitions beyond the warrant and index-style diversification (Article
9(1)(d)); no leverage or derivatives that would make it a strategic actor
(Article 9(1)(e) to (g)). What remains is pure economic participation, the
position of any passive minority holder, which is the position Norway's
fund holds at comparable scale across European listed undertakings without
an Article 63 case ever being brought. What the case law demands of any
restriction that survives, the instrument answers on its face:
non-discrimination (identical treatment of Union and third-country
undertakings under Article 3), an overriding general interest stated in the
recitals, and proportionality carried by the fixed 3 %, the independent and
separately justiciable valuation (Articles 5(9), 6 and 7) and the Article
52(1) balance. And unlike every struck golden share, this is not a Member
State reserving national influence against integration: it is a uniform
Union rule for the whole internal market, and its uniformity removes the
divergence that national participation schemes would create. The honest
residue is that mandatory future dilution is itself a cost investors will
price; objection 4 prices it, and proportionality, not denial, is the
defence.

**Design consequence.** DC-13's permanent non-voting rule and Article 9's
conduct prohibitions are this objection's answer in law. What they cannot
do is bind a future legislature, and this memorandum does not pretend
otherwise: the drafting of Article 12(3) records that binding future
legislatures failed the gates in an earlier round, and an attempt on 21
August 2026 to give the rule operative force in that paragraph was
abandoned because hostile counsel preferred it present, reading it as a
Union-law command that the Reserve be stripped of the protective class
rights Article 5(4)(b) gives it. What stands is a design rule binding this
instrument and anyone amending it: economic participation is the maximum,
and no control right, veto or governance privilege attaches to the
Reserve's holdings (DC-32). It is a commitment the text keeps, not a lock
the text can impose.

### 17. You are seizing equity in companies Europe does not govern

**The objection, at full strength.** The warrant obligation reaches
undertakings incorporated in Delaware or Singapore, whose shares sit
offshore and whose systems are built offshore, because their services are
used in the Union. Public international law lets the Union regulate foreign
conduct only where it has immediate, substantial and foreseeable effects in
the internal market (Gencor T-102/96; Intel C-413/14 P), and even then it
regulates conduct, not ownership: no effects-doctrine case has ever
required a foreign parent to dilute its own capital. Third-country
governments will treat a compulsory 3 % subscription in their champions as
expropriation by regulation, answerable under investment treaties and
trade commitments, and they will retaliate. The Union would be claiming a
power it would never concede to others: a foreign statute demanding 3 % of
a European champion's equity as the price of serving that market.

**What it gets right.** A warrant on a foreign parent whose only Union link
is that its website resolves would overreach and would deserve to lose. The
nexus must be economic substance in the Union, not accessibility.
Retaliation is a real cost and reciprocity a real argument.

**The answer the instrument must give.** Four structural choices, all
already in the articles. First, the trigger is Union commerce, not Union
accessibility: designation requires provision in the internal market with
EUR 7,5 billion of annual Union turnover in at least three Member States
(Article 3(2)(a)), an economic-presence test far above any effects-doctrine
threshold, and the rents being shared are by construction rents drawn from
Union users. Second, the undertaking is the group: 'undertaking'
consolidates linked enterprises (Article 2(1)), the single-economic-unit
principle of Union competition law (Akzo Nobel C-97/08 P), so no thin
Union subsidiary can shield the parent to which the automated services'
value actually accrues. Third, the mechanism respects foreign company law
rather than purporting to override it: for undertakings governed by
third-country law the subscription is an obligation of result (Article
5(5)), enforced through Article 13 as a condition of continuing access to
the internal market, the architecture of every market-access condition the
Union already imposes, and the company-law derogations of Article 5(7)
reach Member State law only. Fourth, the condition is universal: Union
undertakings bear it identically, so a treaty claim or trade panel has no
discrimination to hold on to, and reciprocity runs in the instrument's
favour, because a Union that asserts the principle accepts it from others.

On the practical incidence the objection now has a concrete answer rather
than an abstract one. Under the designation test of Article 3(2)(b) as
amended, the undertakings presumptively designated on August 2026 figures
span the United States, Taiwan and, near the threshold, the Union itself
(evidence/designation-count.md), so the measure's first-years incidence is
no longer a set consisting exclusively of undertakings of one third
country, and the universality of the condition is visible in the
designated set itself rather than asserted about a hypothetical one.

**Design consequence.** DC-10's market-access nexus and DC-2's group
consolidation are this objection's answers in law. It adds one rule of its
own: for undertakings governed by third-country law, the warrant is an
obligation of result enforced as a market-access condition, never a
purported override of foreign company law (DC-33).

### 18. Corporate structuring will simply route around all of this

**The objection, at full strength.** Every mechanism in this Regulation
assumes a moment at which value becomes visible, and corporate law exists
to move that moment. A hyper-automated undertaking is the ideal escape
artist: it needs little capital, so it need never list; it generates cash,
so it can pay its founders through decades of dividends, leveraged
recapitalisations and selective buybacks while the warrant sits dormant
for ever. If it must eventually deal, it deals in a capital stack the
Reserve does not sit in: seed through Series G preferred with two- and
three-times participating liquidation preferences, so that a sale
distributes everything to preferred holders and the Reserve's three per
cent of common is worth precisely nothing. If the trigger still nears, the
group demerges: model weights, training infrastructure and user base
migrate to an unlisted sister, and what floats is a low-margin European
storefront. If all else fails, a friendly private credit fund converts
debt to equity in a preventive restructuring, old equity is extinguished
by court order, and the same people own the same models through a new
company the following morning. Meanwhile the shares the Reserve does hold
in third-country parents are taxed at source at rates it cannot reclaim,
because a supranational body resident nowhere has no treaty to invoke.
Each of these is ordinary practice, not abuse; the instrument is a
crystallisation event in a world that has spent forty years learning to
avoid events.

**What it gets right.** All of it. An instrument that hangs on a single
trigger will be routed around by people who structure for a living, and a
regulation that says so only in its recitals has conceded the point. The
answers below are additions the file did not have; they came from outside
review and the memorandum says so.

**The answer the instrument must give.** Close the timing, the ranking,
the perimeter and the exit, and be honest where the closure is partial.

Timing first: the warrant no longer waits on a sale. Article 5(3) makes
it crystallise where shareholder extraction over three consecutive years
exceeds 25 % of the undertaking's turnover from the covered activity, which
is the point at which staying private has become a way of paying oneself
rather than a way of building; and in any event on the seventh anniversary of issuance,
whatever the undertaking has or has not done. An undertaking may still
stay private for ever. It may no longer stay private and be paid.

Ranking second: Article 5(4)(b) entitles the Reserve to shares ranking,
for dividends and for the proceeds of any sale or liquidation, equally
with the most favourably ranking class created after designation, and with
ordinary shares otherwise. Three per cent of a common tranche standing
behind a three-times participating preference is not three per cent of
anything, and the instrument now says which three per cent it means,
without taking from investors the preference they actually paid for before
designation. Article 5(10) makes any reorganisation whose main purpose or
effect is to put the Reserve below where that paragraph places it
ineffective as against the Reserve, while leaving it good between the
parties to it.

Perimeter third: Article 5(11) requires the transferee to issue a warrant
of its own where automated assets go to an affiliate or a commonly
controlled entity or leave at less than arm's length, and leaves the
transferor bound in respect of what it retains. The aggregate across the
covered undertaking and every transferee is capped at the stated
percentage of their combined capital, so that closing this route cannot
turn into a multiplier on a group that divides itself. Article 2(14) names what may not be
walked out of the door: model parameters, training and inference
infrastructure, data sets, the intellectual property the service depends
on. This is the succession logic of merger control rather than an
invention.

Exit fourth: Article 5(12) reattaches the obligation where the automated
assets emerge from insolvency or a restructuring under Directive (EU)
2019/1023 into an entity controlled by the same people, or in which those
people hold the majority of the economic rights, and requires a warrant to
be issued afresh within three months. A genuine failure still extinguishes the
Reserve's holding, as it extinguishes every shareholder's, because the
Reserve is an owner and owners bear that. What it does not do is bless the
version where the owners survive and only the obligation dies.

And the honest partial: source taxation. A Union regulation cannot confer
on the Reserve a treaty benefit that a third country has not granted, and
a body resident nowhere may be withheld against at the full statutory
rate. Two answers were drafted and struck. Instructing the Commission to
negotiate with third countries would have commanded a prerogative that
Article 218 TFEU places elsewhere. Permitting the Reserve to route its
holdings so as to reduce the rate would have written treaty shopping into
an instrument whose entire case is that capital should be broadly owned
and should pay what it owes; hostile counsel had the headline ready, and
was right to have it. What survives is Article 8(5): the Reserve
publishes each year the tax it could not reclaim, and the Commission
answers for it in the Article 14 report. That is a smaller answer than the
problem, and it is the honest one. A leak reported annually is a leak the
campaign can be judged on; a leak nobody measures only grows.

One route counsel kept and the instrument deliberately leaves open. An
undertaking may borrow heavily from lenders who are nobody's relation, pay
them market interest, and arrive at the long-stop worth less than it would
have been unlevered. That is not extraction and the definition should not
pretend otherwise: the money goes to strangers, not to insiders, and the
founders are poorer by exactly the same proportion as the Reserve. Every
shareholder in a leveraged company owns a smaller claim on a larger
balance sheet, and an instrument that took 3 % of the equity cannot also
insist the equity be unencumbered. What the file must not do is confuse
that with the routes above, where value leaves for pockets that are the
same pockets. Leverage is a risk the Reserve takes as an owner; extraction
is a transfer the Regulation stops.

**Design consequence.** DC-35: crystallisation triggers on extraction and on
time, not only on a sale. DC-36: subject to the rescue carve-out, the
Reserve's shares rank with the most favoured class created after the
designation, leaving earlier preferences untouched, and subordinating
arrangements are ineffective as against the Reserve. DC-37: the transferee
issues its own warrant over its own capital; the transferor stays bound for
the automated assets it retains, and the aggregate across them never exceeds
the stated percentage of their combined capital. DC-38: unrecoverable source
taxation is published annually; the instrument does not direct the Reserve
to arrange its holdings to reduce it. DC-39: the obligation reattaches where
the same owners reacquire the assets out of a restructuring.

### 19. Sweden tried this and could not even legislate it

**The objection, at full strength.** This mechanism is not new and it has
already failed, in the one country most likely to have carried it. The
Meidner plan, endorsed by the Swedish trade union confederation's congress
in 1976, required profitable undertakings to issue new shares worth 20 % of
their annual profits to collectively held funds, year after year, until
those funds held a majority of the shares. That is this instrument's
mechanism: a compulsory issuance of new equity to a collective holder,
settled in shares rather than cash, calibrated to the undertaking's own
prosperity.

It did not survive its own drafting. By the time the Riksdag legislated in
1983, the compulsory share issuance had been abandoned and replaced with a
levy on profits and on the wage sum, capped in aggregate and limited to
holdings of no more than 8 % of any one undertaking. The design converted,
under political pressure and before enactment, into precisely the thing this
memorandum spends Article 8 and objection 2 insisting this instrument is
not: a tax. Then Swedish business mobilised against even the diluted version
on a scale without modern parallel, with a demonstration on 4 October 1983
that drew between 75 000 and 100 000 people where the organisers had
expected 5 000, and repeated it annually until a change of government
abolished the funds in 1991, against minimal resistance from the movement
that had proposed them.

The reading is unkind and it is available to anyone who knows the file. In
the most union-friendly advanced economy in the world, at the peak of
organised labour's power, with a sympathetic government, the compulsory
issuance of equity to a collective fund proved unlegislatable, converted
into a fiscal measure at the drafting stage, and was repealed within eight
years by the first government that wanted to. A drafter who does not know
this has not done the reading. A drafter who knows it and omits it is
hiding it.

**What it gets right.** Almost all of it, as history. The mechanism is the
same family. The conversion to a levy is real and is the sharpest available
evidence for objection 2's characterisation attack, because it shows
experienced legislators reaching for the fiscal instrument when the
equity instrument became politically impossible. The 1991 abolition is a
genuine instance of the raid this instrument drafts Chapter VI against, and
it belongs beside Poland, Spain and Ireland in the evidence base rather
than being left out because it is inconvenient. The mobilisation is a real
prediction about what happens when capital reads a proposal of this kind
as a transfer of control.

**The answer the instrument must give.** Three differences, each of which
maps onto a specific reason the Swedish design failed, and none of which is
cosmetic.

First, terminus. Meidner's funds were designed to accumulate without limit
until ownership changed hands, and its author said so; that was the point,
not a side effect. This instrument takes 3 % of fully diluted capital once,
per designation, with the aggregate across an undertaking and every
transferee capped at that same percentage under Article 5(11) and Article
7(2). There is no path from this instrument to control, because the
arithmetic does not permit one. An opponent who says otherwise is arguing
against a different proposal.

Second, control. The Swedish funds voted, and they were run by the unions.
The scholarship on the defeat is consistent that the mobilisation was about
who would govern the companies rather than about the money, and the 8 %
ceiling was itself an attempt to answer that fear. The Reserve holds
non-voting shares under Article 5(4)(a), is forbidden by Article 9 from
seeking or exercising influence, and DC-32 makes economic participation the
maximum. The constituency that made 1983 possible was employers who
believed they were being nationalised in instalments. That belief cannot be
formed about an instrument that cannot vote.

Third, beneficiary. The Swedish funds accrued to a labour movement, which
made them a party question in a two-party fight. This instrument's
distributions accrue equally to every citizen of the Union under Article 10,
including the shareholders and the employees of the designated undertakings
themselves. That does not make opposition impossible. It makes "them
against us" harder to draw.

What this file will not claim is that the differences make the political
economy safe. They do not. The honest position is that Sweden shows the
mechanism can be legislated only if it is visibly bounded, visibly
powerless as to control, and visibly universal in who it pays, and that a
proposal failing any of those three has a documented way of dying. This
instrument is drafted to satisfy all three, and objection 4 already prices
the residual political risk rather than denying it.

**Design consequence.** DC-41: the instrument must be bounded, without votes
or control rights, and universal in who it pays, all three at once, because
the Swedish precedent shows that failing any one of them is sufficient to
lose. The word to avoid is passive. The Reserve does assert claims: Article
5(4)(b) fixes its rank and Article 5(10) makes subordinating arrangements
ineffective against it, and an opponent will call that anything but passive.
The defensible claim is narrower: the Reserve holds no votes, appoints no
one, and has no say in the management of the undertaking. Even that is not
the end of it. Hostile counsel makes the further point that a rank the
undertaking cannot subordinate constrains how it raises distressed or
preference capital, since new money normally demands seniority, and calls
that a veto over capital structure in substance. It is not a governance
right and Article 5(10) leaves the arrangement effective between the parties
to it. It was, all the same, a constraint on financing that the word passive
would conceal, and it is now answered in the text rather than carried: the
second subparagraph of Article 5(10) lets genuinely new money rank ahead of
the Reserve, at arm's length, from persons unconnected with the undertaking
and its controllers, while the undertaking is in a likelihood of insolvency
or must meet a prudential requirement, and only to the extent of the new
consideration provided. Rescuers are paid before the Reserve; engineered
seniority beyond the new money is still caught, because that is where the
abuse lives, and the undertaking bears the burden of proof. DC-42: the wage-
earner funds belong in the evidence base as a raid precedent and in this
file as an objection, stated before an opponent states it.


### 20. Taking the voteless shares hands control to the people you named as the problem

**The objection, at full strength.** The instrument takes three per cent of
the economic value and none of the votes. The arithmetic of that is not
neutral. Before the warrant, the existing holders own all of the capital and
cast all of the votes; after it they own ninety-seven per cent of the capital
and still cast all of the votes. Their control per euro of their own money has
gone up, by about three per cent, and the Union has handed it to them. A file
whose diagnosis is that the ownership of productive capital is too narrow
responds by creating the largest permanently voteless shareholder in Europe
and widening, at every covered undertaking, precisely the wedge between
cash-flow rights and control rights that corporate-governance scholarship
identifies as the most reliable predictor of minority expropriation and
unaccountable management. The founders of the frontier firms already hold
control through dual-class structures on minority economic stakes. This gives
them more of it, for free, by statute.

The legitimation point is worse than the arithmetic. Once the Union itself
accepts voteless equity as the form its own citizens' participation takes, no
Union institution can coherently object to dual-class listings, loyalty shares
or any other separation of ownership from control. The instrument does not
merely tolerate the wedge; it endorses it, in a Regulation, on behalf of
450 million people.

**What it gets right.** The mechanical claim is exactly true and this file
should not pretend otherwise: non-voting shares raise the relative voting
weight of every voting share, and the raise here is real. If the diagnosis
were about who controls firms rather than about who receives the returns to
capital, the instrument would be answering a question it did not ask, and
answering it in the wrong direction.

**The answer the instrument must give.** Not that this is the wrong lens. An
earlier draft of this passage called the governance reading a category error,
on the ground that the instrument's claim is distributional. Four review
gates rejected that in the same terms, and they were right: an instrument
that alters the ratio of cash-flow rights to control rights at every
undertaking it touches is a governance instrument in effect, whatever it is
in intention, and it is properly judged on its effects. The answer below
concedes the effect and defends the choice.

The choice was between three positions and the file has taken the least bad
one. A Reserve with votes proportionate to its stake is a politically
directed shareholding in every frontier firm in the internal market: it is
objection 9's honeypot with a lever attached, and objection 16's golden
share, which the Court has struck down in every form it has taken since
Commission v Germany (C-112/05). A Reserve with no stake at all abandons the
distributional claim entirely. A Reserve with economic participation and no
control accepts a real governance cost in exchange for the only position that
survives Article 63 and the golden-share line. Article 5(4)(a) and Article
9(1)(a) to (c) put that beyond the drafter's later convenience, and DC-43
keeps any successor honest about it.

On magnitude, one comparison and its limits. Three per cent of enlarged
capital raises the remaining holders' voting weight by roughly one
thirty-second of itself, and buy-back programmes of that order run routinely
at the undertakings this instrument covers without anyone calling them a
transfer of control. That comparison is offered for size and for nothing
else, and it does not survive being pushed further: a buy-back is elective,
is executed for consideration and returns cash to the holders whose weight
rises, whereas this is compulsory, is subscribed at nominal value and returns
nothing to them. Reviewers were right to say the two are not alike in kind.
They are alike in the one respect the paragraph uses them for, which is how
much the voting weight of a remaining share actually moves.

On legitimation, the objection lands and is only partly answered. Voteless
shares are not this instrument's invention: Union company law has permitted
them for decades and every Member State provides for them, so the Reserve
takes a class the market already trades. But the Union has lately been
legislating in the other direction, adding safeguards around multiple-vote
structures precisely because the separation of ownership from control is
understood to be a hazard, and a Regulation that plants a permanent voteless
block in every covered undertaking sits uneasily beside that. The honest
statement is that the instrument spends some of the Union's authority on the
proposition that economic participation without control is a legitimate form
of ownership, and that the price is real. It is paid deliberately, because
the alternative is a Union holding votes in the undertakings it regulates,
and this file would rather defend a wedge than defend that.

The precise interaction with the Union's multiple-vote share legislation is
recorded as an open acquis interface point rather than argued here from a
citation this file has not yet verified, and it joins the acquis
interface points already recorded on the list before filing.

**Design consequence.** The instrument's claim is distributional and no
amendment gives the Reserve votes without arguing itself as a different
instrument, but the governance effect is conceded and defended rather than
disclaimed (DC-43). The relative voting effect on existing holders is stated
with its size, and the buy-back comparison is confined to magnitude with its
disanalogy stated in the same breath (DC-44).


### 21. Why three per cent, and not one, or ten

**The objection, at full strength.** The number is asserted. Nowhere in this
file is it derived. Article 52(1) of the Charter permits a limitation on the
right to property only where it is necessary and genuinely meets an objective
of general interest, and necessity is the question a bare figure cannot
answer: if three per cent achieves the objective, one per cent is the less
intrusive means and the measure fails; if one per cent does not achieve it,
the file has not shown why three does. The reviewing court will ask the
legislature to show its work, as it asked in every proportionality case worth
citing, and this file will hand it a round number that sits comfortably below
the level at which the objection "you are nationalising them" becomes easy to
make. That is a political calibration wearing the clothes of a legal one, and
the Commission's Legal Service will see it on the first reading. Every other
number in the instrument is tied to something: the thresholds in Article 3 to
measurable quantities, the seven-year long stop to the observed interval
between designation and realisation. The one number that determines how much
is taken is tied to nothing.

**What it gets right.** All of it. This is the weakest load-bearing point in
the file, and no quality of drafting anywhere else repairs it. It would be
worse than useless to answer it here with a derivation invented to fit a
figure already chosen: that is precisely the vice the objection names, and a
reviewer who caught it would be entitled to discount everything else in this
memorandum.

**The answer the instrument must give.** The objection is correct, and the
attempt to answer it produced something worse than a missing derivation: a
demonstration that no derivation of the kind a court would want can be
produced at all while Article 1 stands as drafted.

The published model is linear in the percentage. Annex II's arithmetic, as
implemented in the simulator on the campaign site, accumulates the Reserve's
capital by adding the warrant percentage of each crystallising flow, and
every distribution downstream is a fraction of that capital. Doubling the
percentage doubles the dividend at every horizon and halving it halves it,
exactly, in every scenario the simulator offers. The computation is set out
in evidence/warrant-percentage.md and anyone can rerun it. There is no
threshold, no kink and no discontinuity anywhere on the curve, which means
there is no percentage at which the instrument starts working and below which
it does not.

That is fatal to the obvious defence. Necessity under Article 52(1) asks
whether a less intrusive measure would achieve the objective. If the
objective is Article 1's, the participation of citizens in the capital value
created by hyper-automated undertakings, then one per cent achieves it, and
so does one tenth of one per cent, because each produces participation and
the Article states no quantity that participation must reach. An opponent
does not even need to argue that three per cent is too much. They need only
observe that a smaller figure achieves the stated objective, and the
necessity limb fails on the instrument's own words.

So the defect is not in this memorandum, and it cannot be repaired here. It
is in Article 1. An instrument that interferes with Article 17 of the Charter
and states its objective qualitatively has left the necessity limb with
nothing to be tested against, and no amount of argument about three per cent
substitutes for that. Either the objective acquires a quantity against which
a percentage can be measured, or the Article 52(1) defence rests on the
proportionality limb alone, which asks only whether the burden is excessive
and to which the answer is the ceiling rather than the floor.

The ceiling is where the file's defence honestly sits today. A percentage
large enough to strip existing holders of the substance of their property
crosses from a regulation of use into a deprivation. Hauer (44/79) is the
authority for the distinction itself and for the proposition that the right
to property may be regulated in the general interest; it concerned a
temporary restriction on planting vines and is not authority for a
compulsory transfer of equity, and this file does not offer it as one. James
and Others v United Kingdom (1986) is cited for the same distinction and for
nothing further: the taking there was accompanied by compensation, so it is
authority about where the line runs and not about what may be taken without
paying for it. Objection 1 carries that argument and its honest residue,
which is that no decided case places a permanent, non-crisis, uncompensated
dilution of a healthy undertaking on the right side of the line. Three per
cent is comfortably below any plausible deprivation ceiling. Being below a
ceiling is a proportionality argument, not a necessity argument, and this
file will not dress one as the other.

That repair has now been made, and this passage records both the repair
and its honest limit. Article 1(2) states the objective as an ownership
position: holdings per citizen of the order of six months of the median
equivalised disposable income in the Union, in constant prices, within a
generation of the first designations. On the published model and the
amended designation test of Article 3(2)(b), the aggregate designated
value is of the order of EUR 20 trillion on August 2026 figures
(evidence/designation-count.md), and the stake per adult within a
generation is about EUR 8 400 at three per cent, EUR 5 600 at two and
EUR 2 800 at one (evidence/sizing-the-ask.md). Six months of median
equivalised disposable income is of the order of EUR 9 000. Three per
cent is therefore the smallest integer percentage capable of approaching
the stated objective, one per cent manifestly cannot, and the necessity
limb of Article 52(1) has, for the first time, a quantity to test
against, published, reproducible, and revisited at every Article 14
report, where the same clause that could raise the percentage on the
evidence is the clause that lowers it.

The honest limit is the circularity a reviewer will point out and this
file states first: with a linear model, any target-percentage pair is
arguable, so the target itself is not derived, it is chosen, openly, in
the enacting terms. That is not a defect the drafting can remove; it is
what a legislative objective is. The case law requires a stated objective
and a reasoned relationship between the measure and it, not an objective
that derives itself, and no instrument's does. What this file no longer
does is assert a percentage against no objective at all.

**Design consequence.** The percentage is derived as the minimum integer
consistent with the objective stated in Article 1(2), on a published and
reproducible model, and the circularity inherent in choosing the target is
stated rather than concealed (DC-45). Article 1(2) carries the quantified
objective, assessed in each Article 14 report in both directions, and the
derivation is revisited whenever the designated set or the model moves
(DC-46).


## The constraints table

The articles are drafted against this table. A draft that violates a DC fails
review regardless of its prose.

| DC | Constraint | Source objection |
|---|---|---|
| DC-1 | Prospective warrants on future value; never retroactive transfer | 1 |
| DC-2 | High, objective, group-consolidated thresholds | 1, 5, 17 |
| DC-3 | Statutory passivity; crystallisation only at defined statutory events, never at a discretionary or political one | 1, 6 |
| DC-4 | No monetary flow from undertakings; instruments only | 2, 4 |
| DC-5 | Distributions are property income of the reserve | 2 |
| DC-6 | Severable layering for partial ECI registration | 2 |
| DC-7 | Union warrant standards; Member State custody via pension rails | 3, 14 |
| DC-8 | Minimum standards, not uniform machinery | 3 |
| DC-9 | Obligation never convertible into a flow charge | 4 |
| DC-10 | Market-access nexus, not establishment nexus | 5, 17 |
| DC-11 | Substance-over-form headcount consolidation | 5 |
| DC-12 | Event-triggered crystallisation; no ongoing valuation | 6 |
| DC-13 | Permanently non-voting economic interests | 6, 16 |
| DC-14 | Dividend communicated as compounding from small | 6 |
| DC-15 | Recitals argue ownership and mechanism, never wage-share decline | 7 |
| DC-16 | Value stated under both futures | 7 |
| DC-17 | Strongest nulls cited in the memorandum itself | 8 |
| DC-18 | Stated falsification condition with a date | 8 |
| DC-19 | No sovereign debt holdings | 9 |
| DC-20 | Entrenchment from day one: express amendment only, published independent assessment, honesty about Treaty limits | 9 |
| DC-21 | No emergency clause | 9 |
| DC-22 | Individual claims incapable of surrender or seizure; distributed amounts owned and inheritable | 9, 13 |
| DC-23 | Raid resistance claimed as friction, never impossibility | 9 |
| DC-24 | Self-executing by operation of law; no programme machinery | 10 |
| DC-25 | Consumer surplus affirmed; instrument additive to it | 11 |
| DC-26 | Explicit scope-and-limits recital | 12 |
| DC-27 | UBI distinction carried by legal form | 13 |
| DC-28 | Funding-source novelty only; existing rails for delivery | 14 |
| DC-29 | Interference capped at the stated percentage in execution; independent, separately challengeable valuation; judicial review | 1 |
| DC-30 | Essential elements (trigger, reserve ownership, entitlement, interference) in the articles, never delegated | 1 |
| DC-31 | Wherever a per-citizen payout figure is shown, the per-citizen stake in the Reserve is shown beside it | 15 |
| DC-32 | Economic participation is the maximum: no control right, veto or governance privilege attaches to the Reserve's holdings, binding this instrument and anyone amending it, without pretending to bind a future legislature | 16 |
| DC-33 | For third-country-law undertakings the warrant is an obligation of result as a market-access condition, never an override of foreign company law | 17 |
| DC-34 | No tier between valuation and the courts; correction is ex post and the transaction never waits | 6 |
| DC-35 | Crystallisation triggers on shareholder extraction and on time, not only on a sale | 18 |
| DC-36 | The Reserve's shares rank with the most favoured class created after the designation, leaving earlier preferences untouched; subordinating arrangements are ineffective against the Reserve, save for new money at arm's length from unconnected persons in rescue, to the extent of the new consideration | 18 |
| DC-37 | The transferee issues its own warrant over its own capital; the transferor stays bound for what it retains, and the aggregate across them never exceeds the stated percentage of their combined capital | 18 |
| DC-38 | Unrecoverable source taxation published annually; the Reserve is not directed to arrange its holdings to reduce it | 18 |
| DC-39 | The obligation reattaches where the same owners reacquire the assets out of a restructuring | 18 |
| DC-40 | Below a de minimis the distribution interval lengthens; it never becomes a reason not to pay | 15 |
| DC-41 | Bounded, without votes or control rights, and universal in who it pays: the Swedish wage-earner funds show that failing any one of the three is enough to lose. The Reserve does assert claims as to rank and against subordination; what it never acquires is votes, board seats or any say in management | 19 |
| DC-42 | The wage-earner funds are stated as an objection here and as a raid precedent in the evidence base, before an opponent states them | 19 |
| DC-43 | The claim is distributional and no amendment gives the Reserve votes without arguing itself as a different instrument; the governance effect on remaining holders is conceded and defended, never disclaimed as the wrong lens | 20 |
| DC-44 | The relative voting effect on existing holders is stated with its size, not left for an opponent to compute, and any comparison drawn to buy-backs is confined to magnitude with its disanalogy stated alongside | 20 |
| DC-45 | The percentage is the minimum integer consistent with the objective stated in Article 1(2), derived on a published, reproducible model; the circularity of choosing the target is stated, never concealed | 21 |
| DC-46 | Article 1(2) carries the quantified objective, assessed in each Article 14 report in both directions; the derivation is revisited whenever the designated set or the model moves | 21 |

## Status

Objections are OPEN until the articles answer them, save where noted below;
12 is CONCEDED by scope. Objection 18 was added on 21 August 2026 from an
external review of corporate-structuring routes around the instrument.
Unlike objections 16 and 17, it did not find the answers already in the
articles: it describes five routes. Four of them are now closed by
amendments to Articles 2 and 5. The fifth, source taxation, prompted an
amendment to Article 8 but is not closed, and the answer to that objection
says so: publication is a smaller answer than the problem. A sixth item,
borrowing at arm's length, was considered and deliberately left open,
because it is not the extraction the objection is about. It is the first objection in
this file whose answer had to be written rather than cited.

Objections 16 and 17 were added on 20 August 2026 from an external
challenge (the Article 63 golden-share line; qualified-effects overreach);
their answers were already in Articles 3, 5(5) and 9, which is what
drafting against the table is for, and the residue they add is DC-32 and
DC-33.
Objection 1 carries the largest legal risk and objection 6 the largest design
risk. Gate 1's admissibility letter still leads with objections 1 and 2, but
recalibrated by the drafting research: registration is the lower hurdle
(manifestly-outside test, partial registration, the registered wealth-tax
ECI), so the letter tests the characterisation for the Council stage, not for
the register.

Objection 2's fiscal reading has now been reached independently by three
readers: hostile counsel on 27 August 2026, the ECI Forum's advisers on 27
August 2026 and an ECI veteran on 5 September 2026 (pipeline/EXTERNAL-REVIEWS.md,
review 5). The objection is unchanged; what changes is its status, from an
adversary's argument to the ordinary reader's first impression, which the
presentation, not the drafting, must now answer.


# SOURCE: own-the-machine/regulation/memorandum/explanatory-memorandum.fr.md

<!-- Traduction de courtoisie. Le texte anglais fait foi ; en cas de divergence, l'anglais prévaut. Source: explanatory-memorandum.md -->

# Exposé des motifs

Accompagnant le projet de règlement du Parlement européen et du Conseil relatif à des règles harmonisées concernant la participation des citoyens aux gains de productivité automatisés.

Le présent exposé des motifs suit la structure que la Commission utilise pour ses propres propositions. Il est rédigé par des citoyens, non par la Commission, et n'est pas obligatoire : le règlement (UE) 2019/788 permet à une initiative citoyenne de joindre un projet d'acte juridique et n'exige rien de ce type. Il existe parce que les questions auxquelles les services de la Commission devraient répondre au sujet de cet instrument méritent qu'on y réponde avant qu'elles ne soient posées, et parce qu'un dossier qui ne peut y répondre n'est pas prêt à faire l'objet de suites. Lorsqu'une réponse n'existe pas encore, le présent exposé des motifs l'indique plutôt que de remplir la rubrique.

---

## 1. Contexte de la proposition

### 1.1 Motivation et objectifs de la proposition

Les systèmes cognitifs automatisés commencent à produire des résultats à une échelle qui ne requiert plus une quantité correspondante de travail humain. Lorsqu'un tel découplage se produit, les revenus de la production reviennent aux détenteurs du capital qui incorpore l'automatisation, et la part revenant aux citoyens sous forme de salaires diminue parallèlement à la part du travail.

Le problème auquel le présent règlement entend remédier n'est pas ce résultat en soi, qui relève de multiples instruments, mais un problème plus restreint relevant de la compétence de l'Union: la propriété du capital dans lequel se concentrent ces rendements est extrêmement restreinte, et les États membres ont commencé à y réagir de manière isolée, par des prélèvements nationaux divergents, des mécanismes de participation et des propositions visant à taxer la production automatisée. Ces divergences fragmentent le marché intérieur précisément pour les entreprises qui exercent leurs activités à l'échelle de l'ensemble de celui-ci.

L'objectif est énoncé et quantifié à l'article 1er, paragraphe 2: la participation des citoyens de l'Union à la valeur en capital créée par la production hyperautomatisée, à une échelle où les avoirs sous-jacents au droit de chaque citoyen atteignent un montant de l'ordre de six mois de revenu disponible équivalent médian dans l'Union dans le délai d'une génération à compter des premières désignations.

### 1.2 Cohérence avec les dispositions existantes dans le domaine d'action

L'architecture de désignation suit le règlement (UE) 2022/1925 (règlement sur les marchés numériques): critères qualitatifs cumulatifs, seuils quantitatifs établissant une présomption réfragable, autonotification, voie de désignation en deçà des seuils fondée sur les faits et pouvoir anti-contournement. Il s'agit d'une réutilisation délibérée d'une structure que le législateur de l'Union a déjà adoptée et que la Cour n'a pas remise en cause.

L'articulation avec le droit des sociétés est rédigée sous la forme d'une dérogation expresse et étroite à la directive (UE) 2017/1132 plutôt que d'une primauté générale, suivant ainsi la formule de l'acquis en matière de résolution. L'articulation avec le régime des prospectus constitue une exemption expresse au titre du règlement (UE) 2017/1129. L'article 1er, paragraphe 5, préserve la directive (UE) 2016/2341 et le règlement (UE) 2019/1238, sous réserve des dispositions de l'article 11.

Cinq points d'articulation avec l'acquis demeurent ouverts et sont énumérés à la section 5.4. Ils sont recensés plutôt que résolus, ce qui reflète fidèlement l'état d'avancement.

### 1.3 Cohérence avec les autres politiques de l'Union

L'instrument retient des fonds propres sans droit de vote et ne confère aucun droit de gouvernance, ce qui le maintient hors du champ couvert par la jurisprudence de la Cour relative aux participations publiques spécifiques (Commission c. Allemagne, C-112/05, et jurisprudence ultérieure). Ce choix a un coût, examiné à l'objection 20: les actions sans droit de vote augmentent le poids de vote relatif des détenteurs restants, et l'Union a récemment légiféré en sens inverse sur les structures d'actions à droits de vote multiples dans la directive (UE) 2024/2810. L'interaction avec cette directive constitue un point d'articulation ouvert et non résolu.

Aucune disposition du présent règlement ne crée de ressource propre de l'Union, et aucun élément n'entre dans le budget de l'Union. Il s'agit d'une contrainte de conception et non d'une propriété accessoire: voir section 4.

---

## 2. Base juridique, subsidiarité et proportionnalité

### 2.1 Base juridique

La base juridique est exposée par couche, et non selon un centre de gravité
unique pour l'ensemble de l'acte, car des procédures législatives
incompatibles ne peuvent être fusionnées en une seule base (Dioxyde de
titane, C-300/89) et parce qu'une argumentation unitaire concéderait la
qualification de la couche la plus faible aux opposants à la couche la plus
forte. La note sur la divisibilité expose ces couches; la règle de
décomposition no 3 impose ce traitement. L'article 114 du TFUE sous-tend le
régime de désignation, les obligations de transparence et le warrant: des
règles adressées à des entreprises opérant sur l'ensemble du marché
intérieur, éliminant les divergences que des prélèvements nationaux
distincts sur la participation et l'automatisation créent déjà. La
Commission a enregistré une initiative reposant sur cette même logique de
divergence en terrain au moins aussi contesté : l'initiative de 2023 sur
l'imposition des grandes fortunes, par la décision (UE) 2023/1487. L'avis
indépendant obtenu par l'intermédiaire du Forum de l'ICE le 27 août 2026,
consigné dans pipeline/EXTERNAL-REVIEWS.md et qui ne lie personne, interprète cette décision de la même manière et recommande de la citer ici. L'article 352 du
TFUE sous-tend les éléments que l'article 114 ne couvre pas, à savoir
l'établissement de la Réserve en tant qu'organisme au niveau de l'Union et
le droit individuel des citoyens. Cette base n'est pas un terrain vierge
pour la participation : le Conseil a agi sur la participation des
travailleurs salariés aux bénéfices et aux résultats de l'entreprise par la
recommandation 92/443/CEE, adoptée sur le prédécesseur de l'article 352. Une
recommandation ne crée aucune compétence et le présent exposé des motifs n'en revendique aucune ; ce qu'elle établit est plus étroit et utile : l'Union a
déjà traité la participation aux résultats de l'entreprise comme une
question de niveau européen sur cette base. Ces éléments sont rédigés de
manière à être séparables, précisément pour que l'unanimité qu'ils
requièrent ne puisse prendre en otage les couches fondées sur l'article 114,
et pour qu'un enregistrement partiel ou une annulation partielle élague
l'instrument plutôt que de le détruire.

L'article 114, paragraphe 2, du TFUE exclut les dispositions fiscales, et la
question de qualification qui en découle constitue le risque juridique le
plus sérieux que comporte le présent instrument. Elle est exposée dans toute
sa force et traitée à l'objection 2, et c'est dans cette objection, et non
dans le présent exposé des motifs, que se trouve l'argumentation. En résumé:
l'obligation porte sur un actif et non sur un flux, est payable en actions
et jamais en numéraire, ne finance aucun budget, ne transite par aucun
trésor public et ne confère aucune recette à l'Union. L'avis du Forum de
l'ICE du 27 août 2026 mentionne l'article 115 du TFUE comme base
envisageable si cette qualification venait à échouer ; il est consigné ici,
non retenu. L'article 115 n'exclut pas les dispositions fiscales, mais,
selon l'analyse des conseillers eux-mêmes, il exige la même lecture
d'harmonisation que l'article 114 tout en abandonnant le vote à la majorité
qualifiée, et la rédaction par couches intègre déjà l'unanimité là où elle
est inévitable.

### 2.2 Choix de l'instrument

Un règlement, et non une directive, pour trois raisons. L'obligation s'attache à un nombre restreint d'entreprises opérant sur l'ensemble du marché intérieur, et une transposition dans vingt-sept régimes nationaux reproduirait exactement les divergences que la mesure a pour objet d'éliminer. Le warrant doit avoir un contenu identique dans chaque État membre car une entreprise donnée émet un instrument unique auprès d'une Réserve unique. Et le droit est détenu directement par les citoyens à l'encontre d'un organisme de l'Union, ce qui exige une applicabilité directe plutôt que des mesures nationales d'exécution. Le chapitre V confie l'administration des droits à des véhicules nationaux, ce qui constitue le lieu approprié et autorisé pour les variations nationales.

### 2.3 Subsidiarité

L'objectif ne peut pas être atteint de manière suffisante par les États membres agissant séparément, car les entreprises concernées opèrent sur l'ensemble du marché intérieur et des mesures nationales créeraient précisément la divergence que le règlement élimine. Un régime national de participation s'appliquerait à des entreprises dont la valeur découle d'une activité à l'échelle de l'Union, ce qui, soit manquerait sa cible, soit produirait vingt-sept prétentions incompatibles sur le même capital. Le considérant 34 en contient la formulation formelle.

### 2.4 Proportionnalité

L'ingérence dans le droit de propriété au titre de l'article 17 de la Charte est réelle et n'est pas minimisée dans ce dossier. La proportionnalité est assurée par cinq caractéristiques de la rédaction: le pourcentage est fixe et faible; l'obligation est prospective et ne s'attache qu'à la valeur constituée après la désignation; elle ne se cristallise que lorsque les propriétaires mêmes de l'entreprise réalisent de la valeur; l'évaluation est indépendante et susceptible de recours distinct au titre des articles 6 et 7; et la détention est passive, sans droit de vote, sans siège au conseil d'administration et sans direction de la gestion.

Sur le volet de la nécessité, le présent exposé des motifs prend acte d'une limite plutôt que de revendiquer un point fort. L'article 1er, paragraphe 2, énonce désormais un objectif chiffré, et trois pour cent constitue le plus petit pourcentage entier qui s'en approche selon le modèle publié, de sorte que la nécessité peut pour la première fois être démontrée à partir d'une quantité définie plutôt que simplement affirmée. Toutefois, le modèle étant linéaire par rapport au pourcentage, la cible elle-même est choisie plutôt que déduite. L'objection 21 expose ce point de manière exhaustive, y compris sa circularité, avant qu'un réviseur ne le fasse.

---

## 3. Résultats des évaluations ex post, des consultations des parties prenantes et des analyses d'impact

### 3.1 Évaluations ex post

Néant. Il n'existe aucun instrument de l'Union en vigueur dans ce domaine susceptible d'être évalué.

### 3.2 Consultation des parties prenantes

Aucune consultation formelle n'a été menée, et aucune n'aurait pu l'être : il s'agit d'un projet citoyen et aucune institution n'a procédé à une consultation à son sujet. Affirmer que « les parties prenantes ont été consultées » serait faux, et le présent exposé des motifs ne l'affirmera pas.

Ce qui existe en lieu et place est un examen contradictoire, mené sur le texte à chaque étape et publié dans son intégralité : six points de contrôle couvrant la forme juridique, le respect des contraintes, la base juridique, l'analyse contradictoire hostile, la cohérence avec l'acquis et la fidélité de structure, chaque verdict étant consigné, y compris les échecs, ainsi qu'un registre public consignant ce que chaque cycle a modifié et ce qui a été refusé, motifs à l'appui. Vingt et une objections sont formulées sous leur forme la plus rigoureuse et reçoivent une réponse, plusieurs d'entre elles étant fatales si elles étaient fondées, et au moins deux options de conception complètes ont été écartées au cours de ce processus avant d'atteindre le stade de la publication.

Cela ne remplace pas la consultation des personnes qu'un instrument lierait, et le présent exposé des motifs ne le présente pas comme tel. C'est ce qu'un dossier peut accomplir avant d'avoir qualité pour consulter quiconque. Une demande relative à la recevabilité est en cours d'examen auprès du forum de l'initiative citoyenne européenne.

### 3.3 Analyse d'impact

Aucune analyse d'impact formelle au titre des lignes directrices pour une meilleure réglementation n'a été effectuée, et une initiative citoyenne n'est pas tenue d'en réaliser une. Ce qui suit constitue l'analyse existante, sous la forme utilisée par ces lignes directrices, en précisant ses limites.

**Options stratégiques envisagées.**

*Option 0, absence d'action de l'Union.* Les États membres continuent de légiférer séparément sur les prélèvements sur l'automatisation et les régimes de participation. Les divergences s'accentuent, les entreprises concernées sont confrontées à vingt-sept régimes ou à aucun, et la question de la propriété reçoit une réponse nationale là où elle ne peut trouver de réponse qu'à l'échelle à laquelle opèrent les entreprises. Il s'agit du scénario de référence par rapport auquel les autres options sont évaluées, et c'est l'option que l'examen contradictoire identifie systématiquement comme étant la plus sûre pour le législateur de l'Union et la pire pour l'objectif visé.

*Option 1, une taxe sur la production automatisée ou sur les jetons d'inférence.* Il s'agit de la famille concurrente directe : des propositions législatives de ce type existent dans des pays tiers, y compris une proposition déposée aux États-Unis en août 2026 prévoyant un taux progressif à mesure que le chômage augmente. Elle permet de lever des fonds plus tôt et en montants plus élevés au cours des premières décennies, ce que le warrant ne fait pas. Elle a été rejetée pour deux motifs de fond, et une troisième observation est consignée séparément car elle ne doit pas être confondue avec un motif. Premièrement, il s'agit d'un flux et non d'un actif, de sorte que les citoyens reçoivent un transfert plutôt qu'une détention, et la distinction entre une prestation et une participation constitue la thèse centrale du présent instrument : un transfert est renégocié annuellement et annulable à la majorité simple, une détention constitue une propriété. Deuxièmement, et pour la même raison, elle peut être abrogée par la majorité qui l'adopte, ce que l'historique des ponctions documenté dans le corpus de données probantes montre qu'il ne s'agit pas d'un risque théorique. L'observation distincte est qu'un prélèvement sur la consommation ou sur la production relève sans ambiguïté du domaine fiscal et exigerait l'unanimité en vertu de l'article 113 du TFUE. Il s'agit là d'une conséquence de la nature d'un tel instrument, et non d'un motif de lui préférer le présent instrument, et le présent exposé des motifs ne la présente pas comme telle. La thèse de la propriété est antérieure à toute question de compétence et demeurerait identique si les deux voies requéraient la même majorité. Le lecteur est fondé à mettre à l'épreuve cette affirmation au regard des quatre critères énoncés dans GOVERNANCE.md, qui ont été adoptés avant le choix de toute base juridique et qui rejettent les instruments fondés sur les flux selon leurs propres termes. La comparaison complète, y compris les ordres de grandeur, est publiée sous evidence/token-taxes.md.

*Option 2, un fonds souverain de l'Union capitalisé par le budget.* Cela nécessite des fonds dont l'Union ne dispose pas, entre en concurrence directe avec toutes les autres lignes budgétaires et aboutit à un fonds détenu par l'Union plutôt que par les citoyens, ce qui va à l'encontre de l'objectif d'appropriation et expose les actifs précisément à l'historique de ponctions documenté dans le corpus de données probantes.

*Option 3, une participation assortie de droits de vote.* Une Réserve détenant des actions avec droit de vote conférerait à l'Union une influence sur les entreprises qu'elle régule. Option rejetée : il s'agit du pot de miel assorti d'un levier de l'objection 9 et de l'action spécifique de l'objection 16, que la Cour a invalidée sous toutes ses formes.

*Option 4, le warrant de capital citoyen, privilégiée.* Sans droit de vote, pourcentage fixe, prospective, ne se cristallisant qu'à la réalisation par les propriétaires eux-mêmes, payable uniquement en actions. Elle est retenue parce qu'elle est la seule option identifiée qui transfère la propriété plutôt que des revenus et qui transforme l'abrogation en expropriation : un législateur futur peut toujours s'en saisir, mais il doit le faire au titre d'une privation de propriété, dans le respect de l'article 17 et de l'article 52, paragraphe 1, de la Charte, plutôt qu'en modifiant une ligne budgétaire. La règle DC-23 énonce le principe qui sous-tend ce choix, selon lequel la résistance aux ponctions constitue une friction et jamais une impossibilité, et le présent exposé des motifs ne revendique rien de plus qu'une friction.

**Incidences économiques.** Les entreprises désignées subissent une dilution de trois pour cent de leur capital, en une seule fois, se cristallisant lors de leur propre événement de liquidité, lors d'un prélèvement au profit des actionnaires supérieur au seuil fixé ou à l'échéance butoir de sept ans, la première occurrence étant retenue, de sorte que le calendrier leur appartient uniquement jusqu'à ce que l'échéance butoir soit atteinte. Les investisseurs intégreront dans les prix la dilution future obligatoire dès la désignation, ce qui constitue un coût réel examiné à l'objection 4. Neuf entreprises sont présumées désignées sur la base des chiffres d'août 2026, pour une valeur combinée d'environ 20,5 billions d'euros ; le calcul figure sous evidence/designation-count.md. L'instrument n'a aucun effet sur les entreprises extérieures à cet ensemble, et les petites et moyennes entreprises en sont très éloignées : les entreprises les plus à forte intensité capitalistique dépendantes de la main-d'œuvre observées atteignent un ratio valeur/masse salariale compris entre trente et quarante, pour un seuil fixé à quatre-vingts.

**Incidences sociales.** L'incidence sociale visée est la distribution égale d'une part de propriété aux citoyens de l'Union, sans condition de ressources, demande préalable ni critère d'éligibilité, le droit s'attachant en vertu de la citoyenneté de l'Union et les distributions étant effectuées à compter de l'âge de la majorité conformément à l'article 10 ; son ampleur attendue est énoncée en toute franchise à l'article 1er, paragraphe 2, et dans le simulateur : proche de zéro pendant des années, progressant pour atteindre un ordre de grandeur de quelques centaines d'euros par an sur plusieurs décennies, et sensiblement plus uniquement si l'automatisation transforme l'économie bien au-delà de son état actuel. Le présent règlement ne promet ni statut, ni finalité, ni sens, et le considérant 5 l'indique expressément. Il ne s'agit pas d'une mesure de remplacement du revenu et elle ne peut le devenir à aucun pourcentage que cet instrument pourrait porter : le calcul arithmétique figure sous evidence/sizing-the-ask.md.

**Incidences environnementales.** Évaluées comme non significatives, au regard du principe consistant à « ne pas causer de préjudice important » et de l'obligation de cohérence prévue à l'article 6, paragraphe 4, du règlement (UE) 2021/1119 (la loi européenne sur le climat), plutôt qu'écartées d'emblée. L'instrument ne réglemente ni ce qu'une entreprise produit, ni la manière dont elle le produit, ni l'énergie qu'elle utilise. Il transfère une part de propriété et ne génère aucune activité physique, aucune infrastructure, aucun transport et aucun changement dans les décisions de production, de sorte qu'aucun des six objectifs environnementaux n'est affecté négativement par une disposition opérationnelle quelconque. Les canaux méritant d'être mentionnés sont indirects et sont cités ici afin que le lecteur puisse les soupeser plutôt que de les découvrir. Premièrement, les entreprises désignées comprennent des exploitants d'infrastructures informatiques à forte intensité énergétique, et le règlement n'augmente ni ne restreint cette consommation ; il est neutre à cet égard, ce qui constitue un constat d'absence d'effet et non la revendication d'un avantage. Deuxièmement, une Réserve détenant des participations dans de telles entreprises acquiert une exposition à leur risque de transition, que son obligation de préservation du capital au titre de l'annexe II l'oblige à gérer ; l'article 9 lui interdit d'utiliser cette détention pour orienter la conduite d'une quelconque entreprise, sur le plan environnemental ou autre. Troisièmement, les distributions aux citoyens constituent des revenus du patrimoine d'une ampleur précisée ailleurs dans le présent exposé des motifs, trop faible au cours des décennies concernées pour produire un effet mesurable sur la consommation. Aucun avantage environnemental positif n'est revendiqué, et aucune évaluation de la pérennité climatique au titre de la boîte à outils pour une meilleure réglementation n'a été réalisée. Au vu des éléments disponibles, l'instrument est neutre pour l'environnement par conception.

**Droits fondamentaux.** L'article 17 (propriété) est concerné par l'obligation d'émission et examiné en détail ci-dessus ainsi qu'à l'objection 1. L'article 16 (liberté d'entreprise) est concerné par l'imposition de l'émission. L'article 41 (bonne administration) est concerné par les décisions individuelles de désignation au titre de l'article 3 et par les enquêtes de marché au titre de l'article 4, et est garanti par le droit d'être entendu sur les conclusions préliminaires de la Commission prévu à l'article 4, paragraphe 4, par les délais de décision fixes et par l'obligation de motivation. L'article 47 (recours effectif et tribunal impartial) est concerné par ces mêmes décisions une fois adoptées, par l'évaluation indépendante contraignante au titre des articles 6 et 7 et par les sanctions au titre de l'article 13 ; il est garanti par un contrôle juridictionnel complet devant la Cour de justice, et l'article 7 rend l'évaluation justiciable séparément afin qu'un litige sur la valeur n'ait pas à être intégré dans un litige relatif à la désignation. Les articles 20 et 21 (égalité et non-discrimination) sont concernés par les critères de seuil de l'article 3, paragraphe 2, qui s'appliquent de manière identique aux entreprises de l'Union et des pays tiers. L'article 8 (protection des données à caractère personnel) est concerné par la gestion des droits et traité au considérant 33 et à l'article 11, paragraphe 5. L'article 34 de la Charte (sécurité sociale et aide sociale) est mentionné dans le considérant relatif à la Charte en tant qu'élément de contexte, non comme fondement.

**Incidence budgétaire** : voir section 4.

### 3.4 Adéquation de la réglementation et simplification

L'instrument impose une obligation de notification aux entreprises atteignant les seuils et n'impose rien à quiconque d'autre. Les deux valeurs utilisées dans le critère de désignation figurent déjà dans des comptes audités, de sorte que la conformité ne nécessite aucune nouvelle mesure. La désignation elle-même constitue une décision de la Commission assortie d'un délai fixe, et la voie de réfutation est strictement circonscrite.

### 3.5 Ce dont la présente section ne peut se prévaloir

Il n'y a eu aucune consultation des entreprises qui seraient désignées, aucune modélisation macroéconomique au-delà du simulateur publié, aucun avis du comité d'examen de la réglementation, et aucune évaluation réalisée par des professionnels de la discipline. Chaque énoncé quantitatif ci-dessus repose sur les quatre notes de données probantes et sur le modèle publié, tous reproductibles, aucun n'ayant fait l'objet d'un audit. Le lecteur qui s'appuie sur le présent exposé des motifs doit le considérer comme un projet rigoureusement testé et non comme une analyse d'impact.

---

## 4. Incidence budgétaire

Le règlement ne crée aucune ressource propre de l'Union, aucune recette pour le budget de l'Union et aucune obligation de dépense pour les États membres. Aucun flux de trésorerie n'intervient à aucun moment entre une entreprise et une autorité publique : l'obligation est acquittée en actions, auprès de la Réserve, qui appartient aux citoyens.

Deux coûts sont réels et ne sauraient être masqués par cette architecture. La Commission supporte des coûts administratifs au titre des décisions de désignation, des enquêtes de marché, du régime d'évaluation indépendante et de l'évaluation périodique prévue à l'article 14 ; une estimation dérivée, étalonnée sur les effectifs affectés à l'application du règlement sur les marchés numériques pour une population comparable d'entreprises et présentée sous la forme d'une fourchette plutôt que d'un engagement, évalue ces besoins entre 30 et 60 équivalents temps plein, soit de l'ordre de 5 à 12 millions d'EUR par an au sein des lignes budgétaires existantes (evidence/administrative-cost.md). Les évaluations elles-mêmes sont supportées, à chaque événement, par l'entreprise couverte en vertu de l'article 6, paragraphe 3, à un ratio de coût proche d'un millionième de la valeur couverte, et les coûts de fonctionnement propres de la Réserve sont étalonnés par rapport aux 4 à 5 points de base publiés du fonds norvégien, qu'une conception plus passive devrait permettre de réduire. La Réserve prend en charge les coûts de conservation, d'administration et de distribution, que l'annexe II, point 2, déduit des revenus réalisés avant toute distribution, et l'article 10, paragraphe 6, plafonne les frais que les véhicules nationaux peuvent prélever afin que l'administration ne puisse éroder le droit.

Ces fourchettes constituent des comparaisons étalonnées et non une fiche financière législative ; une proposition de la Commission en nécessiterait une, établie en ayant accès aux données du tableau des effectifs dont le présent dossier ne dispose pas, et l'évaluation au titre de l'article 14 est le mécanisme qui remplacera les fourchettes par des coûts mesurés, à la hausse comme à la baisse. Le point structurel demeure valable indépendamment des fourchettes : les coûts de fonctionnement pèsent sur les revenus propres du fonds et sur l'enveloppe administrative existante de la Commission, non sur de nouveaux crédits, et l'instrument est conçu de sorte qu'une année au cours de laquelle la Réserve ne génère aucun revenu est une année où elle ne distribue rien, plutôt qu'une année où des coûts sont facturés à quiconque.

## 5. Autres éléments

### 5.1 Plans de mise en œuvre et suivi

L'article 14 oblige la Commission à suivre la diffusion des systèmes cognitifs automatisés, la détention d'actions par les ménages, les parts du travail et du capital dans la valeur ajoutée au sein des secteurs concernés, le fonctionnement même du règlement ainsi que l'évolution, à la hausse comme à la baisse, de la part du travail dans l'Union par rapport à 2025. Elle doit procéder à une évaluation et présenter un rapport au plus tard le 31 décembre 2032, puis tous les trois ans.

La condition de réfutabilité constitue la disposition inhabituelle et procède d'un choix délibéré. L'article 14, paragraphe 3, oblige le rapport à indiquer expressément les cas où les éléments de preuve ne corroborent pas la prémisse même du règlement, et à proposer une modification ou une abrogation. L'article 1er, paragraphe 2, oblige ce même rapport à évaluer si l'objectif quantifié est manifestement hors d'atteinte ou manifestement dépassé, et à proposer de modifier le pourcentage ou les seuils, à la hausse comme à la baisse. Un règlement reposant sur une affirmation empirique réfutable se doit de comporter son propre test.

### 5.2 Documents explicatifs

L'ensemble du dossier est public : le dispositif, les considérants, les annexes, le présent exposé des motifs, la note relative aux contre-arguments, la note relative à la divisibilité, la base de données probantes ainsi que chaque avis d'examen, y compris ceux auxquels le texte n'a pas satisfait. L'historique de rédaction constitue un journal des modifications public.

### 5.3 Explication détaillée des dispositions spécifiques

Le chapitre Ier (articles 1er à 2) énonce l'objet, l'objectif quantifié et les définitions. Le chapitre II (articles 3 à 4) procède à la désignation des entreprises couvertes sur la base de critères qualitatifs cumulatifs assortis d'une présomption quantitative réfragable, et prévoit des enquêtes de marché ainsi qu'un réexamen. Le chapitre III (articles 5 à 7) crée le warrant de capital citoyen, ses événements de cristallisation, y compris le déclencheur du prélèvement au profit des actionnaires et l'échéance butoir de sept ans, l'évaluation indépendante et les garanties. Le chapitre IV (articles 8 à 9) institue la Réserve et lui interdit de voter, de diriger, d'acquérir au-delà du warrant ou de recourir à l'effet de levier. Le chapitre V (articles 10 à 11) crée le droit individuel du citoyen et son administration par l'intermédiaire de véhicules nationaux. Le chapitre VI (article 12) protège la Réserve et les droits. Le chapitre VII (articles 13 à 16) prévoit les sanctions, le suivi, les délégations de pouvoir et la procédure de comité. Le chapitre VIII (articles 17 à 18) contient les dispositions transitoires et l'entrée en vigueur. L'annexe I définit la méthodologie de calcul ; l'annexe II, l'arithmétique de rétention et de distribution.

La note relative à la divisibilité précise la manière dont l'instrument se décompose en cas d'invalidation d'une partie, en quatre niveaux, de sorte qu'un enregistrement partiel ou une annulation partielle élague l'instrument au lieu de le détruire.

### 5.4 Points ouverts, énoncés plutôt que dissimulés

- Cinq points d'articulation avec l'acquis, y compris l'interaction avec la directive (UE) 2024/2810 relative aux structures avec actions à droits de vote multiples.
- La question de savoir si un critère par segment d'activité devrait être réintroduit en tant que seconde présomption à l'article 3, paragraphe 2, en cas de constatation d'une dilution par acquisition antérieure à la désignation.
- La question de savoir si l'instrument doit s'étendre à la fabrication de semi-conducteurs, ce que le volet qualitatif et la réfutation prévue à l'article 3, paragraphe 5, laissent actuellement à décider au cas par cas.

Chacun de ces points est consigné dans le registre d'examen ou dans les notes de rédaction, avec le raisonnement qui a conduit à le laisser ouvert.


# SOURCE: own-the-machine/regulation/memorandum/explanatory-memorandum.md

# Explanatory memorandum

Accompanying the draft Regulation of the European Parliament and of the
Council on harmonised rules for citizen participation in automated
productivity gains.

This memorandum follows the structure the Commission uses for its own
proposals. It is written by citizens, not by the Commission, and it is not
required: Regulation (EU) 2019/788 permits a citizens' initiative to attach
a draft legal act and asks nothing of this kind. It exists because the
questions the Commission's services would have to answer about this
instrument are worth answering before they are asked, and because a file
that cannot answer them is not ready to be acted on. Where an answer does
not exist yet, this memorandum says so rather than filling the heading.

---

## 1. Context of the proposal

### 1.1 Reasons for and objectives of the proposal

Automated cognitive systems are beginning to produce output at a scale that
does not require a corresponding quantity of human labour. Where that
decoupling occurs, the returns to production accrue to the holders of the
capital that embodies the automation, and the share reaching citizens
through wages falls with the labour share.

The problem this Regulation addresses is not that outcome in itself, which
is a matter for many instruments, but a narrower one within the Union's
competence: the ownership of the capital in which those returns
concentrate is extremely narrow, and Member States have begun to respond
separately, with divergent national levies, participation schemes and
proposals for taxing automated output. Those divergences fragment the
internal market for exactly the undertakings that operate across all of
it.

The objective is stated and quantified in Article 1(2): participation of
citizens of the Union in the capital value created by hyper-automated
production, at a scale where the holdings behind each citizen's entitlement
reach the order of six months of median equivalised disposable income in the
Union within a generation of the first designations.

### 1.2 Consistency with existing provisions in the policy area

The designation architecture follows Regulation (EU) 2022/1925 (the Digital
Markets Act): cumulative qualitative criteria, quantitative thresholds
giving rise to a rebuttable presumption, self-notification, a
below-threshold designation route on the facts, and an anti-circumvention
power. That is a deliberate reuse of a structure the Union legislature has
already adopted and the Court has not disturbed.

The company-law interface is drafted as express, narrow derogation from
Directive (EU) 2017/1132 rather than as general override, following the
formula of the resolution acquis. The prospectus interface is an express
exemption under Regulation (EU) 2017/1129. Article 1(5) preserves Directive
(EU) 2016/2341 and Regulation (EU) 2019/1238 save as Article 11 provides.

Five acquis interface points remain open and are listed in section 5.4.
They are recorded rather than resolved, which is the honest state.

### 1.3 Consistency with other Union policies

The instrument takes non-voting equity and confers no governance right,
which keeps it outside the field the Court's case law on special public
shareholdings occupies (Commission v Germany, C-112/05, and the line
following it). That choice has a cost, examined at objection 20: voteless
shares raise the relative voting weight of the remaining holders, and the
Union has lately legislated in the other direction on multiple-vote share
structures in Directive (EU) 2024/2810. The interaction with that Directive
is an open interface point, not a resolved one.

Nothing in this Regulation creates a Union own resource, and nothing enters
the Union budget. That is a design constraint, not an incidental property:
see section 4.

---

## 2. Legal basis, subsidiarity and proportionality

### 2.1 Legal basis

The legal basis is stated by layer, not as a single centre of gravity for
the whole act, because incompatible legislative procedures cannot be fused
into one basis (Titanium Dioxide, C-300/89) and because a unitary argument
would concede the weakest layer's characterisation to the strongest layer's
opponents. The severability memorandum sets the layers out; decomposition
rule 3 requires this treatment. Article 114 TFEU carries the designation
regime, the transparency obligations and the warrant: rules addressed to
undertakings operating across the whole internal market, removing the
divergence that separate national participation and automation levies are
already creating. The Commission has registered an initiative resting on
that same divergence logic over comparably contested ground: the 2023
wealth-tax initiative, by Decision (EU) 2023/1487. The independent advice
obtained through the ECI Forum on 27 August 2026, recorded in
pipeline/EXTERNAL-REVIEWS.md and binding on nobody, reads that decision the
same way and recommends citing it here. Article 352 TFEU carries the
elements Article 114 does not reach, namely the establishment of the Reserve
as a Union-level body and the individual entitlement of citizens. That basis
is not untrodden ground for participation: the Council acted on the
participation of employed persons in profits and enterprise results by
Recommendation 92/443/EEC, adopted on Article 352's predecessor. A
recommendation creates no power and this memorandum claims none from it;
what it establishes is narrower and useful, that the Union has treated
participation in enterprise results as a Union-level concern under this
basis before. Those elements are drafted to be severable precisely so that
the unanimity they require cannot hold the Article 114 layers hostage, and
so that partial registration or partial annulment trims the instrument
rather than destroying it.

The preamble of the draft cites Article 114 alone. A single act cannot
carry two legislative procedures: Article 352 requires unanimity in the
Council and the consent of the Parliament where Article 114 requires the
ordinary legislative procedure, and the legal-form and legal-basis gates of
6 September 2026 (pipeline/reviews) confirmed that a citation scoped by
chapter is not an available form. The Reserve, the entitlement and their
protection, Chapters IV to VI, are therefore drafted so that, if Article
114 is held not to reach them, they can be enacted as a separate Council
Regulation on Article 352 with the warrant regime unchanged. That is the
form Layer 3 of the severability memorandum provides for, and it is what
the registration
text's reference to Article 352 contemplates.

Article 114(2) excludes fiscal provisions, and the characterisation question
that follows is the most serious legal risk this instrument carries. It is
stated at full strength and answered at objection 2, and that objection, not
this memorandum, is where the argument lives. The short form: the obligation
takes an asset and not a flow, is payable in shares and never in cash, funds
no budget, passes through no treasury and confers no revenue on the Union.
The ECI Forum's advice of 27 August 2026 notes Article 115 TFEU as a
conceivable basis if that characterisation were to fail; it is recorded
here, not adopted. Article 115 does not exclude fiscal provisions, but on
the advisers' own analysis it demands the same harmonisation reading as
Article 114 while surrendering qualified majority voting, and the layered
drafting already prices unanimity in where it is unavoidable.

### 2.2 Choice of the instrument

A Regulation, and not a Directive, for three reasons. The obligation
attaches to a small number of undertakings operating across the entire
internal market, and transposition into twenty-seven national regimes
would reproduce exactly the divergence the measure exists to remove. The
warrant must have identical content in every Member State because a single
undertaking issues one instrument to one Reserve. And the entitlement is
held directly by citizens against a Union body, which requires direct
applicability rather than national implementing law. Chapter V leaves the
administration of entitlements to national vehicles, which is where
national variation belongs and is permitted.

### 2.3 Subsidiarity

The objective cannot be sufficiently achieved by Member States acting
separately, because the undertakings concerned operate across the entire
internal market and national measures would create the very divergence the
Regulation removes. A national participation scheme would apply to
undertakings whose value arises from Union-wide activity, which either
under-reaches or produces twenty-seven incompatible claims on the same
capital. Recital 34 carries the formal statement.

### 2.4 Proportionality

The interference with the right to property under Article 17 of the Charter
is real and is not minimised in this file. Proportionality is carried by
five features of the drafting: the percentage is fixed and small; the
obligation is prospective and attaches only to value formed after
designation; it crystallises only when the undertaking's own owners realise
value; the valuation is independent and separately justiciable under
Articles 6 and 7; and the holding is passive, with no vote, no board seat
and no direction of management.

On the necessity limb, this memorandum records a limit rather than claiming
a strength. Article 1(2) now states a quantified objective, and three per
cent is the smallest integer percentage that approaches it on the published
model, so necessity can for the first time be argued from a stated quantity
rather than asserted. But the model is linear in the percentage, so the
target itself is chosen rather than derived. Objection 21 sets this out in
full, including the circularity, before a reviewer does.

---

## 3. Results of ex-post evaluations, stakeholder consultations and impact assessments

### 3.1 Ex-post evaluations

None. There is no existing Union instrument in this field to evaluate.

### 3.2 Stakeholder consultations

No formal consultation has been held, and none could be: this is a citizens'
draft and no institution has consulted on it. Saying "stakeholders were
consulted" would be false and this memorandum will not say it.

What exists instead is adversarial review, run against the text at every
stage and published in full: six review gates covering legal form,
constraint compliance, legal basis, hostile counsel, acquis coherence and
layer fidelity, with every verdict committed including the failures, and a
public ledger recording what each round changed and what was refused with
reasons. Twenty-one objections are stated at their strongest and answered,
several of them fatal-if-true, and at least two whole design alternatives
were killed in that process before reaching publication.

That is not a substitute for consulting the people an instrument would
bind, and this memorandum does not present it as one. It is what a file can
do before it has standing to consult anybody. A registrability enquiry is
pending with the European Citizens' Initiative Forum.

### 3.3 Impact assessment

No formal impact assessment under the Better Regulation guidelines has been
carried out, and a citizens' initiative is not required to carry one. What
follows is the analysis that does exist, in the form those guidelines use,
with its limits stated.

**Policy options considered.**

*Option 0, no Union action.* Member States continue to legislate separately
on automation levies and participation schemes. The divergence grows, the
undertakings concerned face twenty-seven regimes or none, and the ownership
question is answered nationally where it can only be answered at the scale
the undertakings operate. This is the baseline against which the others are
measured, and it is the option hostile review consistently identifies as
the safest for the Union legislature and the worst for the objective.

*Option 1, a tax on automated output or on tokens of inference.* This is the
live competing family: legislative proposals of this kind exist in third
countries, including one introduced in the United States in August 2026 with
a rate that escalates as unemployment rises. It raises money sooner and in
larger amounts in the early decades, which the warrant does not. It was
rejected on two substantive grounds, and a third observation is recorded
separately because it must not be mistaken for a reason. First, it is a flow
and not an asset, so citizens receive a transfer rather than a holding, and
the distinction between a benefit and a stake is the entire thesis of this
instrument: a transfer is renegotiated annually and cancellable by simple
majority, a holding is property. Second, and for the same reason, it is
repealable by the majority that enacts it, which the raid history in the
evidence base shows is not a theoretical risk. The separate observation is
that a consumption or output levy is unambiguously fiscal and would require
unanimity under Article 113 TFEU. That is a consequence of what such an
instrument is, not a reason for preferring this one, and this memorandum
does not offer it as one. The ownership thesis is prior to any competence
question and would be the same if both routes required the same majority. A
reader is entitled to test that claim against the four tests in
GOVERNANCE.md, which were adopted before any legal basis was chosen and
which reject flow-based instruments on their own terms. The full comparison,
including the magnitudes, is published at evidence/token-taxes.md.

*Option 2, a Union sovereign wealth fund capitalised from the budget.* This
requires the money the Union does not have, competes directly with every
other budget line, and produces a fund owned by the Union rather than by
citizens, which fails the ownership objective and exposes the assets to
exactly the raid history the evidence base documents.

*Option 3, a voting stake.* A Reserve holding voting shares would give the
Union influence over the undertakings it regulates. Rejected: it is
objection 9's honeypot with a lever attached and objection 16's golden
share, which the Court has struck down in every form it has taken.

*Option 4, the citizens' capital warrant, preferred.* Non-voting, fixed
percentage, prospective, crystallising only at the owners' own realisation,
payable only in shares. It is chosen because it is the only option
identified that transfers ownership rather than income and converts repeal
into expropriation: a future legislature can still take it, but it must do
so as a taking of property, meeting Article 17 and Article 52(1) of the
Charter, rather than by amending a budget line. DC-23 states the rule this
reflects, that raid resistance is friction and never impossibility, and this
memorandum does not claim more than friction.

**Economic impacts.** The designated undertakings bear a dilution of three
per cent of capital, once, crystallising on their own liquidity event, on
shareholder extraction above the stated threshold, or at the seven-year long
stop, whichever comes first, so the timing is theirs only until the long
stop reaches it. Investors will price mandatory future dilution from
designation onward, which is a real cost and is examined at objection 4.
Nine undertakings are presumptively designated on August 2026 figures, with
roughly EUR 20,5 trillion of combined value; the calculation is at
evidence/designation-count.md. The instrument has no effect on any
undertaking outside that set, and small and medium-sized enterprises fall
far outside it: the most capital-intensive labour-reliant undertakings
observed reach a value-to-payroll ratio in the thirties, against a threshold
of eighty.

**Social impacts.** The intended social impact is the distribution of an
ownership stake equally to citizens of the Union, without means test,
application or condition, the entitlement attaching by virtue of Union
citizenship and distributions being made from the age of majority under
Article 10, and its expected magnitude is stated honestly in Article 1(2)
and in the simulator: near zero for years, growing to something of the order
of a few hundred euros a year across decades, and materially more only if
automation transforms the economy far beyond its present state. This
Regulation does not promise status, purpose or meaning, and recital 5 says
so in terms. It is not an income-replacement measure and cannot become one
at any percentage this instrument could carry: the arithmetic is at
evidence/sizing-the-ask.md.

**Environmental impacts.** Assessed as not significant, against the do no
significant harm principle and the consistency duty in Article 6(4) of
Regulation (EU) 2021/1119 (the European Climate Law), rather than dismissed.
The instrument regulates neither what an undertaking produces, nor how, nor
what energy it uses. It transfers a share of ownership and creates no
physical activity, no infrastructure, no transport and no change in any
production decision, so none of the six environmental objectives is
adversely affected by any operative provision. The channels worth naming are
indirect and are named here so that a reader can weigh them rather than
discover them. First, the designated undertakings include operators of
energy-intensive computing infrastructure, and the Regulation neither
increases nor restrains that consumption; it is neutral to it, which is a
statement of no effect and not a claim of benefit. Second, a Reserve holding
equity in such undertakings acquires an exposure to their transition risk,
which its capital-preservation duty under Annex II obliges it to manage;
Article 9 forbids it from using that holding to direct any undertaking's
conduct, environmental or otherwise. Third, distributions to citizens are
property income of a magnitude stated elsewhere in this memorandum, too
small in the relevant decades to produce a measurable consumption effect. No
positive environmental benefit is claimed, and no climate-proofing
assessment under the Better Regulation toolbox has been carried out. On the
evidence available the instrument is environmentally neutral by
construction.

**Fundamental rights.** Article 17 (property) is engaged by the issuance
obligation and examined at length above and at objection 1. Article 16
(freedom to conduct a business) is engaged by compelling issuance. Article
41 (good administration) is engaged by the individual designation decisions
under Article 3 and the market investigations under Article 4, and is served
by the right to be heard on the Commission's preliminary findings in Article
4(4), by the fixed decision deadlines and by the duty to state reasons.
Article 47 (effective remedy and fair trial) is engaged by those same
decisions once taken, by the binding independent valuation under Articles 6
and 7 and by the penalties under Article 13; it is served by full judicial
review before the Court of Justice, and Article 7 makes the valuation
separately justiciable so that a dispute about value need not be carried
inside a dispute about designation. Articles 20 and 21 (equality and non-
discrimination) are engaged by the threshold criteria in Article 3(2), which
apply identically to Union and third-country undertakings. Article 8
(protection of personal data) is engaged by the administration of
entitlements and addressed in recital 33 and Article 11(5). Article 34 of
the Charter (social security and social assistance) is referenced in the
Charter recital as context, not as a basis.

**Budgetary implications**: see section 4.

### 3.4 Regulatory fitness and simplification

The instrument imposes a notification duty on undertakings meeting the
thresholds and nothing on anyone else. Both figures in the designation test
are already in audited accounts, so compliance requires no new
measurement. Designation itself is a Commission decision with a fixed
deadline, and the rebuttal route is cabined.

### 3.5 What this section cannot claim

There has been no consultation of the undertakings that would be
designated, no macroeconomic modelling beyond the published simulator, no
Regulatory Scrutiny Board opinion, and no assessment by anyone who does
this professionally. Every quantitative statement above rests on the four
evidence notes and the published model, all reproducible, none audited. A
reader relying on this memorandum should treat it as a well-tested draft
and not as an impact assessment.

---

## 4. Budgetary implications

The Regulation creates no Union own resource, no revenue for the Union
budget and no expenditure obligation on the Member States. No cash flows
from any undertaking to any public authority at any point: the obligation
is discharged in shares, to the Reserve, which is owned by citizens.

Two costs are real and should not be hidden by that architecture. The
Commission bears administrative costs for designation decisions, market
investigations, the independent valuation regime and the periodic evaluation
under Article 14; a derived estimate, calibrated against the Digital Markets
Act's enforcement staffing for a comparable population of undertakings and
stated as a range rather than a promise, puts this at 30 to 60 full-time
equivalents, in the order of EUR 5 to 12 million a year within existing
budget headings (evidence/administrative-cost.md). The valuations themselves
are borne per event by the covered undertaking under Article 6(3), at a cost
ratio near one part in a million of the covered value, and the Reserve's own
running costs are benchmarked against the Norwegian fund's published 4 to 5
basis points, which its more passive design should undercut. The Reserve
bears the costs of custody, administration and distribution, which Annex II
point 2 deducts from realised income before anything is distributed, and
Article 10(6) caps the fees national vehicles may levy so that
administration cannot erode the entitlement.

These ranges are calibrated comparisons, not a legislative financial
statement; a Commission proposal would require one, prepared with access to
establishment-plan data this file does not have, and the Article 14
evaluation is the mechanism that will replace the ranges with measured cost,
in both directions. The structural point stands independently of the ranges:
the running costs fall on the fund's own income and on the Commission's
existing administrative envelope, not on a new appropriation, and the
instrument is designed so that a year in which the Reserve earns nothing is
a year in which it distributes nothing rather than a year in which someone
is billed.

---

## 5. Other elements

### 5.1 Implementation plans and monitoring

Article 14 obliges the Commission to monitor the diffusion of automated
cognitive systems, household equity holdings, the labour and capital shares
of value added in the sectors concerned, the Regulation's own operation,
and the evolution of the Union labour share against 2025 in either
direction. It must evaluate and report by 31 December 2032 and every three
years thereafter.

The falsification condition is the unusual part and is deliberate. Article
14(3) obliges the report to state expressly where the evidence does not
support the Regulation's own premise, and to propose amendment or repeal.
Article 1(2) obliges the same report to assess whether the quantified
objective is manifestly unattainable or manifestly exceeded, and to propose
amending the percentage or the thresholds in either direction. A regulation
resting on a falsifiable empirical claim should carry its own test.

### 5.2 Explanatory documents

The whole file is public: the enacting terms, the recitals, the annexes,
this memorandum, the counter-arguments memorandum, the severability
memorandum, the evidence base and every review verdict including the ones
the text failed. The drafting history is a public commit log.

### 5.3 Detailed explanation of the specific provisions

Chapter I (Articles 1 to 2) states the subject matter, the quantified
objective and the definitions. Chapter II (Articles 3 to 4) designates
covered undertakings on cumulative qualitative criteria with a rebuttable
quantitative presumption, and provides for market investigation and review.
Chapter III (Articles 5 to 7) creates the citizens' capital warrant, its
crystallisation events including the extraction trigger and the seven-year
long stop, the independent valuation and the safeguards. Chapter IV
(Articles 8 to 9) establishes the Reserve and prohibits it from voting,
directing, acquiring beyond the warrant, or leveraging. Chapter V (Articles
10 to 11) creates the individual entitlement and its administration through
national vehicles. Chapter VI (Article 12) protects the Reserve and the
entitlements. Chapter VII (Articles 13 to 16) provides penalties,
monitoring, delegation and committee procedure. Chapter VIII (Articles 17
to 18) contains the transitional provisions and entry into force. Annex I
carries the counting methodology; Annex II the retention and distribution
arithmetic.

The severability memorandum sets out how the instrument decomposes if a
part fails, in four layers, so that partial registration or partial
annulment trims rather than destroys.

### 5.4 Open points, stated rather than concealed

- Five acquis interface points, including the interaction with Directive
  (EU) 2024/2810 on multiple-vote share structures.
- Whether a segment-level limb should return as a second presumption in
  Article 3(2) if pre-designation dilution by acquisition is observed.
- Whether the instrument should reach semiconductor fabrication at all,
  which the qualitative limb and the Article 3(5) rebuttal currently leave
  to be decided case by case.

Each of these is on the record in the review ledger or the drafting notes
with the reasoning that left it open.


# SOURCE: own-the-machine/regulation/memorandum/severability.md

# Severability layering

How the instrument decomposes when institutions start cutting, and what
each cut costs. This document is strategy, not law: it binds the drafters
and the campaign, and the layer-fidelity gate reviews the articles against
it. It exists because the legal-basis gate's standing finding is real: the
complete instrument's centre of gravity is contestable, and the honest
response is to know in advance which parts stand on which legal basis, and
what the ask becomes at each stage of trimming.

## The four layers

### Layer 0: the question (survives everything)

The ask that survives any trimming, including partial registration of a
European Citizens' Initiative under the settled case law allowing it:

> The Commission is asked to assess, and to propose instruments for,
> the participation of citizens of the Union in the productivity gains of
> hyper-automated production, including designation criteria for
> undertakings whose output is substantially decoupled from employment,
> and mechanisms by which the gains of such production become broadly
> owned.

Nothing in Layer 0 requires any particular legal basis, because it asks
for an assessment and a proposal, which is what an initiative may ask.
Registration of Layer 0 is the Gate 1 floor: if the Commission will not
register even this, the project's premise about the legal channel fails
and the kill criterion in campaign/GATES.md applies.

### Layer 1: designation and transparency (Article 114 TFEU, comfortable)

Articles 1 to 4, 14, 16, 18, with Annex I; penalties limited to the
notification and information duties; recitals 1 to 8, 30 to 32, 34 to 36.

A regulation that designates hyper-automated undertakings on harmonised
criteria, makes the designation public, and reports on adoption,
employment effects and ownership concentration. It harmonises exactly the
thing Member States are starting to do divergently, on the DMA's own
architecture, and it carries the falsification condition. No warrant, no
Reserve, no entitlement.

This layer is defensible under Article 114 on the DMA precedent with no
novel doctrine. It is also, standing alone, worth having: designation
plus the Article 14 evidence base is what every subsequent instrument,
Union or national, would build on.

### Layer 2: the warrant (Article 114 TFEU, contested; fallback 352)

Articles 5 to 7, 13 in full, 15, 17, with the company-law derogations and
the valuation machinery; recitals 9 to 20, 29.

The obligation to issue the citizens' capital warrant, crystallising on
the first liquidity event, on shareholder extraction above the stated
share of covered turnover or on the seven-year long-stop, whichever comes
first, with the BRRD-pattern safeguards. The Article
114 case: it removes the incentive for divergent national levies and
participation schemes (recital 1), harmonises the company-law derogations
the subscription needs, and secures the level playing field between Union
and third-country undertakings. The attack (legal-basis gate, first run):
the centre of gravity is redistribution, not market-building, and
Article 114(2) excludes fiscal provisions; the controlling line is Tobacco
Advertising (C-376/98), which demands genuine obstacles or appreciable
distortions, not a desirable policy. The defence rests on the
non-fiscal structure being real (Article 8's insulation, settlement in
shares only), not asserted, and on recital 1's divergence record being
genuine.

If the characterisation fails, this layer moves to Article 352: unanimity
in Council, consent of the Parliament. That is a political mountain, and
this document says so rather than pretending otherwise.

### Layer 3: the Reserve and the entitlement (Article 352 TFEU, honestly)

Articles 8 to 12, with Annex II; recitals 21 to 28, 33.

The Reserve as a new Union-level body holding assets for citizens, the
universal entitlement arising by operation of law, national vehicles, the
raid-proofing. Creating a new body with legal personality and a direct
Union-to-citizen property relationship is where Article 114 is weakest and
where the subsidiarity objection concentrates. The body-creation precedents
cut both ways: Article 114 has sustained Union bodies that serve
harmonisation (ENISA, C-217/04; ESMA's intervention powers, C-270/12), but a
new legal form standing apart from national laws required what is now
Article 352 (the European Cooperative Society, C-436/03), and a Reserve
owing citizens a direct property relationship resembles the second more than
the first. The honest position: Layer 3 is drafted to be defensible under
Article 352, and its unanimity requirement is priced in. The campaign's
answer to "you will never get unanimity" is the wealth-tax precedent: the
fight is meant for the Council, in public, on the record. The basis itself
has carried participation before: Council Recommendation 92/443/EEC, on the
promotion of participation by employed persons in profits and enterprise
results, was adopted on Article 352's predecessor, a reference supplied by
the ECI Forum's advice of 27 August 2026 (pipeline/EXTERNAL-REVIEWS.md,
review 4). A recommendation confers no power; it shows the terrain is not
untrodden.

## Decomposition rules

1. Every layer must function with the layers above it struck. Layer 1
   without Layers 2 and 3 is a designation-and-evidence regulation.
   Layers 1 and 2 without Layer 3 would park crystallised shares with an
   independent depositary pending a distribution instrument; that escrow
   amendment is not in the draft, because in the draft the Reserve
   exists, but it is the prepared answer if Layer 3 is severed in
   legislative procedure, and no article may be drafted in a way that
   forecloses it.
2. No article may create a dependency downward on a higher-numbered
   layer's existence, other than Layer 2's delivery of shares to the
   Reserve, for which point 1's escrow is the severance answer.
3. The memorandum must argue each layer's basis separately. A single
   centre-of-gravity argument for the whole instrument concedes the
   weakest layer's characterisation to the strongest layer's opponents.
4. At Council stage, concessions run top down: Layer 3 is conceded to a
   separate instrument before Layer 2 is weakened, and Layer 2 is
   conceded to Article 352 procedure before Layer 1 is abandoned.
   Nothing in Layer 1 is conceded; it is the floor above Layer 0.
5. The ECI registration ask is Layer 0 as primary request with the full
   Regulation annexed as the suggested instrument, so that partial
   registration, if the Commission insists on it, trims the annex and
   not the ask.

**This rule was an assumption until 27 August 2026; it is now a finding,
within the limits of its source.** The ECI Forum's legal advice service,
answering questions 2 and 3 of campaign/GATE1-LETTER.md (reply of 27 August
2026, recorded verbatim in pipeline/EXTERNAL-REVIEWS.md, review 4), states
that if the goals comply with the ECI Regulation the initiative must be
registered "regardless of the mechanism described in your proposed legal
act", that the mechanism's contestability "is not a relevant consideration
for the registration", and that a full draft act may be provided where it
shows the proposal falls within the Commission's competence. The contrary
reading surfaced on 21 August, that the annex enlarges what is assessed, did
not survive the question. The limits: the advice is independent, expressly
non-binding on the Commission, and a finding about the registration stage
only; it says nothing about how the annex fares in legislative procedure,
which is what rules 1 to 4 are for.

## What this costs and why it is worth it

Layering is a concession in advance, and hostile readers will quote it as
lack of confidence. The alternative is a monolith that dies whole at its
weakest point, which is how most redistributive proposals at Union level
have died. The book's own analysis is that the mechanism matters more
than the vehicle: designation and evidence (Layer 1) create the factual
record; the warrant (Layer 2) is the mechanism; the Reserve (Layer 3) is
one distribution architecture among several possible. Losing Layer 3 to
an intergovernmental or successor instrument loses elegance, not the
point.


# SOURCE: own-the-machine/regulation/recitals.md

# Recitals

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 114 thereof,

Having regard to the proposal from the European Commission,

After transmission of the draft legislative act to the national parliaments,

Having regard to the opinion of the European Economic and Social Committee,

Acting in accordance with the ordinary legislative procedure,

Whereas:

(1) The internal market comprises an area without internal frontiers in
which the free movement of goods, services, persons and capital is ensured.
The conditions under which highly automated undertakings operate in the
internal market are increasingly the subject of divergent national
initiatives, including proposals for levies on automated production,
national social-dividend schemes and mandatory employee-participation
regimes extended to undertakings with few employees. Such divergence
creates fragmentation, distorts competition and gives undertakings an
incentive to locate activities according to regulatory exposure rather
than economic merit. That this is the pattern rather than a
possibility is established by the taxation of digital activity, where
the absence of a Union measure was followed by unilateral national
taxes in eight Member States, at rates, on bases and with
thresholds that do not correspond, so that the same undertaking falls
inside one national regime and outside its neighbour's on identical
revenue. Harmonised rules at Union level are therefore necessary, and
are more effective before national answers multiply than after.

(2) Advances in artificial intelligence and related automation
technologies enable a new category of undertaking: one which attains very
substantial turnover and market value while engaging very little human
labour in production. Such undertakings are lawful, productive and often
beneficial. Their emergence is nevertheless economically unprecedented,
because the mechanisms by which productivity gains have historically been
diffused through the population, above all wages and the broad taxation of
labour income, presuppose that production requires labour at scale.

(3) Where output is substantially decoupled from employment, the gains
from automation accrue by default to a narrow base of shareholders. No
existing instrument of Union law addresses the resulting concentration of
capital ownership. Competition law addresses conduct, not ownership;
Regulation (EU) 2022/1925 addresses the contestability of digital markets;
Regulation (EU) 2024/1689 addresses the safety of artificial intelligence
systems. This Regulation complements those instruments by addressing the
distribution of the ownership of automated production itself.

(4) The appropriate response is not a tax on the flows of automated
production. Taxes on flows burden activity year by year, are borne in part
by consumers and employees, depend on annual political renewal and treat
the gains of automation as public revenue to be spent. The response chosen
by this Regulation operates on assets instead: a limited, one-time right
to subscribe for equity in the most labour-decoupled undertakings, held in
a common reserve for the benefit of all Union citizens. An equity stake
participates in gains only where gains exist, imposes no recurring burden
on production and converts the automation dividend into broadly held
capital rather than public expenditure.

(5) This Regulation addresses the distribution of the capital value
created by hyper-automated production and does not purport to regulate
employment, wages, taxation as such, or the internal organisation of
undertakings beyond what the citizens' capital warrant requires. It does
not promise status, purpose, meaning or the other goods that employment
supplies as a by-product, and nothing in this Regulation, and no material
presenting it, should be read as making such a promise. Its object is
narrower and more precise than that: a broadly held equity stake in the
value that automation creates, and nothing beyond it. That object is
stated in Article 1 with its scale: an ownership position for each
citizen measured against a published statistic of Union living
standards, reached within a generation, so that the necessity of the
percentage laid down in Article 5 can be assessed against a stated
objective and revisited on the evidence. The stake is the objective;
distributions remain the property income that follows from ownership
and are not the purpose of the obligation.

(6) So that the obligations laid down in this Regulation apply only to
undertakings in which the decoupling of output from labour is extreme,
durable and of Union significance, undertakings should be designated on the
basis of objective qualitative criteria, accompanied by quantitative
thresholds giving rise to a rebuttable presumption. That architecture, which
follows the model of Regulation (EU) 2022/1925, provides legal certainty for
undertakings while preserving the ability of the Commission to designate on
the facts and to disregard arrangements whose main purpose or effect is the
avoidance of designation. Designation should be capable of preceding any
liquidity event and of applying irrespective of admission to trading,
because the warrant attaches to value at its formation and a contrary rule
would let an undertaking place itself beyond the Regulation by remaining
private; and arrangements whose main purpose or effect is the avoidance of
designation are disregarded, which is the settled anti-circumvention formula
of Union market regulation and restricts no restructuring undertaken for
genuine commercial reasons. Small and medium-sized enterprises fall far
outside the thresholds and are unaffected by this Regulation.

(7) The quantitative thresholds should capture only undertakings of very
substantial scale whose market valuation stands in a proportion to their
expenditure on human labour that has no precedent among labour-intensive
undertakings. Compensation of labour is the appropriate measure of the
labour actually engaged, because it is recorded in audited accounts and
cannot be increased without genuine payment for genuine work, so that an
undertaking reduces its decoupling ratio only by remunerating labour,
which is consistent with the objectives of this Regulation. The ratio
laid down in this Regulation is fixed in its own terms, so that an
undertaking can establish its position from its own audited accounts
alone: it exceeds by a margin of more than double the highest ratios
observed among capital-intensive undertakings whose value remains
explained by their expenditure on labour, and by an order of magnitude
the prevailing ratio among large undertakings admitted to trading in the
Union. It is reviewed under Article 14 and may be amended only by the
ordinary legislative procedure. For the same reasons the thresholds are
assessed at the level of the group of linked enterprises, the single
economic unit to which the value of the automated services accrues.

(8) Designation should follow a notification by the undertaking itself
within a fixed period, with a decision of the Commission within a fixed
period thereafter. Arguments against the presumption should be taken into
account only where they manifestly call it into question, and arguments
based on the definition of the relevant market should not be taken into
account, since designation does not depend on a finding of market power.
Where a designation is repealed, a warrant not yet crystallised should
lapse after five years, ensuring legal certainty for the undertaking while
preserving for a reasonable period the rights acquired by the Reserve.

(9) The citizens' capital warrant should be modest, precise and singular:
a right to subscribe, at nominal value, for shares representing 3 % of the
fully diluted capital of the covered undertaking, once per designation.
The warrant should confer no voting rights and no influence over
management, so that neither the Union nor any public authority obtains
control or direction of any undertaking by virtue of this Regulation. This
Regulation therefore leaves untouched the rules in Member States governing
the system of property ownership and does not effect any transfer of any
undertaking to public ownership.

(10) The warrant should crystallise upon the first liquidity event
following designation: an admission to trading, a change of control or a
substantial secondary sale. It should also crystallise, on the same terms
and before any liquidity event, where the covered undertaking extracts
value to its own shareholders above the threshold this Regulation sets
for that purpose, or where seven years have elapsed since the warrant was
issued. Attaching the public stake to the point at which the
undertaking's own choices, or the mere elapse of that period, make value
claimable keeps the warrant dormant until one of those points is reached
and interferes with no going concern before it is. For the same reason,
an admission to trading which occurred before the entry into force of
this Regulation should not constitute a liquidity event, and this
Regulation should not apply to a liquidity event or other crystallising
event completed before its entry into force.

(11) Shareholder extraction above the threshold this Regulation sets for
that purpose should crystallise the warrant on the same footing as a
liquidity event, because in substance it is the same event. A liquidity
event realises value for the shareholders of a covered undertaking by
converting an unrealised stake into cash or its equivalent; extraction
realises the same value by a different route, distributing it directly to
those shareholders without any sale of the undertaking itself. An
instrument that crystallised only on a sale, an admission to trading or a
comparable transaction would depend on the form the owners of a covered
undertaking choose for taking value out of it, and owners able to achieve
the same result by dividend, buy-back or capital reduction would have
every reason to choose that form instead. The extraction trigger closes
that route, without altering the liquidity-event trigger in any other
respect.

(12) The seven-year long-stop answers a case the liquidity-event and
extraction triggers do not reach: an undertaking that remains privately
held indefinitely, keeps its distributions to shareholders below the
extraction threshold, and so never crystallises the warrant at all, while
its value continues nonetheless to accrue for the benefit of those
shareholders. Absent a long-stop, such an undertaking could defeat the
objective of this Regulation by the simple expedient of staying private
and patient. The long-stop is the answer to that possibility, and it is
proportionate under Article 52(1) of the Charter of Fundamental Rights of
the European Union: it is quantified in years rather than left to
discretion, it is known to the undertaking from the moment of its
designation, and it is subject to the same independent valuation and the
same separate right of challenge before the courts that apply to
crystallisation at a liquidity event.

(13) The warrant should be incapable of settlement in cash. It confers an
entitlement to shares and to nothing else. It is accordingly not a levy,
not a charge on turnover or profit and not revenue of any public
authority, and it is so designed that no payment obligation towards any
budget can arise from it. In excluding settlement in money, the
prohibition restricts the freedom of the undertaking to structure the
discharge of its obligation; that restriction is justified and
proportionate, because it confines the interference to capital ownership
and keeps the undertaking's operating liquidity untouched, which a cash
alternative would not.

(14) Undertakings within the scope of this Regulation include undertakings
governed by the law of third countries which meet the thresholds through
their activity in the internal market. Equal treatment and the level
playing field require that such undertakings assume obligations of
equivalent effect. The obligations laid down in this Regulation attach
only where activity in the internal market meets the thresholds laid down
in it, so that their application to such undertakings rests on the
immediate, substantial and foreseeable effects of their conduct within
the internal market and not on the mere accessibility of their services.
Where the law governing an undertaking does not give
effect to the subscription right, the undertaking should be required to
procure a subscription of equivalent effect as an obligation of result,
without prejudice to the company law of its incorporation, and compliance
should be secured through the enforcement powers laid down in this Regulation,
including, as a last resort, the power to prohibit the making available of
the relevant goods and services on the internal market.

(15) The issuance of shares pursuant to a citizens' capital warrant
requires derogations from certain provisions of Directive (EU) 2017/1132
of the European Parliament and of the Council concerning pre-emption
rights and the consideration for issued shares. Comparable derogations,
adopted in the general interest, form part of the established acquis in
the field of bank recovery and resolution. Because the shares subscribed
by the Reserve are non-voting for as long as it holds them, provisions of
the law of a Member State that restrict the proportion, issuance
conditions or characteristics of non-voting shares should not apply to the
extent that they would prevent the issuance or holding of those shares. The derogations provided for in this Regulation
are strictly limited to what the execution of the subscription requires,
and they are necessary: an issuance that existing shareholders could
pre-empt, that could be made conditional on a resolution of the general
meeting, or that a Member State's non-voting-share rules could block
outright, could not perform the function this Regulation assigns to it.

(16) The shares subscribed pursuant to the citizens' capital warrant
should rank, for the Reserve, equally with the most favourable class of
shares created after the covered undertaking's designation, and otherwise
equally with its ordinary shares, without affecting the ranking of any
creditor. Ranking the Reserve behind classes created after designation
would let the interference be diluted by the covered undertaking's own
subsequent choices; ranking it above every class, including preference
shares subscribed and paid for before designation, would take from those
earlier investors the protection they bargained and paid for, which this
Regulation does not do. Equal ranking with the most favourable class
created after designation, and no disturbance of the claims of creditors,
confines the interference to what the warrant is: an equity interest, not
a priority claim.

(17) The obligations laid down in this Regulation would be of little
value if they could be routed around by an arrangement that subordinates
the Reserve's participation, by moving the automated assets on which a
covered undertaking's designation rests into another entity, or by the
extinguishment of the warrant in an insolvency or restructuring procedure
engineered or exploited by the same persons who controlled the covered
undertaking. An arrangement that subordinates, reduces or defeats the
Reserve's participation should accordingly be ineffective as against the
Reserve, while remaining effective between the parties to it and as
against third parties, so that anti-avoidance is achieved without
unwinding transactions to which the Reserve was not a party. Where a
covered undertaking transfers its automated assets to another undertaking
otherwise than at arm's length, or to a member of its own group or a
person who controls it or is controlled by it, the obligations laid down
in this Regulation should attach to the transferee as if it were the
covered undertaking, so that the assets which carry the value cannot be
moved beyond the warrant's reach while the covered undertaking that
issued it remains bound in respect of what it retains. Anti-avoidance
should not become a multiplier: a group that divides its automated assets
among several entities should owe the same share of its capital as one
that does not, and the stated percentage should therefore apply to the
dilution borne by the shareholders of the covered undertaking and of every
transferee taken together, and not separately to each of them. Where those assets are instead
acquired in an insolvency or restructuring procedure and control of the
transferee ends up, directly or indirectly, with the persons who
controlled the covered undertaking, or with persons acting in concert or
connected with them, the same obligations should reattach to the
transferee, because no genuine change of ownership has in substance
occurred. That reattachment should not extend to a transferee controlled
by persons who did not control the covered undertaking: a genuine sale to
unconnected purchasers in insolvency or restructuring is the ordinary
operation of that law, not an avoidance of this Regulation, and should be
left to run its course without the obligations of this Regulation
attaching to it.

(18) This Regulation interferes with the right to property of the
shareholders of covered undertakings, whose holdings are diluted upon
crystallisation. That interference is provided for by law, genuinely meets
an objective of general interest recognised by the Union and respects the
essence of the right to property: it is a one-time dilution, capped at a
stated percentage, borne at a moment of realised gain by the shareholders
of undertakings whose value derives from an unprecedented decoupling of
output from labour. The Court of Justice has consistently held that the
right to property is not absolute and that its exercise may be regulated
where regulation is proportionate to a legitimate aim of general
interest. The interference effected by this Regulation is quantified,
foreseeable from designation and less intrusive than measures already
upheld in the field of bank resolution. Subscription at nominal
value rather than by gratuitous transfer keeps the mechanism within the
forms of company law while ensuring that the interference is the stated
dilution and nothing more; requiring the Reserve to pay a market price
would demand public expenditure this Regulation is designed not to need
and would convert a mechanism of ownership into a budgetary one. The fair balance rests also on
what the covered undertaking receives: a single harmonised regime of
access to the internal market in place of divergent national levies and
participation schemes, and the legal certainty of an interference fixed
in advance in amount and in moment.

(19) Proportionality further requires safeguards. The dilution borne by
shareholders is capped by this Regulation and verified by an independent
valuation, which is challengeable separately from the transaction it
accompanies and correctable in both directions. The safeguard the
valuation secures is that the interference can never exceed the stated
percentage in execution: the dilution is capped, its price is set by the
event that crystallises it, and no application of this Regulation may take
from shareholders more than the interference it names. That executional
ceiling, not a crisis counterfactual, is what keeps the interference
proportionate in a permanent regime. Neither designation nor
crystallisation suspends, conditions or unwinds any transaction. Every
decision taken under this Regulation is subject to effective judicial
protection in accordance with Article 47 of the Charter of Fundamental
Rights of the European Union.

(20) Where a liquidity event itself establishes a price, a valuation
delivered in advance of the event would be conjecture about a number the
event is about to produce. The independent valuation should therefore be
delivered promptly after completion, while the legal effect of the
subscription attaches at completion and its execution follows delivery of
the valuation.

(21) The European Citizens' Capital Reserve should hold the warrants and
the shares arising from them exclusively for the benefit of holders. Its
assets and income are not public revenue: they should not enter the
general budget of the Union or any national budget, and no payment should
flow between the Reserve and any budget in either direction. In this the
Reserve resembles a statutory funded pension scheme, whose assets are held
for beneficiaries and are not at the disposal of any treasury, rather than
a fund of the Union. The insulation of the Reserve from public finances is
not an administrative preference but a constitutive feature: it is what
makes this Regulation a mechanism of ownership rather than of taxation.

(22) Income from holdings in undertakings governed by the law of a third
country may be taxed at source in that country at rates which the Reserve,
being resident in no State, may be unable to reduce by treaty. The remedy, where there is one, lies in
international agreements, which are concluded in accordance with the
procedures laid down in the Treaties and which this Regulation neither
prejudges nor requires. This Regulation does not direct the Reserve to
arrange its holdings so as to reduce taxation in a third country; an
instrument founded on the proposition that capital should be broadly owned
is in no position to legislate its own treaty shopping. What this
Regulation can do, and does, is oblige the Reserve to report each year the
amount it was unable to recover, so that the cost is known rather than
assumed away.

(23) The Reserve should be a passive owner. It should exercise no votes,
seek no influence over the management of any undertaking and pursue no
industrial policy. Its function is to hold and to distribute, not to
direct. The mandatory presence of the Reserve in the capital of covered
undertakings restricts the free movement of capital. That restriction is
justified: it serves the general interest set out in these recitals, it
applies without distinction to undertakings and investors of the Union
and of third countries, and it is proportionate precisely because the
statutory passivity of the Reserve withholds from it every attribute of
special control that has led the Court of Justice to censure public
shareholdings. A holding which can neither vote nor veto nor instruct
exerts no public influence for an investor to fear.

(24) The Reserve should retain from its income what is necessary to
preserve the real value of its capital and distribute the remainder. That
rule, drawn from the practice of long-horizon sovereign funds, means
distributions grow with the portfolio and compound across decades. It also
means distributions begin modestly. This Regulation makes no promise of
substantial early payments and should not be presented as making one; its
horizon is generational.

(25) Every citizen of the Union who has reached the age of 18 years should
hold an equal entitlement in the Reserve by operation of law, without
application, means test or condition. Universality is design, not
generosity: a means-tested entitlement would divide the population into
contributors and recipients, invite perpetual contestation of the boundary
and convert an ownership stake into a welfare payment. An equal
entitlement held by all is defensible by all.

(26) The entitlement should be personal. It should be incapable of
transfer, assignment, pledge, attachment, surrender or redemption, so that
it cannot be bought out of the hands of those it serves, whether by
markets, by creditors or by the holder's own moment of hardship. That
restriction on the alienability of the entitlement is a justified and
proportionate limitation under Article 52(1) of the Charter and respects
the essence of the right, since it attaches to the underlying entitlement
only, while amounts distributed are the holder's property, freely usable
and inheritable, and it is necessary so that the objective of durable,
broadly held capital ownership is not defeated by immediate liquidation.
Amounts
distributed, once received, are ordinary property of the holder,
inheritable and freely usable.

(27) Member States should administer entitlements through national
vehicles, since Member States hold the civil registries and payment
infrastructure that administration requires. Administration fees should be
capped and entitlements portable, so that the quality of a Member State's
administration cannot diminish the substance of a citizen's entitlement.
The cap on fees limits the freedom of designated vehicles to set prices;
that limitation is necessary and proportionate to prevent the erosion of
the entitlement by administrative costs. The administration of
entitlements is a service of general economic interest, and the cap is
compatible with the freedom to conduct a business on the conditions
Article 106(2) TFEU attaches to such services and proportionate under
Article 52(1) of the Charter; Member States remain free
to compensate designated vehicles for verifiable net costs above the cap.

(28) The history of pooled public assets is a history of raids. The assets
of the Reserve should therefore be protected by enumerated prohibitions on
lending, guarantee, transfer and encumbrance in favour of public
authorities, and the Reserve should not acquire sovereign debt, so that it
cannot become a captive purchaser of the obligations of any government.
The exclusion of sovereign debt is a rule of portfolio governance internal
to the Reserve, securing its independence, and restricts no movement of
capital by any other person. An
ordinary regulation cannot bind future legislatures, and this Regulation
does not pretend otherwise; what it can do is ensure that no derogation
from these protections arises by interpretation, and that any future
weakening would need to be enacted expressly, in public, informed by the
independent assessment its reporting provisions require.

(29) Penalties for non-compliance should be effective, proportionate and
dissuasive, and set at a level meaningful to undertakings of the scale
designated. Fines and periodic penalty payments should accrue to the
general budget of the Union and not to the Reserve, so that the body
holding assets for citizens never acquires a financial interest in the
punishment of undertakings. Where an undertaking governed by the law of a
third country persistently refuses to comply with its core obligations,
the Commission should be empowered, as a measure of last resort and
subject to proportionality, to prohibit the making available of the
relevant goods and services on the internal market, since no other means
of enforcement reaches an undertaking with no assets in the Union. Such a
prohibition restricts the freedom to conduct a business recognised by
Article 16 of the Charter of Fundamental Rights of the European Union, and
should accordingly remain available only where no less restrictive measure
can secure compliance, for as long as the refusal persists and no longer.
So conditioned, the prohibition respects the essence of that freedom: it
is temporary, reversible on compliance and confined to the goods and
services concerned, and it leaves the undertaking's activity outside the
internal market untouched.

(30) The premise of this Regulation, that automation at the designated
scale durably decouples output from labour and concentrates ownership, is
an empirical claim, and empirical claims can prove wrong. The Commission
should monitor adoption, employment effects and ownership concentration,
and where the evidence does not support the premise, should state so
expressly and propose amendment or repeal. A regulation founded on a
falsifiable claim should carry its own test. The same monitoring should
extend to the share of value added accruing to labour in the Union as a
whole, in both directions: where that share declines, the evidence
informs the assessment under Article 1 of whether the participation
secured remains adequate to its objective, and where it does not
decline, the same assessment asks whether the obligations imposed remain
justified at their level, so that the indicator moves no obligation of
any undertaking but disciplines the instrument itself.

(31) In order to keep the methodologies for counting turnover, employment
and value, and for calculating the retention necessary to preserve the
real capital of the Reserve, aligned with technological and market
developments, the power to adopt acts in accordance with Article 290 of
the Treaty on the Functioning of the European Union should be delegated to
the Commission in respect of amendments to Annexes I and II. The essential
elements of this Regulation, including the designation criteria, the
percentage and terms of the warrant, the entitlement and its protections,
are laid down in the enacting terms and are not subject to delegation. It
is of particular importance that the Commission carry out appropriate
consultations during its preparatory work, including at expert level, and
that those consultations be conducted in accordance with the principles
laid down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making. In particular, to ensure equal participation in the
preparation of delegated acts, the European Parliament and the Council
receive all documents at the same time as Member States' experts, and
their experts systematically have access to meetings of Commission expert
groups dealing with the preparation of delegated acts.

(32) In order to ensure uniform conditions for the implementation of this
Regulation as regards the establishment of the list of independent valuers
and their appointment, implementing powers should be conferred on the
Commission. Those powers should be exercised in accordance with Regulation
(EU) No 182/2011 of the European Parliament and of the Council.

(33) The administration of entitlements involves the processing of
personal data, limited to what the identification of holders and the
execution of distributions require. That processing is necessary for the
performance of a task carried out in the public interest, and no data
beyond those fields should be collected or retained. Regulation (EU)
2016/679 applies to such processing. The European Data Protection Supervisor was consulted in
accordance with Article 42(1) of Regulation (EU) 2018/1725 of the European
Parliament and of the Council and delivered an opinion on [date].

(34) Since the objective of this Regulation, namely to ensure on the basis
of harmonised rules that the gains of hyper-automated production in the
internal market are broadly owned, cannot be sufficiently achieved by the
Member States, because the undertakings concerned operate across the
entire internal market and national measures would create the very
divergence this Regulation removes, but can rather, by reason of its scale
and effects, be better achieved at Union level, the Union may adopt
measures, in accordance with the principle of subsidiarity as set out in
Article 5 of the Treaty on European Union. In accordance with the
principle of proportionality as set out in that Article, this Regulation
does not go beyond what is necessary in order to achieve that objective.

(35) This Regulation respects the fundamental rights and observes the
principles recognised by the Charter of Fundamental Rights of the European
Union, in particular Articles 16, 17, 20, 34 and 47 thereof, concerning
respectively the freedom to conduct a business, the right to property,
equality before the law and the right to an effective remedy and to a
fair trial.

(36) Application of the substantive obligations of this Regulation should
be deferred so that undertakings, Member States and the Commission can
prepare, while the notification obligation applies from entry into force
so that the first designations follow without delay,

---

Drafting notes (non-normative). Recitals use 'should' throughout and
impose nothing (JPG guideline 10). Each recital carries weight the
enacting terms need: (4) is the assets-not-flows doctrine; (5) is the
DC-26 scope-and-limits recital answering objection 12, conceded in full;
(10) the in-time doctrine and the answer to retroactivity, with (11) and
(12) justifying the extraction and long-stop triggers added to Article
5(3); (13) and (21) the fiscal characterisation defence; (9) the Article
345 TFEU answer; (15) and (18) the BRRD-pattern property-interference
justification, with (19) and (20) the safeguards, and (16) and (17) the
ranking and anti-avoidance rules added to Article 5(4)(b) and 5(10) to
(12); (24) the DC-14 honesty rule; (25) the universality argument; (28)
the honest limits of entrenchment after the round-1 and round-2 findings;
(30) the falsification condition, which is DC-18; (31) carries
the standard Better Law-Making language including the equal-access
sentence the Parliament expects; (34) is the standard subsidiarity
formula. The final recital ends with a comma by convention, leading into
the enacting formula.


# SOURCE: own-the-machine/pipeline/EXTERNAL-REVIEWS.md

# External reviews: what was raised, what changed, what was refused

The gates in `pipeline/reviews/` record what the project's own machinery
found. This file records what people outside it found, and what happened
next. It exists so that anyone who takes the trouble to review this draft
can see exactly what their review did, including where it was refused and
why. A reviewer who cannot tell whether they were heard does not review
twice.

Format per review: the challenge in the reviewer's terms, the disposition,
and the provision that carries it.

---

## Review 3, 21 August 2026: legal basis, valuation bottleneck, empirical baseline

**1. Article 114 needs genuine harmonisation, not a desirable policy.**
ACCEPTED, and it was the most valuable finding of the three. Recital 1
asserted that Member States were diverging with nothing behind the
assertion, which is precisely what *Tobacco Advertising* (C-376/98)
forbids, in the recital carrying the legal basis. The answer is
`evidence/EVIDENCE.md` section 8: eight Member States operating digital
services taxes at rates from 1,5 % to 7,5 % on bases that do not match,
entry thresholds differing by four orders of magnitude, six more Member
States with proposals not yet adopted. The legal-basis gate then confirmed
the record suffices to carry Layer 1 under Article 114.

A second correction followed on 21 August: recital 1 had still said "a
majority of Member States", where the evidence says eight of twenty-seven.
The recital now says what the evidence says.

**2. Valuation disputes will bottleneck in litigation; insert binding
arbitration.** REFUSED, with reasons on the record. Article 6(5) means a
challenge does not suspend the transaction and Article 6(4) corrects in
both directions after the event, so the gridlock the proposal guards
against does not arise. A binding tier between the valuation and the
courts would have to satisfy Article 47 of the Charter and the *Meroni*
limits on delegation, and would buy nothing that Article 6 does not
already provide. DC-34 records the refusal so that the next reviewer to
propose it can see it was considered rather than missed.

**3. Argue from ownership rather than from the falling wage share.**
ALREADY DONE, and verified rather than asserted: the recitals contain no
wage-share or labour-share argument, and DC-15 is the rule that keeps it
that way.

---

## Review 4, 21 August 2026: six corporate-structuring routes

The most productive review the project has had, and the first where the
answers were not already in the articles. Five of the six required new
drafting.

**1. Stay private for ever and the warrant never crystallises.** ACCEPTED.
Article 5(3) now crystallises the warrant before any liquidity event on
either of two triggers: shareholder extraction exceeding 25 % of covered
turnover over the same period, and a seven-year long-stop from issuance.
DC-35.

**2. Bury the Reserve under later preference classes.** ACCEPTED. Article
5(4)(b) ranks the Reserve's shares equally with the most favourably
ranking class created *after* the designation, which answers the attack
without expropriating preferences investors actually paid for before it.
Article 5(10) makes a subordinating arrangement ineffective as against the
Reserve while leaving it effective between the parties, so anti-avoidance
does not unwind transactions the Reserve was never party to. DC-36.

**3. Demerge or licence the automated assets into a clean entity.**
ACCEPTED. Article 2(14) defines automated assets and Article 5(11) makes
the transferee issue its own warrant. See the correction below, which
matters.

**4. Third-country withholding tax strips the Reserve's income.**
ACCEPTED IN PART, and the partial answer is stated as partial. Article
8(5) requires the unrecoverable amount to be published annually. A second
limb permitting the Reserve to arrange its holdings so as to reduce the
rate was drafted and struck: it would have written treaty shopping into an
instrument whose entire case is that it is not a fiscal device. Objection
18 says in terms that publication is a smaller answer than the problem.
DC-38.

**5. Phoenix the business through an insolvency.** ACCEPTED. Article 5(12)
reattaches the obligation where the same owners, judged by control or by a
majority of economic rights, reacquire the assets, with no time window. It
expressly does not apply where control passes to persons who did not
control the covered undertaking, because reattaching to a genuine rescuer
would expropriate the rescue. DC-39.

**6. Early-phase distributions are pennies, and the scheme discredits
itself on its first payment.** ACCEPTED. Article 10(6) declares a
distribution only where each holder would receive at least ten times the
average cost of executing one payment, with a backstop of at least once in
every three calendar years, and Article 10(7) publishes the withheld
per-holder amount and the per-holder capital in a year with no payment.
Annex II point 4 states the threshold as a ratio to the payment cost
rather than a euro figure, because a number in an annex ages and gets
quoted. DC-40, and DC-31 requires the stake to be shown wherever a payout
figure is.

---

## What the project's own gates then found in the answers

Recorded here because it bears directly on the value of review 4, and
because it is the most useful thing in this file for anyone deciding
whether to spend time on this draft.

The answer to route 3 contained a defect worse than the route. Article
5(11) required the transferee to issue its own warrant while the
transferor's obligations continued "unaffected". A group dividing its
automated assets among five subsidiaries would therefore have owed 3 %
from each of them and 3 % from the parent. That breaks the 3 % ceiling in
Article 7(2), which is the proportionality anchor the entire defence of
this instrument rests on.

It is now capped: the transferor stays bound for the automated assets it
retains, and the aggregate across the covered undertaking and every
transferee cannot exceed the stated percentage of their combined fully
diluted capital, with Article 7(2) stating the same cap on the same
aggregate basis.

Two things about how it was found are worth more than the fix.

It survived nine rounds of hostile counsel. It was found only when the
Design Consequences table was corrected: DC-37 had described the provision
as attaching "pro rata to value", which was the rule before the article
was amended. The drafters had been reading the table rather than the
article. A derived description that misdescribes its source does not
merely mislead a reader; it hides the defect from the authors, because a
stale summary reads as a statement that the thing has already been
checked.

And it happened twice in one day. After Article 5(11) was capped, DC-37
still said the transferor's obligation "continues unaffected", the exact
words struck from the article that morning. Both are now corrected in the
memorandum and in all four translations.

---

## Standing burdens, not defects

Named here so no reviewer spends time discovering them. The
characterisation of the participation mechanism under Article 114 remains
contestable and the instrument is layered so that the fight happens where
it belongs; see `regulation/memorandum/severability.md`. The Charter
Article 17(1) fair-balance argument for healthy going concerns cannot lean
on the BRRD cases, which assume failing banks, and objection 1 says so.
Subsidiarity remains a yellow-card risk.

## Open, and deliberately so

Two items from the 21 August gate run were recorded rather than fixed,
because each is a drafting decision that should be taken deliberately:
the position of a sub-threshold transferee under Article 5(11), and five
further acquis interface points. Both are in
`pipeline/reviews/2026-08-21-full-suite-post-recitals.md`.


---

## Review 4, 27 August 2026: the ECI Forum's answer to the Gate 1 advice request

Received 27 August 2026, six days inside the eight-working-day maximum, in
answer to the four questions of campaign/GATE1-LETTER.md (submitted 21
August, request 2332). The advice is independent (European Citizen Action
Service via the Forum), expressly non-binding on the Commission, and is
recorded here verbatim before anything was decided on it, as the letter and
campaign/FORUM-REPLY-PLAYBOOK.md require.

### Verbatim

> Sent on: 27/08/2026

> Dear Citizen,
>
> Thank you for submitting your inquiry through the ECI Forum.
>
> We understand that by your proposal for an ECI you would like the European Commission (EC) to propose a measure that would ensure EU citizens' participation in the productivity gains of undertakings active in hyper-automated production by requiring such undertakings to issue a 3% non-voting warrant of their capital to a holding in the interest of EU citizens.
>
> To be successfully registered, a proposed European Citizens' Initiative (ECI) must be in accordance with Article 6 (3) Regulation (EU) 2019/788 (ECI Regulation), i.e. the proposed initiative must not manifestly fall outside the framework of the Commission's powers to submit a proposal for a legal act of the Union for the purpose of implementing the Treaties; furthermore it must not be manifestly abusive, frivolous or vexatious nor manifestly contrary to the values of the EU in Article 2 TEU and rights enshrined in the Charter of Fundamental Rights of the EU.
>
> Article 114 TFEU, proposed in your enquiry, could constitute a legal basis for your proposed measure only under a very wide interpretation of this provision. A measure based on Article 114 TFEU must aim to promote the proper functioning of the internal market, must harmonise the national laws of the EU member states, and must not concern fiscal measures.
>
> While the definition of undertakings active in hyper-automated production would require a harmonised EU-wide rule, the creation of a fund to which these undertakings must contribute would arguably not harmonise the laws of the EU member states. As the EC usually takes a more restrictive approach when it comes to harmonisation measures, we suggest that you consider an alternative legal basis for your proposal (particularly Article 352 TFEU, also proposed in your enquiry).
>
> Moreover, in your current proposal the measure is designed as a social measure rather than as internal market measure. If you want to suggest Article 114 TFEU as a legal basis, we recommend that you further elaborate why your proposal is an internal market measure aiming at harmonising the law of the EU member states. You could for example argue that divergent national rules on citizen participation could distort competition in the internal market and therefore should be harmonised. The EC has already accepted a similar logic related to the wealth tax initiative in Implementing Decision (EU) 2023/1487, and we consider that reference to this Decision would support your proposal.
>
> Although your measure does not directly concern taxation, the EC might take the view that it is also covered by the exclusion of fiscal provisions under Article 114(2) TFEU, because it has similar effects by imposing financial contributions on undertakings. If this is the case, you could suggest Article 115 TFEU as proposed legal basis for your measure, as Article 115 TFEU does not exclude fiscal measures. However, rules under Article 115 TFEU must equally harmonise the laws of the member states as provided for by Article 114 TFEU. It is therefore not sufficient to propose a separate legal act in addition to the national laws of the EU member states, but national rules must be replaced by the suggested act on EU level. This means that Article 115 TFEU would equally only offer a legal basis under a very wide interpretation.
>
> Given the narrow approach by the European Commission to the interpretation of Articles 114 and 115 TFEU, you might want to consider Article 352 as alternative legal basis for your proposed measure. Article 352 provides a more general legal basis for legal acts pursuing one of the goals of the EU set out in the Treaty on the EU (TEU). Your proposed measure could serve as a contribution to the goals set out in Article 3 TEU, namely balanced economic growth and price stability as well as a highly competitive social market economy, aiming at full employment and social progress. The Council has, for example, adopted a recommendation on employee participation in profits and enterprise results based on the predecessor of Article 352 TFEU (see EUR-Lex - 31992H0443 - EN - EUR-Lex).
>
> Please also note that measures based on Article 114 can be adopted by a qualified majority, whereas measures based on Articles 115 and 352 require unanimity. You might therefore wish to take into consideration a proposal for a recommendation instead of a binding legal act. As your idea affects fundamental rights such as equality, the freedom to choose an occupation and property (because only a defined type of companies is concerned), the EC might examine whether the measure is proportionate to the aims that you want to achieve. If the EC considers the measure to be disproportionate, it would not hinder registration of your ECI, but we consider that addressing these possible concerns upfront might increase the chances that your ECI is registered.
>
> Partial registration of your initiative is possible, if some of the suggested goals fall outside the competence of the EU to propose a legal act as anchored in Article 6(3) of the ECI Regulation. If the goals of your proposal comply with the requirements set out in the ECI Regulation, it must be registered by the EC, regardless of the mechanism described in your proposed legal act. The contestability of the proposed legal mechanism is therefore not a relevant consideration for the registration of the ECI itself, if the goals pursued do not manifestly fall outside the scope of the EC's competence.
>
> Likewise, the ECI Regulation itself does not state how the proposal should be formulated or that a full draft is required. As outlined above, the crucial element for the EC's assessment is whether the proposal is covered by their competences. Thus, you may provide a full draft for a legal act if it follows from the draft that the proposal falls within the Commission's competence.
>
> We trust that the above information is of assistance to you. Should you require further assistance, please do not hesitate to contact us.
>
> Kind regards,
>
> The European Citizens' Initiative Forum Team

### Disposition

Playbook scenario B, with the weakest-point answer of scenario C folded in.
Point by point:

1. **Decomposition rule 5 is CONFIRMED and moves from assumption to
   finding.** "If the goals of your proposal comply with the requirements
   set out in the ECI Regulation, it must be registered by the EC,
   regardless of the mechanism described in your proposed legal act." The
   objectives are the unit of assessment; the annexed mechanism's
   contestability "is not a relevant consideration for the registration".
   regulation/memorandum/severability.md rule 5 is rewritten accordingly,
   citing this reply and its non-binding character.
2. **The draft act carries no registration penalty.** It may be provided
   "if it follows from the draft that the proposal falls within the
   Commission's competence", which is precisely what the severable-layer
   drafting is for. The registration path stays as designed: objectives as
   Layer 0, full Regulation annexed.
3. **The weakest point is named where objection 2 already argues it**:
   Article 114 holds "only under a very wide interpretation"; the fund limb
   does not harmonise; the measure reads social rather than internal-market;
   and the 114(2) fiscal exclusion might be stretched over it by effect.
   Nothing in this changes the file's position, because the file already
   holds it; the advice to "further elaborate" the divergence-distorts-
   competition argument points at work the memorandum and evidence base
   have done since 21 August.
4. **Two citable gains.** The advisers recommend citing Implementing
   Decision (EU) 2023/1487 for the divergence logic ("we consider that
   reference to this Decision would support your proposal"), converting
   GATE1's open question 4 into a yes. And they supply a precedent the file
   did not have: Council Recommendation 92/443/EEC on employee
   participation in profits and enterprise results, adopted on Article
   352's predecessor, which strengthens the Layer 3 basis argument.
5. **Recorded, not adopted:** the suggestion of a non-binding
   recommendation instead of a legal act (it would surrender the
   instrument's entire point and is not required for registration); Article
   115 as a fiscal-safe fallback basis (noted in the legal-basis record as
   a third string, with the advisers' own caveat that it demands the same
   wide reading as 114); and the reminder that 115/352 require unanimity,
   which the severability architecture already prices in.
6. **Gate 1, sounding one: PASSED.** No kill criterion is touched: the core
   ask is registrable on the advisers' reading, partially at worst. The
   response, per playbook scenario B: thanks, no follow-up question.
   Soundings two and three proceed with this reasoning quoted.

## Review 5, 5 September 2026: an ECI veteran's reply to sounding letter C

Received 5 September 2026, within a day of the letter, in answer to
campaign/SOUNDING-LETTERS.md letter C. A short written reply from a
practitioner who has taken initiatives through registration; no call, no
question list taken up. Recorded verbatim on its substance, nameless as
the letter promised, before anything was decided on it.

### Verbatim (substance)

> One thing I did not see with your text was proposed legal basis in the
> Treaty on the functioning of the EU. Since you are demanding a new tax on
> companies I guess that without that the Commission might decide that
> your proposal implies a Treaty change and therefore not to register your
> ECI.

> I think it's also acceptable to put all ECI's in the same straight
> jacket: title, short proposal, legal basis, longer explanatory annex plus
> any requested law added. Without this discipline it would be difficult
> for people going on to the Commission portal to compare different ECIs
> and decide which to sign.

> My advice would be to draft your proposal as per instructions with the
> correct character count and see if it can resonate with the public.
> Several drafts are necessary.

### Disposition

1. **The legal basis was not visible where a reader lands. ACCEPTED as a
   presentation defect, verified before acceptance:** the site's landing
   page, law index and about page carried no Treaty article; the
   explanatory memorandum states the basis in section 2.1, a third of the
   way down; the registration-format text with its Treaty-provisions
   section existed only in this repository. Two fixes: the preamble now
   carries the citations every Union act opens with, naming Article 114
   (regulation/recitals.md, closing the legal-form finding of 19 August;
   the two-act form for the Article 352 layer is recorded in memorandum
   2.1), and the registration-format text is published on the site with the
   legal basis on the first screen.
2. **The fiscal reading is the default reading. RECORDED against objection
   2.** This is the third independent reader to reach for "tax" before
   anything else, after hostile counsel (pipeline/reviews, 27 August,
   attack 1) and the ECI Forum's advisers (Article 114(2) "by effect").
   Objection 2 already states the case at full strength; what changes is
   the status of the risk, from an adversary's argument to the ordinary
   reader's first impression, which the presentation must answer before
   the argument gets a hearing.
3. **The Treaty-change instinct. ANSWERED BY PRESENTATION, not by new
   drafting.** The file seeks no Treaty amendment (memorandum 2.1;
   severability layers); the registration text now says so in one
   sentence. The instinct arose because no basis was visible, and it is
   the instinct the Commission's registration unit will share.
4. **The format advice. ALREADY MET, NOW VISIBLE.** campaign/REGISTRATION-TEXT.md
   has held title, objectives, Treaty provisions and annex within the Annex
   II limits of Regulation (EU) 2019/788 since August; it is now rendered on
   the site. "Several drafts" and "see if it can resonate with the public"
   are taken as the sequencing rule for Gate 2: the short text is tested on
   people before the long one is perfected further.
5. **Gate 1, sounding three: ANSWERED.** No kill criterion is touched. What
   was asked for (the registration dialogue as lived) was not what came
   back; what came back was worth more.


# SOURCE: own-the-machine/campaign/REGISTRATION-TEXT.md

# ECI registration text

The text that would go into the Commission's registration form, in the
fields and within the limits set by Annex II to Regulation (EU) 2019/788.
Status: DRAFT, not filed. Filing is a Gate 2 action. This exists because
every Gate 1 conversation will ask what the ask actually says, and the
draft Regulation is not that: under Article 6(3)(c) the registration test
is applied to this text.

Two things govern the drafting. First, Article 6(4) allows partial
registration only where part of the initiative "including its main
objectives" survives, so the main objectives here are Layer 0 of
regulation/memorandum/severability.md, an assessment and a proposal, and
the draft Regulation sits in the accompanying-draft slot where trimming
can reach it without touching the ask. Second, Annex II counts the
objectives and the annex in characters **without spaces**.

---

## 1. Title

> Citizens' participation in the productivity gains of hyper-automated production

79 characters, limit 100.

---

## 2. Objectives

We ask the Commission to assess, and to propose instruments ensuring,
the participation of citizens of the Union in the productivity gains of
hyper-automated production, meaning production whose output is
substantially decoupled from employment.

Returns from highly automated production risk concentrating in a few large
undertakings. Divergent national responses to the digital economy can
fragment the internal market; harmonised participation mechanisms merit
assessment.

We therefore ask the Commission:

1. to assess, and to propose harmonised criteria and a procedure for, the
designation of undertakings whose output is substantially decoupled from
employment;

2. to propose mechanisms by which the gains and value of such production
become broadly owned by, or shared with, citizens of the Union;

3. to report periodically on automation, employment and ownership
concentration, so that any instrument adopted can be corrected or
repealed on the evidence.

A complete draft Regulation accompanies this initiative as an
illustration. The objectives, not the draft, are what we ask for.

932 characters without spaces (1089 with), limit 1 100.

---

## 3. Provisions of the Treaties considered relevant

Article 114 TFEU (approximation of laws for the establishment and
functioning of the internal market), as the primary contemplated basis
for designation, transparency and the harmonised participation
mechanism.

Article 352 TFEU, as the residual basis for any element the Commission
considers to fall outside Article 114, in particular the creation of a
Union body holding assets and the individual entitlement.

Article 3(3) TEU and Article 9 TFEU, as to the objectives of a highly
competitive social market economy and of taking social requirements into
account in the Union's policies.

No amendment of the Treaties is sought. The initiative asks the Commission to assess the use of existing bases,
primarily Article 114 TFEU and residually Article 352 TFEU. Reliance on
Article 352 would require a separate act, with Council unanimity and
Parliament's consent. The illustrative draft currently cites Article 114
only; it is not a completed two-act architecture. The accompanying draft
is severable by layer; the Commission decides what, if anything, can be
registered and proposed within its powers.

---

## 4. Annex on the subject, objectives and background

Subject matter. The initiative concerns the distribution of the capital
value produced by highly automated undertakings. Its premise is
empirical, not ideological: where output is substantially decoupled from
employment, the historic channel through which citizens shared in
productivity, namely wages, may not carry all the gains. The initiative
asks the Commission to open a second channel, ownership, and to do so on
harmonised Union rules rather than leaving it to twenty-seven divergent
national answers.

The fragmentation is not hypothetical. Eight Member States operate
digital services taxes at rates between 1,5 % and 7,5 % with thresholds
that differ by orders of magnitude, several more have proposals before
their parliaments, and the resulting patchwork applies different
liabilities to the same cross-border service depending on where its
users happen to be. The European Parliament rejected a robot tax in
February 2017, the question has returned with the large-scale adoption of
artificial intelligence, and no Union instrument occupies the field.

The mechanism we illustrate. Undertakings above objective thresholds
would be designated on the model of Regulation (EU) 2022/1925. Each
designated undertaking would issue, once, a non-voting citizens' capital
warrant entitling a common reserve to subscribe at nominal value for 3 %
of its fully diluted capital, crystallising on the undertaking's first
liquidity event, or earlier where it distributes value to its own
shareholders above a stated share of its turnover, or in any event seven
years after issuance. The reserve would hold the resulting shares without votes, board seats or any say in management, insulated in both directions from Union and national
budgets. Citizens of the Union would hold equal, personal and
non-transferable entitlements to distributions as and when they are
realised, carrying no right of individual cash redemption or sale,
administered through national vehicles.

The participation mechanism is settled in shares; Reserve capital and
citizen distributions remain outside public budgets. The Reserve pays
the shares' nominal value in cash, the undertaking bears valuation costs,
and enforcement fines accrue to public budgets. No undertaking is required
to sell assets to settle the warrant. The warrant also crystallises at the seven-year backstop even without
a liquidity event or shareholder extraction. We propose this as a measure
of company law and market regulation; its possible classification as a
fiscal measure remains contested despite its settlement in shares.

Honesty about the difficulty. We do not claim the legal basis is
uncontested. The characterisation of the participation mechanism under
Article 114 is arguable and we have published the argument against it at
full strength, together with the case law relied on by both sides, in a
public memorandum of objections. Our position is that a characterisation
dispute of this kind belongs to the legislative stage, as it did for the
initiative on wealth taxation registered in 2023, and not to the
registration stage, where the test is whether the ask manifestly falls
outside the Commission's powers.

Severability. The ask above is drafted so that it survives trimming. Its
main objectives are an assessment and a proposal, within the Commission's Treaty powers. Whether it can propose particular
elements remains subject to the applicable legal basis. If
the Commission concludes that parts of the accompanying draft exceed
what it could propose, we would prefer partial registration under
Article 6(4) of Regulation (EU) 2019/788 to refusal, with any trimming
applying to the accompanying draft rather than to the objectives.

Evidence and correction. Article 14 requires a published assessment,
including evidence contrary to the draft's assumptions about decoupling.
The Commission would propose amendment or repeal where appropriate;
correction or repeal is not automatic. The complete text, the
objections to it, the evidence base and the record of every adversarial
review it has been through are public at ownthemachine.eu.

3484 characters without spaces (4100 with), limit 5 000.

---

## 5. Draft legal act

Annex II permits organisers to submit a draft legal act. The complete
draft Regulation at regulation/ is submitted in that slot, with the
memorandum of objections and the evidence base referenced but not
submitted, since they are published.

---

Drafting notes (not part of the registration). The title avoids the
campaign name, which is a communications asset and not a description of
the ask. The objectives close by saying which of the two documents is
the ask, so that a registration officer reading only field 2 knows the
draft is illustrative. The annex concedes the legal-basis difficulty
rather than waiting to be caught on it, on the same reasoning as the
Gate 1 letter: the audience has read stronger cases than this one and
discounts a text that claims certainty. The digital services tax figures
are those in evidence/EVIDENCE.md section 8 and carry its sourcing; they
must be re-verified before filing, not before sounding.


# SOURCE: own-the-machine/campaign/DISTRIBUTION.md

# Distribution: how the open-source law gains traction

18 August 2026, amended 19 August 2026 (see campaign/GATES.md): the site and
the repositories are public, quietly, ahead of independent registrability advice
(Gate 1). That moves the public moment, not the gates: no announcement, no
active traction push, until Gate 1 clears; constitution still waits for that
advice and filing waits for Gate 2. Traction work before that point is
seeding, not publicity.

## The authorship question, settled

The instinct to omit the book "to avoid conflict of interest" is the wrong fix
for a real concern. Omission does not remove a conflict; it hides one, and
hidden is worse. The campaign is called Own the Machine; the book's cover line
is "who owns the machine"; the four tests structure the regulation's articles.
The connection will be discovered within a day of any traction, and at that
point the story becomes the concealment instead of the idea. The project's own
AI-transparency rule states the principle already: a feature when declared, a
liability when discovered. Authorship works identically.

The legitimate version of the instinct is about EMPHASIS and MONEY, and both
have clean mechanisms:

- **The campaign leads with the evidence and the law, not the book.** The book
  appears in the sources of the memorandum, one citation among ECB, Eurostat,
  NBIM and the Polish statute book. The campaign is not a marketing funnel.
- **A standing declared-interest line, everywhere:** "This initiative grew out
  of research for my book. Every campaign-relevant argument is free online in
  five languages; nobody needs to buy anything to evaluate this proposal."
  The essays and reading guide make that literally true today.
- **Keep the declared interest visible.** No royalty pledge is adopted, no
  organisation is constituted and the campaign receives no book proceeds.
  Any future proposal to change that must pass the published funding rules
  and be disclosed before it takes effect.
- **Two voices, one honesty.** The campaign speaks institutionally; David
  speaks as the author who drafted it. Same facts, different registers, no
  pretence they are unrelated.

## What actually creates ECI traction (base rates, again)

Broad public sharing and partner networks can both bring support. Neither
viral reach nor a list of endorsements guarantees completed statements.
Previous campaigns illustrate different routes, not a ceiling on what this
project can achieve. The sharing plan's job is
to (a) make the arguments familiar before the law appears, (b) give partner
organisations ready-made material, and (c) surface the seven organisers and
two institutional partners that Gate 2 requires. Reach that does not serve one
of those three is vanity.

## Phase 1, now to launch: seeding without announcing

Already in motion, and it is the right machine:
- **The September European sequence** (Stable entry, ownership post) IS the
  seeding. Every argument the campaign will need, published first as honest
  analysis with sources, so the eventual law lands on prepared ground.
- Future Stable entries and LinkedIn posts keep building the evidence in
  public: Denmark's LD, the Polish statute, the sanitised literature. By
  launch, a regular reader has met every load-bearing fact.
- **Quietly reserve the handles now** (Bluesky, LinkedIn page, Mastodon,
  GitHub org, YouTube) exactly as the domain was parked. Reserving is free;
  losing consistent Own the Machine handles after launch can be costly.
- Substantive public replies are one channel to test. Record observable
  reach and questions; an anecdotal successful reply is not a conversion forecast.

## Phase 2, at launch: the mechanics

Ranked by expected yield for THIS audience:

1. **The simulator is one possible explanatory asset.** Any shared result must carry its assumptions, date and limits beside both
   the capital and payout figures. Present scenarios, never a personal payment
   promise. Output cards should remain understandable without the source page. This is the one component where genuine
   virality is plausible; design it for that from day one.
2. **The "open-source law" angle for the tech press and HN.** "We are drafting
   an EU regulation like an open-source project; PRs welcome; here is
   GOVERNANCE.md" is a novel story independent of the content. The invitation is open to
   anyone who wants to inspect or contribute to the work; eligibility to sign
   depends on ECI rules, not occupation.
3. **Per-country threshold cards.** "Belgium needs 15,840 of us; live count."
   Keep progress factual; the Commission publishes the
   counts. 27 localised variants from one template.
4. **The hostile-question FAQ as a content series.** One hard question, one
   honest answer, one card each: "Isn't this just a tax?" "Who stops
   politicians spending it?" (answer: here is the Polish statute, article and
   date). The honesty is the differentiator; campaign copy is what everyone
   else produces.
5. **Bluesky/Mastodon EU-policy bubble** for the Brussels crowd, LinkedIn for
   the professional base, Reddit per the existing ledger rule (weeks of
   commenting before any post). Politico/Euractiv op-ed at launch per the
   action plan.
6. **Partner kits over own reach:** every asset downloadable, remixable,
   CC-licensed, so a union local or student group can localise without asking.
   The multiplier is other people's channels.

## Phase 3, sustained: the drumbeat

- Weekly build-in-public notes (what changed in the draft and why), which is
  the Stable's cadence applied to a law.
- Merge decisions as content: "we rejected this PR because it failed the
  universality test" is governance as storytelling, and nobody else has it.
- Milestone moments mapped to the ECI calendar (registration decision, first
  threshold country, hearing) rather than invented occasions.

## What NOT to do

- No launch before Gate 1. A retracted or refused registration after a public
  launch is the worst opening possible.
- No anonymous or pseudonymous promotion of any kind. See authorship, above.
- No paid amplification before organic proof; the budget belongs in Gate 3.
- No dark patterns on the signature path: the COCS handoff is already one
  click too many, and trust is the campaign's only currency.


# SOURCE: own-the-machine/campaign/GATES.md

# Gates and kill criteria

Condensed from FEASIBILITY.md; that file carries the full reasoning.

- **Gate 0 (complete, ~zero cost):** draft the Regulation and memorandum in
  this repository; build the simulator; no announcement. Kill criterion:
  none. The repository was private while this gate ran and is public,
  unannounced, since 19 August 2026, per the amendment at the end of this
  file.
- **Gate 1 (STARTED 21 August 2026, ~zero cost):** admissibility opinion via
  the ECI Forum's free legal advice; three soundings (ETUC/ETUI, one Belgian
  MEP office, one ECI veteran). KILL: if the core ask is unregistrable even
  partially, publish as the book's model law and stop.
  - Forum request **SENT 21 August 2026, ANSWERED 27 August 2026** (six days
    early). Sounding 1 passed: the advice read registration as turning on
    the goals, not on the annexed mechanism. What was submitted is recorded
    in GATE1-LETTER.md; the answer and its disposition in
    pipeline/EXTERNAL-REVIEWS.md.
  - The three soundings: letter A (researcher) sent 2 September 2026,
    letter C (ECI veteran) sent 4 September 2026, letter B (Belgian MEP
    office) follows. Texts in SOUNDING-LETTERS.md. No reply after ten days
    means one short follow-up, then stop.
- **Gate 2 (Q4 2026):** seven credible organisers in seven states plus at
  least two institutional partners, on paper. KILL: fewer than two partners by
  year end means do not file. The partner requirement tests practical
  support; a past initiative's signature count is not a forecast for this one.
- **Gate 3 (2027, resourced launch):** organisational setup, filing and
  launch backed by a costed operating plan. As clarified by the initiator
  on 6 September 2026, engineering and production should use automation
  and volunteered capacity first; no six-figure cash minimum or salaried
  staffing requirement is assumed. Record named responsibilities, available
  hours, actual cash needs and backup arrangements before collection.

Hard constraints: all signatures live on the Commission's COCS (settled law
since 2023); draft the ask in severable layers so partial registration trims
without gutting; the realistic deliverable is the hearing and the Commission's
formal response, not the statute.


## Amendment, 19 August 2026: quiet launch precedes Gate 1

Decision by the initiator: the site (ownthemachine.eu) and the three
repositories go public, unannounced, before the Gate 1 soundings, so
that outreach leads with the living site rather than an attachment and
a confidentiality ask. This moves the public moment, not the gates:
constitution still waits for Gate 1's registrability opinion, filing
for Gate 2, and every kill criterion stands. The site's own /about
page has carried the consequence from day one: if a gate fails, the
page says so and the repository stays up as a public good.


# SOURCE: own-the-machine/campaign/REVIEW-AND-LAUNCH-PLAN-2026-09-06.md

**Own the Machine: project review and campaign operating plan**

Prepared 6 September 2026. Recommendations for discussion with the founding group; this document is a proposed operating plan, not a spending commitment. The accompanying correction package updates campaign prose and the funding gate to reflect an automation-first approach; the enacting legal text and donor exclusions are unchanged.

**Assessment**

The project has a coherent central idea: give citizens a durable claim on automation-related capital without requiring them first to have wages available to invest. The public draft, objections, version history and declared connection to the book make the idea inspectable. Those are substantial assets.

The main weakness is the distance between the careful legal work and its public explanation. Several summaries promise more certainty, narrower coverage or later obligations than the articles support. The participation pages were written for an earlier research stage. They now discourage the ongoing relationships that a campaign needs.

Seven eligible organisers make an ECI possible. They do not establish that a million-signature campaign is ready. Keep the existing gates, but strengthen the coalition gate from a count of partners to evidence of committed capacity, dates, people and funding.

Scope: live homepage HTML retrieved on 6 September; indexed public pages; local English website content, simulator source, key legal articles, registration text, external-review record, campaign documents; book chapter guide, conclusion and selected chapter passages. This is a substantive and communications review, not a full fact-check of the book, independent legal opinion, rendered visual review or accessibility certification. Website subpage findings below refer to the local source unless expressly identified as live.

**1. Corrections before wider publicity**

The table records findings at the start of this review. The accompanying correction package addresses the public-copy items; the reviewer disposition record tracks verification and remaining legal work. These are historical findings, not a claim that all remain open.

| Priority | Finding and evidence | Recommended correction |
|---|---|---|
| Immediate | Live homepage says the equity is claimed only when owners cash in. Article 5(3)(b) also triggers after seven years. FAQ and press copy repeat the simplification; simulator lag guidance says private firms can remain private and the instrument waits. | Explain the liquidity event, extraction trigger and seven-year backstop consistently. Distinguish issuing a warrant from exercising it. |
| Immediate | FAQ presents EUR 75bn valuation and 80-times-payroll as an exclusive coverage test. Article 3 also includes a turnover alternative, durability, rebuttal and designation below thresholds after investigation. The brief says designation is never discretionary. | Describe the numbers as a rebuttable presumption, followed by the investigation route. Remove categorical exclusions of all ordinary large businesses. |
| Immediate | FAQ answers the tax question categorically. The Forum advice recorded on 27 August expressly identifies fiscal-characterisation risk. | Say the proposal is designed as equity participation; its legal classification remains contested. No public-budget receipt does not by itself settle that classification. |
| Immediate | The brief still says Forum advice is due 2 September. Join says no external human has tested the project; the review log now records Forum advice and an ECI veteran's response. | Publish an accurate dated status and distinguish informal advice, completed soundings, formal registration and eventual adoption. Do not describe the Forum response as Commission approval. |
| Immediate | The homepage describes an untouchable entitlement. Article 12's own notes concede limits on binding future legislators. | Say the design includes protections against diversion and avenues for legal challenge; do not promise political or legal invulnerability. |
| High | Registration objectives ask for assessment and mechanisms for broad participation; the brief calls the exact 3% regulation the ask. | Explain precisely what supporters would sign and that the draft mechanism illustrates the broader objectives. Publish a clear boundary on changes the organisers would accept after partial registration. |
| High | Registration objectives assert falling labour share, while the review ledger says the European argument was deliberately moved away from that premise. | Reconcile the registration text with the project's own evidence caveats before filing. This review does not independently establish the latest labour-share figures. |
| High | Sign page describes thresholds as roughly MEPs multiplied by 750. Distribution plan gives Belgium 15,510. | Replace with the official current table; Belgium is 15,840. Use a dated shared data source, not hand-entered figures across translations. |

Article references: [designation](../regulation/articles/03-designation.md), [warrant](../regulation/articles/05-warrant.md), [entitlement](../regulation/articles/10-entitlement.md), [protection](../regulation/articles/12-protection.md), [registration objectives](REGISTRATION-TEXT.md), [external advice](../pipeline/EXTERNAL-REVIEWS.md). Current country requirements: [Commission thresholds](https://citizens-initiative.europa.eu/thresholds_en).

There are two additional drafting questions for counsel. Article 5(4)(e)'s statement about no obligations before liquidity needs reconciliation with paragraph 3's earlier crystallisation. Article 3(8)'s broad rule against arrangements increasing labour compensation needs a clear boundary protecting genuine hiring and pay rises; the FAQ currently presents hiring as the straightforward escape from designation. These are review questions, not determinations that the provisions are invalid.

**2. Strengthen the proposal's economics and the connection to the book**

The book supplies the motivation and institutional examples. It does not independently validate this particular warrant, classification test or EU legal basis. Present three separate propositions: broader capital ownership is desirable; this instrument might create it; this instrument must survive empirical, legal and administrative testing.

Commission an independent economic assessment of the 80-times-payroll proxy, including false positives, outsourced labour, valuation cycles and company responses. Distinguish measured data from estimated private-company valuations. The review should also compare the proposed instrument with plausible alternatives on the same criteria, rather than treating the four design tests as proof that the preferred mechanism wins.

The fund's concentrated exposure deserves a public explanation: if the covered firms lose value during an employment shock, households could face both labour-market and capital-income disappointment. Explain what non-voting ownership and the acquisition restrictions mean for diversification. Publish conservative estimates net of administration, foreign withholding and execution costs, including years with no distribution.

The simulator already discloses continuing cohorts in its assumptions. However, the implementation continues adding new covered company value even at zero growth. That is an assumption about future new designations, not simply compounding the original stake. It needs evidence or an explicitly hypothetical label. Add a closed-cohort scenario that stops additions after the initial pool is exhausted, a separate new-cohort control, and loss/no-distribution scenarios. Distinguish realised distributable income from capital appreciation. Use years after implementation instead of a fixed 2027 start. The lag control should separate time to designation from the seven-year post-issuance backstop.

Do not make a personal annual-euro prediction the campaign's main share card. Keep the simulator as an explanatory tool, carrying assumptions and uncertainty with every exported result. Preserve the book disclosure and free access to the underlying argument; campaign communications should never require a purchase.

**3. Website and public message**

Keep the name. It expresses the project's central question clearly once explained. The first screen should let a reader understand the proposal, its current status and the available next step without understanding warrants or Treaty articles.

Suggested draft, subject to reconciliation with the final registered objectives:

> **When machines create wealth, citizens should share in owning it.**
>
> Own the Machine proposes a common Reserve that would hold shares in qualifying highly automated companies and distribute income equally to adult EU citizens. We are preparing a citizens' initiative asking the European Commission to act. This is a proposal, not an existing benefit; payments would depend on the fund's income.

Before registration, the primary action should be “Get launch updates”, if the organisers adopt a separate opt-in mailing list. Secondary actions: “Read the proposal” and “Help organise”. Keep a clear “Not yet registered; signatures are not open” status. After collection opens, the primary action becomes “Support on the official EU website”.

Introduce an explanatory diagram: qualifying company → non-voting shares in a common reserve → income → equal citizen distributions. Beside it, explain that individual entitlements cannot be sold or redeemed and payments are uncertain. Preserve accessible text equivalents.

Replace the participation page's instruction that supporters are not needed with distinct ways to follow, volunteer, offer organisational support and review the draft. GitHub is useful for public drafting; it should not be the preferred gateway for every prospective organiser. Private contact should be an ordinary option without asking someone to justify it.

The no-list policy is an existing deliberate choice. A mailing list would require a documented change, clear consent and updated privacy text before launch; this review does not authorise implementation. Keep official statements of support separate from newsletter subscriptions. Existing personal correspondence must not be imported into a list.

Use the same meaning in every language, reviewed by native speakers. Prioritise coverage of the actual operating team's languages and public information needs; maintain a visible language-completion matrix. Test comprehension with 15–20 readers unfamiliar with the project: can they explain the ask, eligibility, payment uncertainty, current status and next action? Test mobile navigation, keyboard use, zoom, signing handoff and slow connections before launch. No results from those tests are claimed here.

**4. What the million means**

An ECI needs at least one million valid statements of support and national minima in at least seven Member States. The organising group requires at least seven eligible EU citizens living in seven different Member States; seven different nationalities are not required. Collection lasts twelve months and must start within six months of registration. Success secures institutional consideration and a response, not automatic adoption of the draft. [Commission process](https://citizens-initiative.europa.eu/how-it-works_en).

Plan for **1.3 million submitted statements**, with a sensitivity range of 1.25–1.5 million. At a hypothetical 80% validation rate, 1.3 million yields 1.04 million valid statements. Apply headroom separately to national thresholds: EU-wide surplus cannot compensate for falling short in the seventh country. These are planning assumptions, not a forecast of invalidity.

Maintain an administrative tracker for all 27 countries: official threshold, submitted total, certified total when available, gap, responsible coordinator and information-language readiness. Aim to clear thresholds with headroom in more than seven countries. Choose operational coverage based on confirmed capacity; do not assume the organisers' residence countries must supply the seven successful thresholds.

Online statements use the Commission's central system; official paper forms remain possible. The system provides aggregate country statistics and optional supporter communications without disclosing subscribers' email addresses to organisers. Use those capabilities before building duplicate infrastructure. [Official collection-system guidance](https://citizens-initiative-forum.europa.eu/document/central-online-collection-system_en).

**5. Distribution model and coalition commitments**

The existing distribution plan correctly identifies partner networks as central. Fur Free Europe built a network of 82 partners before launch and ultimately exceeded 1.5 million signatures. That is evidence for investing in coalition capacity, not a promise that the same result transfers to this much more complex proposal. [ECI Forum case study](https://citizens-initiative-forum.europa.eu/document/fur-free-europe_en).

Build one general-public campaign with a common factual message, available in multiple languages. Use voluntary partner publication, editorial coverage, open events, public social posts, subscriptions and freely shareable explanatory material. Geographic tracking serves the ECI's administrative thresholds; do not build political-preference profiles or different claims for different nationalities or demographic groups.

For every participating organisation, record a named owner, approved role, channels it can actually use, publication dates, staff time, translation capacity, any financial contribution and reporting expectations. An endorsement without delivery commitments is useful credibility but contributes zero to the conservative signature forecast. Do not record unconfirmed organisations as partners.

An illustrative capacity model, to replace with evidence:

| Contribution | Hypothetical yield | Total |
|---|---:|---:|
| 20 substantial partner commitments | 25,000 completed statements each | 500,000 |
| 50 smaller partner commitments | 8,000 each | 400,000 |
| Public editorial coverage, public events, direct sharing and owned channels combined | 400,000 | 400,000 |
| Total | | 1,300,000 |

These yields are requirements to test, not industry benchmarks. Audience overlap can make simple addition badly misleading. Deduct overlap and repeat exposure; distinguish an invitation, a click, a reported completion and an officially recorded statement. Large audience counts without demonstrated completion do not justify filing.

The public-information package for partners should contain a two-page explanation, a 60-second captioned video, an accessible presentation, general invitation copy, a difficult-questions FAQ, a speaker briefing, the official signing link when available, printable QR material and a current status sheet. Use dated versions and a named editor. Partners must not add guaranteed payments or claim EU endorsement.

Channel responsibilities:

| Channel | Work and purpose | Useful measure |
|---|---|---|
| Partner channels | Scheduled publication and accessible explanation | Commitments delivered; aggregate collection changes |
| Earned media | Public press kit, interviews and responses to substantive criticism | Accurate coverage and referral activity |
| Owned website/email | Stable explanation, status updates and official signing handoff | Consent-based subscriptions, useful replies and outbound activity where measurable |
| Public social/video | Consistent general message, short explainers, public Q&A and milestones | Sharing and meaningful traffic, not follower totals alone |
| Public events | Open briefings, questions and help navigating official instructions | Attendance, questions resolved and aggregate activity |

Do not budget on buying political reach from Meta or Google in the EU. Both announced restrictions ending the relevant advertising services in 2025. Organic participation is a separate activity. Check any other paid placement against current platform terms and applicable advertising rules before spending. [Meta policy](https://about.fb.com/news/2025/07/ending-political-electoral-and-social-issue-advertising-in-the-eu/amp/), [Google announcement](https://blog.google/company-news/inside-google/around-the-globe/google-europe/political-advertising-in-eu/).

**6. First 90 days, before the collection clock**

| Period | Deliverables | Accountable role |
|---|---|---|
| Days 1–14 | Fix contradictions across English and translations; publish current stage; agree organiser roles, decision rights and acceptable registration scope; adopt or reject an opt-in update list explicitly | Founding group + editor |
| Days 15–30 | Independent legal and economic review briefs; corrected plain-language explainer; reader-comprehension sessions; costed resourcing plan; first written partner delivery commitments | Policy lead + operational coordinator |
| Days 31–60 | Public-information kit; native-language review; coordinator training; open information sessions; measured evidence of audience interest; funding commitments | Partnerships + communications |
| Days 61–90 | Consolidate de-duplicated capacity assumptions; rehearse launch logistics; assess readiness against gates; decide whether to file or continue preparation | Founding group |

Do not count pre-registration interest as signatures, and do not collect unofficial statements in anticipation of registration. Website testing before registration measures understanding and interest, not the actual completion rate on the eventual official form.

Recommended filing conditions: eligible organising group confirmed; coherent objectives; independent advice and remaining risks understood; at least two substantive institutional partners under the existing gate; a wider delivery plan supporting the intended scale; named operational owner, who may be a volunteer; secured core operating runway; current public copy; clear decision on what partial registration would still justify proceeding.

Recommended collection-start conditions: formal registration and final scope published; official system ready; translations checked; partner launch dates reconfirmed; help/contact coverage; a funded operating plan through collection and verification. Registration creates a six-month launch deadline, so preparation should precede filing.

**7. Twelve-month collection programme**

The following trajectory is a management target, not a prediction or evidence that publicity can produce it:

| End of month | Cumulative submitted target |
|---:|---:|
| 1 | 100,000 |
| 2 | 180,000 |
| 3 | 280,000 |
| 4 | 380,000 |
| 5 | 490,000 |
| 6 | 600,000 |
| 7 | 710,000 |
| 8 | 820,000 |
| 9 | 940,000 |
| 10 | 1,060,000 |
| 11 | 1,180,000 |
| 12 | 1,300,000 |

Launch week: publish the registered ask, organiser identities, funding position and official signing instructions together; coordinate agreed partner publications; hold one open briefing; answer questions publicly; verify links and status daily. Use precise dates and the Commission's actual deadline.

Months 2–3: correct observed misunderstandings, complete missed partner commitments and improve accessibility. Months 4–6: refresh material with answered questions, independent reviews and genuine milestones. Months 7–9: reassess coverage, translation and help capacity wherever the administrative tracker shows gaps. Months 10–12: explain the deadline, repeat the general invitation across participating channels and maintain signing support. Do not imply that someone should sign twice.

Publish three useful public items a week: one explanation, one substantive question answered, and one factual progress update. Send a fortnightly update only to subscribers who opted in. Hold a monthly open Q&A. Offer journalists timely factual briefings around real developments; do not manufacture controversies or imply endorsements from people who merely responded to a request.

At each weekly review calculate remaining statements divided by remaining days. If the trailing 28-day rate stays materially below the required rate for two reviews, reassess deliverable partner commitments and practical barriers, revise the forecast and decide which activities merit resources. Extra posting alone is not a recovery plan. Do not rely on a last-week surge.

Keep completion measurement honest. An outbound click is not a signature. Use official aggregate totals as the source of truth; use partner schedules and aggregate referrals only as imperfect attribution. Do not promise person-level conversion tracking across the Commission handoff. The current no-tracking policy remains binding unless deliberately changed and disclosed.

**8. People, automation and a staged budget (revised after the initiator's clarification)**

The initiator intends to supply the engineering and automation himself, with collaborators contributing relationships, judgement and responsibility. The earlier EUR 300,000 scenario assumed a conventional staffed campaign. It is not a requirement, not evidence of what this campaign will cost, and not a prerequisite for testing demand.

For reference, that scenario allocated EUR 144,000 to three paid full-time-equivalent functions, EUR 36,000 to coordination, EUR 24,000 to translation/accessibility, EUR 24,000 to events/media, EUR 12,000 to technology, EUR 18,000 to specialist review/administration and EUR 42,000 to contingency. Much of the production and coordination workload can instead be automated or contributed. None of those positions needs to be hired merely because it appeared in an illustrative budget.

Start with a **EUR 5,000–15,000 preparation envelope**, released by actual need, not spent in advance. A working EUR 10,000 example:

| Work | Cash allowance | How to reduce it |
|---|---:|---|
| Hosting, API review, monitoring and backups | EUR 1,000 | Existing infrastructure and spend caps |
| Independent legal/economic scrutiny | EUR 3,500 | Pro bono or institutional review |
| Native-language and accessibility review | EUR 1,500 | Named volunteer reviewers |
| Organisational setup/accounting advice | EUR 1,500 | Partner support; confirm actual legal-form needs |
| Open briefings, travel or printing | EUR 500 | Remote sessions and downloadable assets |
| Contingency | EUR 2,000 | Hold until a concrete need appears |
| Total | EUR 10,000 | No salaries assumed |

These are planning allowances, not quotes. Specialist advice and any organisation-formation costs should be confirmed before committing; neither an ASBL nor a particular spending level is established here as an ECI legal requirement. If review is donated and existing tools suffice, the first phase can cost materially less.

For the collection year, use a provisional **EUR 15,000–40,000 cash envelope**, plus explicitly volunteered time, and reforecast after real activity. A EUR 25,000 working scenario allocates EUR 3,000 to infrastructure/review, EUR 5,000 to independent scrutiny and administration, EUR 4,000 to language/accessibility review, EUR 3,000 to volunteer/event expenses, EUR 3,000 to editorial/video help where automation is inadequate and EUR 7,000 to contingency and follow-up. This is not a claim that EUR 25,000 will deliver a million signatures. If the team can cover a function itself, keep the money unspent. If its availability fails, reduce scope or cost the replacement explicitly.

Automate drafting, source-change alerts, translation drafts, build checks, versioned publishing, reminders for internal tasks, aggregate progress reports, public FAQ retrieval and spend monitoring. Use queues and approval records so one erroneous claim cannot be replicated across every language and channel at once. Automation should keep people informed about failures, not quietly retry unlimited paid calls.

Keep accountable people for final claim approval, legal representation, native-language judgement, partner relationships, public interviews, finance and difficult questions. These are roles, not necessarily salaries. Agree realistic hours and a backup for each responsibility. Automation reduces production labour; it does not demonstrate external support or confer permission to speak for an organisation.

The founding group should own the campaign and its decisions, with the initiator owning engineering and evidence work. A volunteer coordinator or rotating operational role can manage commitments. Do not impose a paid operational coordinator before a measured bottleneck justifies one.

**A public sharing experiment before large spending.** The general story can demonstrate the method: people using AI tools to build a proposal for sharing the gains of those tools. Publish the actual workflow, costs, mistakes and human decisions so the claim is inspectable. Do not imply that an automated campaign proves that the proposed fund already exists or is economically sufficient.

Create one short captioned explainer, one plain-language page and one open question session. Make the same factual message freely shareable in the supported languages. Test whether unfamiliar readers understand the proposal and voluntarily share it. Before registration, measure understanding and available public engagement, not unofficial signatures. After collection opens, compare official aggregate signature growth with the timing of publications, without claiming person-level attribution.

Virality is a plausible upside to test, not a required expense or a dependable forecast. Concern about jobs does not by itself prove support for this particular mechanism. Separate attention, comprehension, sharing and official completion. If one completed supporter eventually produces an average of more than one additional completed supporter, a referral chain can grow; repeat exposure, ineligible viewers and overlap can prevent that even when view counts grow rapidly. This is an explanatory condition, not a measured campaign rate. Aim for a useful explanation people choose to share, then let observed results determine investment.

Retain the adopted donor exclusions and transparent funding ledger. Record actual cash and in-kind support, including the limits on volunteered hours. Statutory disclosures include support above EUR 500 per sponsor and regular updates; assign finance responsibility from registration onward. [ECI Regulation, Article 17](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:02019R0788-20240502).

**9. After collection and decisions still needed**

Plan for national verification, certificates, submission, the parliamentary hearing and the Commission response. Keep raw totals distinct from validated support. Publish what the result does and does not establish. Fund public updates and policy work after collection rather than disbanding the campaign at the headline number.

The most important inputs for the next revision are actual supplier costs, available volunteer hours, existing public reach, organiser commitments and partner delivery commitments. Until those are known, the budget and yield model are explicitly scenarios. The immediate decision is whether the founding group can resource the first 90 days and correct the public explanation; a mass launch should follow evidence that the larger operation can be sustained.


# SOURCE: own-the-machine-site/content/en/brief.md

## The ask

We are preparing an initiative asking the Commission to assess and propose
instruments for citizens to share in gains from hyper-automated production.
The [registration objectives](/law/registration) are the request; the 3 %
warrant Regulation illustrates one mechanism. Neither has been registered.

## How the illustrative draft works

- **Designation.** The Commission assesses durable decoupling of production
  from employment. Thresholds create a rebuttable presumption; investigation
  can also lead to designation below them.
- **Warrant.** Within three months of designation, a company issues a
  non-voting warrant for shares representing 3 % of fully diluted capital,
  subscribed at nominal value, subject to Article 5's cap.
- **Triggers.** The first liquidity event, shareholder extraction above the
  Article 5 threshold, or the seven-year backstop triggers subscription.
  Settlement is in shares; it does not itself produce cash for payouts.
- **Entitlement.** EU citizens aged 18 or older would share equally in
  declared distributions. The right cannot be sold, pledged or redeemed.
  No means test; registration with a national vehicle is needed for payment.
  Available income determines distributions, which may be zero.

## Legal basis

Articles 114 and 352 TFEU are proposed, contested bases. Article 352 requires
unanimity. Registration would not approve the draft's legality or guarantee
its adoption; partial registration may change what can proceed.

## The central objection

The share obligation might be classified as a fiscal measure. Settlement in
shares outside public budgets does not settle that question. The
[objections](/law/objections) explain the challenge and the project's response.
Protections against diversion cannot prevent all future legislative changes.

## Status: 6 September 2026

No filing, registration or signature collection. The Forum advised on
27 August; an ECI veteran responded on 5 September. Both are independent
feedback, not institutional approval. Recruitment continues. The initiator
pays hosting and review costs; no organisation or donations are recorded.

## Take part

Ask questions or help organise via [take part](/join), privately or publicly.
Interest is not a signature or commitment to file. The statutory group needs
eligible EU citizens living in seven Member States, not seven nationalities.


# SOURCE: own-the-machine-site/content/en/faq.md

## What is this, in one sentence?

A proposal for citizens to share in the gains of highly automated production,
with an illustrative draft EU law creating a common fund that holds company
shares and pays equal distributions to adult EU citizens.

## Do I get money? How much, and when?

There is no benefit to claim today. Under the draft, every EU citizen aged
18 or older would have an equal right to distributions when declared. The
entitlement cannot be sold, pledged or redeemed; payment requires
registration with a national vehicle. Amounts depend on the fund's realised
income after costs and retention rules and could be zero. The draft's
long-term capital objective is an objective, not a guaranteed balance or
income. The [simulator](/simulator) explores assumptions, including continued
new company stakes; it is not a forecast of your payments. Article 10(6)
requires annual distribution when the amount per holder reaches ten times
the average payment cost, and at least once in every third calendar year
with a positive distributable amount. Small unpaid amounts roll forward;
a payment every year is not guaranteed.

## Is this a tax?

The draft is designed as equity participation: covered companies issue shares
to a common Reserve rather than making cash contributions to a public budget.
Whether EU law would nevertheless classify it as a fiscal measure is
contested. The independent ECI Forum advice identifies that risk, and the
[objections](/law/objections) give the argument and the project's response.

## Which companies would be covered?

The Commission would assess whether production depends significantly on
automated cognitive systems and is durably decoupled from employment. A
rebuttable presumption applies when the draft's thresholds are met: at least
EUR 7.5 billion in annual EU turnover or EUR 75 billion in value, activity in
at least three Member States, and a value at least eighty times worldwide
labour compensation, sustained for two financial years. A company may rebut
the presumption. The Commission may also designate a company below those
thresholds after investigation. The thresholds are indicators, not proof
that a business operates without people.

## Will this kill jobs, or drive innovation away?

Those effects need independent assessment. A 3 % share obligation could
affect investment, prices and business decisions, even without a cash levy.
The draft uses labour compensation in its designation test and includes
anti-avoidance rules, so hiring more people is not an automatic exemption.
It provides monitoring and review; it cannot promise that there will be no
unwanted effects.

## Will companies simply leave the EU?

The draft applies to covered activity in the internal market regardless of
where a company is established. Moving a headquarters would not by itself
remove the obligation. Companies could still change services, investment or
market participation. Cross-border enforceability and proportionality are
contested questions; the size of the EU market does not settle them.

## Who controls the fund? Can politicians raid it?

The Reserve's shares would carry no votes or management rights. Article 12
prohibits diversion to public budgets and gives holders a court remedy.
These are legal barriers, not a guarantee that future legislators cannot
change the law. The personal entitlement is a right to declared
distributions, not an individually redeemable portfolio of company shares.

## What if AI stays small and the transformation never comes?

Fewer qualifying companies or lower returns could mean a small fund and
little or no income. Article 14 requires the Commission to assess the
evidence and, where appropriate, propose amendment or repeal. The draft
does not automatically switch itself off, and its administrative and company
obligations are not costless even if the gains disappoint.

## When does a company have to issue the shares?

It first issues a warrant within three months of designation. The warrant
crystallises on the first liquidity event, earlier shareholder extraction
above 25 % of covered turnover over three consecutive financial years, or
the seven-year backstop (the draft's "long-stop") from warrant issuance. Article 5 sets the precise
rules. A private company cannot avoid the backstop simply by staying private.
Shares entering the fund do not guarantee immediate cash distributions.

## What do I have to do now?

There is nothing to sign yet. You can read the proposal, ask questions,
volunteer or discuss becoming an organiser on the [take part](/join) page.
The site has no mailing list and does not collect statements of support.
If the initiative is registered and collection opens, the site will link to
the Commission's official signing system. One million valid statements and
the required national thresholds secure consideration and a response, not
automatic adoption of the illustrative law.

## Who is behind this, and who pays for it?

David Vanheeswijck initiated the project and pays its hosting and AI review
costs. As of 6 September 2026, no constituted organisation or third-party
funding is recorded. The [about](/about) page names the editor and discloses
the connection to his book. The review ledger distinguishes model reviews
from external feedback; neither is an EU institutional endorsement.


# SOURCE: own-the-machine-site/content/en/join.md

## Where this actually stands

As of 6 September 2026, no version has been filed or registered with the
Commission and no statements of support are being collected. Check the
[versions](/law/versions) page for the registration record. Organiser
recruitment is under way; interest does not mean the statutory group is
already constituted.

The ECI Forum supplied independent, non-binding advice on 27 August, and an
ECI veteran responded on 5 September. The public record includes the
questions raised and the project's responses. This is external feedback,
not approval by the Commission. The project still needs independent scrutiny
and people willing to take responsibility for its next stage.

## Ways to help

**Question the proposal.** Read the draft and raise a specific objection.
Public [issues and pull requests](https://github.com/ownthemachine/own-the-machine/issues)
make the discussion available to everyone. Private questions are welcome too.

**Help organise.** Express interest in the founding group, native-language
review, explaining the proposal or practical coordination. You do not need
to be a programmer or agree with every article to start a conversation.

**Connect an organisation.** Introductions, independent review and concrete
commitments of time or publication support can help establish whether a
campaign is feasible. An introduction does not imply an endorsement.

## What being an organiser means

The statutory group needs at least seven EU citizens old enough to vote in
European Parliament elections and living in at least seven different Member
States. Seven different nationalities are not required. MEPs do not count
towards the minimum. The group appoints a representative and substitute;
organisers' names are published in the Commission's register. The
[official rules](https://citizens-initiative.europa.eu/how-it-works_en)
govern eligibility and responsibilities.

Expressing interest now is not agreeing to file. Before committing, the
group must agree its objectives, responsibilities, funding arrangements and
remaining legal risks. The published gates still apply. Signing a registered
initiative would support its registered objectives; the detailed Regulation
is an illustrative mechanism, not an already adopted law.

## How to get in touch

Write to [hello@ownthemachine.eu](mailto:hello@ownthemachine.eu), or open a
public issue if you prefer a public discussion. Both routes are welcome.
For an organiser enquiry, it helps to state your Member State of residence,
what you could contribute and your questions. No identity document is needed
to express interest, and none should be posted in a public issue.

## What happens to what you send

A GitHub issue is public. An email reaches the editor; it is not added to a
mailing list, forwarded or published without your agreement. There is no
mailing list or donation form. Contact is used to answer the enquiry, not
to send unsolicited campaign messages. See [about](/about) for the controller
and your rights. Any later change to these arrangements must be explained
before it takes effect.


# SOURCE: own-the-machine-site/content/en/sign.md

## Current status

No version is registered and there is nothing to sign for this initiative
today. The status box and [versions](/law/versions) page carry the registration
record. An expression of interest is not an official statement of support.

## How signing works

If collection opens, this site will link to the initiative's page on the
Commission's Central Online Collection System. That is the only online
collection system for newly registered ECIs. Official paper forms are also
permitted; this campaign has not opened paper collection. Follow the
Commission's privacy information for the precise handling of signing data.
This website will not host its own signature form.

## Who can sign

EU citizens can sign once per initiative, wherever they live, if they meet
the minimum signing age for their nationality. That is generally the age for
European Parliament voting; some Member States allow ECI support from age
16 separately. Consult the Commission's current
[eligibility and data requirements](https://citizens-initiative.europa.eu/data-requirements_en).
The draft fund's proposed age of 18 is separate from signing eligibility.

## What information is needed

The official form specifies the information required for your Member State
of nationality. This may include an identification-document number or
personal identification number. Some countries support electronic identity.
Use the official form's instructions; do not send identity documents to
this campaign or put personal signing information in public discussions.

## What one million means

Success requires one million valid statements of support and minimum totals
in at least seven Member States within the twelve-month collection period.
For initiatives registered on or after 16 July 2024, thresholds are calculated
using the total number of MEPs, currently 720: Belgium's is 15,840. Consult
the [official threshold table](https://citizens-initiative.europa.eu/thresholds_en)
for the current figures. Submitted counts remain subject to verification.

Success leads to examination and a reasoned Commission response, not an
automatic referendum result or adoption of the draft. The proposed
[registration objectives](/law/registration) are the request; the Regulation
illustrates a possible mechanism. See the
[official process](https://citizens-initiative.europa.eu/how-it-works_en).

## During collection

The registered text will be fixed and published beside the living draft,
with differences visible under the [versions](/law/versions) rules. The
Commission's system offers optional initiative updates after signing; the
organisers can send these through that system without receiving subscribers'
email addresses. This site's no-list policy is separate from that official
option. Collection dates and the official link will appear only once confirmed.

## Before collection

Read the [one-page summary](/brief), consider the [objections](/law/objections)
and use [take part](/join) to ask questions or help organise. Nobody needs to
buy the book, provide an identity document or pay to evaluate the proposal.


# SOURCE: own-the-machine-site/content/en/press.md

## What this is

Own the Machine is an open-source draft EU Regulation accompanying a proposed
European Citizens' Initiative. The proposed objectives ask the Commission to
assess and propose mechanisms for citizens to participate in productivity
gains from hyper-automated production. The detailed 3 % warrant mechanism is
illustrative; nothing has been registered or adopted.

## Boilerplate, free to reuse

Own the Machine proposes broader citizen participation in the gains of
highly automated production. Its illustrative draft would create a common
Reserve holding non-voting company shares and equal, non-transferable rights
to distributions for EU citizens aged 18 or older. Payments would depend on
available income and could be zero. The text, objections and review history
are public at ownthemachine.eu. No EU institution endorses the initiative.

## The numbers and their limits

- The draft's rebuttable quantitative presumption combines EUR 75 billion
  in value or EUR 7.5 billion in EU turnover, activity in at least three
  Member States, and value at least eighty times worldwide labour
  compensation, sustained for two financial years. Investigation can also
  lead to designation below the thresholds.
- A warrant is issued within three months of designation. It crystallises
  at the first liquidity event, shareholder extraction exceeding 25 % of
  covered turnover over three consecutive financial years, or the seven-year
  backstop after issuance. Article 5 sets the precise conditions and cap.
- The warrant entitles the Reserve to subscribe at nominal value for shares
  representing 3 % of fully diluted capital. Share issuance is not cash
  income available for immediate distribution.
- The draft's capital objective is of the order of six months of median EU
  disposable income per citizen within a generation. It is an objective,
  not a guaranteed result; projections rely on uncertain assumptions about
  company coverage, new stakes, returns and costs.

Use the current [evidence](/evidence) and [legal text](/law) for definitions
and dated estimates. The simulator shows conditional scenarios, not a
forecast, confidence interval or personal entitlement valuation.

## Status, as of 6 September 2026

No filing, registration or signature collection. The ECI Forum supplied
independent, non-binding advice on 27 August; an ECI veteran replied on
5 September. Organiser recruitment and further scrutiny continue under the
published gates. No constituted organising group is recorded. A statutory
group needs eligible EU citizens living in seven different Member States,
not necessarily seven different nationalities.

## Legal and practical limits

The design uses shares and keeps assets outside public budgets. Its possible
fiscal classification and proposed Treaty bases remain contested; the Forum
advice is not Commission approval. Legal protections against diversion cannot
guarantee that future legislators never amend the rules. The Reserve would
have no voting or management rights. The individual entitlement could not be
sold, pledged or redeemed; payment would require registration with a national
vehicle. Success as an ECI would secure consideration and a response, not
automatic enactment of this Regulation.

## Assets and contact

- Public text and source material are available without buying anything.
  The initiator's interest in his book is disclosed on [about](/about).
- Social preview images are available under ownthemachine.eu/og/ in the
  five website languages.
- PDF and EPUB downloads on the [law page](/law) identify the draft version.
- Text is CC BY-SA 4.0; the website and tools are open source.
- Contact: [hello@ownthemachine.eu](mailto:hello@ownthemachine.eu).
  David Vanheeswijck answers; there is no press office or guaranteed reply time.


# SOURCE: own-the-machine-site/content/en/about.md

## What this is

An open-source draft EU Regulation intended to let citizens of the Union
participate in the capital value created by hyper-automated production,
prepared as the basis for a possible European Citizens' Initiative. The
legal text, its memorandum, its objections and every review verdict
live in a public repository; this site renders them.

## Not an EU document

This is a citizens' proposal. It is not published by, endorsed by,
affiliated with or reviewed by the European Union, the European
Commission, the European Parliament or any other Union institution,
body, office or agency. It has no legal force. It is drafted in the
conventions of Union legislation because a proposal meant to be
assessed by those institutions should arrive in the form they read; the
form is a courtesy to the reader, never a claim of authority. The site
carries no EU emblem, and the seal it does carry belongs to this
project alone.

## Who

Initiated by David Vanheeswijck (Belgium). The drafting method uses
adversarial AI review under the editor's responsibility; every verdict
and disposition is on the [ledger](/law/ledger). An organisers' group
of at least seven eligible EU citizens living in seven different Member States will be constituted
if the project passes its own gates.

## Who publishes this

Responsible for this site and for the draft it renders: David
Vanheeswijck, Belgium. Write to
[hello@ownthemachine.eu](mailto:hello@ownthemachine.eu); that address
reaches the editor, and everything substantive about the text belongs
in the open, as an [issue or pull
request](https://github.com/ownthemachine/own-the-machine) on the
repository, where the answer can be read by everyone the draft
concerns.

The same person is the controller for the little data this site
occasions, described below.

## Declared interest

The draft grew out of a book by its initiator. The campaign takes
nothing from the book's sales and does not link to it, and every
argument here can be checked without buying anything. That is not the
whole of it. Attention paid to this campaign is attention that can
reach the book, and the author is the same person, so the interest is
real whether or not a link exists. It is declared here to be weighed,
not because it has been designed away.

## The gates

The campaign proceeds only through published gates with kill criteria:
registrability soundings before constitution, constitution before
filing, registration before collection. Independent, non-binding Forum
advice arrived on 27 August 2026; an ECI veteran responded on 5 September.
Neither response constitutes registration or institutional approval.
Organiser recruitment continues. If a gate fails, this page will say
so and the repository stays up as a public good.

## Funding

No organisation, no bank account, no donations and no third-party money of
any kind. Nobody has been paid, and nobody has worked on this for payment.

Saying "none" would be the easier answer and it would not be true. This
site costs something to run and the initiator pays it personally: the
domain, object storage and edge delivery at Scaleway in France, and the API
calls the review gates consume. No campaign-specific third-party funding or support is recorded as of
6 September 2026. Standard platform services on ordinary terms, including
GitHub and Cloudflare, are disclosed below.

Regulation (EU) 2019/788 obliges a registered initiative to name every
source giving more than EUR 500 in a year and to keep that declaration
current while signatures are collected. The obligation starts at
registration. The declaration starts now, in campaign/FUNDING.md, which
also carries the rules adopted in advance about what will never be
accepted.

## Your data

This site sets no cookies, runs no analytics scripts and loads nothing
from third parties. There is no consent banner because there is
nothing to consent to.

What is nonetheless processed, stated plainly rather than claimed away:
any server that answers a request sees the address it came from, so the
host keeps short-lived technical logs, including IP addresses, to
deliver the pages and to defend against abuse. That is the whole of it;
those logs are not read for any other purpose, are not combined with
anything, are not sold and are not shared. If you switch this site
between paper and plate, that choice is written into your own browser's
storage and never leaves it.

Anyone in the Union may ask what is held about them, and may complain
to a supervisory authority; in Belgium that is the Data Protection
Authority. When signing opens, it happens on the European Commission's
own collection system under Regulation (EU) 2019/788, not here.

## Where this site lives

The pages you are reading are stored in Scaleway Object Storage in the
Paris region and served from Scaleway's own network. Scaleway is a
French company; the files, the cache and the certificate are European.

Two parts are not, and a campaign about European ownership should say
which: the domain's DNS is answered by Cloudflare, a United States
company, though no page content passes through it, and the source
repository is hosted on GitHub, also American. The one exception in
the serving path is www.ownthemachine.eu, which is a redirect to this
site and carries no content of its own.

Nothing here depends on any of that remaining true. The site is a
static build of a public repository: it can be rebuilt and served from
anywhere, by anyone, in minutes.

## Where the review runs

The automated gate verdicts are produced by models; external human feedback
is recorded separately. The compute
that produced it has a jurisdiction of its own. Until 23 August 2026
the gates ran through OpenRouter, an American router. The pipeline uses Requesty's European endpoint. EU hosting, zero retention
and no training use remain the default requirements. For the public or intended-for-publication, non-sensitive material
Fable 5.1 reviews introduced on 6 September 2026, the editor permits the
router-reported 30-day retention while retaining EU hosting and no training
use. That exception excludes private correspondence, non-public personal data
and sensitive unpublished material; public author attribution may appear.

The runner does not take that on trust. Before it spends a token it
reads the router's own record of where the model runs and what becomes
of the text, and refuses to start if the model is absent or fails the
requirements selected for that run. Retention exceptions must be explicit;
they do not change the default checks. Whatever it read is written
into the review record, so each verdict carries the evidence rather
than the assurance.

One distinction is worth keeping sharp, because it is the distinction
this proposal is about. Hosted in Europe is not built in Europe. The
models are American, running on European infrastructure under European
rules, and of what this endpoint offers only Mistral is a European
laboratory. A campaign about who owns the machine should say plainly
that it does not yet run on one Europe owns.

## Accessibility

Target: WCAG 2.1 AA, with the WCAG 2.2 focus-appearance and target-size
criteria adopted early. The site is keyboard-complete and respects
reduced-motion preferences. Found a barrier?
[Open an issue](https://github.com/ownthemachine/own-the-machine-site/issues).


# SOURCE: own-the-machine-site/content/en/contribute.md

The draft improves the way open source improves: in public, by pull
request, against stated criteria. Three repositories:

- [own-the-machine](https://github.com/ownthemachine/own-the-machine):
  the law, its memorandum, the review ledger (CC BY-SA 4.0).
- [own-the-machine-tools](https://github.com/ownthemachine/own-the-machine-tools):
  the review gates and linter (MIT).
- [own-the-machine-site](https://github.com/ownthemachine/own-the-machine-site):
  this site (AGPL-3.0).

## The merge criteria

Every change to the legal text must survive four tests: it claims
assets, not flows; it reaches every citizen equally; it strengthens legal protection against diversion;
and it establishes the claim while capital forms, before crystallisation.
Mechanical constraints (the DC table in the
[objections](/law/objections)) apply before merge. Substantive changes run
all six adversarial gates; prose changes run legal form and layer fidelity;
editorial changes run the linter. Verdicts and editorial dispositions are
recorded publicly. A pull request that weakens a protection does not merge
under the published governance rules.

## Ways in

- **Argue.** Take on an objection, or raise a new one at full strength.
  The strongest contribution is the attack we have not answered.
- **Draft.** Improve an article against the Joint Practical Guide
  conventions; the linter and gates will meet you.
- **Translate.** Languages are promoted from machine-translated to
  human-verified one page at a time; native readers are the bottleneck.
- **Build.** The site and tools are ordinary open source with issues
  waiting.


# SOURCE: own-the-machine-site/src/i18n/en.mjs

// English: the source of truth. Every other dictionary translates THIS
// file and is reviewed against it by the translation gate.
export default {
  code: 'en', name: 'English',
  chrome: {
    law: 'The law', objections: 'Objections', ledger: 'Ledger',
    faq: 'FAQ',
    join: 'Take part',
    simulator: 'Simulator', evidence: 'Evidence', about: 'About',
    skip: 'Skip to content',
    recitals: 'Recitals',
    footNavLabel: 'All pages',
    footNavFile: 'The file',
    footNavUnderstand: 'Understand it',
    footNavAct: 'Act, and who we are',
    explanatory: 'Explanatory memorandum',
    registration: 'The proposal, in the Commission’s format',
    severability: 'Severability',
    versions: 'Versions',
    brief: 'One page',
    sign: 'How to sign',
    press: 'Press',
    contribute: 'Contribute',
    themeToggle: 'Switch between paper and plate (light and dark)',
    footerQuestion: 'Who owns the machine?',
    footerDrafted: 'Drafted in the open',
    footerLicence: 'text CC BY-SA 4.0, code AGPL-3.0',
    footerHosting: 'hosted in the EU',
    footerPrivacy: 'no cookies, no tracking',
    onThisPage: 'On this page', backToTop: 'Back to top',
    contentsLink: 'Contents', historyLink: 'history',
    reviewLink: 'what review found', fullReview: 'full review', diff: 'diff',
    editorDisposition: 'Editor disposition',
    ogImageAlt: 'A citizen’s certificate bearing the seal of Own the Machine',
    metaDescription: 'An open-source draft EU Regulation: capital for all, so the dividend follows.',
  },
  banner: {
    lawEnglish: 'What follows in English is the draft itself. This page shows the authoritative English text; translations of the legal text are for understanding only.',
    pageMachine: 'This page was translated and checked through the project’s open review process; no native speaker has read it yet. Spotted a mistake? Report it on %GITHUB%.',
    enOnly: 'This page is not yet available in this language; the English original follows.',
    recordsEnglish: 'The reviews themselves are conducted in English and the entries below quote their records in the original; the rest of this page is translated.',
    stale: 'The English original has changed since this translation was made; details may differ until it is refreshed.',
    pageVerified: 'This translation has been verified by a native reader.',
    plainStale: 'This plain-language summary was written against an earlier version of the article below; the article itself is current and is what governs.',
  },
  home: {
  "eyebrow": "A draft regulation of the citizens of Europe",
  "tagline": "Capital for all, so the dividend follows.",
  "ask": "When machines create wealth, citizens should share in owning it. This project proposes citizen participation in the gains of highly automated production. The complete draft Regulation illustrates one mechanism; the proposed initiative asks the Commission to assess and propose instruments. Nothing is registered and there is nothing to sign yet.",
  "basis": "Proposed legal bases: Articles 114 and 352 TFEU; no Treaty change is sought. The legal basis remains contested. <a href=\"%REG%\">Read the proposed registration objectives.</a>",
  "ctaRead": "Read the law",
  "ctaObjections": "Start with the objections",
  "ctaJoin": "What would help",
  "col1Head": "The mechanism",
  "col1": "A covered company would issue a warrant for a 3 % non-voting stake. The first liquidity event, shareholder extraction above the draft's threshold or a seven-year backstop triggers subscription at nominal value. The obligation is settled in shares; it does not itself generate cash for citizens.",
  "col2Head": "The entitlement",
  "col2": "Every EU citizen aged 18 or older would have an equal, personal right to declared distributions. It cannot be sold, pledged or redeemed. No means test; payment requires registration with a national vehicle. Returns may be small or zero. Legal safeguards resist diversion but cannot prevent all future amendments.",
  "col3Head": "The method",
  "col3": "Drafted in public, adversarially reviewed, every verdict and every fix on the record. The <a href=\"%LEDGER%\">ledger</a> records objections, corrections and editorial decisions.",
  "declared": "Declared interest: the draft grew out of a book by its initiator; the campaign stands on its own legal text, and every argument here can be checked without buying anything. Draft at commit %COMMIT%.",
  "title": "A draft regulation of the citizens of Europe"
},
  lawIndex: {
    title: 'The draft Regulation',
    intro: 'The working draft: <a href="%RECITALS%">recitals</a>, articles and annexes, with anchored paragraphs. The English text is the draft; commit %COMMIT%. Changes appear on the <a href="%LEDGER%">ledger</a>.',
    citationLabel: 'Citations',
    chapter: 'Chapter', annex: 'Annex', annexes: 'Annexes', memorandum: 'Memorandum',
    article: 'Article', recitals: 'Recitals',
    explanatoryLink: 'Explanatory memorandum, in the Commission\u2019s own structure',
    registrationLink: 'The proposal, in the Commission’s format',
    objectionsLink: 'The objections, at full strength',
    severabilityLink: 'Severability: what survives trimming',
    downloadsHead: 'Take the whole draft with you',
    downloadsNote: 'The complete instrument and memorandum in one document, stamped with commit %COMMIT%.',
    chapters: [
      'Subject matter, scope, definitions',
      'Designation of covered undertakings',
      'The citizens’ capital warrant',
      'The European Citizens’ Capital Reserve',
      'The citizens’ entitlement',
      'Protection of the Reserve and of entitlements',
      'Penalties, monitoring, delegation, committee',
      'Transitional and final provisions',
    ],
    briefLink: 'New here? Read the proposal in one page.',
    versionsHead: 'Status of the text',
    versionsLink: 'Versions: what is fixed, and what still moves',
  },
  lawDoc: {
    eyebrowArticle: 'The draft Regulation · Article %N%',
    eyebrowAnnex: 'The draft Regulation · Annex %N%',
    eyebrowRecitals: 'The draft Regulation',
    plainLabel: 'Plain language · not the legal text',
    whereas: 'Whereas:',
    provenance: 'Verbatim from the law repo at commit %COMMIT%',
    prevRecitals: '&larr; Recitals', nextAnnex: 'Annex I &rarr;',
  },
  objections: {
    title: 'The objections, at full strength',
    eyebrow: 'Memorandum · the honesty surface',
    intro: 'The draft began with objections, stated as strongly as possible. Further objections and revisions have been added through public review. Each objection ends in design consequences, and the design-constraints table below is a merge criterion: text that violates it does not merge. Where an objection is conceded, it says so. This page is the campaign’s credibility strategy, not its confession: read it first, then read <a href="%LAW%">the law it produced</a>.',
    description: 'The objections to the draft, with the consequences for its design.',
  },
  memorandum: {
    title: 'Severability: what survives trimming',
    eyebrow: 'Memorandum · strategy in public',
    intro: 'Most redistributive proposals at Union level die whole, at their weakest point. This document says in advance which parts of the Regulation stand on which legal basis, what the ask becomes at each stage of trimming, and in which order concessions run. Publishing it is a deliberate choice: hostile readers will quote it as lack of confidence, and the alternative is worse.',
    description: 'How the instrument decomposes when institutions start cutting, and what each cut costs.',
  },
  ledger: {
    title: 'The ledger', eyebrow: 'The law shows its work',
    intro1: 'Substantive changes run all six adversarial gates: legal form, design-constraint compliance, legal basis, hostile counsel, coherence with existing EU law, and layer fidelity. Prose changes run legal form and layer fidelity; editorial changes run the linter. Verdicts and editorial dispositions are recorded here.',
    intro2: 'Every verdict is committed to the repository, including the ones that drew blood. A REVISE verdict merges only with a written editor disposition. Reviews are run adversarially by AI under the editor’s responsibility; the dispositions below are the editor’s, on the record.',
    intro3: 'Each entry wears a seal derived from its commit hash: no two amendments carry the same mark.',
    description: 'The public change history of the draft: every adversarial review, every verdict, every editor disposition.',
    gates: {
      'legal-form': 'Legal form', 'dc-compliance': 'Design constraints',
      'legal-basis': 'Legal basis', 'hostile-counsel': 'Hostile counsel',
      'acquis-coherence': 'Acquis coherence', 'layer-fidelity': 'Layer fidelity',
    },
  },
  simulator: {
  "title": "The dividend, honestly",
  "eyebrow": "The simulator · ranges, not promises",
  "description": "Illustrative Reserve scenarios over fifty years, with assumptions and model limits stated.",
  "intro": "These curves illustrate assumptions, not predicted payments. The simplified model uses positive returns and continued additions of newly covered company stakes. Its band is a sensitivity comparison, not a confidence interval. The legal distribution rules are in <a href=\"%ANNEX2%\">Annex II</a>; actual income, costs and losses could produce lower or zero payments.",
  "revLabel": "Starting covered revenue assumption (EUR bn/yr)",
  "revNote": "The default is anchored to the project's August 2026 estimate of roughly EUR 1 400 billion for a presumptively covered set. Coverage and private-company valuations are uncertain; these are scenario inputs, not Commission designations.",
  "lagLabel": "Scenario delay to the start of stake inflows (years)",
  "lagNote": "This models delay from the illustrative starting year, including designation and implementation; it is not permission to postpone an issued warrant. Article 5 triggers it at the first liquidity event, the extraction threshold or the seven-year backstop after issuance.",
  "retLabel": "Portfolio real return (%/yr)",
  "retNote": "A constant positive real return is assumed here. The model does not simulate losses, separate realised income from appreciation or deduct actual administration costs and withholding taxes; this is not a payout forecast.",
  "growthLabel": "Growth of new covered stake inflows after the first wave (%/yr)",
  "growthNote": "Zero keeps annual inflows constant; it does not stop new stakes. Continuing new cohorts are assumed separately from growth in shares already held, and this scenario does not establish how many new companies will qualify.",
  "sceptic": "Assume little",
  "reset": "Reset",
  "chartLabel": "Illustrative annual distributions per citizen over fifty years, with a sensitivity band",
  "axisLabel": "EUR per citizen per year, constant 2026 euros",
  "sentence": "In these illustrative scenarios, annual distributions are EUR %LOW% to %HIGH% per citizen by %YEAR%. Actual payments could be lower or zero.",
  "stakeSentence": "The model shows EUR %SLOW% to %SHIGH% of Reserve capital per citizen by %YEAR%. That is not an individually saleable or redeemable balance.",
  "forecast": "Higher-growth scenario",
  "generationSentence": "By %YEAR%, the scenarios show EUR %SLOW% to %SHIGH% of Reserve capital per adult citizen and EUR %DLOW% to %DHIGH% in annual distributions. These are model outputs, not guaranteed rights to those amounts.",
  "disclaimer": "This model does not establish that the draft's long-term objective will be met. All settings assume ongoing new stakes and positive returns; the lower setting is not a worst case. The calendar assumes an illustrative 2027 start, not an agreed implementation date. There is no registered initiative or existing benefit to claim.",
  "assumptionsHead": "Every assumption in this model",
  "assumptions": [
    "The model applies 3 % to new covered company value, assuming value equals fourteen times covered revenue. The draft also includes an extraction trigger and a seven-year post-issuance backstop; the model aggregates timing rather than simulating each warrant.",
    "An initial pool enters over ten years from the selected delay, followed by continuing new cohorts at the rate you set. Zero growth still adds stakes every year. The number of eligible adult EU citizens is held at 350 million for all fifty years.",
    "The model simplifies the distribution arithmetic in Annex II: a collar based on three past years, floored at 2 % of capital and capped by an assumed income return. It does not implement all legal requirements, actual costs, losses, payment-frequency rules or a separate real-capital retention calculation.",
    "The band varies the same assumptions to show sensitivity, not statistical probability. The code is <a href=\"https://github.com/ownthemachine/own-the-machine-site\">public</a>; the scenario does not value your personal entitlement."
  ]
},
  evidence: {
    title: 'Evidence', eyebrow: 'Sourced, ranked, and honest about the gaps',
    description: 'The numbers behind the draft, ranked, sourced, including the citations we tell you not to use.',
    intro: 'The European evidence base behind the draft, with sources, and a dead-citations list: numbers that circulate in this debate that we checked and will not use, including some that would have helped us.',
  },
  contribute: {
    title: 'Contribute', eyebrow: 'The law is a repository',
    description: 'How to improve the law: open a pull request, argue an objection, translate a page.',
  },
  about: {
    title: 'About', eyebrow: 'Who, why, and under what rules',
    description: 'Who is behind this, the declared interest, the gates, and how this campaign treats your data.',
  },
  explanatory: {
    title: 'Explanatory memorandum', eyebrow: 'The proposal in the form the Commission uses for its own',
    description: 'Context, legal basis, subsidiarity and proportionality, the options appraisal and impacts, budgetary implications, and the open points.',
    intro: 'A citizens\u2019 initiative is not required to produce this. It exists because the Commission\u2019s services would have to write exactly this document if they ever acted on the initiative, and because a file that cannot answer these questions is not ready to be acted on. Where an answer does not exist yet, it says so rather than filling the heading.',
  },
  registration: {
    title: 'The proposal, in the Commission\u2019s format', eyebrow: 'What would be filed',
    description: 'Title, objectives and Treaty provisions within the limits of Regulation (EU) 2019/788, with character counts.',
    intro: 'The Commission assesses the proposed objectives and accompanying material for registration. The Regulation illustrates a mechanism; partial registration and the scope that survives are for the Commission to decide.',
  },
  faq: {
    title: 'Questions people actually ask', eyebrow: 'The short answers, with the long ones one click away',
    description: 'Do you get money, is it a tax, who pays, can politicians raid it, and what happens if AI stays small.',
  },
  press: {
    title: 'For press', eyebrow: 'Facts, status, boilerplate and contact',
    description: 'What Own the Machine is, the numbers that matter, its honest status, and how to reach the person behind it.',
  },
  sign: {
    title: 'How signing works', eyebrow: 'Nothing to sign yet; here is how it would work',
    description: 'Where European Citizens\u2019 Initiatives are really signed, who can sign, and what your country asks for.',
    stageLabel: 'Stage',
    stageNone: 'Nothing has been filed and no signature is being collected anywhere, by anyone. Anyone collecting data for this initiative today is not us.',
    stageRegistered: 'A version is registered. Signing happens only on the European Commission\u2019s official system, linked from this page, never here.',
  },
  brief: {
    title: 'The proposal in one page', eyebrow: 'Executive brief',
    description: 'What the draft asks for, how it works, its legal basis, the objection that matters most, and its actual status.',
    draftAt: 'draft at commit', readLaw: 'The full text', readObjections: 'Read the objections',
    readJoin: 'What would help', printHint: 'This page is built to print to a single sheet of A4.',
  },
  join: {
    title: 'Take part', eyebrow: 'What would actually help, and what it commits you to',
    description: 'Nothing is being collected. What this needs is arguments, and seven people willing to be named.',
    stageLabel: 'Stage',
    stageNone: 'Nothing has been filed and no signature is being collected anywhere. Nobody is being asked to commit to anything today.',
    stageRegistered: 'A version of this draft is registered. Signature collection runs on the European Commission\u2019s own system, never here.',
  },
  versions: {
    title: 'Versions', eyebrow: 'What is fixed, and what still moves',
    description: 'Whether any version of this draft has been filed or registered, and the rule that governs the text from the moment one is.',
    stateLabel: 'Status',
    noneTitle: 'No version is registered.',
    noneBody: 'Nothing has been filed with the European Commission, and no signature is being collected anywhere. Everything on this site is a draft.',
    registeredTitle: 'Registered version', filed: 'filed', fromCommit: 'from commit',
    draftNotice: 'You are reading the living draft, which is still changing. Signatures are collected on the registered text, %NUMBER%, which is fixed and cannot be amended. %LINK%.',
    registeredLinkText: 'See what that means and where the two differ',
  },
  notFound: {
    title: 'Not found', heading: 'Nothing is certified at this address',
    body: 'The page you asked for does not exist. The law is at <a href="%LAW%">/law</a>; everything else starts at <a href="%HOME%">the cover</a>.',
  },
};


# SOURCE: own-the-machine-site/src/scripts/simulator.ts

// The simulator island: the only interactive JavaScript on the site.
// Implements Annex II arithmetic as amended 19 August 2026: real-capital
// retention, three-year smoothing collar floored at 2 % of capital, no
// leverage, everything in constant euros. Designated value crystallises
// as a continuing flow: the first wave over ten years from the median
// event lag, later cohorts growing at the chosen rate. Horizon: fifty
// years, because a capital-preserving fund is misdescribed by its first
// three decades.

const ADULTS = 350e6;
const VALUE_MULTIPLE = 14; // firm value as a multiple of covered revenue:
// the measured ratio of the designated set under Article 3(2)(b) as amended,
// EUR ~20,5tn of value on ~EUR 1,43tn of revenue (evidence/designation-count.md)
const YEARS = 50;

interface Inputs { revBn: number; lag: number; ret: number; growth: number }
interface Series { dist: number[]; stake: number[] }

function run({ revBn, lag, ret, growth }: Inputs): Series {
  const r = ret / 100;
  const g = growth / 100;
  const flowAtFull = (revBn * VALUE_MULTIPLE) / 10; // EUR bn of firm value crystallising per year
  let capital = 0; // EUR bn, real
  const dist: number[] = [];
  const stake: number[] = [];
  const history: number[] = [];
  for (let y = 0; y < YEARS; y++) {
    const growthYears = Math.max(0, y - (lag + 10));
    const flow = y >= lag ? flowAtFull * Math.pow(1 + g, growthYears) : 0;
    // Annex II: distributable capped by realised income (point 2) and by
    // the collar, itself floored at 2 % of capital (point 3 as amended)
    const last3 = history.slice(-3);
    const avg = last3.length ? last3.reduce((a, b) => a + b, 0) / last3.length : 0;
    const d = Math.min(capital * r, Math.max(1.25 * avg, 0.02 * capital));
    capital += capital * r - d + 0.03 * flow;
    history.push(d);
    dist.push((d * 1e9) / ADULTS); // EUR per citizen per year
    stake.push((capital * 1e9) / ADULTS); // DC-31: the stake beside the payout
  }
  return { dist, stake };
}

const $ = (id: string) => document.getElementById(id) as HTMLInputElement;
const I18N = JSON.parse(document.getElementById('sim-i18n')!.textContent || '{}');
const nfInt = new Intl.NumberFormat(I18N.lang || 'en', { maximumFractionDigits: 0 });
const nfDec = new Intl.NumberFormat(I18N.lang || 'en', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const fmt = (v: number) => (v >= 10 ? nfInt.format(v) : nfDec.format(Math.max(v, 0)));

function draw() {
  const inputs: Inputs = { revBn: +$('rev').value, lag: +$('lag').value, ret: +$('ret').value, growth: +$('growth').value };
  $('rev-out').textContent = String(inputs.revBn);
  $('lag-out').textContent = String(inputs.lag);
  $('ret-out').textContent = String(inputs.ret);
  $('growth-out').textContent = String(inputs.growth);

  const centralS = run(inputs);
  const lowS = run({ revBn: inputs.revBn * 0.5, lag: Math.min(15, inputs.lag + 3), ret: Math.max(2, inputs.ret - 1), growth: Math.max(0, inputs.growth - 2) });
  const highS = run({ revBn: inputs.revBn * 1.6, lag: Math.max(3, inputs.lag - 2), ret: Math.min(6, inputs.ret + 1), growth: Math.min(12, inputs.growth + 3) });
  const central = centralS.dist, low = lowS.dist, high = highS.dist;

  const W = 720, H = 300, PL = 52, PB = 30, PT = 12;
  const maxY = Math.max(...high, 10) * 1.08;
  const X = (y: number) => PL + (y / (YEARS - 1)) * (W - PL - 10);
  const Y = (v: number) => H - PB - (v / maxY) * (H - PB - PT);
  const line = (s: number[]) => s.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`).join('');
  const band = line(high) + low.map((v, i, a) => `L${X(a.length - 1 - i).toFixed(1)} ${Y(a[a.length - 1 - i]).toFixed(1)}`).join('') + 'Z';

  const year0 = 2027;
  const ticksY = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(maxY * f));
  const svg = document.getElementById('curve')!;
  svg.innerHTML =
    ticksY.map((t) => `<line x1="${PL}" y1="${Y(t)}" x2="${W - 10}" y2="${Y(t)}" stroke="var(--guilloche)" stroke-width="0.6"/>` +
      `<text x="${PL - 8}" y="${Y(t) + 4}" text-anchor="end" font-size="11" fill="var(--ink-soft)" font-family="var(--ui)">${t}</text>`).join('') +
    [0, 10, 20, 30, 40, 49].map((y) => `<text x="${X(y)}" y="${H - 8}" text-anchor="${y === 49 ? 'end' : 'middle'}" font-size="11" fill="var(--ink-soft)" font-family="var(--ui)">${year0 + y}</text>`).join('') +
    `<path d="${band}" fill="var(--seal-gold)" opacity="0.13"/>` +
    `<path d="${line(central)}" fill="none" stroke="var(--seal-gold)" stroke-width="2"/>` +
    `<text x="${PL}" y="${PT + 2}" font-size="11" fill="var(--ink-soft)" font-family="var(--ui)">${I18N.axisLabel}</text>`;

  const y20l = low[19], y20h = high[19];
  const payoutLine = (I18N.sentence || '')
    .split('%LOW%').join(fmt(y20l))
    .split('%HIGH%').join(fmt(y20h))
    .split('%YEAR%').join(String(year0 + 19));
  const stakeLine = (I18N.stakeSentence || '')
    .split('%SLOW%').join(nfInt.format(Math.round(lowS.stake[19])))
    .split('%SHIGH%').join(nfInt.format(Math.round(highS.stake[19])))
    .split('%YEAR%').join(String(year0 + 19));
  document.getElementById('sentence')!.textContent = payoutLine + ' ' + stakeLine;
  // DC-31 at the fifty-year mark: the generation line carries stake and payout together
  const genLine = (I18N.generationSentence || '')
    .split('%SLOW%').join(nfInt.format(Math.round(lowS.stake[49])))
    .split('%SHIGH%').join(nfInt.format(Math.round(highS.stake[49])))
    .split('%DLOW%').join(fmt(low[49]))
    .split('%DHIGH%').join(fmt(high[49]))
    .split('%YEAR%').join(String(year0 + 49));
  document.getElementById('generation')!.textContent = genLine;
}

for (const id of ['rev', 'lag', 'ret', 'growth']) $(id).addEventListener('input', draw);
document.getElementById('sceptic')!.addEventListener('click', () => {
  $('rev').value = '300'; $('lag').value = '15'; $('ret').value = '2'; $('growth').value = '0'; draw();
});
document.getElementById('reset')!.addEventListener('click', () => {
  $('rev').value = '1400'; $('lag').value = '7'; $('ret').value = '4'; $('growth').value = '5'; draw();
});
// Higher-growth scenario inputs are assumptions for exploration, not a forecast.
// The labels disclose the continued addition of company stakes.
document.getElementById('forecast')!.addEventListener('click', () => {
  $('rev').value = '3000'; $('lag').value = '5'; $('ret').value = '4'; $('growth').value = '8'; draw();
});
draw();


# SOURCE: own-the-machine-site/package.json

{
  "name": "own-the-machine-site",
  "type": "module",
  "version": "0.1.0",
  "private": true,
  "license": "AGPL-3.0-only",
  "scripts": {
    "sync": "node scripts/sync-law.mjs",
    "dev": "npm run sync && astro dev",
    "build": "npm run sync && npm run artefacts && npm run og && astro build && npm run sitemap",
    "preview": "astro preview",
    "artefacts": "node scripts/make-artefacts.mjs",
    "og": "node scripts/make-og.mjs",
    "audit": "node scripts/a11y.mjs",
    "sitemap": "node scripts/make-sitemap.mjs",
    "check:translations": "node scripts/check-translations.mjs",
    "check:toc": "node scripts/check-toc.mjs",
    "check:release": "npm run check:translations && node scripts/check-labels.mjs && node scripts/check-brief.mjs && node scripts/check-toc.mjs && node scripts/check-reach.mjs"
  },
  "dependencies": {
    "@fontsource/inter": "^5.1.0",
    "@fontsource/literata": "^5.1.0",
    "@fontsource/playfair-display": "^5.1.0",
    "astro": "^5.1.0",
    "jszip": "^3.10.1",
    "marked": "^15.0.0",
    "puppeteer": "^25.8.0"
  },
  "devDependencies": {
    "@axe-core/puppeteer": "^4.13.0",
    "@types/node": "^26.2.0"
  }
}


# SOURCE: own-the-machine-site/scripts/sync-law.mjs

#!/usr/bin/env node
// Renders the law repo into src/generated/ as JSON the pages import.
// The site is a rendering of the law repo, never a second copy: this
// output is gitignored and rebuilt on every build. Point LAW_REPO at a
// checkout of ownthemachine/own-the-machine.
import { readFileSync, readdirSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, basename } from 'node:path';
import { execSync } from 'node:child_process';
import { marked } from 'marked';

const LAW = process.env.LAW_REPO || join(process.cwd(), '..', 'own-the-machine');
if (!existsSync(join(LAW, 'regulation'))) {
  console.error(`sync-law: no law repo at ${LAW}; set LAW_REPO`);
  process.exit(1);
}
const OUT = join(process.cwd(), 'src', 'generated');
mkdirSync(OUT, { recursive: true });

marked.setOptions({ mangle: false, headerIds: false });

const read = (p) => readFileSync(join(LAW, p), 'utf8');
// Everything after the first horizontal rule is drafting notes: never
// rendered on the public site (the ledger carries the story instead).
const stripNotes = (t) => t.split(/\n---\n/)[0].trim();

let lawCommit = 'unknown';
try {
  lawCommit = execSync('git rev-parse --short HEAD', { cwd: LAW }).toString().trim();
} catch { /* fine: not a git checkout */ }

// Staleness is per source file, not per repository. Comparing a page against
// the repo's HEAD marks every translation stale whenever anything at all is
// committed, including a review record or a campaign note, and a warning that
// fires constantly is a warning nobody reads. What a reader needs to know is
// whether the English text THIS page renders has moved since the page was
// written, so compare against the last commit that touched that file.
const sourceCommits = new Map();
const commitFor = (relPath) => {
  if (!sourceCommits.has(relPath)) {
    let c = lawCommit;
    try {
      c = execSync(`git log -1 --format=%h -- ${relPath}`, { cwd: LAW })
        .toString().trim() || lawCommit;
    } catch { /* fine: not a git checkout */ }
    sourceCommits.set(relPath, c);
  }
  return sourceCommits.get(relPath);
};

// ---- articles -------------------------------------------------------
const artDir = join(LAW, 'regulation', 'articles');
const articles = readdirSync(artDir).filter((f) => f.endsWith('.md')).sort().map((f) => {
  const raw = readFileSync(join(artDir, f), 'utf8');
  const body = stripNotes(raw);
  const m = body.match(/^# Article (\d+): (.+)$/m);
  const number = Number(m[1]);
  const title = m[2].trim();
  const text = body.replace(/^# .+$/m, '').trim();
  // Legal paragraphs ("3. The ...") must not become markdown ordered
  // lists: render each blank-line block as one anchored paragraph, with
  // lettered points on their own lines.
  const html = text.split(/\n\n+/).map((block) => {
    const pm = block.match(/^(\d+)\.\s+([\s\S]*)$/);
    const NL = String.fromCharCode(10);
    const inline = (t) => marked.parseInline(
      t.split(NL + '(').join('@@BR@@(').split(NL).join(' ')
    ).replace(/@@BR@@/g, '<br>');
    if (pm) {
      return `<p id="art-${number}-${pm[1]}"><span class="para-num">${pm[1]}.</span> ${inline(pm[2])}</p>`;
    }
    return `<p>${inline(block)}</p>`;
  }).join('\n');
  return { number, title, slug: `article-${number}`, html, file: f };
}).sort((a, b) => a.number - b.number);

// ---- plain-language layers (L0/L1) per locale -----------------------
// content/{lang}/plain/article-N.md: frontmatter + "L0: ..." line + L1
// paragraph. Gated by the layer-fidelity gate before deploy. Like the
// other law-derived content below, a plain page carries its own
// source-commit and goes stale the same way: written against one
// commit of the article, silently wrong the moment the article moves on.
const plainFor = (n, sourceFile) => {
  const out = {};
  for (const loc of ['en', 'nl', 'fr', 'de', 'es']) {
    const f = join(process.cwd(), 'content', loc, 'plain', `article-${n}.md`);
    if (!existsSync(f)) continue;
    const raw = readFileSync(f, 'utf8');
    const m = raw.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
    if (!m) continue;
    const meta = {};
    for (const line of m[1].split('\n')) {
      const i = line.indexOf(':');
      if (i > 0) meta[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    }
    const body = m[2].trim();
    const l0m = body.match(/^L0:\s*(.+)$/m);
    const l1 = body.replace(/^L0:.*$/m, '').trim();
    // A missing source-commit must read as stale, not as current: a new
    // plain page without the field should fail loudly (banner shows) the
    // moment it ships, rather than silently claiming to be up to date.
    out[loc] = {
      l0: l0m ? l0m[1].trim() : '',
      l1: marked.parse(l1),
      stale: (meta['source-commit'] || '')
        !== commitFor(`regulation/articles/${sourceFile}`),
    };
  }
  return out;
};
for (const a of articles) a.plain = plainFor(a.number, a.file);

// ---- translated rubrics ---------------------------------------------
// content/{lang}/rubrics.md: | slug | english | rubric |. The English column
// is the drift check. A rubric that moves in the law repo must not leave a
// translation of the old heading standing, so a mismatch fails the build
// rather than shipping a heading that no longer exists upstream.
const rubricsFor = () => {
  const out = {};
  for (const loc of ['nl', 'fr', 'de', 'es']) {
    const f = join(process.cwd(), 'content', loc, 'rubrics.md');
    if (!existsSync(f)) continue;
    for (const line of readFileSync(f, 'utf8').split('\n')) {
      const cells = line.split('|').map((c) => c.trim());
      if (cells.length !== 5 || !cells[1] || cells[1] === 'slug'
          || cells[1].startsWith('---')) continue;
      const [, slug, english, rubric] = cells;
      (out[slug] ||= {})[loc] = { english, rubric };
    }
  }
  return out;
};
const rubrics = rubricsFor();
const attachRubrics = (item, englishRubric) => {
  const per = rubrics[item.slug] || {};
  item.titles = {};
  for (const [loc, { english, rubric }] of Object.entries(per)) {
    if (english !== englishRubric) {
      throw new Error(
        `rubric drift: content/${loc}/rubrics.md records ${item.slug} as\n`
        + `  "${english}"\nbut the law repo now says\n  "${englishRubric}"\n`
        + 'Update the translation, then the english column.'
      );
    }
    item.titles[loc] = rubric;
  }
};
for (const a of articles) attachRubrics(a, a.title);

// ---- recitals -------------------------------------------------------
const recitalsRaw = read('regulation/recitals.md');
const recBody = stripNotes(recitalsRaw)
  .replace(/^# Recitals$/m, '').replace(/^Whereas:$/m, '').trim();
const recitals = marked.parse(recBody).replace(
  /<p>\((\d+)\)/g,
  (_, n) => `<p id="recital-${n}"><span class="para-num">(${n})</span>`
);
// The Treaty citation is one line of the preamble, above the numbered
// recitals: a reader looking for the legal basis should not have to open
// the recitals page and scan past the whereas clauses to find it.
// It is matched as a whole paragraph and re-joined, so that hard-wrapping the
// line (as the numbered recitals below it are wrapped) cannot silently
// truncate a legal citation to its first line; and a match that does not
// look like a citation fails the build rather than rendering half of one.
const preamble = stripNotes(recitalsRaw).split(/\n\s*\n/).map((b) => b.replace(/\s*\n\s*/g, ' ').trim());
const citation = preamble.find((b) => b.startsWith('Having regard to the Treaty on the Functioning of the European Union')) || null;
if (citation !== null && !(/Article \d+/.test(citation) && citation.endsWith(','))) {
  throw new Error(`sync-law: Treaty citation looks truncated or malformed: ${JSON.stringify(citation)}`);
}

// ---- annexes --------------------------------------------------------
const annexDir = join(LAW, 'regulation', 'annexes');
const annexes = readdirSync(annexDir).filter((f) => f.endsWith('.md')).sort().map((f, i) => {
  const body = stripNotes(readFileSync(join(annexDir, f), 'utf8'));
  const title = body.match(/^# (.+)$/m)[1];
  const item = {
    numeral: ['I', 'II', 'III'][i],
    slug: basename(f, '.md'),
    title,
    html: marked.parse(body.replace(/^# .+$/m, '').trim()),
  };
  // the annex rubric is stored without its "Annex I: " prefix, like the
  // article rubrics, so both sides of the drift check compare like with like
  attachRubrics(item, title.replace(/^Annex [IVX]+:\s*/, ''));
  return item;
});

// Mentions of repo files in prose become links to the repository, so a
// site reader lands on the real file instead of a dead relative path.
const REPO = 'https://github.com/ownthemachine/own-the-machine/blob/main';
const KNOWN = { 'EVIDENCE.md': 'evidence/EVIDENCE.md', 'GATES.md': 'campaign/GATES.md',
  'GOVERNANCE.md': 'GOVERNANCE.md', 'CONTRIBUTING.md': 'CONTRIBUTING.md' };
const linkRepoPaths = (html) => html.replace(
  new RegExp('(^|[\\s(])((?:[a-z][a-z0-9-]*/)*[A-Za-z0-9_.-]+[.]md)(?=[\\s,.)<]|$)', 'g'),
  (m, pre, path) => {
    const target = path.includes('/') ? path : (KNOWN[path] || null);
    return target ? pre + '<a href="' + REPO + '/' + target + '">' + path + '</a>' : m;
  });

// Long texts get an "On this page" contents list generated from their
// h2 headings (the EUR-Lex / ECL in-page navigation pattern).
const slug = (t) => t.toLowerCase().replace(/<[^>]+>/g, '').replace(/&[a-z]+;/g, ' ')
  .replace(/[^a-z0-9\s-]/g, '').trim().replace(/\s+/g, '-').slice(0, 60);
const withToc = (html, depth = 2) => {
  const toc = [];
  const seen = new Set();
  const out = html.replace(/<h([23])>([\s\S]*?)<\/h\2?[23]>/g, (m, lvl, inner) => {
    const text = inner.replace(/<[^>]+>/g, '').trim();
    let id = slug(text) || 'section';
    while (seen.has(id)) id += '-b';
    seen.add(id);
    if (lvl === '2') toc.push({ id, text, children: [] });
    else if (depth >= 3 && toc.length) toc[toc.length - 1].children.push({ id, text });
    return `<h${lvl} id="${id}">${inner}</h${lvl}>`;
  });
  return { html: out, toc };
};

// ---- localised long-form content ------------------------------------
// content/{lang}/{name}.md are gated translations with frontmatter
// (source, source-commit, status). Missing file = English fallback with
// an honesty banner; stale source-commit = an extra staleness line.
const CONTENT = join(process.cwd(), 'content');
const parseFM = (raw) => {
  const m = raw.match(/^---\n([\s\S]*?)\n---\n/);
  const meta = {};
  let body = raw;
  if (m) {
    for (const line of m[1].split('\n')) {
      const i = line.indexOf(':');
      if (i > 0) meta[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    }
    body = raw.slice(m[0].length);
  }
  return { meta, body };
};
// A translated page that links to /law/versions sends its reader to the
// ENGLISH page, silently, in the middle of a Dutch sentence. Every localised
// file in this repository carried unprefixed internal links, because the
// prefix is a property of where the page is served and not of what the
// translator wrote. Rewrite at render time instead of asking four translators
// to remember it. Asset paths are not localised and are left alone.
const ASSET_PREFIXES = ['/downloads/', '/og/', '/_astro/', '/fonts/'];
const localiseLinks = (html, loc) => html.replace(
  /href="(\/[^"#]*)"/g,
  (m, path) => (
    path.startsWith(`/${loc}/`) || ASSET_PREFIXES.some((a) => path.startsWith(a))
      ? m
      : `href="/${loc}${path}"`
  ));

// Drafting notes are commentary for the campaign team, appended after the
// last section and never part of what would be filed; cut at that
// paragraph (and the "---" line before it, if any) wherever it appears,
// English source and any localised copy alike, rather than leaning on
// stripNotes, which would cut this file's first SECTION separator instead.
const DRAFTING_NOTES = /\n(?:---\n)?\s*(?:Drafting notes \(not part of the registration\)\.|<!-- drafting-notes -->)[\s\S]*$/;
const cutDraftingNotes = (body) => body.replace(DRAFTING_NOTES, '').trim();

const loadLocalized = (name, opts = {}) => {
  const out = {};
  for (const loc of ['nl', 'fr', 'de', 'es']) {
    const f = join(CONTENT, loc, `${name}.md`);
    if (!existsSync(f)) continue;
    const { meta, body } = parseFM(readFileSync(f, 'utf8'));
    const trimmed = opts.stripDraftingNotes ? cutDraftingNotes(body) : body.trim();
    const html = localiseLinks(linkRepoPaths(marked.parse(trimmed)), loc);
    const doc = opts.toc ? withToc(html, opts.depth || 2) : { html, toc: [] };
    out[loc] = {
      ...doc,
      status: meta.status || 'machine',
      stale: opts.source
        ? (meta['source-commit'] || '') !== commitFor(opts.source)
        : false,
    };
  }
  return out;
};

// ---- memorandum: objections + severability --------------------------
const objections = {
  en: withToc(linkRepoPaths(marked.parse(read('regulation/memorandum/counter-arguments.md'))), 3),
  ...loadLocalized('objections', { toc: true, depth: 3, source: 'regulation/memorandum/counter-arguments.md' }),
};
const severability = {
  en: withToc(linkRepoPaths(marked.parse(read('regulation/memorandum/severability.md')))),
  ...loadLocalized('severability', { toc: true, source: 'regulation/memorandum/severability.md' }),
};
const explanatory = {
  en: withToc(linkRepoPaths(marked.parse(read('regulation/memorandum/explanatory-memorandum.md'))), 3),
  ...loadLocalized('explanatory', { toc: true, depth: 3, source: 'regulation/memorandum/explanatory-memorandum.md' }),
};

// ---- registration text (Annex II format) -----------------------------
// campaign/REGISTRATION-TEXT.md uses "---" lines as section separators,
// not as a drafting-notes cutoff, so it is rendered whole (sections 1 to
// 5) rather than through stripNotes; only the drafting-notes block after
// the last section, which is commentary for the campaign team and never
// part of what would be filed, is cut.
const registrationBody = cutDraftingNotes(
  read('campaign/REGISTRATION-TEXT.md').replace(/^# ECI registration text$/m, '')
);
const registration = {
  en: withToc(linkRepoPaths(marked.parse(registrationBody))),
  ...loadLocalized('registration', {
    toc: true, source: 'campaign/REGISTRATION-TEXT.md', stripDraftingNotes: true,
  }),
};

// ---- ledger: review files with front matter -------------------------
const revDir = join(LAW, 'pipeline', 'reviews');
const ledger = readdirSync(revDir).filter((f) => f.endsWith('.md')).sort().reverse().map((f) => {
  const raw = readFileSync(join(revDir, f), 'utf8');
  const fm = raw.match(/^---\n([\s\S]*?)\n---\n/);
  const meta = {};
  if (fm) for (const line of fm[1].split('\n')) {
    const i = line.indexOf(':');
    if (i > 0) meta[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  const dispo = raw.match(/## Editor disposition[^\n]*\n([\s\S]*)$/);
  return {
    file: f,
    gate: meta.gate || 'unknown',
    target: meta.target || '',
    commit: meta.commit || '',
    verdict: meta.verdict || '',
    disposition: meta.disposition || '',
    date: meta.date || '',
    dispositionHtml: dispo ? marked.parse(dispo[1].trim()) : '',
  };
});

// ---- evidence -------------------------------------------------------
let evidence = { en: { html: '', toc: [] } };
try {
  evidence = {
    en: withToc(linkRepoPaths(marked.parse(read('evidence/EVIDENCE.md').replace(/^# .+\n/, '')))),
    ...loadLocalized('evidence', { toc: true, source: 'evidence/EVIDENCE.md' }),
  };
} catch (e) { console.error('sync-law: WARNING, evidence source missing, page will be empty:', e.message); }

// ---- about + contribute (site-native content) -----------------------
const siteDoc = (name) => ({
  en: { html: marked.parse(readFileSync(join(CONTENT, 'en', `${name}.md`), 'utf8')) },
  ...loadLocalized(name),
});
const about = siteDoc('about');
const contribute = siteDoc('contribute');
const versions = siteDoc('versions');
const joinDoc = siteDoc('join');
const brief = siteDoc('brief');
const faq = siteDoc('faq');
const press = siteDoc('press');
const sign = siteDoc('sign');

// ---- registered version state ---------------------------------------
// Whether a version of this draft has been filed and registered is a fact
// about the world, not a fact about this build, so it is read from the law
// repo instead of being asserted in a page. A missing or null entry means
// nothing is registered, which is both the honest default and the current
// truth. Everything downstream keys off this: the versions page reports it,
// and the draft notice on the law pages only appears once it is non-null,
// because before registration there is no second text to distinguish from.
let registered = null;
try {
  const parsed = JSON.parse(read('versions/REGISTERED.json'));
  registered = parsed.registered || null;
} catch (e) {
  console.error('sync-law: no versions/REGISTERED.json, treating as unregistered');
}

// ---- structure ------------------------------------------------------
const structure = marked.parse(stripNotes(read('regulation/STRUCTURE.md')).replace(/^# .+$/m, '').trim());

writeFileSync(join(OUT, 'law.json'), JSON.stringify({
  lawCommit,
  builtAt: new Date().toISOString(),
  articles, recitals, annexes, objections, severability, ledger, evidence, about, contribute, structure,
  versions, join: joinDoc, brief, faq, press, sign, explanatory, registered, registration, citation,
}, null, 1));
console.log(`sync-law: ${articles.length} articles, ${annexes.length} annexes, ${ledger.length} ledger entries @ ${lawCommit}`);
console.log(`sync-law: registered version: ${registered ? registered.number : 'none'}`);


# SOURCE: own-the-machine-tools/review.sh

#!/usr/bin/env bash
# Generic adversarial review runner for the legislation pipeline.
# Usage: review.sh <input.md> <output.md> <prompt.md>
#
# Routing. The gate runs on an EU-hosted, zero-retention endpoint by default.
# That is not a preference: a campaign about European ownership of automated
# capital should not send its own drafts through a jurisdiction it is arguing
# about, and a draft Regulation is unpublished legal text until it is filed.
#
# Env:
#   REQUESTY_API_KEY   (or REVIEW_API_KEY; OPENROUTER_API_KEY still works when
#                       REVIEW_BASE_URL is pointed back at OpenRouter)
#   REVIEW_BASE_URL    default https://router.eu.requesty.ai/v1
#   REVIEW_MODEL       default vertex/gemini-3.7-flash@eu
#   REVIEW_PROFILE     optional astra | fable-5.1; resolves against live metadata
#                      without changing retention, region or training checks
#   REVIEW_TIMEOUT     default 1800 (seconds per request; reasoning-tier
#                      models on long adversarial prompts exceed 600)
#   REVIEW_VERIFY      default 1. Read the router's own model metadata and
#                      refuse to run unless it satisfies the requirements
#                      below. 0 skips verification entirely, and the review
#                      record then claims nothing about jurisdiction.
#   REVIEW_REQUIRE_EU          default 1  geolocation must be eu
#   REVIEW_REQUIRE_ZDR         default 1  retention must be 0 days
#   REVIEW_REQUIRE_NO_TRAINING default 1  text must not be trained on
#                      Three separate switches so that relaxing one does not
#                      silently drop the other two. The provenance line always
#                      reports what the router said, so a relaxed run is
#                      visible in every verdict it produced.
# A .env beside this script is loaded if present, so the key stays out of the
# shell history and out of the repository (.env is gitignored).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
[[ -f "$HERE/.env" ]] && set -a && . "$HERE/.env" && set +a

IN="${1:?usage: review.sh <input.md> <output.md> <prompt.md>}"
OUT="${2:?}"; PROMPT="${3:?}"
# Optional positional profile and explicit public-material retention exception.
# These are per invocation; the .env and default requirements stay unchanged.
if [[ -n "${4:-}" ]]; then export REVIEW_PROFILE="$4"; fi
if [[ -n "${5:-}" ]]; then
  [[ "$5" == "public-retention-exception" && "${REVIEW_PROFILE:-}" == "fable-5.1" ]] || {
    echo "unsupported retention exception; only explicit public Fable reviews are supported" >&2; exit 1; }
  export REVIEW_REQUIRE_ZDR=0
fi
BASE="${REVIEW_BASE_URL:-https://router.eu.requesty.ai/v1}"
MODEL="${REVIEW_MODEL:-vertex/gemini-3.7-flash@eu}"
VERIFY="${REVIEW_VERIFY:-1}"
KEY="${REVIEW_API_KEY:-${REQUESTY_API_KEY:-${OPENROUTER_API_KEY:-}}}"
[[ -f "$IN" && -f "$PROMPT" ]] || { echo "missing input or prompt" >&2; exit 1; }
[[ -n "$KEY" ]] || { echo "no API key: set REQUESTY_API_KEY (see README)" >&2; exit 1; }
[[ ! -e "$OUT" ]] || { echo "review output already exists; use a new round filename" >&2; exit 1; }
[[ -z "${REVIEW_PROFILE:-}" || "$VERIFY" == "1" ]] || {
  echo "REVIEW_PROFILE requires live model verification" >&2; exit 1; }
mkdir -p "$(dirname "$OUT")"
TMP="$(mktemp)"; RESP="$(mktemp)"; CFG="$(mktemp)"; META="$(mktemp)"; DOC_SNAPSHOT="$(mktemp)"; PROMPT_SNAPSHOT="$(mktemp)"
trap 'rm -f "$TMP" "$RESP" "$CFG" "$META" "$DOC_SNAPSHOT" "$PROMPT_SNAPSHOT"' EXIT
cp "$IN" "$DOC_SNAPSHOT"; cp "$PROMPT" "$PROMPT_SNAPSHOT"
chmod 600 "$CFG"; printf 'header = "Authorization: Bearer %s"\n' "$KEY" > "$CFG"

# ---- provenance, verified rather than asserted ----------------------
# The router publishes geolocation and retention per model. Read it, prove the
# claim before spending tokens, and carry what it said into the review record.
PROV="router $(printf '%s' "$BASE" | sed -E 's#https?://([^/]+).*#\1#')"
if [[ "$VERIFY" == "1" ]]; then
  curl -sS --max-time 120 -K "$CFG" -o "$META" "$BASE/models" || {
    echo "could not read $BASE/models to verify EU routing" >&2; exit 1; }
  RESOLVED=$(python3 - "$META" "$MODEL" "$BASE" <<'PY'
import json, sys
meta, model, base = json.load(open(sys.argv[1])), sys.argv[2], sys.argv[3]
rows = meta if isinstance(meta, list) else meta.get('data', [])
import os, re
profile = os.environ.get('REVIEW_PROFILE', '')
families = {'astra': 'gpt-6-astra', 'fable-5.1': 'claude-fable-5.1'}
if profile:
    if profile not in families:
        sys.exit('unknown REVIEW_PROFILE; choose astra or fable-5.1')
    family = families[profile]
    candidates = [r for r in rows if re.search(
        r'(?:^|/)' + re.escape(family) + r'(?:@[^/]+)?$', r.get('id', ''))]
    # Prefer EU and zero retention, but never silently waive a requirement.
    candidates.sort(key=lambda r: (r.get('geolocation') != 'eu',
                                    r.get('data_retention_days') not in (0, '0'),
                                    r.get('id', '')))
    if not candidates:
        sys.exit(f'{profile} ({family}) is not offered by {base}; no substitute used')
    model = candidates[0]['id']
m = next((r for r in rows if r.get('id') == model), None)
if m is None:
    sys.exit(f"model {model!r} is not offered by {base}. "
             "Pick an exact model ID from its catalogue.")
geo = str(m.get('geolocation', '')).lower()
days = m.get('data_retention_days')
trained = m.get('data_used_for_training')
want = lambda k: os.environ.get(k, '1') == '1'
# Three separable guarantees, so that relaxing one does not silently drop the
# others. Region is the thesis. Training use is the principle: a proposal about
# capital formed out of other people's inputs without their consent should not
# hand its own text over for training. Retention is hygiene, and this corpus is
# published anyway, so it is the one that can defensibly be relaxed.
bad = []
if want('REVIEW_REQUIRE_EU') and geo != 'eu':
    bad.append(f"geolocation={geo or 'unknown'}")
if want('REVIEW_REQUIRE_ZDR') and days not in (0, '0'):
    bad.append(f"retention_days={days}")
# unknown is not a pass: a router that does not say must not be taken to mean no
if want('REVIEW_REQUIRE_NO_TRAINING') and trained not in (False, 'false'):
    bad.append(f"trained_on={'unknown' if trained is None else trained}")
if bad:
    sys.exit("refusing to run: " + ", ".join(bad) + ". The review record would "
             "claim a guarantee this model does not offer. Relax the specific "
             "requirement deliberately (see README) rather than all of them.")
host = base.split('//')[-1].split('/')[0]
# The line reports what the router actually said, never what was required, so a
# relaxed run is visible in every verdict it produces.
print(model)
print(f"router {host} · geolocation {geo} · retention {days}d · "
      f"trained-on {str(trained).lower()} · lab {m.get('model_lab', '?')}")
PY
  ) || exit 1
  MODEL="${RESOLVED%%$'\n'*}"
  PROV="${RESOLVED#*$'\n'}"
fi

build_body() {  # $1 = "with" | "without" temperature
  python3 - "$PROMPT_SNAPSHOT" "$DOC_SNAPSHOT" "$MODEL" "${REVIEW_TEMPERATURE:-0.3}" "$1" > "$TMP" <<'PY'
import json, sys
prompt, doc, model, temp, mode = (open(sys.argv[1]).read(), open(sys.argv[2]).read(),
                                  sys.argv[3], sys.argv[4], sys.argv[5])
body = {"model": model,
        "messages": [{"role": "user", "content": prompt + "\n\n---\n\n" + doc}]}
# Reasoning-tier models reject temperature outright ("deprecated for this
# model"), so it is a parameter the runner must be able to drop.
if mode == "with" and temp not in ("off", ""):
    body["temperature"] = float(temp)
print(json.dumps(body))
PY
}
call() {
  # curl -w prints a code even when the transfer fails, and a fallback echo
  # would append a second one ("000000"), which the retry test below can
  # never match. Sanitise to exactly one three-digit code whatever happens.
  local code
  code=$(curl -sS --max-time "${REVIEW_TIMEOUT:-1800}" --connect-timeout 30 \
    -K "$CFG" -H "Content-Type: application/json" \
    -o "$RESP" -w '%{http_code}' -d @"$TMP" "$BASE/chat/completions") || true
  [[ "$code" =~ ^[0-9]{3}$ ]] || code="000"
  printf '%s' "$code"
}
build_body with
HTTP=$(call)
if [[ "$HTTP" == "400" ]] && grep -qi 'temperature' "$RESP"; then
  echo "note: $MODEL rejects temperature; retrying without it" >&2
  build_body without
  HTTP=$(call)
fi
for backoff in 20 60; do
  [[ "$HTTP" == "429" || "$HTTP" =~ ^5 || "$HTTP" == "000" ]] || break
  echo "note: HTTP $HTTP from $MODEL, retrying in ${backoff}s" >&2
  sleep "$backoff"; HTTP=$(call)
done
[[ "$HTTP" == "200" ]] || { echo "review HTTP $HTTP from $BASE" >&2; head -c 400 "$RESP" >&2; exit 1; }
python3 - "$RESP" "$OUT" "$MODEL" "$PROMPT" "$PROV" "$DOC_SNAPSHOT" "$PROMPT_SNAPSHOT" <<'PY'
import json, sys, os, datetime, hashlib
r = json.load(open(sys.argv[1])); txt = r["choices"][0]["message"]["content"]
u = r.get("usage", {})
hdr = (f"# Review\n\n> Reviewer: `{sys.argv[3]}` · {sys.argv[5]}\n"
       f"> {datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')} · "
       f"tokens in={u.get('prompt_tokens','?')} out={u.get('completion_tokens','?')}\n"
       f"> Prompt: {os.path.basename(sys.argv[4])} · Verbatim model output below ; do not edit.\n\n")
hdr += ('> Bundle SHA-256: `' + hashlib.sha256(open(sys.argv[6], 'rb').read()).hexdigest()
        + '`\n> Prompt SHA-256: `' + hashlib.sha256(open(sys.argv[7], 'rb').read()).hexdigest()
        + '`\n\n')
open(sys.argv[2], "w").write(hdr + txt + "\n")
# Models sometimes emphasise the line ("**VERDICT: PUBLISH**"); a plain
# startswith would then read a pass as no verdict at all. Strip emphasis
# on both sides before matching.
import re as _re
v = []
for line in txt.splitlines():
    s = _re.sub(r"^[\s>*_#`-]+", "", line).strip()
    if s.upper().startswith("VERDICT:"):
        v.append(_re.sub(r"[\s*_`]+$", "", s))
print(v[-1] if v else "NO VERDICT LINE ; treat as REVISE")
print(f"review written: {sys.argv[2]}")
if len(v) != 1 or v[0].upper() != 'VERDICT: PUBLISH':
    sys.exit(2)
PY


# SOURCE: own-the-machine-tools/README.md

# own-the-machine-tools

The review machinery for the [own-the-machine](https://github.com/ownthemachine/own-the-machine)
draft EU Regulation: the adversarial gate runner, the six gate prompts and
the mechanical linter. Split out so the law repository stays a civic
artefact (text, evidence, governance and the ledger of its own evolution)
while the workshop lives here.

This is machinery, not policy. The normative documents (GOVERNANCE.md,
DRAFTING-RULES.md, the constraints table) live with the law; the prompts
here enforce them and cite them by path. Review OUTPUTS also live with the
law, under pipeline/reviews/, because a verdict on a statute is part of the
statute's history, not of the tooling.

## Use

    cp .env.example .env && $EDITOR .env     # REQUESTY_API_KEY; .env is gitignored
    python3 lint-legislation.py              # run from the law repo root
    ./review.sh <bundle.md> <out.md> prompts/<gate>.md

Gate order and model-tier guidance: pipeline/README.md in the law repo.

## Where the review runs, and why it is in the EU

The gate runs on an EU-hosted, zero-retention endpoint by default. That is
not decoration. A campaign arguing about European ownership of automated
capital should not send its own drafts through a jurisdiction it is arguing
about, and a draft Regulation is unpublished legal text until it is filed.

    REVIEW_BASE_URL    https://router.eu.requesty.ai/v1
    REVIEW_MODEL       vertex/gemini-3.7-flash@eu

The runner does not take the routing on trust. Before spending a token it
reads the router's own model metadata and refuses to start unless that model
is reported as `geolocation: eu`, `data_retention_days: 0` and
`data_used_for_training: false`. What it read is then stamped into the review
record, so every verdict in the law repository carries the evidence for the
claim rather than the claim:

    > Reviewer: `vertex/gemini-3.7-flash@eu` · router router.eu.requesty.ai ·
    > geolocation eu · retention 0d · trained-on false · lab google

Those are three separate guarantees and three separate switches, because
relaxing one should not silently drop the other two:

    REVIEW_REQUIRE_EU           1   the thesis: it runs in the Union
    REVIEW_REQUIRE_NO_TRAINING  1   the principle: our text is not training data
    REVIEW_REQUIRE_ZDR          1   hygiene: nothing is kept after the call

If one of them ever has to give, it should be retention. This corpus is
published: the source under review is in a public repository, the prompts are
in this one, and the translations ship within hours. Training use is the one
to hold, because a proposal about capital built out of other people's inputs
without their consent should not hand its own text over to be trained on.

Unknown counts as failure. A router that does not report these fields is
refused while the requirements are on, rather than being read as a quiet yes.
`REVIEW_VERIFY=0` skips verification altogether, for instance to use the
OpenRouter setup this repository ran until 23 August 2026; the provenance
line then names the router and claims nothing about jurisdiction, because
nothing was checked.

**EU-hosted is not EU-made, and the two should not be blurred.** The models
above are built by American laboratories and run on European infrastructure
under zero retention. Of the models this endpoint offers, only Mistral's are
from a European laboratory. Both facts belong in the record.

## Requested reviewer profiles

The existing Requesty account and EU endpoint remain the integration.
`REVIEW_PROFILE=astra` resolves the exact `gpt-6-astra` family from the
live catalogue; `REVIEW_PROFILE=fable-5.1` resolves `claude-fable-5.1`.
Profiles prefer EU/zero-retention routes and enforce the same requirements
as an explicit `REVIEW_MODEL`. They never substitute another model family.
When a profile is selected it takes precedence over `REVIEW_MODEL`.

On 6 September 2026 the configured catalogue listed
`vertex/claude-fable-5.1@eu` with EU hosting, 30-day retention and no training
use. It did not list GPT-6 Astra. Astra support is therefore configured but
unavailable through this catalogue; it must not be reported as having run.
Availability is checked afresh on every call.

The editor requested Fable 5.1 for the public claim-correction review. For
that public-material run only, use the documented retention exception:

    REVIEW_PROFILE=fable-5.1 REVIEW_REQUIRE_ZDR=0 ./review.sh bundle.md round-1.md prompts/layer-fidelity.md

Equivalent explicit per-run arguments (useful in command approval rules):

    ./review.sh bundle.md round-1.md prompts/layer-fidelity.md fable-5.1 public-retention-exception

EU and no-training checks remain enabled. This exception does not cover
private correspondence, non-public personal data or sensitive unpublished input.
Public author attribution may appear in public or intended-for-publication,
non-sensitive review material.
The website disclosure and each review's provenance report the exception;
the default remains zero retention.

For Astra, once Requesty offers it under the required conditions:

    REVIEW_PROFILE=astra ./review.sh bundle.md round-1.md prompts/hostile-counsel.md

The runner preserves existing outputs: choose a new filename for each round.
It stamps bundle and prompt SHA-256 hashes, and exits 2 for REVISE, missing
or ambiguous verdicts. Exit 0 requires exactly one PUBLISH verdict. An editor
may record a disposition on an unresolved finding, but the runner itself
never converts that finding into a pass.

Offline regression checks: `python3 -m unittest discover -s tests`.

## Disclosure

Reviews are run adversarially by AI under the editor's responsibility, and
every verdict is committed to the law repository, failed rounds included.
This repo exists so that claim is inspectable, not decorative.

Licence: MIT. Reuse for your own legislation welcome; the prompts are the
interesting part.


# SOURCE: own-the-machine-tools/.env.example

# Copy to .env beside review.sh. .env and .env.* are gitignored; never commit
# a real key, and never paste one into an issue, a commit message or a chat.
#
# EU-hosted, zero-retention routing (the default, see README).
REQUESTY_API_KEY=

# Optional overrides.
# REVIEW_BASE_URL=https://router.eu.requesty.ai/v1
# REVIEW_MODEL=vertex/gemini-3.7-flash@eu
# REVIEW_PROFILE=astra
# REVIEW_PROFILE=fable-5.1
# Profiles use live catalogue IDs and keep all verification requirements.
# Fable's EU route currently reports 30-day retention; public-material
# exceptions require REVIEW_REQUIRE_ZDR=0 explicitly (see README).
#
# Three separate guarantees, so relaxing one does not drop the others. If one
# ever has to give it should be ZDR, never NO_TRAINING: this corpus is public
# anyway, but a proposal about capital built from other people's inputs without
# consent should not hand its own text over as training data. Unknown fails
# closed. The provenance line always reports what the router actually said.
# REVIEW_REQUIRE_EU=1
# REVIEW_REQUIRE_NO_TRAINING=1
# REVIEW_REQUIRE_ZDR=1
#
# Skip verification entirely, for a router that cannot report these fields
# (OpenRouter). The review record then claims nothing about jurisdiction.
# REVIEW_VERIFY=1
#
# Some reasoning-tier models reject `temperature` outright. The runner drops
# it automatically on that error; set to "off" to never send it.
# REVIEW_TEMPERATURE=0.3
#
# Back-compatible: used only when REVIEW_BASE_URL points at OpenRouter.
# OPENROUTER_API_KEY=


# SOURCE: own-the-machine-tools/tests/test_review.py

"""Exercise routing, retention and verdict handling without network calls."""
import json
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ReviewTests(unittest.TestCase):
    def run_review(self, rows, verdict='VERDICT: PUBLISH', **env):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root/'review.sh').write_text((ROOT/'review.sh').read_text())
            (root/'input.md').write_text('Public draft')
            (root/'prompt.md').write_text('Review')
            (root/'models.json').write_text(json.dumps(rows))
            (root/'response.json').write_text(json.dumps({'choices': [{'message': {'content': verdict}}]}))
            (root/'curl').write_text('''#!/usr/bin/env python3
import sys,os,pathlib,json
args=sys.argv[1:]; root=pathlib.Path(os.environ['FIXTURE'])
out=pathlib.Path(args[args.index('-o')+1])
if args[-1].endswith('/models'):
 out.write_bytes((root/'models.json').read_bytes())
else:
 body=json.loads(pathlib.Path(args[args.index('-d')+1][1:]).read_text())
 (root/'selected.txt').write_text(body['model'])
 if os.environ.get('MUTATE_INPUT'):
  (root/'input.md').write_text('Changed after request')
  (root/'prompt.md').write_text('Changed prompt')
 out.write_bytes((root/'response.json').read_bytes())
 print('200',end='')
''')
            (root/'curl').chmod(0o755)
            if env.pop('PREEXIST', False): (root/'output.md').write_text('old review')
            extra=env.pop('ARGS', [])
            clean={k:v for k,v in os.environ.items() if not k.startswith(('REVIEW_', 'REQUESTY_', 'OPENROUTER_'))}
            clean.update(PATH=str(root)+os.pathsep+os.environ['PATH'], FIXTURE=str(root), REVIEW_API_KEY='fixture-only', **env)
            r=subprocess.run(['bash',str(root/'review.sh'),str(root/'input.md'),str(root/'output.md'),str(root/'prompt.md')]+extra,env=clean,capture_output=True,text=True)
            output=(root/'output.md').read_text() if (root/'output.md').exists() else ''
            selected=(root/'selected.txt').read_text() if (root/'selected.txt').exists() else None
            return r,output,selected

    @staticmethod
    def model(id='vertex/claude-fable-5.1@eu', retention=0, geo='eu', trained=False):
        return dict(id=id,geolocation=geo,data_retention_days=retention,data_used_for_training=trained)

    def test_astra_is_not_substituted(self):
        r,_,selected=self.run_review({'data':[self.model()]},REVIEW_PROFILE='astra')
        self.assertNotEqual(r.returncode,0);self.assertIsNone(selected)
        self.assertIn('no substitute',r.stderr)

    def test_retention_is_not_silently_relaxed(self):
        r,_,selected=self.run_review({'data':[self.model(retention=30)]},REVIEW_PROFILE='fable-5.1')
        self.assertNotEqual(r.returncode,0);self.assertIsNone(selected)

    def test_explicit_public_exception_is_stamped(self):
        r,out,selected=self.run_review({'data':[self.model(retention=30)]},REVIEW_PROFILE='fable-5.1',REVIEW_REQUIRE_ZDR='0')
        self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(selected,self.model()['id'])
        self.assertIn('retention 30d',out);self.assertIn('Bundle SHA-256',out)

    def test_hashes_identify_sent_content_even_if_files_change(self):
        r,out,_=self.run_review([self.model()],REVIEW_PROFILE='fable-5.1',MUTATE_INPUT='1')
        self.assertEqual(r.returncode,0,r.stderr)
        for text in ['Public draft','Review']:
            self.assertIn(hashlib.sha256(text.encode()).hexdigest(),out)

    def test_positional_exception(self):
        r,out,_=self.run_review([self.model(retention=30)],ARGS=['fable-5.1','public-retention-exception'])
        self.assertEqual(r.returncode,0,r.stderr);self.assertIn('retention 30d',out)
        r,_,selected=self.run_review([self.model()],ARGS=['astra','public-retention-exception'])
        self.assertNotEqual(r.returncode,0);self.assertIsNone(selected)

    def test_other_guarantees_still_hold(self):
        for field in [{'geo':'global'},{'trained':True},{'trained':None}]:
            with self.subTest(field=field):
                r,_,selected=self.run_review({'data':[self.model(retention=30,**field)]},REVIEW_PROFILE='fable-5.1',REVIEW_REQUIRE_ZDR='0')
                self.assertNotEqual(r.returncode,0);self.assertIsNone(selected)

    def test_list_catalogue_and_emphasised_verdict(self):
        r,out,_=self.run_review([self.model(id='azure/gpt-6-astra@swedencentral')],'**VERDICT: PUBLISH**',REVIEW_PROFILE='astra')
        self.assertEqual(r.returncode,0,r.stderr);self.assertIn('gpt-6-astra',out)

    def test_revise_missing_and_ambiguous_verdicts_fail(self):
        for verdict in ['VERDICT: REVISE','No decision','VERDICT: PUBLISH\nVERDICT: REVISE']:
            with self.subTest(verdict=verdict):
                r,out,_=self.run_review({'data':[self.model()]},verdict,REVIEW_PROFILE='fable-5.1')
                self.assertEqual(r.returncode,2);self.assertIn(verdict,out)

    def test_existing_round_is_preserved(self):
        r,out,selected=self.run_review({'data':[self.model()]},PREEXIST=True)
        self.assertNotEqual(r.returncode,0);self.assertEqual(out,'old review');self.assertIsNone(selected)

    def test_profiles_require_verification(self):
        r,_,selected=self.run_review({'data':[self.model()]},REVIEW_PROFILE='fable-5.1',REVIEW_VERIFY='0')
        self.assertNotEqual(r.returncode,0);self.assertIsNone(selected)

if __name__ == '__main__': unittest.main()
