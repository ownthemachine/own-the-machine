# Independent verification of outstanding legal findings

Baseline: 0aeaada. No changes to operative text. The findings are hypotheses; assess and challenge them.


# FULL SOURCE: own-the-machine/pipeline/findings/2026-09-06-review-scope.md

# Review of outstanding findings: scope and source

Requested by the initiator on 6 September 2026, following the claim-correction review. This is an independent diagnostic review of findings, not an amendment to the law or a release gate asserting the statute is ready. The operative draft remains unchanged. Source: law repository commit 0aeaada (operative text unchanged by the preceding campaign-copy corrections).

Questions to test, not conclusions to assume:

1. Does Article 5(4)(e) conflict with issuance, extraction-triggered crystallisation, the seven-year trigger or execution duties? Distinguish obligations imposed by the warrant from statutory duties. Is the narrower finding stronger than saying all earlier duties are contradictory?
2. Could Article 3(8) disregard genuine hiring/pay rises or genuine reductions in value? Test the strongest interpretation tying its second sentence to the first sentence's avoidance context, and its consistency with recital 7.
3. Do Articles 8–9 establish sufficient positive governance for the Reserve? Check every article/annex for organs, appointment, representation, decision authority and accountability, and any power to supply these later. Distinguish missing governance from a requirement for paid campaign staff. Identify choices that cannot responsibly be decided by a copy edit.
4. Does Article 13 cover refusal to execute the subscription under Article 5(5), as well as failure to issue/procure/notify? Trace its third-sentence cross-reference exactly. Do not equate a gap in this penalty list with absence of the substantive obligation or all civil/judicial enforcement. Check third-country cases and Article 5 transferees.
5. Are the existing memorandum's post-designation-value-only, owners-realisation-only, notification-only, outside-the-nine-unaffected, audited-accounts-only and age-of-majority descriptions faithful to the operative text? Check fee cross-reference 10(6) against 11(3) and the allegedly unenumerated five acquis interfaces. Check the French counterpart and its source alignment.

For each, identify the strongest defence of the current wording, the finding that survives that defence, likely practical consequence, and whether resolution is an editorial correction, substantive drafting repair, governance choice, or external legal question. Distinguish verifiable text defects from uncertain litigation predictions. Do not invent numerical probabilities of a court outcome. Treaty/property-rights validity is not established or rejected by this audit.

The review receives complete regulation files, governance, drafting rules, evidence and the original review records. The two model reviewers receive the same immutable bundle independently. Preserve all verdicts and disclose model routing and retention. This material is public or intended-for-publication and non-sensitive; the existing explicit per-run Fable retention exception is used, with EU hosting and no training still required.

External legal checks, 6 September 2026: Article 290 TFEU permits specified delegation concerning non-essential elements and reserves essential elements to the legislative act. Article 291 concerns implementation, including conferred implementing powers where uniform conditions are needed. Neither is an unbounded power to fill every gap in a draft. Determining the essential governance choices for this particular Reserve requires analysis, not assumption. Sources: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:12012E290 ; https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:12012E291 . These are contextual checks, not a complete legal-basis opinion.


# FULL SOURCE: own-the-machine/GOVERNANCE.md

# Governance: how an open-source law changes

This repository is public. Every rule here is written for that fact:
strangers proposing amendments to a draft statute, in public, with the
history permanent.

## Roles

- **Editor:** David Vanheeswijck, until a campaign organisation exists and
  formally assumes the role. The editor merges; nobody else does, including
  automated tooling.
- **Reviewers:** anyone. Review rounds run by the team are committed to
  pipeline/reviews/ so outside reviewers can see the standard applied.
- **Contributors:** anyone, via issues and pull requests. No CLA; the
  licences (LICENSING.md) are the contract.

## The merge criteria

Two layers, both mandatory. Prose quality is judged last, not first.

**Substantive: the four tests.** A change fails review by definition if it
makes the instrument
1. less about assets and more about flows,
2. less universal (any means test, any discretionary gate),
3. less raid-proof (weakening entrenchment, adding emergency clauses,
   permitting sovereign self-dealing), or
4. later (moving obligations past the formation of the gains).

**Mechanical: the constraints table.** Every PR touching regulation/ must
state which DCs from regulation/memorandum/counter-arguments.md it touches.
A draft that violates a DC is rejected regardless of drafting quality. A PR
arguing a DC itself is wrong must amend the counter-arguments file first, in
the same PR, and survives only if the underlying objection is answered at
least as well as before.

## Change classes

| Class | Examples | Required before merge |
|---|---|---|
| Editorial | typo, punctuation, layout | editor's read |
| Prose | recital wording, memorandum text | legal-form gate + editor |
| Substantive | any enacting term, any threshold, any definition | full pipeline (all six gates) + editor |
| Constitutional | the four tests, the DC table, this file | full pipeline + public issue open ≥14 days + editor |

### The 14-day window assumes a public, and there is not one yet

The constitutional window was written for a repository people read. This one
is public but unannounced, and nobody has been asked to look at it. Running
a 14-day comment period against that audience produces no comments and then
treats the silence as ratification, which is a worse outcome than not
running it: it manufactures a legitimacy this project has not earned and
would have to defend later.

So the window runs from the first outreach, not from the merge. Until this
draft has been put in front of people who were invited to argue with it:

- constitutional changes may be merged by the editor on the full pipeline
  alone, and are **provisional**;
- each one is listed below as it is made;
- at first outreach every provisional change re-opens together, for the full
  14 days, and anything unable to survive that is reverted.

Provisional constitutional changes, pending the window:

- 21 August 2026: "Versions: the freeze at registration", added below.
- 22 August 2026: objections 20 and 21 and constraints DC-43 to DC-46 in
  regulation/memorandum/counter-arguments.md.
- 22 August 2026, second entry: the designation-ratio package. Article
  3(2)(b) redesignated on fair market value against audited compensation
  of labour; Annex I point 3 rewritten accordingly; Article 1(2)
  quantified objective; Article 14(1)(e) labour-share indicator; recitals
  5, 6, 7 and 30 amended; DC-45 and DC-46 restated. Two prior designs
  were killed in gate review before this one; the record is in
  pipeline/reviews/2026-08-22-designation-ratio.md. DC-46 records that Article 1's
  objective needs quantifying before filing, which is the largest open
  drafting item this file has; the reasoning is in
  pipeline/reviews/2026-08-22-objections-20-21.md.

This clause is itself provisional under its own terms.

## Process

1. Open an issue describing the change and which objections (1-18) it
   relates to. Drafting starts in the issue, not the PR.
2. PR from a branch; template requires: DCs touched, change class, gates run,
   review files added under pipeline/reviews/.
3. Gates run per class (pipeline/README.md). Verdicts are committed, PUBLISH
   and REVISE alike. A REVISE with a written editor disposition can merge;
   silent overrides cannot.
4. Editor merges with a message stating what the change does to the
   instrument, not what it does to the text.

## Versions: the freeze at registration

Everything above describes a living draft. Registration under Regulation
(EU) 2019/788 changes that, and this repository has to change with it.
From the moment an initiative is registered, the annex as registered is
what citizens are asked to sign, and it cannot be amended. A draft that
keeps moving while signatures are collected against a fixed text is not
transparency; it is a gap between what was signed and what is published,
and it would rightly be read that way.

The rule is adopted here before there is anything to freeze, so that it
cannot later be written to suit a convenience.

1. **On the day of registration the filed text is frozen.** It is copied
   verbatim into versions/, with the commit it was taken from, the date of
   filing and the Commission's decision. Nothing in that directory is ever
   edited afterwards. A correction to a frozen version is a new frozen
   version, never an edit of the old one.
2. **versions/REGISTERED.json is the machine-readable state.** It names the
   registered version or records that there is none. The site reads that
   file and reports what it finds; no page states the answer from memory.
3. **The living draft continues, and says so on every page.** Work does not
   stop at registration, because the Commission's response is argued
   against the best version of the case, not the filed one. Every page
   rendering the living draft carries the distinction plainly, and the
   registered text is reachable in one click from any of them.
4. **Divergence is published, not characterised.** Where the living draft
   and the registered text differ, the difference is a diff a reader can
   read for themselves, never a claim about how minor it is.
5. **The frozen text is authoritative for what was signed. The living draft
   is authoritative for nothing until it is itself filed.**

Before registration, which is where this project stands, the state is
simply that no version is registered and the whole repository is a draft.

## Transparency rules

- No force-pushes to main, ever, once public. History is the product.
- Every review round, including failed ones, is committed.
- Editor dispositions that decline a finding are written into the review
  file, as in the wider project's practice.
- The site's public ledger is rendered from the review files and release
  notes: outcomes and dispositions are the public story; prompts and tooling
  remain inspectable in the tools repository.
- Funding and support are declared in campaign/FUNDING.md, and the
  declaration is kept current from now rather than from the moment
  Regulation (EU) 2019/788 makes it compulsory. "None" is not an
  acceptable answer while anyone is paying for anything.


# FULL SOURCE: own-the-machine/pipeline/README.md

# The legislation pipeline

The strictest gate set in the project, because the artefact is a draft
statute that professionals must be unable to dismiss on form, and because
the repo is public: the pipeline is part of the credibility, visible to
every reader.

Inherited from the book project's hard-won lessons: reviewers get FULL
document context, never fragments; every round is committed, PUBLISH and
REVISE alike; declined findings carry a written editor disposition; and the
automated gate is trusted on rule violations, never on whether a sentence
lands. The final read is always human.

## The six gates

Run in this order; later gates assume earlier ones passed. **The runner, the
six gate prompts and the linter live in the
[own-the-machine-tools](https://github.com/ownthemachine/own-the-machine-tools)
repository (MIT)**: machinery there, so this repository stays the civic
artefact: the law, its evidence, its governance and the ledger of its own
evolution. Review OUTPUTS are committed here under pipeline/reviews/,
because a verdict on a statute is part of the statute's history.

| # | Gate | Catches | Suggested model tier |
|---|---|---|---|
| 1 | Legal form | Joint Practical Guide violations, powers architecture, DMA threshold pattern, memorandum skeleton | fast |
| 2 | DC compliance | violations of the 30-row constraints table | fast |
| 3 | Legal basis and rights | Art. 114/173 reasoning, subsidiarity, proportionality, Charter Art. 17, Art. 345 | strongest available |
| 4 | Hostile counsel | how a litigator for covered undertakings, or the Legal Service, kills the text | strongest available |
| 5 | Acquis coherence | collisions with company law, Prospectus, IORP II, PEPP, DMA definitions | strong |
| 6 | Layer fidelity | drift between the articles, the memorandum and the plain-language layer | fast |

Before any gate: the linter from the tools repo (mechanical checks; free; no
excuse to skip).

## Which gates when

- Editorial changes: lint only.
- Prose changes: lint + gates 1 and 6.
- Substantive changes: lint + all six.
- Constitutional changes: all six plus the 14-day public issue
  (GOVERNANCE.md).

## Review file convention, and what the public actually sees

Review files live at pipeline/reviews/YYYY-MM-DD-<gate>-<slug>.md and open
with front matter the site can render:

    gate: hostile-counsel
    target: regulation/articles/03-designation.md
    commit: <sha>
    verdict: REVISE
    disposition: merged-with-fixes | declined (reason) | pending
    date: 2026-09-04

The campaign site renders a public ledger of the law's evolution from these
files and from release notes: what changed, what prompted it, what review
found, how the editor disposed of it, with a diff link. That ledger, not
this tooling, is the public story. The prompts and runner stay inspectable
here, because the repo is open and hiding machinery reads worse than owning
it, but the product is a law that shows its work, not a showcase of the
workshop.

## Status

All six gates are operational. DRAFTING-RULES.md was completed from the
legislative-drafting research on 18 August (source record with all URLs:
research-drafting-2026-08-18.md); the legal-form gate now enforces the Joint
Practical Guide, the DMA Article 3 threshold pattern, the BRRD property
architecture and the Commission's memorandum skeleton.


# FULL SOURCE: own-the-machine/pipeline/DRAFTING-RULES.md

# Drafting rules

Distilled 18 August 2026 from the legislative-drafting research
(pipeline/research-drafting-2026-08-18.md carries the full findings and
sources). These rules are operative: the legal-form gate enforces them, and a
draft violating them is not "stylistically imperfect", it is the first
dismissal the institutions will reach for.

## The three acts on the desk

1. **DMA, Regulation (EU) 2022/1925**, Articles 2, 3, 4, 17, 49, 53 and the
   Annex: the complete threshold, presumption, notification, designation,
   rebuttal and review machine. Our micro-giant designation chapter follows
   it almost line for line.
2. **BRRD, Directive 2014/59/EU**, recitals 13, 49-51, 88, 120-124, 130-131;
   Articles 34, 36, 47, 59-62, 73-75, 85: the only judicially validated
   architecture for diluting or extinguishing equity by act of law (Kotnik
   C-526/14, Ledra C-8/15 P, Dowling C-41/15, Aeris Invest C-535/22 P). Our
   property-rights chapter.
3. **AI Act package**, COM(2021) 206 plus Regulation (EU) 2024/1689 Articles
   51-52 and 97: the current-generation explanatory memorandum to copy
   structurally, and a second example of presumption thresholds kept
   technology-proof by delegated act.

Do NOT cite Regulation 2022/1854 (the solidarity contribution) as validated
precedent: its characterisation defence is untested (T-802/22 outcome not
final) and its emergency logic is unavailable to a permanent instrument. Use
its surplus-only base design and review clauses as drafting aids only.

## Structure (Joint Practical Guide, 2nd ed. 2015)

- Title, citations, recitals, enacting terms, annexes. Enacting-terms order:
  subject matter and scope; definitions; rights and obligations; powers;
  procedure; transitional and final provisions. Articles numbered
  continuously across chapters.
- One idea per sentence. Ambiguity papering over disagreement gets read
  restrictively by the Court (C-6/98 ARD).
- A Regulation applies directly: draft obligations on the addressee ("Every
  covered undertaking shall...") never "Member States shall ensure", except
  where a duty is genuinely the Member State's.
- Enacting terms command in the present indicative "shall". Recitals reason
  with "should" and contain zero normative content (JPG G10; C-162/97
  Nilsson: recitals cannot derogate from articles). Nothing normative may
  live only in a recital; every obligation needs a motivating recital, in
  the order of the provisions.
- All definitions in Article 2, none containing an obligation, every defined
  term used with exactly one meaning and no synonyms.
- Cross-references minimal, precise, intelligible without lookup. Annexes
  technical only: no new right or obligation may live in an annex.
- Mandatory reasoning (Art 296 TFEU) for derogations, exceptions,
  retroactivity and provisions prejudicial to particular interests; the JPG's
  model subsidiarity recital has gaps that MUST be filled case by case:
  unfilled boilerplate is itself a recognised defect.

## Powers architecture (Arts 290/291 TFEU)

- Essential elements stay in the articles, reviewably (C-355/10): for us the
  warrant trigger, the reserve's ownership structure, the dividend
  entitlement and the interference with shareholders are essential and may
  never be delegated.
- Delegated acts supplement or amend non-essential elements (threshold
  methodology, annex counting rules); implementing acts make individual
  designation decisions and templates (C-427/12; Reg 182/2011 comitology).
- Use the standard six-paragraph "Exercise of the delegation" article
  (CSDR Art 67 pattern) and the standard delegated-acts and comitology
  recitals with the 2016 IIA expert-consultation language.

## Thresholds (the DMA Article 3 model, followed exactly)

Cumulative qualitative test in paragraph 1; quantitative rebuttable
presumption in paragraph 2 with each metric mapped to one qualitative limb in
the recitals; self-notification within a deadline; designation decision
within a deadline; rebuttal only by "sufficiently substantiated arguments"
that "manifestly put into question" the presumption, with market-definition
economics excluded; below-threshold designation via market investigation;
review of designations at least every three years. Numbers in the article,
counting methodology in an annex, adjustment by tightly conditioned
delegated act.

## Property rights (the BRRD formula, adapted)

- An honest interference recital naming Charter Article 17 (BRRD recital 13
  model) plus a full Article 52(1) proportionality recital (recital 49
  model) plus the standard Charter recital naming Articles 17, 16, 47 and 34
  (recital 130 model).
- A quantified no-worse-off safeguard with independent valuation,
  compensation mechanism and separately challengeable valuation (BRRD Arts
  36, 73-75; upheld in Aeris Invest). ADAPTATION REQUIRED: BRRD's
  counterfactual is insolvency; ours must be market-consistent (no
  shareholder worse off than under an equivalent market-terms issuance),
  because a permanent regime cannot lean on crisis reasoning (Dowling's
  limit).
- Express, clearly and narrowly defined derogations from Directive (EU)
  2017/1132 pre-emption and capital-increase rules and from SRD 2007/36
  (BRRD recitals 120-124 formula). Silent conflict with company law reads as
  amateurism.
- A judicial-review article (BRRD Art 85; Charter Art 47).

## Interfaces the articles must write explicitly

Prospectus exemption (Reg 2017/1129: the warrant is a transferable
security); the reserve is not an AIF (AIFMD 2011/61); CRR own-funds
interaction; IORP II and PEPP interface preserving Member State social
competence; an EDPS recital for pension-rail data processing (Art 42(1) Reg
2018/1725); distinguish the golden-shares case law under Art 345 TFEU.

## The explanatory memorandum

Reproduce the Commission's five-section skeleton exactly, numbering
included (verified against COM(2021) 206): 1 context; 2 legal basis,
subsidiarity, proportionality, choice of instrument; 3 evaluations,
consultations, impact assessment, with a fundamental-rights subsection;
4 budgetary implications; 5 other elements including article-by-article
explanation. Annex a completed subsidiarity grid (COM(2018) 703). Our
evidence base substitutes for the impact assessment and must be presented
as such; Parliament uses EPRS added-value assessments for this and an ECI
has no equivalent, so the memorandum does that work itself.

## Monitoring and review

A monitoring article that generates the data, then: "By [date], and every
three years thereafter, the Commission shall evaluate this Regulation and
report to the European Parliament, the Council and the European Economic and
Social Committee", closing with measures "which may include legislative
proposals" (DMA Art 53 pattern). Pair with the falsification condition
(DC-18), which is our addition to the genre.

## The characterisation ladder

The single highest-stakes drafting decision: Art 114 (internal market,
centre of gravity per C-376/98 Tobacco Advertising: disparities alone are
not enough, the measure must genuinely improve the internal market's
functioning), falling back Art 115 (unanimity), Art 352 (unanimity plus
consent), with fatal drift being Art 311 own resources. Registration is NOT
where this fight happens: the test there is "manifestly outside" the
Commission's powers (Reg 2019/788 Art 6(3)(c)), partial registration is
judicially established (C-899/19 P), and the EU wealth-tax ECI was
registered in 2023. The characterisation fight comes in Council. Draft every
ask severable, each with its own defensible basis.

## The strategic rule

No outsider text has ever been enacted as written. Draft so the mechanics
(thresholds, designation, no-worse-off safeguard, review cycle) survive
transplantation into a Commission-rewritten shell. Form buys the hearing;
severability buys survival; the mechanics are the legacy.


# FULL SOURCE: own-the-machine/regulation/STRUCTURE.md

# Provisional structure of the Regulation

Working title: Regulation of the European Parliament and of the Council on
harmonised rules for citizen participation in automated productivity gains
(Citizens' Capital Regulation).

Legal bases: Article 114 TFEU, with Article 352 TFEU as the fallback where
Article 114 does not comfortably reach. Severable layers per DC-6.

| Ch | Articles | Content | Status |
|---|---|---|---|
| I | 1-2 | Subject matter, scope, definitions | drafted |
| II | 3-4 | Designation of covered undertakings; market investigation and review | drafted |
| III | 5-7 | The citizens' capital warrant; independent valuation; safeguards | drafted |
| IV | 8-9 | The European Citizens' Capital Reserve; prohibited holdings and conduct | drafted |
| V | 10-11 | The citizens' entitlement; national vehicles | drafted |
| VI | 12 | Protection of the Reserve and of entitlements | drafted |
| VII | 13-16 | Penalties; monitoring and evaluation; delegation; committee procedure | drafted |
| VIII | 17-18 | Transitional and final provisions | drafted |

Citations and recitals: drafted, see regulation/recitals.md (citations
added 6 September 2026, closing the legal-form finding of 19 August). DC-26,
the explicit scope-and-limits recital, is outstanding and not yet drafted.

Annex I: methodology for counting turnover, fair market value and full-time
equivalents (referenced by Article 3; technical only per JPG G22). Drafted,
regulation/annexes/annex-1-counting.md.

Annex II: methodology for the capital-preservation retention (referenced by
Article 8(4); technical only). Drafted,
regulation/annexes/annex-2-retention.md.

The four tests map: in time = Chapter II; assets not flows = Chapter III;
universal = Chapter V; raid-proof = Chapter VI. Each drafted article carries
non-normative drafting notes after a separator; the notes never enter the
legal text.

## Accompanying documents

| Document | Content | Status |
|---|---|---|
| memorandum/explanatory-memorandum.md | The five-section explanatory memorandum in the Commission's own structure: context; legal basis, subsidiarity and proportionality; evaluations, consultations and impact assessment including the policy-options appraisal; budgetary implications; other elements | drafted |
| memorandum/counter-arguments.md | The objections, at full strength, with answers and the constraints table | drafted |
| memorandum/severability.md | How the instrument decomposes if a layer fails | drafted |
| evidence/ | The sourced, reproducible basis for every quantitative claim | drafted |


# FULL SOURCE: own-the-machine/regulation/annexes/annex-1-counting.md

# Annex I: Methodology for turnover, employment and value

## 1. Union turnover

Annual Union turnover comprises the amounts derived by the undertaking
during the financial year from the sale of products and the provision of
services to undertakings or consumers in the Union, after deduction of
sales rebates and of value added tax and other taxes directly related to
turnover. Turnover is attributed to the Union where the customer is
established or, in the case of consumers, resident in the Union.
Intra-group transactions are excluded. Where the undertaking
comprises linked enterprises, turnover is calculated on a
consolidated basis.

## 2. Turnover of the automated segment

The turnover attributable to the provision of the goods and services
referred to in point (a) of Article 3(1), used for the assessment of that
point and in any market investigation pursuant to Article 4, comprises the
worldwide turnover derived from that provision. Where such goods or services
are sold together with other goods or services for a single consideration,
the consideration is attributed between them on a consistent and documented
basis reflecting their relative stand-alone value.

## 3. Compensation of labour

The annual worldwide compensation of labour of an undertaking comprises
all compensation of employees within the meaning of the European system
of accounts, including social contributions payable by the employer and
share-based compensation measured at grant value, as recorded in accounts
audited in accordance with the law applicable to the undertaking,
calculated on a consolidated basis for the group of linked enterprises,
and averaged over the last two financial years.

Compensation paid under arrangements whose main purpose or effect is to
raise the undertaking's compensation of labour without a corresponding
supply of labour to the undertaking shall be disregarded. Article 3(8)
applies.

## 4. Fair market value

Fair market value is determined by reference to the most recent of
the following, adjusted for capital raised or returned since:
(a) the price per share paid in the most recent transaction in which
shares representing at least 2 % of the capital were issued or
transferred for consideration to persons independent of the undertaking,
applied to the fully diluted capital;
(b) an independent valuation prepared in accordance with internationally
accepted valuation standards within the preceding 12 months;
(c) where shares of the undertaking are admitted to trading, the average
market capitalisation over the preceding six months.

## 5. Information accompanying a notification

A notification pursuant to Article 3(3) contains:
(a) the identity of the undertaking and of all linked enterprises;
(b) the calculations referred to in points 1 to 4, with the data and
attribution bases used;
(c) the audited financial statements for the last two financial years;
(d) a description of the goods and services referred to in point (a) of
Article 3(1) which the undertaking provides, and of the automated
cognitive systems on which their provision depends;
(e) the law governing the undertaking and, where that law is the law of a
third country, the measures by which the undertaking intends to give
effect to Article 5.

---

Drafting notes (non-normative). Point 3 measures labour by audited
compensation of employees rather than by headcount, after the 22 August 2026
reviews: a headcount is unpublished and cheaply padded, where payroll is a
single audited line, and under a compensation denominator the contracting-
out of labour raises the ratio towards designation, so the only route down
is direct employment. The anti-avoidance rule for payroll and valuation
gaming lives in Article 3(8) after the form gate found an autonomous command
in an annex (JPG 22). Annex language is descriptive throughout for the same
reason; the obligations flow from the articles that reference it. Point 3 is
drafted so that Article 2(8) can cite it for compensation of labour. Point 2
no longer feeds a quantitative threshold; it serves the qualitative
assessment under Article 3(1)(a) and market investigations, and the
information duty in point 5(b) keeps the segment figures available to the
Commission for that purpose. Point 4 mirrors the practice of growth-equity
valuation without legislating a model. The 2 % floor in point 4(a) excludes
token transfers priced for other reasons.

# FULL SOURCE: own-the-machine/regulation/annexes/annex-2-retention.md

# Annex II: Methodology for the retention preserving real capital

## 1. Retention

The amount to be retained pursuant to Article 8(4) in respect of a
financial year is the amount necessary so that the capital of the
Reserve at the end of that year, measured at fair value, is not lower in
real terms than its capital at the end of the preceding financial year,
after account is taken of:
(a) inflation, measured by the harmonised index of consumer prices for
the Union published by the Commission (Eurostat);
(b) unrealised changes in the fair value of the Reserve's holdings, to
the extent recognised under point 3.

## 2. Distributable amount

The distributable amount for a financial year is the realised
income of the Reserve for that year, comprising dividends, interest,
proceeds of disposals in excess of carrying value and other realised
returns, less the retention under point 1 and less the administrative
costs of the Reserve. Where the retention under point 1 equals or exceeds
realised income, the distributable amount is zero; the shortfall
is carried forward and retained from the realised income of
subsequent years before any distribution.

## 3. Smoothing

For the purposes of point 1, changes in fair value are recognised
evenly over five financial years from the year in which they arise. The
distributable amount for a financial year does not exceed the greater
of:
(a) 125 % of the average of the distributable amounts for the three
preceding financial years; and
(b) 2 % of the capital of the Reserve at the end of that year.

## 4. Cost of executing a payment

The average cost of executing one payment to a holder, for the purposes of
Article 10(6), is the total of the charges levied by national vehicles and
by payment service providers for executing the most recent distribution,
divided by the number of holders paid. Where no distribution has yet been
made, it is the average of the charges quoted to the Reserve by national
vehicles for executing one payment.

## 5. Exclusions

For the purposes of point 2, realised income excludes amounts obtained by
borrowing and the proceeds of disposals of holdings effected for the
purpose of funding a distribution.

---

Drafting note (non-normative). Point 4 was added on 21 August 2026 against
the objection that early distributions would be too small to be worth
transferring, and rewritten the same day. Two figures were rejected. A
floor of EUR 50, as proposed in review, would suppress every distribution
until roughly the fiftieth year on this instrument's own central
assumptions: that is a policy of deferral wearing the costume of an
efficiency measure. A floor of EUR 2 was drafted and then withdrawn
because hostile counsel wrote the headline it hands over, and because a
figure in an annex ages while the cost it stands for moves. What remains
is a ratio: ten times what it costs to make the payment. It is
self-adjusting, it states the actual reason, and there is no number in it
for anyone to quote.

---

Drafting notes (non-normative). This is the Norway spending rule made
operative: real capital is preserved first, only realised income above
preservation is distributed, and point 3's five-year smoothing plus the
125 % collar prevents both a bumper-year blowout and a political demand to
liquidate holdings for a headline payment; the outright prohibition on
funding distributions by borrowing or forced disposal moved to
Article 8(4) after the form gate found an autonomous command in an annex
(JPG 22), and point 4 keeps the arithmetic aligned with it. The
capital-fraction floor in point 3(b) was added on 19 August 2026 after
the public simulator, implementing this Annex exactly as drafted,
exposed a crumb-trap: a collar measured only against a trailing average
that starts near zero suppresses distributions for over a decade even
as capital accumulates. The floor lets distributions scale with the
Reserve while the collar still smooths spikes; realised income remains
the binding ceiling under point 2.
Point 2's carry-forward makes bad years honest instead of deferred. The
methodology enforces DC-14 at the level of arithmetic: early distributions
are small because early realised income is small, and no clause here can
be operated to promise otherwise.


# FULL SOURCE: own-the-machine/regulation/articles/01-subject-matter.md

# Article 1: Subject matter and scope

1. This Regulation lays down harmonised rules ensuring the participation of
citizens of the Union in the capital value created by hyper-automated
undertakings operating in the internal market.

2. The participation referred to in paragraph 1 shall be of such scale
that, on the designations made under Article 3 and the methodology laid
down in Annex II, the aggregate value of the holdings attributable to each
citizen's entitlement is capable of reaching, within one generation of the
first designations and in constant prices, an amount of the order of six
months of the median equivalised disposable income in the Union as
published by the Commission (Eurostat). Distributions under Article 10
remain the property income of the holders and are governed solely by
Article 8 and Annex II. The Commission shall assess progress against this
objective in each report under Article 14(2), and where the assessment
shows the objective to be manifestly unattainable or manifestly exceeded,
the report shall be accompanied, where appropriate, by a proposal to amend
the percentage laid down in Article 5(2) or the thresholds laid down in
Article 3(2).

3. To that end, this Regulation establishes:
(a) criteria and a procedure for the designation of covered undertakings;
(b) an obligation on covered undertakings to issue citizens' capital
warrants to the European Citizens' Capital Reserve;
(c) the European Citizens' Capital Reserve and the rules governing its
holdings and conduct;
(d) an individual entitlement of citizens of the Union to distributions from
the Reserve, administered through national vehicles;
(e) rules protecting the Reserve and individual entitlements.

4. This Regulation applies to undertakings offering goods or services in the
internal market, irrespective of their place of establishment.

5. This Regulation is without prejudice to Directive (EU) 2016/2341 and to
Regulation (EU) 2019/1238, save as expressly provided in Article 11.

---

Drafting notes (non-normative). Paragraph 3 is the market-access nexus
(DC-10), the DMA and GDPR pattern. Paragraph 4 pre-answers the pension
acquis interface (research checklist item 19). One idea per sentence
throughout per JPG G1.


# FULL SOURCE: own-the-machine/regulation/articles/02-definitions.md

# Article 2: Definitions

For the purposes of this Regulation, the following definitions apply:

(1) 'undertaking' means an entity engaged in an economic activity,
regardless of its legal status and the way in which it is financed,
including all linked enterprises within the meaning of Article 3(3) of the
Annex to Recommendation 2003/361/EC;

(2) 'covered undertaking' means an undertaking designated pursuant to
Article 3;

(3) 'automated cognitive services' means services whose provision depends to
a significant extent on software systems, including artificial intelligence
systems within the meaning of Article 3(1) of Regulation (EU) 2024/1689,
performing tasks that would otherwise require human cognitive labour;

(4) 'citizens' capital warrant' means a financial instrument issued
pursuant to Article 5 which confers the right to subscribe for shares in a
covered undertaking;

(5) 'Reserve' means the European Citizens' Capital Reserve established by
Article 8;

(6) 'liquidity event' means any of the following:
(a) the admission of shares of the covered undertaking to trading on a
regulated market or multilateral trading facility, in the Union or in a
third country;
(b) a change of control of the covered undertaking;
(c) one or more transactions within any period of 12 months by which shares
representing at least 20 % of the capital of the covered undertaking are
transferred for consideration;

(7) 'change of control' means the acquisition, directly or indirectly, of
decisive influence over the covered undertaking within the meaning of
Article 3(2) of Regulation (EC) No 139/2004;

(8) 'compensation of labour' means the annual worldwide compensation of
employees of an undertaking, calculated in accordance with point 3 of
Annex I;

(9) 'fair market value' means the value determined in accordance with
Annex I on the basis of the most recent funding transaction, independent
valuation or observable market price, whichever is most recent;

(10) 'holder' means a natural person in whom an entitlement is vested
pursuant to Article 10;

(11) 'national vehicle' means the body or arrangement designated by a
Member State pursuant to Article 11 to administer entitlements;

(12) 'distribution' means a payment made from the Reserve to holders
pursuant to Article 10;

(13) 'shareholder extraction' means, in respect of a covered undertaking
and a period, the aggregate value transferred by it to its shareholders, to
undertakings within the same group, to persons controlling it and to persons
connected with any of them, a person being connected where the same natural
persons hold, directly or indirectly, the majority of the economic rights in
both, comprising:
(a) dividends and other distributions, consideration paid for the
repurchase or redemption of its own shares, and reductions of capital paid
out;
(b) repayments of principal on debt owed to any such person, and loans made
to and claims acquired on any such person to the extent not repaid or
realised within twelve months;
(c) interest on such debt, and payments for the use of intellectual
property, for management and for other services rendered by any such
person, in each case to the extent that the payment exceeds what would
have been agreed between independent undertakings;

(14) 'automated assets' means the software systems referred to in point (3),
the model parameters, training and inference infrastructure, data sets and
intellectual property rights on which the provision of the goods or services
referred to in Article 3(1)(a) principally depends.

---

Drafting notes (non-normative). Definitions carry no obligations (JPG G14).
Point (3) ties to the AI Act definition rather than inventing one
(acquis-coherence). Point (6)(c)'s 20 % secondary-sale trigger prevents
crystallisation avoidance by staged private sales. Point (8) implements
DC-11 substance-over-form headcount. Points (13) and (14) serve Article 5's second and third crystallisation
triggers and the succession rule: an undertaking that never sells itself
can still pay itself, and the assets that carry the value are nameable.
Point (13)(b) exists because hostile counsel, given the first draft,
answered that it would simply stop paying dividends and take the cash out
as royalties, management fees and intercompany interest instead. The test is therefore value transferred above arm's length, whatever the
payment is called; the arm's-length standard is the one transfer pricing
already uses, so the evidence is the evidence a tax authority would ask
for. Point (b) stands apart from that standard because counsel's second
answer was to lend the money in and take it out again as principal, which
is arm's length in every particular and drains the undertaking all the
same. Repayment to an insider is therefore extraction outright. Counsel's next
answer was to reverse the direction, lending the undertaking's own cash
upstream to the parent and never calling it back, so point (b) covers
lending out as well as paying back: cash that leaves for a related pocket
and stays there for a year is cash that left, whichever way the promissory
note points. This is the numerator for Article 5(3)(a): shareholder
extraction, as defined here, is measured against covered turnover alone.
A paid-in-capital limb was deleted from Article 5(3)(a) after outside
money proved able to inflate it (see the drafting notes to Article 5),
so what money is put in by outsiders no longer matters to the threshold;
only what insiders take out does. 'Fair market value' is needed for
Article 3 designation, not for warrant pricing, which is event-priced.


# FULL SOURCE: own-the-machine/regulation/articles/03-designation.md

# Article 3: Designation of covered undertakings

1. An undertaking shall be designated as a covered undertaking where:
(a) it provides automated cognitive services, or goods or services whose
production depends to a significant extent on automated cognitive systems,
in the internal market;
(b) the economic output of the undertaking is substantially decoupled from
its employment of labour; and
(c) the position referred to in points (a) and (b) is durable.

2. An undertaking shall be presumed to satisfy: (a) point (a) of paragraph
   1, where it achieves an annual Union turnover equal to or above EUR 7,5
   billion, or where its fair market value amounts to at least EUR 75
   billion, and it provides the goods or services referred to in that point
   in at least three Member States; (b) point (b) of paragraph 1, where its
   fair market value equals or exceeds eighty times its annual worldwide
   compensation of labour, each calculated in accordance with Annex I; (c)
   point (c) of paragraph 1, where the thresholds in points (a) and (b) of
   this paragraph were met in each of the last two financial years.

3. Where an undertaking meets all the thresholds laid down in paragraph 2,
it shall notify the Commission thereof within two months after those
thresholds are met, providing the information listed in Annex I. A failure
to notify shall not prevent designation on the basis of the facts
available to the Commission.

4. The Commission shall, without undue delay and at the latest 45 working
days after receiving the complete information referred to in paragraph 3,
designate by decision the undertaking as a covered undertaking.

5. The undertaking may, with its notification, present sufficiently
substantiated arguments demonstrating that, exceptionally, although it
meets all the thresholds in paragraph 2, it does not satisfy the
requirements of paragraph 1. Those arguments shall be taken into account
only where they manifestly call the presumption into question; arguments
based on the definition of the relevant market shall not be taken into
account. Where such arguments require detailed assessment, the Commission
may open a market investigation pursuant to Article 4(1) instead of
designating within the period laid down in paragraph 4.

6. The Commission may designate as a covered undertaking any undertaking
that satisfies the requirements of paragraph 1 without meeting the
thresholds of paragraph 2, following a market investigation conducted
pursuant to Article 4.

7. The obligations laid down in this Regulation shall apply to a covered
undertaking irrespective of whether its shares are admitted to trading, and
designation shall precede any liquidity event wherever the thresholds of
paragraph 2 are met before that event.

8. An undertaking shall not segment, divide, combine or restructure its
   activities, or acquire or dispose of undertakings, where the main purpose
   or one of the main effects thereof is to avoid meeting the thresholds
   laid down in paragraph 2. The Commission shall disregard any such
   arrangement when applying this Regulation, and shall likewise disregard
   any transaction, arrangement or attribution the main purpose or one of
   the main effects of which is to increase the compensation of labour, or
   to reduce the fair market value, referred to in point (b) of paragraph 2.

9. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex I where necessary to
reflect technological and market developments. Those delegated acts shall
not amend the thresholds laid down in paragraph 2.

---

Drafting notes (non-normative). Architecture is DMA Article 3, deliberately:
cumulative qualitative limbs (paragraph 1), mapped quantitative presumption
(paragraph 2), self-notification with facts-available fallback (3),
deadline-bound designation (4), cabined rebuttal excluding market-definition
economics (5), below-threshold route (6). Paragraph 7 is the in-time test as
an operative rule. Paragraph 8 keeps thresholds in the article per DC-30 and
C-355/10: only the counting methodology is delegable. EUR 7,5 and 75 billion
mirror magnitudes the Union legislature has already accepted as marking
gateway scale. Numbers use the EU decimal comma. Satisfies DC-2, DC-10,
DC-11, DC-30.

Paragraph 2(b) history, which matters. The first design used turnover per
full-time equivalent on the automated segment; research of 22 August 2026
(evidence/designation-count.md) showed it designated two undertakings,
missed every integrated incumbent by factors of two to fourteen, turned on
an unpublished self-computed headcount, and inverted the anti-avoidance
incentive. The replacement, fair market value against audited compensation
of labour at a fixed ratio of eighty, computes from two audited figures and
makes direct employment the only route down. It is group-consolidated,
which reopens on paper the acquisition-dilution escape (buy payroll to
dilute the ratio) that the original segment basis was chosen to close.
The route is closed differently now, by three provisions in conjunction:
paragraph 8's disregard power is effects-based ("one of the main
effects"), so it reaches an acquisition whose commercial logic is genuine
but whose main effect is staying under the ratio, which purpose-based
abuse doctrine (Halifax, Cadbury Schweppes) would not; Article 4(3)
repeals a designation only for failure of the QUALITATIVE criteria of
paragraph 1 over two years, never for the presumption ratio alone, and
refuses repeal where the failure results from a paragraph 8 arrangement;
and paragraph 6 designates on the facts below the presumption. Open
points for the editor: the two-year durability window (DMA uses three);
whether fair market value alone suffices for point (a) given pre-revenue
frontier undertakings; and whether a segment limb should return as a
second presumption if pre-designation dilution is observed in practice.


# FULL SOURCE: own-the-machine/regulation/articles/04-review-of-designation.md

# Article 4: Market investigation and review of designation

1. The Commission may conduct a market investigation for the purpose of
Article 3(6). It shall conclude the investigation within 12 months by a
decision designating the undertaking or closing the investigation.

2. The Commission shall review each designation at least every three years,
and whenever the covered undertaking so requests on the basis of a
substantial change in the facts on which the designation was based.

3. The Commission shall repeal a designation where the covered undertaking
has not satisfied the requirements of Article 3(1) for two consecutive
financial years. Repeal shall not be granted where the failure to satisfy
those requirements results from an arrangement referred to in Article 3(8). Repeal shall not affect a citizens' capital warrant
already issued, save that a warrant shall lapse five years after repeal if
it has not crystallised by that date.

4. Before adopting a decision under this Article or under Article 3, the
Commission shall communicate its preliminary findings to the undertaking
concerned and give it the opportunity to be heard within a period of not
less than 20 working days.

---

Drafting notes (non-normative). Paragraph 2 mirrors DMA Article 4. Paragraph
3's lapse rule prevents a repealed designation from carrying a perpetual
contingent claim, which proportionality review would punish; five years
balances avoidance (de-designate, then list) against indefiniteness. The
right to be heard in paragraph 4 answers a due-process line of attack before
it is made. Hostile counsel round 2 built a permanent-immunity chain through this
Article (designate, dilute the ratio by acquisition, obtain repeal, wait out
the lapse, spin off and list). Three links are now cut: the acquisition is
an Article 3(8) arrangement and is disregarded across the Regulation, repeal
is unavailable where the change results from such an arrangement, and
Article 5(1) limits the one-warrant rule to the same designation, so
re-designation after a genuine repeal carries a fresh warrant.


# FULL SOURCE: own-the-machine/regulation/articles/05-warrant.md

# Article 5: The citizens' capital warrant

1. Within three months of its designation, a covered undertaking shall issue
to the Reserve a citizens' capital warrant. It shall not be required to
issue more than one such warrant in respect of the same designation.

2. The citizens' capital warrant shall entitle the Reserve, upon the first
liquidity event following issuance or upon crystallisation under paragraph
3, whichever occurs first, and upon no other occasion, to subscribe at
nominal value for newly issued shares representing 3 % of the fully diluted
capital of the covered undertaking determined immediately before that event
or, in the case of paragraph 3, immediately before the date of
crystallisation.

3. The citizens' capital warrant shall also crystallise, and shall be
exercisable on the same terms, where either of the following occurs before
a liquidity event:
(a) shareholder extraction by the covered undertaking in any period of
three consecutive financial years exceeds 25 % of its turnover from the
goods and services referred to in Article 3(1)(a) over the same period;
(b) seven years have elapsed since the issuance of the warrant.

Crystallisation under this paragraph shall take effect on the last day of
the financial year in which the condition is met, and the valuation under
Article 6 shall be performed as at that date.

4. The citizens' capital warrant shall:
(a) confer no voting rights, no rights of information beyond those provided
in this Regulation and no right to participate in the management of the
covered undertaking;
(b) entitle the Reserve to shares which rank, as regards dividends, other
distributions and the proceeds of any sale, liquidation or winding up,
equally with the class of shares ranking most favourably in those respects
among the classes created after the designation of the covered
undertaking, and otherwise equally with its ordinary shares, without
affecting the ranking of claims of creditors;
(c) be incapable of settlement in cash or in assets other than the shares
referred to in paragraph 2;
(d) be non-transferable, save to a successor of the Reserve established by
Union legislative act;
(e) impose no obligation on the covered undertaking prior to a liquidity
event other than the notification obligation in paragraph 6.

Shares subscribed pursuant to the citizens' capital warrant shall be
non-voting for as long as they are held by the Reserve.

5. The right to the subscription referred to in paragraph 2 shall vest by
operation of law at the completion of the liquidity event or on the date of
crystallisation under paragraph 3. The number of shares to be subscribed
shall be determined by the valuation under Article 6, and the subscription
shall be executed accordingly. Where the law
governing the covered undertaking does not give effect to the first
sentence, the covered undertaking shall take all measures necessary to
procure a subscription of equivalent effect no later than the completion of
the liquidity event or, in the case of crystallisation under paragraph 3,
no later than three months after the date of crystallisation. The dilution resulting from the subscription shall not
exceed the percentage laid down in paragraph 2. The covered undertaking shall execute the
subscription within 20 working days of the delivery of the valuation
referred to in Article 6, and the Reserve shall pay up the shares in full
in cash at their nominal value upon execution.

6. A covered undertaking shall notify the Reserve and the Commission of any
impending liquidity event no later than the earlier of its public
announcement and 30 working days before its completion.

7. Article 49, Article 68(1), (2) and (3), the first subparagraph of
Article 70(2), Article 72 and Article 73 of Directive (EU) 2017/1132, and
any
corresponding provisions of the law of a Member State conferring
pre-emption rights, requiring a decision of the general meeting or
requiring an expert report on consideration, shall not apply to the
issuance of the citizens' capital warrant or to the subscription of
shares pursuant to it. Provisions of the law of a Member State restricting the
proportion, issuance conditions or characteristics of non-voting shares
shall not apply to the extent that they would prevent the issuance or
holding of shares pursuant to this Article.

8. The issuance of the citizens' capital warrant and the issuance, offer
and subscription of shares pursuant to this Article shall not constitute an
offer of securities to the public for the purposes
of Regulation (EU) 2017/1129, and the admission to trading of those shares
shall be exempt from the obligation to publish a prospectus under that
Regulation where shares of the same class are already admitted to trading
on the same regulated market.

9. The valuation of the fully diluted capital for the purposes of paragraphs
2 and 3 shall be performed by an independent valuer appointed in accordance
with Article 6, and shall be open to challenge before the courts in
accordance with Article 7 separately from any other element of the
designation or the event.

10. An arrangement that subordinates, reduces or defeats the economic
participation conferred by this Article shall not be effective as against
the Reserve, which shall be placed in the position it would have occupied
had the arrangement not been made; the arrangement shall remain effective
between the parties to it and as against third parties. In particular, the
issuance of shares ranking ahead of those held or subscribable by the
Reserve, any alteration of the rights attaching to any class of shares, and
any reorganisation of capital shall be of no effect as against the Reserve
to the extent that its main purpose or one of its main effects is to place
the Reserve in a position less favourable than that provided for in
paragraph 4(b).

The first subparagraph shall not apply to an issuance of shares or other
instruments for new consideration in money or money's worth, at arm's
length, to persons who are not members of the same group as the covered
undertaking, do not control it, are not connected with it and are not acting
in concert with any person who controls it, where at the time of the
issuance the covered undertaking is in a likelihood of insolvency within the
meaning of Directive (EU) 2019/1023 or the issuance is necessary to comply
with a prudential requirement under Union law, and only to the extent of the
new consideration provided. To the extent that the preference, ranking or
other advantage conferred by the issuance exceeds the new consideration
provided, the first subparagraph applies to the excess. The covered
undertaking shall bear the burden of establishing that the conditions of
this subparagraph are met.

11. Where a covered undertaking transfers automated assets to another
undertaking, whether by sale, contribution, licence, demerger, division or
otherwise, where the transfer, alone or together with related arrangements,
confers in substance the economic benefit of the automated assets on the
transferee, and the transfer is not made at arm's length or the transferee is
a member of the same group or is controlled, directly or indirectly, by
persons who control the covered undertaking, the transferee shall issue to
the Reserve a citizens' capital warrant in accordance with paragraph 1 as if
it were a covered undertaking, and the obligations of the covered undertaking
under this Article shall continue in respect of the automated assets it
retains. The aggregate of the subscriptions to which the Reserve is entitled
in respect of the same designation, under this paragraph and under paragraph
2, shall not exceed the percentage laid down in paragraph 2 of the combined
fully diluted capital of the covered undertaking and of every transferee, and
the valuation under Article 6 shall determine the subscription in each of
them accordingly.

The obligations of a transferee under this paragraph arise irrespective of
whether the transferee meets the conditions laid down in Article 3, and this
paragraph applies to any onward transfer of the automated assets by a
transferee as it applies to a transfer by a covered undertaking. For the
purposes of the valuation under Article 6, the value of the fully diluted
capital of the transferee shall reflect the automated assets at the value
they would have had on a transfer at arm's length.

12. Where the automated assets of a covered undertaking are acquired by
another undertaking in or in consequence of insolvency proceedings, a
restructuring procedure, including a procedure under Directive (EU)
2019/1023, or any comparable procedure, and, upon completion, the
transferee is controlled directly or indirectly by persons who controlled
the covered undertaking, or those persons hold, directly or indirectly, the
majority of the economic rights in the transferee, the obligations under
this Article shall attach to
the transferee as if it were the covered undertaking, and the transferee
shall issue a citizens' capital warrant afresh within three months of the
completion of the acquisition.

For the purposes of this paragraph, persons acting in concert with those
who controlled the covered undertaking, and persons connected with them,
shall be treated as those persons; and where any of them acquires control
of the transferee, at any time while it holds the automated assets, the
obligations under this Article shall attach to the transferee from the date
of that acquisition.

This paragraph shall not otherwise apply where control of the transferee
is acquired by persons who did not control the covered undertaking, and in
that case the extinguishment of a warrant in such a procedure shall give
rise to no obligation under this Article.

---

Drafting notes (non-normative). The paragraph 7 enumeration was verified
against the consolidated Directive (CELEX 02017L1132-20220812, capital
chapter unamended since) on 19 August 2026 and mirrors Article 84(3) of
the Directive itself, the BRRD-inserted list of exactly the provisions
that block a by-operation-of-law issuance: Article 72(4) makes a general
meeting the only lawful route to disapply pre-emption, which is why the
whole of Article 72 is disapplied; the expert-report rule for increases
is the first subparagraph of Article 70(2), not Article 49 alone.
Articles 45, 46, 47, 69 and 71 need no derogation: subscription at
nominal is not below nominal, and paragraph 5 now provides full cash
payment on execution, satisfying Article 69 expressly. Article 85 equal
treatment is complied with, not derogated from: the dilution falls on
all shareholders pro rata. The capital chapter binds only the public
company forms in Annex I of the Directive (Article 44(1)); for private
forms the Member-State-law limb of paragraph 7 does the same work. The chapter is the assets-not-flows test as
law. Paragraph 4(c) is DC-4 and DC-9 verbatim: the obligation can never
collapse into a fee, which also carries the incidence answer (objection 4).
Dormancy until the event is DC-12; permanent non-voting is DC-13; operation
of law is DC-24. Paragraph 7 uses the BRRD recitals 120-124 formula of
express, narrow company-law derogation; silence there would be read as
amateurism (research checklist 18). Paragraph 8 writes the prospectus
exemption (checklist 19). Paragraph 9 carries DC-29's execution safeguard:
the interference is the stated 3 %, justified in the recitals under Article
52(1) of the Charter on the BRRD model; the safeguard guarantees the
percentage cannot be exceeded in execution and that valuation is independent
and separately justiciable (Aeris Invest pattern). 3 % is deliberately far
below employee-option pools and bail-in scales; proportionality lives partly
in that number. Paragraph 5's third sentence answers hostile counsel's
extraterritoriality attack: for undertakings governed by third-country law
the mechanism is an obligation of result enforced through Article 13
penalties as a condition of market access, the DMA pattern, rather than a
purported override of foreign company law; paragraph 7 accordingly reaches
Member State law only. The necessity limit formerly stated in paragraph 7
moves to the recital motivating it, per JPG G12. Paragraphs 3, 4(b) and 10 to 12 were added on 21 August 2026 against an
external structuring review, and rewritten the same day against hostile
counsel's answer to them. The extraction trigger no longer measures against
fair market value, because counsel undertook to place a fraction of a share
with a friendly fund at an invented valuation a week before the period
opened and so set the denominator out of reach; it now measures against
covered turnover and against capital actually paid in, neither of which can
be inflated without paying for it. Paragraph 4(b) equalises the Reserve
with the most favourable class of shares rather than raising it above every
class, and says expressly that it does not touch creditors, because a rule
that leapfrogged the creditor hierarchy would have been struck down and
would have deserved to be. Paragraph 10 renders a subordinating arrangement
ineffective against the Reserve alone rather than void against the world,
which is how anti-avoidance is done without unwinding third parties who had
nothing to do with it. Two further answers followed the same exchange.
Point 4(b) equalises the Reserve only with classes created after
designation, because a rule that placed it alongside a two-times
participating preference bought and paid for years earlier would take from
those investors the thing they paid for, which is the expropriation this
instrument spends objection 1 denying; against classes engineered after
designation it still bites, and that is where the abuse lives. The paid-in capital limb was deleted altogether at the next pass. It had
been narrowed to exclude money contributed by the group itself, and counsel
answered by having a friendly outside syndicate subscribe ten billion of
low-yield preferred, raising the threshold to ten billion and licensing the
founders to take out nine. A threshold with two limbs joined by "or" is
governed by whichever limb is easier to inflate, so what remains is the one
that cannot be: turnover from the covered activity, which no undertaking
raises without earning it. The seven-year long-stop stands behind it in any
event. For the same reason the reattachment in paragraph 12 lost its
three-year window, which counsel correctly read as a date to wait for. Counsel then took 49 % of
the votes and 90 % of the economics, which is not control, so both this
paragraph and the definition of extraction now follow the majority of the
economic rights as well as control: a person who takes the money is a person the rule is about, whoever holds
the votes. Paragraph 11 stopped attaching the obligation "in proportion to
the value transferred", which counsel rightly called inoperable against an
indivisible equity: the transferee now issues its own warrant over its own
capital and the transferor keeps its own, which needs no arithmetic and is
proportionate because three per cent of a small company is a small
thing; paragraph 11's second subparagraph was added
immediately afterwards, because hostile counsel demonstrated that the first
draft reattached the obligation to entities controlled by any pre-procedure
creditor and so expropriated the rescuers of a genuinely failing
undertaking. The rule now catches the survival of the same controllers,
which is the abuse, and leaves ordinary insolvency alone, which is not.

Three amendments of 25 August 2026, each closing a point the memorandum had
listed as open, each through three adversarial rounds. Paragraph 10's second
subparagraph answers the distressed-capital constraint objection 18 carried:
new money at arm's length from unconnected persons in likelihood of
insolvency ranks ahead, only to the extent of the new consideration, and the
excess of any preference over that consideration falls back under the first
subparagraph, so a ten-times preference on rescue money shields one times
the money and no more. Counsel's claim that a ranking is binary and cannot
have an excess is wrong on the instrument's own terms: preferences are
stated in multiples of an amount, and the carve-out never voids the excess
between the parties, it only keeps it off the Reserve's three per cent.
Paragraph 11 gained a substance gate after counsel showed an ordinary
internal software licence conscripting a subsidiary: the trigger now
requires that the transfer confer in substance the economic benefit of the
automated assets. The sub-threshold question is answered in the second
subparagraph: thresholds do not matter for a transferee, because the
trigger is the tainted transfer and not scale; the paragraph follows onward
transfers; and the valuation of the transferee's capital reflects the
assets at arm's-length value, so a shell cannot be cheap. Two blueprints
counsel priced highly fail on their own facts and are recorded here so the
next reader need not re-litigate them: the arm's-length split to an
unconnected vehicle leaves the full consideration inside the covered
undertaking, where the existing warrant sits on it, and the transferee's
future growth is new value formed outside, reachable by its own designation;
and the apportionment under the aggregate cap follows the Article 6
valuations of each entity, which is arithmetic on values, not an accounting
consolidation. Open points for the editor:
whether 3 % is the right rate (the simulator parameter), treatment of
undertakings already listed at designation (transitional provision in
Chapter VIII), anti-avoidance for pre-event asset-stripping (Article 6), and
the Article 13 penalty scale that makes the obligation of result credible
for third-country groups.


# FULL SOURCE: own-the-machine/regulation/articles/06-valuation.md

# Article 6: Independent valuation

1. The valuation referred to in Article 5(9) shall be performed by a valuer
who is independent of the covered undertaking, of the Reserve and of any
party to the liquidity event, appointed by the Commission from a list
established after an open call. The Commission shall establish the list and
the criteria and rotation governing appointments from it by means of
implementing acts, adopted in accordance with the examination procedure
referred to in Article 16(2). An individual appointment shall be made by
decision of the Commission in accordance with those criteria and that
rotation, and shall not require that procedure.

2. The valuation shall determine the fully diluted capital of the covered
undertaking immediately before the liquidity event or, in the case of
crystallisation under Article 5(3), immediately before the date of
crystallisation, in accordance with internationally accepted valuation
standards and, where an event itself establishes a price, on the basis of
that price.

3. The valuer shall deliver the valuation within 20 working days of the
completion of the liquidity event or of the date of crystallisation under
Article 5(3). The costs of the valuation shall be borne by the
covered undertaking.

4. Where a court finds, pursuant to Article 7, that the valuation
overstated the fully diluted capital, the Reserve shall transfer back to
the covered undertaking, or cancel, the shares subscribed in excess of the
percentage laid down in Article 5(2). Where a court finds that the
valuation understated it, the covered undertaking shall issue the missing
shares to the Reserve.

5. A challenge to the valuation shall not suspend the liquidity event, the
crystallisation or the subscription.

---

Drafting notes (non-normative). The BRRD pattern (Article 36) adapted:
independent valuer, event-price primacy, ex-post correction rather than
ex-ante blockage. Paragraph 4 makes DC-29 executable in both directions,
which is what converts the safeguard from assertion into machinery, per
Aeris Invest. Paragraph 5 protects transactions from hold-up litigation, the same policy
as resolution law. Round 2 moved delivery to after completion: where the
event itself establishes the price, the valuation is arithmetic on that
price, and demanding it before pricing invited deserved ridicule; legal
effect still attaches at completion under Article 5(5), with execution
following the valuation. The open point on the appointment mechanism was closed on 21 August 2026:
hostile counsel observed that an implementing act under Article 291 TFEU is
an act of general application, that using one for each individual
appointment is the wrong instrument, and that convening a committee for
each would break the 20-day deadline in Article 5(5). The list, the
criteria and the rotation are general and stay in the implementing act; the
appointment itself is administration and is made by decision.


# FULL SOURCE: own-the-machine/regulation/articles/07-safeguards.md

# Article 7: Safeguards and judicial review

1. A challenge to the valuation referred to in Article 6 may be brought,
separately from any challenge to the designation, to the liquidity event or
to the crystallisation under Article 5(3),
before the courts of the Member State in which the covered undertaking has
its registered office or, where it has none in the Union, before the Court
of Justice of the European Union.

2. The dilution borne by the shareholders of a covered undertaking in
consequence of this Regulation shall not exceed the percentage laid down in
Article 5(2), determined on the basis of the valuation under Article 6 as
corrected, where applicable, pursuant to Article 6(4). Where warrants have
been issued by transferees pursuant to Article 5(11), that percentage
applies to the dilution borne, taken together, by the shareholders of the
covered undertaking and of every such transferee.

3. This Regulation shall not affect any right of shareholders to
compensation under the law of a Member State against parties other than
the Reserve.

---

Drafting notes (non-normative). The former paragraph restating the Article
263 TFEU remedy was deleted on the form gate's finding that secondary law
must not paraphrase remedies conferred by primary law; standing before the
Court needs no help from us. Paragraph 2 states the quantified ceiling the
proportionality recital relies on: the interference is the stated
percentage, no more, judicially verifiable and correctable in both
directions under Article 6(4). Satisfies DC-29 with Article 6; holders'
remedies sit in Article 12(4).


# FULL SOURCE: own-the-machine/regulation/articles/08-reserve.md

# Article 8: The European Citizens' Capital Reserve

1. The European Citizens' Capital Reserve is established. The Reserve shall
have legal personality and shall enjoy in each Member State the most
extensive legal capacity accorded to legal persons under the law of that
Member State.

2. The Reserve shall hold its assets exclusively for the benefit of
holders. Its assets and income shall not constitute revenue of the Union or
of any Member State and shall not be entered in the general budget of the
Union or in any public budget.

3. The Reserve shall be financed exclusively by the instruments referred to
in Article 5, by the proceeds of their crystallisation and by the returns
on its assets. It shall receive no contribution from, and shall make no
payment to, the general budget of the Union or the budget of any Member
State.

4. The Reserve shall retain from its realised income in each financial year
the amount necessary to preserve the real value of its capital, calculated
in accordance with the methodology laid down in Annex II, and shall make
the remainder available for distribution pursuant to Article 10(6). No
distribution shall be financed by borrowing or by the disposal of holdings
effected for the purpose of the distribution.

5. The Reserve shall state in its accounts, for each financial year, the
amount of tax withheld at source which it was unable to recover, and the
Commission shall address that amount in the report referred to in Article
14(2).

6. The Reserve shall publish annually audited accounts, the valuation of
its holdings and the calculation referred to in paragraph 4.

7. The Reserve shall not be considered an investment firm within the
meaning of Directive 2014/65/EU, an alternative investment fund or an
alternative investment fund manager within the meaning of Directive
2011/61/EU, or an institution for occupational retirement provision within
the meaning of Directive (EU) 2016/2341.

8. The Commission is empowered to adopt delegated acts in accordance with
Article 15 to amend the methodology laid down in Annex II where necessary
to preserve the real value of the capital of the Reserve in the light of
market developments.

---

Drafting notes (non-normative). Drafted in response to hostile counsel's
lead attack, the fiscal characterisation of the warrant as a corporate tax.
Paragraphs 2 and 3 make the non-fiscal structure operative rather than
asserted: no value ever becomes public revenue, enters any budget or is
available to any treasury, in either direction. The closest legal cousins
are statutory funded pension schemes, whose compulsory contributions are not
taxes in Union law because they fund segregated property held for
beneficiaries. Sectoral classification under ESA belongs to statisticians
and is deliberately not legislated here. Paragraph 4 is the Norway spending
rule generalised (retain enough to preserve real capital, distribute the
rest), which also enforces DC-14: distributions grow with the portfolio and
start small. Governance, passivity at Reserve level and prohibited conduct
are Article 9, still reserved; the non-voting rule already binds via
Article 5(4). The retention methodology is Annex II, amendable
under the paragraph 8 empowerment via Article 15. Satisfies DC-4, DC-5, DC-14, DC-19 in part, DC-24.


Drafting note on paragraph 5 (non-normative). A first draft permitted the
Reserve to hold third-country assets through national vehicles where that
reduced taxation at source. It was struck on 21 August 2026 after hostile
counsel offered the headline: a Union fund with a statutory mandate to
arrange its affairs for a lower withholding rate, published by the Union
that blacklists other people for the same thing. An instrument whose case
is that capital should be broadly owned cannot codify treaty shopping for
itself. What remains is the duty to publish the tax it could not recover,
which is the part that lets anyone judge the cost.


# FULL SOURCE: own-the-machine/regulation/articles/09-prohibited-conduct.md

# Article 9: Prohibited holdings and conduct of the Reserve

1. The Reserve shall not:
(a) exercise, directly or indirectly, any voting right attached to any
share it holds;
(b) seek or accept representation in the administrative, management or
supervisory bodies of any undertaking;
(c) give instructions, formally or informally, to any undertaking in which
it holds an interest;
(d) acquire an interest in any undertaking otherwise than pursuant to
Article 5, by reinvestment of its income or by prudent diversification of
crystallised holdings;
(e) borrow, save for temporary liquidity purposes not exceeding 2 % of the
value of its assets and save for the payment of subscription amounts under
Article 5(5), which borrowing shall be repaid from the first realised
income of the Reserve;
(f) grant loans or guarantees;
(g) enter into derivative contracts, save for hedging currency risk on
assets it holds.

2. The Reserve shall manage its holdings with the sole objective of
long-term preservation and growth of value for the benefit of holders.

---

Drafting notes (non-normative). The statutory passivity of DC-13 at the
level of the institution, accepting the Bebchuk cost deliberately per
objection 6; the Greek overcorrection is avoided because passivity here
constrains conduct, not the citizens' claim. Points (e) to (g) close the
leverage and derivative channels that would let a future management
financialise the Reserve. Point (d) permits index-style diversification
after crystallisation, the Norwegian practice, without permitting empire
building.


# FULL SOURCE: own-the-machine/regulation/articles/10-entitlement.md

# Article 10: The citizens' entitlement

1. Every citizen of the Union who has attained the age of 18 years shall hold an
entitlement under this Regulation.

2. The entitlement shall arise by operation of law. It shall not be subject to
any condition relating to income, wealth, employment, contribution history
or any other personal circumstance, nor to any application, save
registration for payment purposes with a national vehicle.

3. All entitlements shall be equal. No act of the Union or of a Member State
shall differentiate between holders in the amount distributed per holder in
respect of the same period.

4. The entitlement shall comprise:
(a) the right to an equal share of every distribution declared by the
Reserve in respect of a period during which the holder was living and met
the condition in paragraph 1; and
(b) the right to have undistributed amounts standing to the holder's
account with a national vehicle treated as the holder's property, which
shall be inheritable in accordance with the law applicable to succession.

5. The entitlement referred to in paragraph 4(a) shall be personal to the holder.
It shall be incapable of assignment, pledge, attachment or seizure, and it
shall not be capable of surrender or redemption against payment.

6. The Reserve shall declare a distribution in each calendar year in which
the distributable amount would provide each holder with not less than ten
times the average cost of executing one payment to a holder, calculated in
accordance with Annex II, and in any event not less often than once in
every third calendar year in which the distributable amount is greater
than zero. An amount not distributed by reason of this paragraph
shall be retained, shall form part of the capital of the Reserve and shall
be distributed in the next distribution. Distributions shall be paid
through national vehicles into the individual account of each holder.

7. In each year in which no distribution is declared, the Reserve shall
publish the amount which would have been distributed per holder and the
value of the capital of the Reserve per holder.

---

Drafting notes (non-normative). Paragraphs 1 to 3 are the universality test
with no means test and no committee: acquisition by operation of law closes
every discretionary gate (DC-24). Paragraph 5 answers Estonia: there is no
exit to take, which is stronger than forfeiture, while paragraph 4(b)
preserves the Danish lesson that what has been distributed into a named
account is real, inheritable property (DC-22 as interpreted: the lifetime
unit is per-person and equal across a generation, so it is not heritable;
accrued amounts are). Paragraph 6 keeps DC-14 while answering the objection that paying a few
cents to 350 million accounts spends a disproportionate share of the
payment on making it: the interval lengthens, the money does not
disappear, and it compounds in the Reserve until it is paid. The
three-year backstop is what stops a de minimis from becoming a reason
never to pay; paragraph 7 is DC-31 applied to the years of silence, so
that a citizen who receives nothing is still told what is held for
them.
Open points for the editor, flagged deliberately: whether long-term
resident third-country nationals are included (political choice; Union
citizens only is the current draft), the age threshold, and whether a
minimum retention rule belongs here or in Article 8 (currently Article 8,
reserved).


# FULL SOURCE: own-the-machine/regulation/articles/11-national-vehicles.md

# Article 11: National vehicles

1. Each Member State shall designate, within 12 months of the entry into
force of this Regulation, one or more national vehicles to administer
entitlements. Existing institutions within the meaning of Directive (EU)
2016/2341, providers within the meaning of Regulation (EU) 2019/1238 and
statutory funds may be designated. By way of derogation from Article 7 of
Directive (EU) 2016/2341, an institution designated as a national vehicle
may carry out the account administration and distribution activities
provided for in this Regulation. A provider within the meaning of
Regulation (EU) 2019/1238 designated as a national vehicle shall maintain
holders' accounts separately from any product governed by that Regulation,
and the requirements of that Regulation shall not apply to those accounts.

2. A national vehicle shall:
(a) maintain an individual account in the name of each holder registered
with it;
(b) credit distributions to holders' accounts without deduction other than
charges permitted under paragraph 3;
(c) treat amounts standing to a holder's account as the holder's property
in accordance with Article 10(4)(b);
(d) apply no condition of access other than identity and the condition in
Article 10(1).

3. Charges levied by a national vehicle on holders shall not exceed the
costs actually incurred in administering the accounts and in any event
0,3 % annually of the amounts administered. A Member State may compensate a
national vehicle for verifiable net costs exceeding that ceiling; such
compensation shall not be charged to holders or to the Reserve.

4. Where a Member State has not designated a national vehicle, or where the
designated vehicle does not comply with paragraph 2, a holder residing in
that Member State may register with a national vehicle of another Member
State, which shall not refuse the registration on grounds of residence.
Where a national vehicle registers a holder pursuant to this paragraph, the
Member State of residence of that holder shall reimburse that national
vehicle for verifiable net costs exceeding the ceiling laid down in
paragraph 3.

5. National vehicles shall process personal data in accordance with
Regulation (EU) 2016/679 and only for the purposes of this Regulation.

---

Drafting notes (non-normative). DC-7 and DC-28 as law: Union standards,
national custody, existing rails expressly reusable. Paragraph 3 caps
administration charges because fee extraction is the quiet raid nobody
legislates against; 0,3 % tracks low-cost pension administration.
Paragraph 4 is the sabotage-by-inaction answer: a Member State that refuses
to build the rail cannot thereby disenfranchise its citizens, and
portability follows the PEPP logic. Paragraph 5 grounds the EDPS recital
required by the research checklist.


# FULL SOURCE: own-the-machine/regulation/articles/12-protection.md

# Article 12: Protection of the Reserve and of entitlements

1. The assets of the Reserve and the entitlements of holders shall not be
cancelled, written down, compulsorily redeemed, seized, transferred,
suspended, lent, encumbered or otherwise applied, in whole or in part, for
the benefit of the general budget of the Union, of any Member State or of
any public body, by any act of the Union or of a Member State.

2. The Reserve shall not acquire or hold, directly or indirectly, debt
instruments issued or guaranteed by the Union, by a Member State, by a
regional or local authority of a Member State, by a central bank or by any
body the obligations of which are guaranteed by any of them.

3. This Regulation shall not be interpreted as authorising any authority
of the Union or of a Member State to derogate from paragraphs 1 and 2.

4. Every holder, and every national vehicle acting for its holders, shall
have the right to an effective remedy before a court or tribunal against
any act or omission infringing this Article, in accordance with Article 47
of the Charter of Fundamental Rights of the European Union.

---

Drafting notes (non-normative). Drafted clause by clause against the actual
raid statutes. Paragraph 1's enumerated verbs track the Polish Act of 6
December 2013, Article 23(1), which cancelled units; cancellation is named
first. Paragraph 2 removes the self-dealing channel that made the Polish
raid worth executing, where Article 23(2) took the Treasury bonds first
(DC-19). Paragraph 3 is DC-21: Ireland's NPRF was raided lawfully through
its own emergency machinery, so this instrument has none. Paragraph 3
went through three drafts under the gates. Binding future legislatures
failed round 1; binding the Commission's right of initiative failed round 2
(Article 17 TEU institutional balance); what remains is the one thing an
ordinary Regulation can say, an interpretive rule, with the
assessment-of-holders duty relocated into the Commission's own reporting
under Article 14(4), which is ordinary review-clause territory. The former
Charter-possessions declaration was likewise deleted: secondary law cannot
define the scope of primary law, so that argument lives in the recitals and
the memorandum. Paragraph 4 remains the real lock: it converts the promise into
individual property, so that a future Polish-style statute meets Article 17
Charter litigation by millions of holders rather than a budget-line debate
(the exact channel Poland exploited was that OFE units were claims on the
state; these are not, per paragraph 2). Greece's HCAP is the overcorrection
this chapter avoids: protection is achieved without placing the asset
beyond citizens' reach. Satisfies DC-19, DC-21, DC-22, DC-23 and DC-20 as amended (a Regulation cannot prescribe voting thresholds for future legislatures, so the constraint now demands express amendment, a published independent assessment and honesty about the limits).


# FULL SOURCE: own-the-machine/regulation/articles/13-penalties.md

# Article 13: Penalties

1. The Commission may by decision impose on a covered undertaking fines not
exceeding 10 % of its total worldwide turnover in the preceding financial
year where it finds that the undertaking, intentionally or negligently:
(a) fails to issue the citizens' capital warrant in accordance with
Article 5(1);
(b) fails to take the measures required by the third sentence of
Article 5(5);
(c) fails to notify a liquidity event in accordance with Article 5(6);
(d) supplies incorrect, incomplete or misleading information under
Article 3(3) or Article 4;
(e) circumvents Article 3(8), or fails to comply with a decision adopted
pursuant to that paragraph.

2. The Commission may by decision impose periodic penalty payments not
exceeding 5 % of the average daily worldwide turnover of the covered
undertaking in the preceding financial year for each day of continued
non-compliance, in order to compel compliance with the obligations
referred to in paragraph 1.

3. Where a covered undertaking that is not established in the Union
persistently fails to comply with the obligations referred to in points
(a) and (b) of paragraph 1, the Commission may by decision, as a measure
of last resort and for no longer than the non-compliance persists,
prohibit the making available of the goods and services referred to in
point (a) of Article 3(1) on the internal market by that undertaking.

4. In fixing the amount of a fine or periodic penalty payment, the
Commission shall have regard to the gravity, duration and recurrence of
the infringement. Before adopting a decision under this Article, the
Commission shall give the undertaking the opportunity to be heard.

5. The Court of Justice of the European Union shall have unlimited
jurisdiction within the meaning of Article 261 TFEU to review decisions
under this Article and may cancel, reduce or increase the fine or periodic
penalty payment imposed.

6. Fines and periodic penalty payments imposed under this Article shall
accrue to the general budget of the Union. They shall not accrue to the
Reserve.

---

Drafting notes (non-normative). The scales are the DMA's, deliberately
familiar. Paragraph 3 is the market-access teeth that make the obligation
of result credible for third-country groups (hostile counsel, kill 2),
bounded as last resort and duration-limited for proportionality. Paragraph
6 matters more than it looks: penalty revenue flowing to the Reserve would
hand critics the fiscal characterisation on a plate and give the Reserve an
enforcement interest; sending fines to the general budget like every other
competition-family fine keeps the Reserve clean under Article 8(3), and the
carve-out is stated expressly so the two provisions cannot be read against
each other.


# FULL SOURCE: own-the-machine/regulation/articles/14-monitoring-review.md

# Article 14: Monitoring and evaluation

1. The Commission shall monitor, on the basis of data published by the
   European Central Bank, Eurostat and the national statistical institutes:
   (a) the diffusion of automated cognitive systems among undertakings in
   the Union; (b) the distribution of household holdings of equity
   instruments in the Union; (c) the share of value added accruing to labour
   and to capital in the sectors in which covered undertakings operate; (d)
   the number of designations, crystallisations and distributions under this
   Regulation and their amounts; (e) the evolution of the share of Union
   gross value added accruing to compensation of employees, as published by
   the Commission (Eurostat), relative to the year 2025, together with the
   Commission's assessment of the contribution of automated cognitive
   systems to any change in either direction.

2. By 31 December 2032, and every three years thereafter, the Commission
shall evaluate this Regulation and submit a report to the European
Parliament, the Council and the European Economic and Social Committee.

3. The report shall state, on the basis of the indicators in paragraph 1,
whether the premise of this Regulation that gains from automated cognitive
systems accrue disproportionately to the holders of the systems remains
supported by the evidence. Where the report finds that the share of
undertakings referred to in point (a) of paragraph 1 exceeds one quarter
and that neither the indicator in point (b) nor the indicator in point (c)
of that paragraph shows the concentration the premise predicts, the report
shall say so expressly and shall be accompanied, where appropriate, by a
proposal for the amendment or repeal of this Regulation.

4. Where a report under paragraph 2 accompanies or precedes a proposal for
the amendment of Article 5, Article 8, Article 10 or Article 12, it shall
include an independent assessment of the effect of the proposal on the
entitlements of holders.

5. The report shall be published.

---

Drafting notes (non-normative). Paragraph 3 is DC-18, the stated
falsification condition, as an operative reporting duty: the Regulation
instructs its own evaluator to declare its premise unsupported if the
evidence goes the other way, and to propose amendment or repeal. No
instrument in the acquis does this explicitly; it is the Stable's
publish-what-contradicts-us discipline written into law, and the
memorandum should present it as such. The indicators map to the evidence
base: ECB HFCS and DWA for (b), the sectoral accounts for (c).


# FULL SOURCE: own-the-machine/regulation/articles/15-delegation.md

# Article 15: Exercise of the delegation

1. The power to adopt delegated acts is conferred on the Commission subject
to the conditions laid down in this Article.

2. The power to adopt delegated acts referred to in Article 3(9) and
Article 8(8) shall be
conferred on the Commission for a period of five years from the entry into
force of this Regulation. The Commission shall draw up a report in respect
of the delegation of power not later than nine months before the end of
the five-year period. The delegation of power shall be tacitly extended
for periods of an identical duration, unless the European Parliament or
the Council opposes such extension not later than three months before the
end of each period.

3. The delegation of power referred to in Article 3(9) and Article 8(8)
may be revoked at
any time by the European Parliament or by the Council. A decision to
revoke shall put an end to the delegation of the power specified in that
decision. It shall take effect the day following the publication of the
decision in the Official Journal of the European Union or at a later date
specified therein. It shall not affect the validity of any delegated acts
already in force.

4. Before adopting a delegated act, the Commission shall consult experts
designated by each Member State in accordance with the principles laid
down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making.

5. As soon as it adopts a delegated act, the Commission shall notify it
simultaneously to the European Parliament and to the Council.

6. A delegated act adopted pursuant to Article 3(9) or Article 8(8) shall
enter into force
only if no objection has been expressed either by the European Parliament
or by the Council within a period of two months of notification of that
act to the European Parliament and the Council or if, before the expiry of
that period, the European Parliament and the Council have both informed
the Commission that they will not object. That period shall be extended by
two months at the initiative of the European Parliament or of the Council.

---

Drafting notes (non-normative). The standard six-paragraph article, CSDR
Article 67 pattern, verbatim where the convention is fixed. Both
conferrals, Annex I methodology (Article 3(9)) and Annex II methodology
(Article 8(8)), are listed in paragraphs 2, 3 and 6, per the convention
that every conferral is named in each of the three control paragraphs.


# FULL SOURCE: own-the-machine/regulation/articles/16-committee.md

# Article 16: Committee procedure

1. The Commission shall be assisted by a committee. That committee shall be
a committee within the meaning of Regulation (EU) No 182/2011.

2. Where reference is made to this paragraph, Article 5 of Regulation (EU)
No 182/2011 shall apply.

---

Drafting notes (non-normative). Added in round 2 after hostile counsel
found the valuation machinery legally orphaned: Article 6(1) confers an
implementing task with no Article 291 TFEU basis. Standard two-paragraph
comitology article, examination procedure, GDPR-family pattern.


# FULL SOURCE: own-the-machine/regulation/articles/17-transitional.md

# Article 17: Transitional provisions

1. An undertaking that meets the thresholds laid down in Article 3(2) on
the date of entry into force of this Regulation shall make the
notification under Article 3(3) within two months of that date.

2. Where the shares of a covered undertaking were admitted to trading
before the entry into force of this Regulation, that admission shall not
constitute a liquidity event. The citizens' capital warrant of such an
undertaking shall crystallise upon the first liquidity event within the
meaning of point (b) or point (c) of Article 2(6) occurring after its
designation, or upon crystallisation under Article 5(3), whichever occurs
first.

3. A liquidity event completed before the entry into force of this
Regulation shall not give rise to any obligation under Article 5.

---

Drafting notes (non-normative). Round 2 rewrote paragraph 2 after hostile
counsel correctly attacked the forced 12-month crystallisation of
already-listed undertakings as an uncompensated taking on an arbitrary
date, which also contradicted the instrument's own in-time doctrine. The
rule is now uniform and purely prospective: a pre-existing admission is not
an event; the warrant of an already-listed undertaking waits, dormant, for
the next genuine liquidity event (change of control or a qualifying 20 %
transfer), exactly as every other warrant does. This Article does not
disapply Article 5(3), so the extraction trigger and the seven-year
long-stop in that paragraph continue to run from issuance, exactly as for
every other warrant. There is accordingly no escape by never having
another liquidity event: absent one, the warrant of an already-listed
undertaking crystallises in any event no later than seven years after
issuance, and sooner if extraction is used to strip it in the meantime.
Paragraph 3 is the express non-retroactivity rule (JPG 10.14).


# FULL SOURCE: own-the-machine/regulation/articles/18-final.md

# Article 18: Entry into force and application

1. This Regulation shall enter into force on the twentieth day following
that of its publication in the Official Journal of the European Union.

2. It shall apply from [OP: please insert the date 18 months after the
date of entry into force of this Regulation], with the exception of
Article 3(3), Article 11(1) and Article 17(1), which shall apply from the
date of entry into force of this Regulation.

3. This Regulation shall be binding in its entirety and directly applicable
in all Member States.

---

Drafting notes (non-normative). The 18-month application delay gives the
designation machinery and national vehicles time to exist; Article 11(1)
runs from entry into force so the rails are built during the delay, not
after it. Paragraph 3 is the standard closing formula for a Regulation.


# FULL SOURCE: own-the-machine/regulation/memorandum/counter-arguments.md

# The case against this Regulation

Drafted first, before any article, on the discipline this project inherits: if
the instrument cannot survive this file, we fix the instrument, not the prose.
Each objection is stated in its strongest form, with its best sources. Each
ends with the design consequence it imposes. The consequences accumulate into
the constraints table at the end, which is the checklist the articles must
clear before anything else is written.

Objections marked **CONCEDED** are limits of the instrument that the
memorandum states plainly rather than argues away. That is not a courtesy. It
is what distinguishes a legal proposal from campaign copy, and it is the
entire credibility strategy of this project.

---

## A. Legal

### 1. This is expropriation

**The objection, at full strength.** A statutory requirement that undertakings
issue equity warrants to a public reserve takes property. Article 17 of the
Charter of Fundamental Rights protects the right to own, use and dispose of
lawfully acquired possessions, and permits deprivation only in the public
interest, in cases and under conditions provided for by law, and subject to
fair compensation paid in good time. A compulsory warrant dilutes existing
shareholders with no compensation at all; the dilution is the point. Article
345 TFEU adds that the Treaties shall in no way prejudice the rules in Member
States governing the system of property ownership. The Court has narrowed
Article 345 considerably, but a hostile Legal Service reading has ample
material, and shareholders of affected firms will litigate from day one.

**What it gets right.** A warrant requirement does transfer value from
existing shareholders to the reserve. Pretending dilution is not a taking of
value would be dishonest, and the memorandum must not do it.

**The answer the instrument must give.** Three structural choices, none
optional. First, the warrant must be drafted as a condition of access to the
Single Market for a defined category of undertaking, prospective and
uniform, in the family of regulatory obligations the Court has upheld when
proportionate (capital requirements, universal service obligations, DMA
gatekeeper duties), not as a seizure of existing holdings. Second, it must
apply only above high, objective thresholds, so proportionality review has
something to hold on to. Third, it must carry consideration: the reserve is a
passive, non-controlling holder, the warrant crystallises only at liquidity
events, and the covered undertaking receives the legal certainty of a single
harmonised regime in place of twenty-seven national experiments. Whether that
consideration is sufficient is the single largest legal risk in the project,
and Gate 1 exists to test it.

Two authorities belong in this file because a hostile reader will bring
them, and because each is less one-sided than it first appears. The first
is Strasbourg's rule that a deprivation without an amount reasonably
related to the value taken is normally disproportionate (James and Others
v United Kingdom, 1986). The same judgment holds, in the same breath, that
legitimate objectives of public interest, and expressly measures of
economic reform or measures designed to achieve greater social justice,
may warrant reimbursement at less than full market value. That is the
authority under which this instrument has to be argued, and it is
available on its terms rather than in spite of them: a 3 % dilution
crystallising at a moment of realised gain, calibrated to a decoupling of
output from labour, is a measure of economic reform if anything is.

The second is Article 345 TFEU. It provides that the Treaties shall in no
way prejudice the rules in Member States governing the system of property
ownership, and the hostile reading is that a mandatory transfer of 3 % of
private enterprise value is a partial socialisation the Union may not
decree. That reading mistakes the addressee. Article 345 preserves the
Member States' freedom to choose between public and private ownership
against the Treaties; it is not a charter of immunity for property against
Union legislation, which is what Article 17 of the Charter governs and
what this memorandum answers under Article 52(1). The Court has read
Article 345 narrowly in precisely that direction, holding that a property
regime chosen by a Member State remains subject to the fundamental
freedoms (Essent, C-105/12 to C-107/12). The instrument leaves every
Member State's system of ownership exactly as it found it: the shares
subscribed are ordinary shares under national company law, held by an
owner with no special rights, and no national rule about who may own what
is displaced.

The drafting research (18 August) settled the architecture to use: BRRD is
the judicially validated template for interfering with equity by act of law
(Kotnik C-526/14, Ledra C-8/15 P, Aeris Invest C-535/22 P), and the
instrument adopts its machinery: an honest interference recital naming
Charter Article 17, a full proportionality recital under Article 52(1) of the Charter, and a
quantified executional safeguard with independent, separately challengeable
valuation. One adaptation is mandatory: BRRD's counterfactual is insolvency,
and a permanent regime cannot lean on crisis reasoning (Dowling C-41/15).
The distinction has to be stated rather than blurred: bank resolution
dilutes shareholders whose shares would be worth nothing in the
counterfactual insolvency, and these undertakings are healthy going
concerns whose shares are worth a great deal. BRRD is therefore borrowed
for its machinery, not for its justification, and this file does not
pretend otherwise; the justification is the one in James and in Hauer, and
it stands or falls on proportionality rather than on a crisis that is not
happening.

One further authority is worth stating precisely, because stated loosely it
would be worth nothing. In Sky Österreich (C-283/11, 22 January 2013) the
Grand Chamber upheld a Union measure requiring holders of exclusive
broadcasting rights to grant competitors access for short news reports,
with compensation capped at the additional costs directly incurred, which
is below what the market would pay. The rights-holders were solvent, there
was no crisis and no counterfactual insolvency. **That case was decided
under Article 16 of the Charter, the freedom to conduct a business, and not
under Article 17.** It is not authority for a taking of equity, and this
file does not offer it as one; hostile counsel would be entitled to
dismantle any such use of it, and would enjoy doing so.

What it does carry is narrower and still useful. This instrument interferes
with Article 16 as well as Article 17, because compelling an undertaking to
issue shares it did not choose to issue is an interference with the conduct
of its business, and the Commission's Legal Service will see both. On that
limb Sky Österreich is directly in point, and it says three things: the
Article 16 freedom is not absolute but must be viewed in relation to its
social function; the Union legislature may set consideration below market
value where the public interest requires it; and the test is the ordinary
Article 52(1) one. The older line supports the same reading of business
interests, which enjoy no protection as mere commercial expectations of
future profit (Nold 4/73). Booker Aquaculture (C-20/00 and C-64/00) is
sometimes cited alongside, and this file does not lean on it: it concerned
the destruction of diseased stock under an animal-health regime, which is a
public-emergency justification this instrument cannot claim.

The Article 17 limb therefore still rests where it rested, on James and on
Hauer, and the honest statement is that no decided case puts a permanent,
non-crisis, uncompensated equity dilution of a healthy undertaking on the
right side of Article 17. That is the largest legal risk in the project and
it is stated as such in the answer above. So
our floor is executional rather than counterfactual: the interference can
never exceed the stated 3 % in execution, its price is set by the
liquidity event itself under an independent and separately challengeable
valuation, and no application of the instrument may take more than the
interference it names. The doctrine underneath is older than any
of this: property in the Union legal order is not an unfettered prerogative
but is protected in its social function, and may be restricted in the
general interest where the restriction is proportionate and leaves the
right's substance intact (Hauer 44/79; Bosphorus C-84/95). The instrument's
restriction is quantified, event-bound and substance-preserving by
construction, which is what those cases require the legislature to show.

**Design consequence.** DC-1: prospective warrant on future value creation at
defined events, never retroactive transfer of existing shares. DC-2: high
group-consolidated thresholds. DC-3: passivity, and crystallisation only at
defined statutory events, never at a discretionary or political one, written
into the instrument itself.

### 2. This is a tax, and the EU may not levy it this way

**The objection, at full strength.** Call it a warrant; it functions as a
levy. Article 114(2) TFEU excludes fiscal provisions from internal market
harmonisation, so if the measure is fiscal in substance the chosen legal base
collapses; the honest bases would be Article 113 or 115, which require
unanimity in Council, which is unobtainable. The Commission has refused ECIs
that drift into own-resources territory, and the Legal Service reads substance,
not labels. The dividend side makes it worse: a recurring payment to every
adult, funded by an obligation on firms, looks like a tax-and-transfer scheme
wearing a corporate-finance costume.

**What it gets right.** The boundary is real and the characterisation battle
decides registrability. This is the objection most likely to kill the full ask
at Gate 1.

**The answer the instrument must give.** The measure must take nothing in
money from any undertaking in any year. No cash flows from firms to the state
at all. The reserve receives instruments, holds them, and distributes returns
on what it owns, exactly as any shareholder does. Dividends to citizens are
property income from an owned portfolio, not the proceeds of a levy: the
Norwegian fund's distributions are not a tax on anyone. The drafting must
police this line everywhere: no revenue-based charges, no minimum payments, no
cash-settlement options that would let the obligation collapse into a fee.
And the ask must be layered so that if the Legal Service still reads it as
fiscal, the severable outer layer (assess and propose instruments for citizen
participation in automated productivity gains) registers on its own.

Recalibration from the drafting research: registration is a lower hurdle
than this objection assumes. The test is "manifestly outside" the
Commission's powers (Reg 2019/788 Art 6(3)(c)), partial registration is
judicially established (C-899/19 P), and the Commission registered the EU
wealth-tax ECI in 2023. The characterisation fight is real but is fought in
Council, after registration. The layering therefore protects the campaign
moment; the warrant-not-levy drafting protects the instrument's life after
it.

**Design consequence.** DC-4: no monetary flow from undertakings; instruments
only. DC-5: distributions defined as property income of the reserve. DC-6:
severable layering for partial registration.

### 3. The Union has no competence to pay citizens a dividend

**The objection, at full strength.** Even if the warrant survives, the
dividend side has no home. The Union budget operates under an own-resources
ceiling; a Union body paying a recurring universal benefit to every adult has
no Treaty basis; social security design is a Member State competence; and
subsidiarity review would ask, fairly, why citizen accounts must be European
at all when Ireland, Denmark and the Netherlands run national systems that
work. Table 29 makes the point against us: pension funding runs from 49.1% in
the Netherlands to 0.0% in France. Systems this different cannot be
harmonised, and should not be.

**What it gets right.** The Union genuinely cannot and should not run
twenty-seven citizens' accounts from Brussels, and the proposal dies at
subsidiarity review if it tries.

**The answer the instrument must give.** Split the instrument along the
competence line. The Union harmonises what is genuinely single-market: which
undertakings issue warrants, on what terms, to what kind of reserve, with what
governance. Custody and distribution federate to Member States through
existing rails: Denmark has LD, Ireland has MyFutureFund, Poland has PPK, the
Netherlands is mid-conversion into individual DC pots. The precedent is PEPP:
a Union framework, national compartments. The Union never touches the money;
it defines the instrument and the minimum standards (universality, lock-up,
raid-proofing) that national implementations must meet.

**Design consequence.** DC-7: Union-level warrant and reserve standards;
Member State custody and payout through existing pension rails. DC-8: minimum
standards, not uniform machinery.

---

## B. Economic

### 4. Firms will pass the cost to consumers, so citizens pay their own dividend

**The objection, at full strength.** The incidence literature on corporate
taxation is unambiguous that legal and economic incidence differ; a
substantial share of corporate burdens lands on workers and consumers. A
warrant obligation raises the cost of operating in Europe; covered firms
reprice; the citizen's dividend arrives net of the citizen's own higher
prices. The scheme is then a circular pump with deadweight loss.

**What it gets right.** Some pass-through of any burden is real and claiming
zero incidence would be amateurish.

**The answer the instrument must give.** Equity dilution has materially
different incidence from a flow charge. A levy on revenue enters marginal cost
and prices directly; a one-time issuance of warrants exercisable at future
liquidity events changes the division of a future capital gain among
shareholders and does not enter this year's marginal cost at all. The firm's
optimal price today is unchanged by who owns claims on its eventual exit
value. Pass-through is not zero, because expected dilution can raise the cost
of capital at the margin, and the memorandum should say so, with the honest
note that this effect is second-order next to any revenue levy, which is
precisely why the instrument is a warrant and not a levy.

**Design consequence.** DC-9 (reinforces DC-4): the obligation must never be
convertible into a flow charge, because the incidence answer depends on it.

### 5. Covered firms will leave, or never come

**The objection, at full strength.** Draghi's report already concedes the
ground: it is too late for the EU to develop systematic challengers to the
major US cloud providers; the US ITK market grows at 12.7% against Germany's
4.1%; only four of the world's top fifty technology companies are European.
Add a warrant obligation and the marginal AI investment goes to London,
Zurich or Austin. Worse, thresholds invite structuring: a revenue-per-employee
test is gamed by pushing headcount into subcontractors, exactly the offshore
structuring Capgemini's numbers already show at scale.

**What it gets right.** Threshold gaming is certain, not possible, and the
competitiveness anxiety is the strongest political headwind in Brussels this
decade.

**The answer the instrument must give.** The obligation attaches to selling
into the Single Market, not to being located in it, exactly as the DMA and
GDPR attach. The empirical record since is that gatekeepers absorbed
designation and stayed, because 450 million high-income consumers are not
optional; the DMA investigations into AWS and Azure did not produce an exit,
they produced compliance teams. Structuring is answered by consolidation:
thresholds computed on group-consolidated figures including contracted-out
labour by economic substance, with the burden on the undertaking to show
otherwise. And the honest concession: at the margin some investment will
route elsewhere, which is a real cost, to be weighed in the memorandum against
the documented cost of the alternative, which is that the gains concentrate
entirely outside Europe anyway. The Synergy history is the exhibit: Europe
declined to regulate its cloud market into openness, and its providers fell
from 29% to 15% of their own home market unregulated.

**Design consequence.** DC-10: market-access nexus, not establishment nexus.
DC-11: group consolidation with substance-over-form headcount rules.

### 6. Warrants on private companies cannot be valued, voted or sold

**The objection, at full strength.** The covered class is dominated by
private undertakings. A reserve holding warrants on private micro-giants
holds paper with no market price, no liquidity and no exit; either it
pressures for early listings, distorting capital markets, or it sits on
unvalued claims for a decade and the dividend it promises cannot be paid.
Meanwhile the governance question is a trap in both directions: a passive
mega-holder is the feeble owner of the Bebchuk critique, and an active one is
a political sovereign shareholder in every major firm. Greece's HCAP shows the
overcorrection: maximal raid-proofing achieved by placing the asset beyond
citizens' reach entirely.

**What it gets right.** All of it. This is the hardest design problem in the
instrument, harder than the legal base.

**The answer the instrument must give.** The warrant is dormant until
crystallisation, whether at a liquidity event (listing, change of control,
or qualifying secondary sale) or, under Article 5(3), where shareholder
extraction exceeds the stated share of covered turnover or seven years
have elapsed since issuance, whichever occurs first. Until then it
requires no valuation, pays nothing and votes nothing; at the
event it converts at the event price, with no discretion. This matches the
book's own window (claim the stake while the asset forms, crystallise when
the market prices it) and removes the valuation and governance problems in
one move: the reserve holds non-voting economic interests, permanently, by
statute, accepting the Bebchuk cost deliberately because the alternative, a
politically voted stake in every large firm, is worse. The dividend in early
years is funded by crystallisations, not by holdings, and the memorandum must
say plainly that the dividend starts small and compounds, Norway-style, and
that anyone promising otherwise is not us. Two-thirds of Norway's fund is
compound return; the honest pitch is the rule, not the first cheque.

One refinement has been considered and rejected. It is put that valuations
of fast-growing private undertakings are volatile enough that disputes over
the dilution ratio could bog the instrument down in litigation, and that an
expedited binding arbitration should therefore sit between the valuer and
the courts. The instrument already answers the problem the proposal aims
at, and the proposal would cost more than it saves. Article 6(5) provides
that a challenge suspends neither the liquidity event nor the subscription,
and Article 6(4) corrects an erroneous valuation afterwards in either
direction, so a dispute delays nobody: this is the resolution-law pattern,
where litigation runs beside the transaction rather than across it. Where
the event itself sets a price, Article 6(2) makes the valuation arithmetic
on that price rather than an opinion about it, which is where volatility
would otherwise enter. And an arbitral tier whose award bound the parties
would meet Article 47 of the Charter on access to a court, and the limits
on conferring discretionary judgement on bodies of the Union; a tier whose
award did not bind them would add a stage without removing one.

**Design consequence.** DC-12: event-triggered crystallisation, no ongoing
valuation. DC-13: permanently non-voting economic interests. DC-14: the
dividend is communicated as compounding from small, never as immediate
income. DC-34: no tier may be inserted between the valuation and the
courts; correction is ex post and the transaction never waits.

---

## C. Empirical

### 7. The European labour share has not fallen, so the diagnosis is wrong

**The objection, at full strength.** AMECO, verified at source: the EU27
adjusted wage share fell 1.2 points in thirty years; Germany's is at a series
high; France is above its 1995 level; compensation of employees was a larger
share of EU output in 2025 than in 2015, 2019 or 2022. The corporate profit
share spike of 2022 has fully reversed to below its 2019 level. The
Regulation's premise, that machine-driven gains are leaving European labour,
is contradicted by the best available aggregate data, and any recital claiming
otherwise is checkable and wrong.

**What it gets right.** Everything it states. This project's own evidence
base established it, and no recital may argue a European labour-share
collapse.

**The answer the instrument must give.** The premise is ownership, not the
wage share. Sixty per cent of euro-area households own their home; eleven per
cent own listed shares; the top decile holds eighty-three per cent of directly
held shares against the bottom half's two; the bottom half's portfolio is
sixty-three per cent housing and three per cent equity. That distribution is
current, verified and undisputed, and it means that however large the
machine's dividend turns out to be, almost no European holds an instrument
that pays it. The Regulation is insurance whose premium is cheapest before
the event: if the mechanism documented at the platform layer (French software
and cloud growing at +8.2% on price increases while the services layer
shrinks; German software at +9.9% against services at +3.1%) reaches the
aggregate labour market, the stake exists; if it never does, citizens own a
diversified claim on European technology, which is not an injury. The
in-time test is the answer to the premature-legislation charge, not a
vulnerability of it.

**Design consequence.** DC-15: recitals argue ownership concentration and
mechanism, never wage-share decline. DC-16: the memorandum presents the
instrument's value under BOTH futures, arrival and non-arrival.

### 8. The best microdata finds nothing for AI to answer for

**The objection, at full strength.** Humlum and Vestergaard, on Danish
registers covering twenty-five thousand workers: precise null effects on
earnings and hours, nothing above two per cent, two years after ChatGPT. The
OECD finds no break in postings for exposed occupations and a flat euro-area
youth gap. The German federal government told the Bundestag there are keine
Hinweise that AI has reduced entry-level chances. Only a fifth of EU firms
with ten or more staff used any AI in 2025. Legislating a permanent
constitutional-grade structure on this evidence is panic dressed as foresight.

**What it gets right.** The nulls are real, well-identified and from the
best registers in Europe. The memorandum cites them in full or loses its
credibility.

**The answer the instrument must give.** Three things, honestly. First, the
nulls measure wages and hours, not ownership: a uniform shift of returns from
labour to capital is structurally invisible to difference-in-differences
designs, which the Danish authors themselves concede (the absence of
measurable labour market effects is not evidence that nothing is happening),
and their working paper's estimate that only three to seven per cent of
productivity gains passed through to earnings vanished from the published
version along with the paper's own title. Second, the diffusion number cuts
both ways: a mechanism used by a fifth of firms has not yet had its
aggregate chance, which is the argument for building the instrument before
rather than after. Third, the memorandum should carry its own falsification
condition, in the open: if adoption passes a quarter of firms and neither
factor shares nor ownership-weighted gains have moved by a defined date, the
accelerationist premise is wrong and the case reduces to the ownership-gap
argument alone, which stands on its own feet. A proposal that states what
would refute it is a different genre from everything else in Brussels, and
that is the point of this project.

**Design consequence.** DC-17: cite the strongest nulls in the memorandum
itself. DC-18: a stated falsification condition with a date.

---

## D. Political

### 9. You are building the next honeypot, and Europe raids honeypots

**The objection, at full strength.** In one article of law, Poland cancelled
51.5% of the units in every member's pension account and took the Treasury
bonds first. Spain drew its reserve fund down 97% and passed the protection
law afterwards. Hungary took the lot. Ireland's NPRF, the closest thing to
this proposal an EU state has built, was liquidated into a bank rescue within
a decade of its creation. Even the Union itself announced InvestAI at 200
billion and reprogrammed existing funds to stage it. The historical base rate
for European states leaving large pools of citizens' capital alone is poor,
and a bigger pool is a bigger prize. Estonia adds the mirror case: given the
claim and the exit simultaneously, a quarter of the fund walked out in a
month, and the leavers earned below the median.

**What it gets right.** This is the book's own chapter 10 thesis returned as
an objection, and it is the strongest political argument in the file. The
raid is not a tail risk; on the European record it is the modal outcome.

**The answer the instrument must give.** Design against the actual statutes,
clause by clause. Against Poland: the reserve may not hold the sovereign debt
of any Member State or of the Union, removing the self-dealing channel that
made OFE worth cancelling. Against Spain: the prohibition on disposal is in
the founding Regulation from day one, not retrofitted, and amendment of the
protection provisions is reserved to express legislative change accompanied
by a published independent assessment of the effect on holders; a Regulation
cannot prescribe voting thresholds or delays for future legislatures, and
pretending otherwise would hand critics the easiest ridicule in the file. Against Ireland: no emergency-use clause of any kind,
because the NPRF's raid was lawful under its own emergency provisions.
Against Estonia: the periodic entitlement is incapable of surrender or
redemption against payment, so there is no exit for a buyout to purchase,
which is the failure Estonia proved; amounts already distributed are the
holder's property, inheritable, the Danish device that held. Against Greece: raid-proofing must never be achieved by removing
the citizen's claim, which is the failure dressed as success. And one honest
sentence the memorandum must contain: no drafting defeats a determined
future sovereign; the design goal is to make the raid loud, slow and
electorally expensive, which is the most any constitution has ever achieved.

**Design consequence.** DC-19: no sovereign debt holdings. DC-20:
entrenchment as friction from day one: express amendment only, a
published independent assessment, and honesty about Treaty limits. DC-21: no
emergency clause. DC-22: individual claims incapable of surrender; distributed amounts owned and inheritable.
DC-23: the raid-resistance claim is stated as friction, never as
impossibility.

### 10. The EU cannot even disburse what it announces

**The objection, at full strength.** The AI Gigafactories call opened
eighteen months after the 200 billion announcement; construction is promised
from 2027; the Commission's sovereign-cloud tender awarded 180 million
against a single hyperscaler's 33.7 billion in Spain. The institutional
metabolism that would operate this Regulation moves at a pace the underlying
economy does not recognise. A citizens' reserve run at that pace would
crystallise warrants years late and distribute nothing for a decade.

**What it gets right.** The disbursement record is accurately damning and
the memorandum gains nothing by disputing it.

**The answer the instrument must give.** Put no Union spending machinery on
the critical path. The obligation runs directly from covered undertakings to
the reserve: warrants issue by operation of law upon crossing the thresholds,
crystallise by operation of law at events, and the reserve's task is custody
and distribution, not procurement. Nothing needs to be built, tendered or
disbursed for the instrument to function; the contrast with InvestAI is the
design, not an embarrassment to it.

**Design consequence.** DC-24: self-executing obligations by operation of
law; no grant, tender or programme machinery anywhere in the instrument.

---

## E. Philosophical

### 11. Everyone gets richer anyway: the consumer surplus answer

**The objection, at full strength.** Nordhaus estimated that innovators
capture around two per cent of the social value of their innovations; the
rest diffuses to consumers through falling prices and new possibilities. The
steam engine made everyone richer without a single citizen holding a warrant
on Boulton and Watt. If AI follows the pattern, the ownership question is a
distraction: the gains arrive in everyone's basket regardless of whose name
is on the equity.

**What it gets right.** Consumer surplus is real, large and the main channel
through which technology has historically raised living standards. The book
concedes it; the memorandum must too.

**The answer the instrument must give.** Two facts sit beside the diffusion
story without contradicting it. First, the lag: British real wages stagnated
for roughly half a century after Watt while output exploded, and the
broadening arrived through unions, franchise and factory legislation, not
through prices alone; the people who lived inside the pause did not get those
decades back, and whoever owned the mine did not wait. An instrument claimed
at the door is the difference between experiencing the pause with and without
an asset. Second, the stock and the flow are different questions: cheaper
consumption and concentrated wealth are compatible, and the euro area
currently demonstrates the combination, with record employment beside an
ownership distribution of eighty-three against two. The dividend does not
obstruct diffusion; it adds an ownership channel beside the price channel.

**Design consequence.** DC-25: the memorandum affirms consumer surplus and
positions the instrument as additive to it, never as a correction of a
falsehood.

### 12. A dividend buys neither status nor purpose

**The objection, at full strength.** Positional goods reprice against any
universal transfer: give everyone more and the house in the right street
costs more. And income without work solves rent, not Tuesday afternoon: the
structure, standing and belonging that employment supplies as a by-product
are not in the reserve's gift. The proposal oversells what capital income can
do for a displaced person.

**What it gets right. CONCEDED in full.** These are the book's own chapters
11 and 13 and they bind its regulation exactly as they bind its argument.

**What the memorandum must therefore say.** The instrument's scope statement,
prominently: this Regulation addresses the distribution of machine-generated
capital income and nothing else. It does not promise status, purpose,
meaning or the best table, and any campaign material that implies otherwise
is wrong by the proposal's own text.

**Design consequence.** DC-26: an explicit scope-and-limits recital.

### 13. This is universal basic income with extra steps

**The objection, at full strength.** Strip the corporate finance and a
citizen receives a recurring unconditional payment from a public body. That
is UBI, a policy the electorate has weighed repeatedly and cheaply funded
versions of which already failed to collect even an ECI's signatures. The
warrant machinery is complexity added to disguise a transfer as a return.

**What it gets right.** The payment is indeed unconditional and universal,
and the family resemblance is real at the point of receipt.

**The answer the instrument must give.** The difference is not in the
receiving but in the standing. A benefit is a flow from the annual budget,
renegotiated annually, cancellable by simple majority, funded by a shrinking
wage base; the account here is property, in the citizen's name, inheritable,
funded by returns on assets the citizen collectively owns. Poland could
cancel account units by statute precisely because they held claims on the
state itself; Denmark's LD has paid for forty-six years because it holds
market assets in named accounts. The tagline is the answer in six words:
capital for all, so the dividend follows. The order is the argument.

**Design consequence.** DC-27 (reinforces DC-22): named, inheritable
individual accounts, so the UBI comparison fails on legal form, not on
rhetoric.

### 14. Pensions already do this; use them

**The objection, at full strength.** Europe already possesses the machinery
for broad capital ownership: the Netherlands has just moved 605 billion into
individual DC entitlements, Sweden's premium pension has compounded at 5.35%
real since 2000, and the American case shows retirement accounts spreading
equity to 58% of households without any statutory warrant. Build pensions,
not novelties.

**What it gets right.** The delivery rails exist, work and are trusted, and
any design that ignores them is wasteful.

**The answer the instrument must give.** Pensions convert wages into
ownership, and the wage is the input this transition erodes; every pension
vehicle in Europe assumes an employer and a payroll deduction, which is
exactly the assumption chapter 6 shows failing. The funded share of accrued
pension wealth is 7.8% in Belgium and 0.0% in France: the rails reach the
employed of the funded countries and no one else. The warrant severs the
funding source from the wage: the reserve's returns flow into precisely
those national account rails (DC-7) whether or not the citizen ever held a
payroll job. Pensions are the pipe; this is a new source feeding it.

**Design consequence.** DC-28 (reinforces DC-7): distribution through
existing national pension rails; the novelty is confined to the funding
source, where it is necessary.

---

### 15. A euro a year is an insult, not a policy

**The objection, at full strength.** Run the instrument's own simulator
on cautious assumptions and it pays a citizen a euro or two a year for
its first decade. No rational person values that; no voter campaigns
for it; no journalist resists the headline. The apparatus is grotesquely
disproportionate to its payload: a new Union body, a designation regime,
valuation machinery, comitology, penalties reaching 10 % of worldwide
turnover, all to deliver less than the price of a coffee. Worse, the
project's own honesty doctrine forbids promising more. An initiative
that must, by its own rules, tell every signer "you will not feel this
for twenty years" has chosen a message no mass campaign has ever won
with. Basic income at least promises the rent.

**What it gets right.** The early flow is genuinely small, and the
campaign is structurally barred from inflating it. The collection risk
is real: deferred rewards lose to immediate ones on every doorstep.

**The answer the instrument must give.** Three parts. First, the smallness
is calibration, not failure: the instrument's size tracks the
phenomenon's size by construction. Three per cent of little is little,
taken from almost no one, and in that world Article 14(3) obliges the
Commission to report that the premise failed and to propose amendment
or repeal; a permanently small dividend is the falsification condition
firing, not the policy limping. The dividend is only ever small in the
world where the problem is also small. Second, the claim can only be
bought early. The Danish worker's frozen 1978 instalment of DKK 4 368,
pointless money at the time, is DKK 119 506 today; two thirds of
Norway's fund is compound return, not oil. The alternative timing,
claiming the stake after the gains are visible and the owners
entrenched, is expropriation and politically impossible. The euro buys
the certificate, and the certificate is the point. Third, the stock
outruns the flow: on the same cautious assumptions the Reserve stands
at roughly EUR 400 of owned capital behind every citizen by year
thirty, before any single year's payout impresses. A campaign that
shows the payout without the stake is misdescribing its own
instrument.

**Design consequence.** This objection is why DC-14 exists (never lead
with an early-year figure), why Article 14(3) carries the falsification
condition on its face, and why Annex II distributes income and never
principal. It adds two mechanical rules of its own: wherever a
per-citizen payout figure is shown, the per-citizen stake in the
Reserve is shown beside it (DC-31); and where a year's distributable
amount would be too small to be worth transferring, the interval
lengthens rather than the money vanishing, subject to a hard backstop of
one distribution in every three years and a duty to publish what was not
paid (DC-40). The threshold is a ratio to the cost of making the payment,
not a figure: a number in an annex ages, and hands a headline to anyone
who wants one.

### 16. This is a golden share, and the Court strikes golden shares down

**The objection, at full strength.** For twenty years the Court has
dismantled every special public equity position in the internal market.
Commission v Germany (C-112/05) struck the Volkswagen Law because voting
caps and a blocking minority gave public authorities influence exceeding
their investment and thereby deterred direct investment; the Portuguese,
French, Italian, British and Dutch golden shares fell the same way under
what is now Article 63 TFEU. A Union-chartered Reserve holding a statutory
3 % of every covered undertaking is a golden share cast as a regulation: a
permanent state-adjacent shareholder no investor chose, planted in the
capital structure of every frontier firm, deterring exactly the
cross-border investment Article 63 protects. Article 345's neutrality about
systems of ownership did not save the Volkswagen Law and will not save
this. The deterrence is not hypothetical: every venture round in a covered
undertaking now prices a mandatory future dilution.

**What it gets right.** The dilution is real and investors will price it,
and any position that carried control-flavoured rights would fall exactly
as Volkswagen fell. The golden-share cases are the controlling
jurisprudence for any public equity position, and the instrument must be
drafted against them, not around them.

**The answer the instrument must give.** The golden-share line condemns one
thing: special rights of control disproportionate to investment, voting
caps, blocking minorities, approval vetoes, board seats, the machinery by
which a state steers a company it does not own. The instrument constructs
the exact inverse, in the articles rather than in assurances. The Reserve's
holding carries no vote, ever (Articles 5(4)(a) and 9(1)(a)); no board
presence (Article 9(1)(b)); no instructions (Article 9(1)(c)); no
acquisitions beyond the warrant and index-style diversification (Article
9(1)(d)); no leverage or derivatives that would make it a strategic actor
(Article 9(1)(e) to (g)). What remains is pure economic participation, the
position of any passive minority holder, which is the position Norway's
fund holds at comparable scale across European listed undertakings without
an Article 63 case ever being brought. What the case law demands of any
restriction that survives, the instrument answers on its face:
non-discrimination (identical treatment of Union and third-country
undertakings under Article 3), an overriding general interest stated in the
recitals, and proportionality carried by the fixed 3 %, the independent and
separately justiciable valuation (Articles 5(9), 6 and 7) and the Article
52(1) balance. And unlike every struck golden share, this is not a Member
State reserving national influence against integration: it is a uniform
Union rule for the whole internal market, and its uniformity removes the
divergence that national participation schemes would create. The honest
residue is that mandatory future dilution is itself a cost investors will
price; objection 4 prices it, and proportionality, not denial, is the
defence.

**Design consequence.** DC-13's permanent non-voting rule and Article 9's
conduct prohibitions are this objection's answer in law. What they cannot
do is bind a future legislature, and this memorandum does not pretend
otherwise: the drafting of Article 12(3) records that binding future
legislatures failed the gates in an earlier round, and an attempt on 21
August 2026 to give the rule operative force in that paragraph was
abandoned because hostile counsel preferred it present, reading it as a
Union-law command that the Reserve be stripped of the protective class
rights Article 5(4)(b) gives it. What stands is a design rule binding this
instrument and anyone amending it: economic participation is the maximum,
and no control right, veto or governance privilege attaches to the
Reserve's holdings (DC-32). It is a commitment the text keeps, not a lock
the text can impose.

### 17. You are seizing equity in companies Europe does not govern

**The objection, at full strength.** The warrant obligation reaches
undertakings incorporated in Delaware or Singapore, whose shares sit
offshore and whose systems are built offshore, because their services are
used in the Union. Public international law lets the Union regulate foreign
conduct only where it has immediate, substantial and foreseeable effects in
the internal market (Gencor T-102/96; Intel C-413/14 P), and even then it
regulates conduct, not ownership: no effects-doctrine case has ever
required a foreign parent to dilute its own capital. Third-country
governments will treat a compulsory 3 % subscription in their champions as
expropriation by regulation, answerable under investment treaties and
trade commitments, and they will retaliate. The Union would be claiming a
power it would never concede to others: a foreign statute demanding 3 % of
a European champion's equity as the price of serving that market.

**What it gets right.** A warrant on a foreign parent whose only Union link
is that its website resolves would overreach and would deserve to lose. The
nexus must be economic substance in the Union, not accessibility.
Retaliation is a real cost and reciprocity a real argument.

**The answer the instrument must give.** Four structural choices, all
already in the articles. First, the trigger is Union commerce, not Union
accessibility: designation requires provision in the internal market with
EUR 7,5 billion of annual Union turnover in at least three Member States
(Article 3(2)(a)), an economic-presence test far above any effects-doctrine
threshold, and the rents being shared are by construction rents drawn from
Union users. Second, the undertaking is the group: 'undertaking'
consolidates linked enterprises (Article 2(1)), the single-economic-unit
principle of Union competition law (Akzo Nobel C-97/08 P), so no thin
Union subsidiary can shield the parent to which the automated services'
value actually accrues. Third, the mechanism respects foreign company law
rather than purporting to override it: for undertakings governed by
third-country law the subscription is an obligation of result (Article
5(5)), enforced through Article 13 as a condition of continuing access to
the internal market, the architecture of every market-access condition the
Union already imposes, and the company-law derogations of Article 5(7)
reach Member State law only. Fourth, the condition is universal: Union
undertakings bear it identically, so a treaty claim or trade panel has no
discrimination to hold on to, and reciprocity runs in the instrument's
favour, because a Union that asserts the principle accepts it from others.

On the practical incidence the objection now has a concrete answer rather
than an abstract one. Under the designation test of Article 3(2)(b) as
amended, the undertakings presumptively designated on August 2026 figures
span the United States, Taiwan and, near the threshold, the Union itself
(evidence/designation-count.md), so the measure's first-years incidence is
no longer a set consisting exclusively of undertakings of one third
country, and the universality of the condition is visible in the
designated set itself rather than asserted about a hypothetical one.

**Design consequence.** DC-10's market-access nexus and DC-2's group
consolidation are this objection's answers in law. It adds one rule of its
own: for undertakings governed by third-country law, the warrant is an
obligation of result enforced as a market-access condition, never a
purported override of foreign company law (DC-33).

### 18. Corporate structuring will simply route around all of this

**The objection, at full strength.** Every mechanism in this Regulation
assumes a moment at which value becomes visible, and corporate law exists
to move that moment. A hyper-automated undertaking is the ideal escape
artist: it needs little capital, so it need never list; it generates cash,
so it can pay its founders through decades of dividends, leveraged
recapitalisations and selective buybacks while the warrant sits dormant
for ever. If it must eventually deal, it deals in a capital stack the
Reserve does not sit in: seed through Series G preferred with two- and
three-times participating liquidation preferences, so that a sale
distributes everything to preferred holders and the Reserve's three per
cent of common is worth precisely nothing. If the trigger still nears, the
group demerges: model weights, training infrastructure and user base
migrate to an unlisted sister, and what floats is a low-margin European
storefront. If all else fails, a friendly private credit fund converts
debt to equity in a preventive restructuring, old equity is extinguished
by court order, and the same people own the same models through a new
company the following morning. Meanwhile the shares the Reserve does hold
in third-country parents are taxed at source at rates it cannot reclaim,
because a supranational body resident nowhere has no treaty to invoke.
Each of these is ordinary practice, not abuse; the instrument is a
crystallisation event in a world that has spent forty years learning to
avoid events.

**What it gets right.** All of it. An instrument that hangs on a single
trigger will be routed around by people who structure for a living, and a
regulation that says so only in its recitals has conceded the point. The
answers below are additions the file did not have; they came from outside
review and the memorandum says so.

**The answer the instrument must give.** Close the timing, the ranking,
the perimeter and the exit, and be honest where the closure is partial.

Timing first: the warrant no longer waits on a sale. Article 5(3) makes
it crystallise where shareholder extraction over three consecutive years
exceeds 25 % of the undertaking's turnover from the covered activity, which
is the point at which staying private has become a way of paying oneself
rather than a way of building; and in any event on the seventh anniversary of issuance,
whatever the undertaking has or has not done. An undertaking may still
stay private for ever. It may no longer stay private and be paid.

Ranking second: Article 5(4)(b) entitles the Reserve to shares ranking,
for dividends and for the proceeds of any sale or liquidation, equally
with the most favourably ranking class created after designation, and with
ordinary shares otherwise. Three per cent of a common tranche standing
behind a three-times participating preference is not three per cent of
anything, and the instrument now says which three per cent it means,
without taking from investors the preference they actually paid for before
designation. Article 5(10) makes any reorganisation whose main purpose or
effect is to put the Reserve below where that paragraph places it
ineffective as against the Reserve, while leaving it good between the
parties to it.

Perimeter third: Article 5(11) requires the transferee to issue a warrant
of its own where automated assets go to an affiliate or a commonly
controlled entity or leave at less than arm's length, and leaves the
transferor bound in respect of what it retains. The aggregate across the
covered undertaking and every transferee is capped at the stated
percentage of their combined capital, so that closing this route cannot
turn into a multiplier on a group that divides itself. Article 2(14) names what may not be
walked out of the door: model parameters, training and inference
infrastructure, data sets, the intellectual property the service depends
on. This is the succession logic of merger control rather than an
invention.

Exit fourth: Article 5(12) reattaches the obligation where the automated
assets emerge from insolvency or a restructuring under Directive (EU)
2019/1023 into an entity controlled by the same people, or in which those
people hold the majority of the economic rights, and requires a warrant to
be issued afresh within three months. A genuine failure still extinguishes the
Reserve's holding, as it extinguishes every shareholder's, because the
Reserve is an owner and owners bear that. What it does not do is bless the
version where the owners survive and only the obligation dies.

And the honest partial: source taxation. A Union regulation cannot confer
on the Reserve a treaty benefit that a third country has not granted, and
a body resident nowhere may be withheld against at the full statutory
rate. Two answers were drafted and struck. Instructing the Commission to
negotiate with third countries would have commanded a prerogative that
Article 218 TFEU places elsewhere. Permitting the Reserve to route its
holdings so as to reduce the rate would have written treaty shopping into
an instrument whose entire case is that capital should be broadly owned
and should pay what it owes; hostile counsel had the headline ready, and
was right to have it. What survives is Article 8(5): the Reserve
publishes each year the tax it could not reclaim, and the Commission
answers for it in the Article 14 report. That is a smaller answer than the
problem, and it is the honest one. A leak reported annually is a leak the
campaign can be judged on; a leak nobody measures only grows.

One route counsel kept and the instrument deliberately leaves open. An
undertaking may borrow heavily from lenders who are nobody's relation, pay
them market interest, and arrive at the long-stop worth less than it would
have been unlevered. That is not extraction and the definition should not
pretend otherwise: the money goes to strangers, not to insiders, and the
founders are poorer by exactly the same proportion as the Reserve. Every
shareholder in a leveraged company owns a smaller claim on a larger
balance sheet, and an instrument that took 3 % of the equity cannot also
insist the equity be unencumbered. What the file must not do is confuse
that with the routes above, where value leaves for pockets that are the
same pockets. Leverage is a risk the Reserve takes as an owner; extraction
is a transfer the Regulation stops.

**Design consequence.** DC-35: crystallisation triggers on extraction and on
time, not only on a sale. DC-36: subject to the rescue carve-out, the
Reserve's shares rank with the most favoured class created after the
designation, leaving earlier preferences untouched, and subordinating
arrangements are ineffective as against the Reserve. DC-37: the transferee
issues its own warrant over its own capital; the transferor stays bound for
the automated assets it retains, and the aggregate across them never exceeds
the stated percentage of their combined capital. DC-38: unrecoverable source
taxation is published annually; the instrument does not direct the Reserve
to arrange its holdings to reduce it. DC-39: the obligation reattaches where
the same owners reacquire the assets out of a restructuring.

### 19. Sweden tried this and could not even legislate it

**The objection, at full strength.** This mechanism is not new and it has
already failed, in the one country most likely to have carried it. The
Meidner plan, endorsed by the Swedish trade union confederation's congress
in 1976, required profitable undertakings to issue new shares worth 20 % of
their annual profits to collectively held funds, year after year, until
those funds held a majority of the shares. That is this instrument's
mechanism: a compulsory issuance of new equity to a collective holder,
settled in shares rather than cash, calibrated to the undertaking's own
prosperity.

It did not survive its own drafting. By the time the Riksdag legislated in
1983, the compulsory share issuance had been abandoned and replaced with a
levy on profits and on the wage sum, capped in aggregate and limited to
holdings of no more than 8 % of any one undertaking. The design converted,
under political pressure and before enactment, into precisely the thing this
memorandum spends Article 8 and objection 2 insisting this instrument is
not: a tax. Then Swedish business mobilised against even the diluted version
on a scale without modern parallel, with a demonstration on 4 October 1983
that drew between 75 000 and 100 000 people where the organisers had
expected 5 000, and repeated it annually until a change of government
abolished the funds in 1991, against minimal resistance from the movement
that had proposed them.

The reading is unkind and it is available to anyone who knows the file. In
the most union-friendly advanced economy in the world, at the peak of
organised labour's power, with a sympathetic government, the compulsory
issuance of equity to a collective fund proved unlegislatable, converted
into a fiscal measure at the drafting stage, and was repealed within eight
years by the first government that wanted to. A drafter who does not know
this has not done the reading. A drafter who knows it and omits it is
hiding it.

**What it gets right.** Almost all of it, as history. The mechanism is the
same family. The conversion to a levy is real and is the sharpest available
evidence for objection 2's characterisation attack, because it shows
experienced legislators reaching for the fiscal instrument when the
equity instrument became politically impossible. The 1991 abolition is a
genuine instance of the raid this instrument drafts Chapter VI against, and
it belongs beside Poland, Spain and Ireland in the evidence base rather
than being left out because it is inconvenient. The mobilisation is a real
prediction about what happens when capital reads a proposal of this kind
as a transfer of control.

**The answer the instrument must give.** Three differences, each of which
maps onto a specific reason the Swedish design failed, and none of which is
cosmetic.

First, terminus. Meidner's funds were designed to accumulate without limit
until ownership changed hands, and its author said so; that was the point,
not a side effect. This instrument takes 3 % of fully diluted capital once,
per designation, with the aggregate across an undertaking and every
transferee capped at that same percentage under Article 5(11) and Article
7(2). There is no path from this instrument to control, because the
arithmetic does not permit one. An opponent who says otherwise is arguing
against a different proposal.

Second, control. The Swedish funds voted, and they were run by the unions.
The scholarship on the defeat is consistent that the mobilisation was about
who would govern the companies rather than about the money, and the 8 %
ceiling was itself an attempt to answer that fear. The Reserve holds
non-voting shares under Article 5(4)(a), is forbidden by Article 9 from
seeking or exercising influence, and DC-32 makes economic participation the
maximum. The constituency that made 1983 possible was employers who
believed they were being nationalised in instalments. That belief cannot be
formed about an instrument that cannot vote.

Third, beneficiary. The Swedish funds accrued to a labour movement, which
made them a party question in a two-party fight. This instrument's
distributions accrue equally to every citizen of the Union under Article 10,
including the shareholders and the employees of the designated undertakings
themselves. That does not make opposition impossible. It makes "them
against us" harder to draw.

What this file will not claim is that the differences make the political
economy safe. They do not. The honest position is that Sweden shows the
mechanism can be legislated only if it is visibly bounded, visibly
powerless as to control, and visibly universal in who it pays, and that a
proposal failing any of those three has a documented way of dying. This
instrument is drafted to satisfy all three, and objection 4 already prices
the residual political risk rather than denying it.

**Design consequence.** DC-41: the instrument must be bounded, without votes
or control rights, and universal in who it pays, all three at once, because
the Swedish precedent shows that failing any one of them is sufficient to
lose. The word to avoid is passive. The Reserve does assert claims: Article
5(4)(b) fixes its rank and Article 5(10) makes subordinating arrangements
ineffective against it, and an opponent will call that anything but passive.
The defensible claim is narrower: the Reserve holds no votes, appoints no
one, and has no say in the management of the undertaking. Even that is not
the end of it. Hostile counsel makes the further point that a rank the
undertaking cannot subordinate constrains how it raises distressed or
preference capital, since new money normally demands seniority, and calls
that a veto over capital structure in substance. It is not a governance
right and Article 5(10) leaves the arrangement effective between the parties
to it. It was, all the same, a constraint on financing that the word passive
would conceal, and it is now answered in the text rather than carried: the
second subparagraph of Article 5(10) lets genuinely new money rank ahead of
the Reserve, at arm's length, from persons unconnected with the undertaking
and its controllers, while the undertaking is in a likelihood of insolvency
or must meet a prudential requirement, and only to the extent of the new
consideration provided. Rescuers are paid before the Reserve; engineered
seniority beyond the new money is still caught, because that is where the
abuse lives, and the undertaking bears the burden of proof. DC-42: the wage-
earner funds belong in the evidence base as a raid precedent and in this
file as an objection, stated before an opponent states it.


### 20. Taking the voteless shares hands control to the people you named as the problem

**The objection, at full strength.** The instrument takes three per cent of
the economic value and none of the votes. The arithmetic of that is not
neutral. Before the warrant, the existing holders own all of the capital and
cast all of the votes; after it they own ninety-seven per cent of the capital
and still cast all of the votes. Their control per euro of their own money has
gone up, by about three per cent, and the Union has handed it to them. A file
whose diagnosis is that the ownership of productive capital is too narrow
responds by creating the largest permanently voteless shareholder in Europe
and widening, at every covered undertaking, precisely the wedge between
cash-flow rights and control rights that corporate-governance scholarship
identifies as the most reliable predictor of minority expropriation and
unaccountable management. The founders of the frontier firms already hold
control through dual-class structures on minority economic stakes. This gives
them more of it, for free, by statute.

The legitimation point is worse than the arithmetic. Once the Union itself
accepts voteless equity as the form its own citizens' participation takes, no
Union institution can coherently object to dual-class listings, loyalty shares
or any other separation of ownership from control. The instrument does not
merely tolerate the wedge; it endorses it, in a Regulation, on behalf of
450 million people.

**What it gets right.** The mechanical claim is exactly true and this file
should not pretend otherwise: non-voting shares raise the relative voting
weight of every voting share, and the raise here is real. If the diagnosis
were about who controls firms rather than about who receives the returns to
capital, the instrument would be answering a question it did not ask, and
answering it in the wrong direction.

**The answer the instrument must give.** Not that this is the wrong lens. An
earlier draft of this passage called the governance reading a category error,
on the ground that the instrument's claim is distributional. Four review
gates rejected that in the same terms, and they were right: an instrument
that alters the ratio of cash-flow rights to control rights at every
undertaking it touches is a governance instrument in effect, whatever it is
in intention, and it is properly judged on its effects. The answer below
concedes the effect and defends the choice.

The choice was between three positions and the file has taken the least bad
one. A Reserve with votes proportionate to its stake is a politically
directed shareholding in every frontier firm in the internal market: it is
objection 9's honeypot with a lever attached, and objection 16's golden
share, which the Court has struck down in every form it has taken since
Commission v Germany (C-112/05). A Reserve with no stake at all abandons the
distributional claim entirely. A Reserve with economic participation and no
control accepts a real governance cost in exchange for the only position that
survives Article 63 and the golden-share line. Article 5(4)(a) and Article
9(1)(a) to (c) put that beyond the drafter's later convenience, and DC-43
keeps any successor honest about it.

On magnitude, one comparison and its limits. Three per cent of enlarged
capital raises the remaining holders' voting weight by roughly one
thirty-second of itself, and buy-back programmes of that order run routinely
at the undertakings this instrument covers without anyone calling them a
transfer of control. That comparison is offered for size and for nothing
else, and it does not survive being pushed further: a buy-back is elective,
is executed for consideration and returns cash to the holders whose weight
rises, whereas this is compulsory, is subscribed at nominal value and returns
nothing to them. Reviewers were right to say the two are not alike in kind.
They are alike in the one respect the paragraph uses them for, which is how
much the voting weight of a remaining share actually moves.

On legitimation, the objection lands and is only partly answered. Voteless
shares are not this instrument's invention: Union company law has permitted
them for decades and every Member State provides for them, so the Reserve
takes a class the market already trades. But the Union has lately been
legislating in the other direction, adding safeguards around multiple-vote
structures precisely because the separation of ownership from control is
understood to be a hazard, and a Regulation that plants a permanent voteless
block in every covered undertaking sits uneasily beside that. The honest
statement is that the instrument spends some of the Union's authority on the
proposition that economic participation without control is a legitimate form
of ownership, and that the price is real. It is paid deliberately, because
the alternative is a Union holding votes in the undertakings it regulates,
and this file would rather defend a wedge than defend that.

The precise interaction with the Union's multiple-vote share legislation is
recorded as an open acquis interface point rather than argued here from a
citation this file has not yet verified, and it joins the acquis
interface points already recorded on the list before filing.

**Design consequence.** The instrument's claim is distributional and no
amendment gives the Reserve votes without arguing itself as a different
instrument, but the governance effect is conceded and defended rather than
disclaimed (DC-43). The relative voting effect on existing holders is stated
with its size, and the buy-back comparison is confined to magnitude with its
disanalogy stated in the same breath (DC-44).


### 21. Why three per cent, and not one, or ten

**The objection, at full strength.** The number is asserted. Nowhere in this
file is it derived. Article 52(1) of the Charter permits a limitation on the
right to property only where it is necessary and genuinely meets an objective
of general interest, and necessity is the question a bare figure cannot
answer: if three per cent achieves the objective, one per cent is the less
intrusive means and the measure fails; if one per cent does not achieve it,
the file has not shown why three does. The reviewing court will ask the
legislature to show its work, as it asked in every proportionality case worth
citing, and this file will hand it a round number that sits comfortably below
the level at which the objection "you are nationalising them" becomes easy to
make. That is a political calibration wearing the clothes of a legal one, and
the Commission's Legal Service will see it on the first reading. Every other
number in the instrument is tied to something: the thresholds in Article 3 to
measurable quantities, the seven-year long stop to the observed interval
between designation and realisation. The one number that determines how much
is taken is tied to nothing.

**What it gets right.** All of it. This is the weakest load-bearing point in
the file, and no quality of drafting anywhere else repairs it. It would be
worse than useless to answer it here with a derivation invented to fit a
figure already chosen: that is precisely the vice the objection names, and a
reviewer who caught it would be entitled to discount everything else in this
memorandum.

**The answer the instrument must give.** The objection is correct, and the
attempt to answer it produced something worse than a missing derivation: a
demonstration that no derivation of the kind a court would want can be
produced at all while Article 1 stands as drafted.

The published model is linear in the percentage. Annex II's arithmetic, as
implemented in the simulator on the campaign site, accumulates the Reserve's
capital by adding the warrant percentage of each crystallising flow, and
every distribution downstream is a fraction of that capital. Doubling the
percentage doubles the dividend at every horizon and halving it halves it,
exactly, in every scenario the simulator offers. The computation is set out
in evidence/warrant-percentage.md and anyone can rerun it. There is no
threshold, no kink and no discontinuity anywhere on the curve, which means
there is no percentage at which the instrument starts working and below which
it does not.

That is fatal to the obvious defence. Necessity under Article 52(1) asks
whether a less intrusive measure would achieve the objective. If the
objective is Article 1's, the participation of citizens in the capital value
created by hyper-automated undertakings, then one per cent achieves it, and
so does one tenth of one per cent, because each produces participation and
the Article states no quantity that participation must reach. An opponent
does not even need to argue that three per cent is too much. They need only
observe that a smaller figure achieves the stated objective, and the
necessity limb fails on the instrument's own words.

So the defect is not in this memorandum, and it cannot be repaired here. It
is in Article 1. An instrument that interferes with Article 17 of the Charter
and states its objective qualitatively has left the necessity limb with
nothing to be tested against, and no amount of argument about three per cent
substitutes for that. Either the objective acquires a quantity against which
a percentage can be measured, or the Article 52(1) defence rests on the
proportionality limb alone, which asks only whether the burden is excessive
and to which the answer is the ceiling rather than the floor.

The ceiling is where the file's defence honestly sits today. A percentage
large enough to strip existing holders of the substance of their property
crosses from a regulation of use into a deprivation. Hauer (44/79) is the
authority for the distinction itself and for the proposition that the right
to property may be regulated in the general interest; it concerned a
temporary restriction on planting vines and is not authority for a
compulsory transfer of equity, and this file does not offer it as one. James
and Others v United Kingdom (1986) is cited for the same distinction and for
nothing further: the taking there was accompanied by compensation, so it is
authority about where the line runs and not about what may be taken without
paying for it. Objection 1 carries that argument and its honest residue,
which is that no decided case places a permanent, non-crisis, uncompensated
dilution of a healthy undertaking on the right side of the line. Three per
cent is comfortably below any plausible deprivation ceiling. Being below a
ceiling is a proportionality argument, not a necessity argument, and this
file will not dress one as the other.

That repair has now been made, and this passage records both the repair
and its honest limit. Article 1(2) states the objective as an ownership
position: holdings per citizen of the order of six months of the median
equivalised disposable income in the Union, in constant prices, within a
generation of the first designations. On the published model and the
amended designation test of Article 3(2)(b), the aggregate designated
value is of the order of EUR 20 trillion on August 2026 figures
(evidence/designation-count.md), and the stake per adult within a
generation is about EUR 8 400 at three per cent, EUR 5 600 at two and
EUR 2 800 at one (evidence/sizing-the-ask.md). Six months of median
equivalised disposable income is of the order of EUR 9 000. Three per
cent is therefore the smallest integer percentage capable of approaching
the stated objective, one per cent manifestly cannot, and the necessity
limb of Article 52(1) has, for the first time, a quantity to test
against, published, reproducible, and revisited at every Article 14
report, where the same clause that could raise the percentage on the
evidence is the clause that lowers it.

The honest limit is the circularity a reviewer will point out and this
file states first: with a linear model, any target-percentage pair is
arguable, so the target itself is not derived, it is chosen, openly, in
the enacting terms. That is not a defect the drafting can remove; it is
what a legislative objective is. The case law requires a stated objective
and a reasoned relationship between the measure and it, not an objective
that derives itself, and no instrument's does. What this file no longer
does is assert a percentage against no objective at all.

**Design consequence.** The percentage is derived as the minimum integer
consistent with the objective stated in Article 1(2), on a published and
reproducible model, and the circularity inherent in choosing the target is
stated rather than concealed (DC-45). Article 1(2) carries the quantified
objective, assessed in each Article 14 report in both directions, and the
derivation is revisited whenever the designated set or the model moves
(DC-46).


## The constraints table

The articles are drafted against this table. A draft that violates a DC fails
review regardless of its prose.

| DC | Constraint | Source objection |
|---|---|---|
| DC-1 | Prospective warrants on future value; never retroactive transfer | 1 |
| DC-2 | High, objective, group-consolidated thresholds | 1, 5, 17 |
| DC-3 | Statutory passivity; crystallisation only at defined statutory events, never at a discretionary or political one | 1, 6 |
| DC-4 | No monetary flow from undertakings; instruments only | 2, 4 |
| DC-5 | Distributions are property income of the reserve | 2 |
| DC-6 | Severable layering for partial ECI registration | 2 |
| DC-7 | Union warrant standards; Member State custody via pension rails | 3, 14 |
| DC-8 | Minimum standards, not uniform machinery | 3 |
| DC-9 | Obligation never convertible into a flow charge | 4 |
| DC-10 | Market-access nexus, not establishment nexus | 5, 17 |
| DC-11 | Substance-over-form headcount consolidation | 5 |
| DC-12 | Event-triggered crystallisation; no ongoing valuation | 6 |
| DC-13 | Permanently non-voting economic interests | 6, 16 |
| DC-14 | Dividend communicated as compounding from small | 6 |
| DC-15 | Recitals argue ownership and mechanism, never wage-share decline | 7 |
| DC-16 | Value stated under both futures | 7 |
| DC-17 | Strongest nulls cited in the memorandum itself | 8 |
| DC-18 | Stated falsification condition with a date | 8 |
| DC-19 | No sovereign debt holdings | 9 |
| DC-20 | Entrenchment from day one: express amendment only, published independent assessment, honesty about Treaty limits | 9 |
| DC-21 | No emergency clause | 9 |
| DC-22 | Individual claims incapable of surrender or seizure; distributed amounts owned and inheritable | 9, 13 |
| DC-23 | Raid resistance claimed as friction, never impossibility | 9 |
| DC-24 | Self-executing by operation of law; no programme machinery | 10 |
| DC-25 | Consumer surplus affirmed; instrument additive to it | 11 |
| DC-26 | Explicit scope-and-limits recital | 12 |
| DC-27 | UBI distinction carried by legal form | 13 |
| DC-28 | Funding-source novelty only; existing rails for delivery | 14 |
| DC-29 | Interference capped at the stated percentage in execution; independent, separately challengeable valuation; judicial review | 1 |
| DC-30 | Essential elements (trigger, reserve ownership, entitlement, interference) in the articles, never delegated | 1 |
| DC-31 | Wherever a per-citizen payout figure is shown, the per-citizen stake in the Reserve is shown beside it | 15 |
| DC-32 | Economic participation is the maximum: no control right, veto or governance privilege attaches to the Reserve's holdings, binding this instrument and anyone amending it, without pretending to bind a future legislature | 16 |
| DC-33 | For third-country-law undertakings the warrant is an obligation of result as a market-access condition, never an override of foreign company law | 17 |
| DC-34 | No tier between valuation and the courts; correction is ex post and the transaction never waits | 6 |
| DC-35 | Crystallisation triggers on shareholder extraction and on time, not only on a sale | 18 |
| DC-36 | The Reserve's shares rank with the most favoured class created after the designation, leaving earlier preferences untouched; subordinating arrangements are ineffective against the Reserve, save for new money at arm's length from unconnected persons in rescue, to the extent of the new consideration | 18 |
| DC-37 | The transferee issues its own warrant over its own capital; the transferor stays bound for what it retains, and the aggregate across them never exceeds the stated percentage of their combined capital | 18 |
| DC-38 | Unrecoverable source taxation published annually; the Reserve is not directed to arrange its holdings to reduce it | 18 |
| DC-39 | The obligation reattaches where the same owners reacquire the assets out of a restructuring | 18 |
| DC-40 | Below a de minimis the distribution interval lengthens; it never becomes a reason not to pay | 15 |
| DC-41 | Bounded, without votes or control rights, and universal in who it pays: the Swedish wage-earner funds show that failing any one of the three is enough to lose. The Reserve does assert claims as to rank and against subordination; what it never acquires is votes, board seats or any say in management | 19 |
| DC-42 | The wage-earner funds are stated as an objection here and as a raid precedent in the evidence base, before an opponent states them | 19 |
| DC-43 | The claim is distributional and no amendment gives the Reserve votes without arguing itself as a different instrument; the governance effect on remaining holders is conceded and defended, never disclaimed as the wrong lens | 20 |
| DC-44 | The relative voting effect on existing holders is stated with its size, not left for an opponent to compute, and any comparison drawn to buy-backs is confined to magnitude with its disanalogy stated alongside | 20 |
| DC-45 | The percentage is the minimum integer consistent with the objective stated in Article 1(2), derived on a published, reproducible model; the circularity of choosing the target is stated, never concealed | 21 |
| DC-46 | Article 1(2) carries the quantified objective, assessed in each Article 14 report in both directions; the derivation is revisited whenever the designated set or the model moves | 21 |

## Status

Objections are OPEN until the articles answer them, save where noted below;
12 is CONCEDED by scope. Objection 18 was added on 21 August 2026 from an
external review of corporate-structuring routes around the instrument.
Unlike objections 16 and 17, it did not find the answers already in the
articles: it describes five routes. Four of them are now closed by
amendments to Articles 2 and 5. The fifth, source taxation, prompted an
amendment to Article 8 but is not closed, and the answer to that objection
says so: publication is a smaller answer than the problem. A sixth item,
borrowing at arm's length, was considered and deliberately left open,
because it is not the extraction the objection is about. It is the first objection in
this file whose answer had to be written rather than cited.

Objections 16 and 17 were added on 20 August 2026 from an external
challenge (the Article 63 golden-share line; qualified-effects overreach);
their answers were already in Articles 3, 5(5) and 9, which is what
drafting against the table is for, and the residue they add is DC-32 and
DC-33.
Objection 1 carries the largest legal risk and objection 6 the largest design
risk. Gate 1's admissibility letter still leads with objections 1 and 2, but
recalibrated by the drafting research: registration is the lower hurdle
(manifestly-outside test, partial registration, the registered wealth-tax
ECI), so the letter tests the characterisation for the Council stage, not for
the register.

Objection 2's fiscal reading has now been reached independently by three
readers: hostile counsel on 27 August 2026, the ECI Forum's advisers on 27
August 2026 and an ECI veteran on 5 September 2026 (pipeline/EXTERNAL-REVIEWS.md,
review 5). The objection is unchanged; what changes is its status, from an
adversary's argument to the ordinary reader's first impression, which the
presentation, not the drafting, must now answer.


# FULL SOURCE: own-the-machine/regulation/memorandum/explanatory-memorandum.fr.md

<!-- Traduction de courtoisie. Le texte anglais fait foi ; en cas de divergence, l'anglais prévaut. Source: explanatory-memorandum.md -->

# Exposé des motifs

Accompagnant le projet de règlement du Parlement européen et du Conseil relatif à des règles harmonisées concernant la participation des citoyens aux gains de productivité automatisés.

Le présent exposé des motifs suit la structure que la Commission utilise pour ses propres propositions. Il est rédigé par des citoyens, non par la Commission, et n'est pas obligatoire : le règlement (UE) 2019/788 permet à une initiative citoyenne de joindre un projet d'acte juridique et n'exige rien de ce type. Il existe parce que les questions auxquelles les services de la Commission devraient répondre au sujet de cet instrument méritent qu'on y réponde avant qu'elles ne soient posées, et parce qu'un dossier qui ne peut y répondre n'est pas prêt à faire l'objet de suites. Lorsqu'une réponse n'existe pas encore, le présent exposé des motifs l'indique plutôt que de remplir la rubrique.

---

## 1. Contexte de la proposition

### 1.1 Motivation et objectifs de la proposition

Les systèmes cognitifs automatisés commencent à produire des résultats à une échelle qui ne requiert plus une quantité correspondante de travail humain. Lorsqu'un tel découplage se produit, les revenus de la production reviennent aux détenteurs du capital qui incorpore l'automatisation, et la part revenant aux citoyens sous forme de salaires diminue parallèlement à la part du travail.

Le problème auquel le présent règlement entend remédier n'est pas ce résultat en soi, qui relève de multiples instruments, mais un problème plus restreint relevant de la compétence de l'Union: la propriété du capital dans lequel se concentrent ces rendements est extrêmement restreinte, et les États membres ont commencé à y réagir de manière isolée, par des prélèvements nationaux divergents, des mécanismes de participation et des propositions visant à taxer la production automatisée. Ces divergences fragmentent le marché intérieur précisément pour les entreprises qui exercent leurs activités à l'échelle de l'ensemble de celui-ci.

L'objectif est énoncé et quantifié à l'article 1er, paragraphe 2: la participation des citoyens de l'Union à la valeur en capital créée par la production hyperautomatisée, à une échelle où les avoirs sous-jacents au droit de chaque citoyen atteignent un montant de l'ordre de six mois de revenu disponible équivalent médian dans l'Union dans le délai d'une génération à compter des premières désignations.

### 1.2 Cohérence avec les dispositions existantes dans le domaine d'action

L'architecture de désignation suit le règlement (UE) 2022/1925 (règlement sur les marchés numériques): critères qualitatifs cumulatifs, seuils quantitatifs établissant une présomption réfragable, autonotification, voie de désignation en deçà des seuils fondée sur les faits et pouvoir anti-contournement. Il s'agit d'une réutilisation délibérée d'une structure que le législateur de l'Union a déjà adoptée et que la Cour n'a pas remise en cause.

L'articulation avec le droit des sociétés est rédigée sous la forme d'une dérogation expresse et étroite à la directive (UE) 2017/1132 plutôt que d'une primauté générale, suivant ainsi la formule de l'acquis en matière de résolution. L'articulation avec le régime des prospectus constitue une exemption expresse au titre du règlement (UE) 2017/1129. L'article 1er, paragraphe 5, préserve la directive (UE) 2016/2341 et le règlement (UE) 2019/1238, sous réserve des dispositions de l'article 11.

Cinq points d'articulation avec l'acquis demeurent ouverts et sont énumérés à la section 5.4. Ils sont recensés plutôt que résolus, ce qui reflète fidèlement l'état d'avancement.

### 1.3 Cohérence avec les autres politiques de l'Union

L'instrument retient des fonds propres sans droit de vote et ne confère aucun droit de gouvernance, ce qui le maintient hors du champ couvert par la jurisprudence de la Cour relative aux participations publiques spécifiques (Commission c. Allemagne, C-112/05, et jurisprudence ultérieure). Ce choix a un coût, examiné à l'objection 20: les actions sans droit de vote augmentent le poids de vote relatif des détenteurs restants, et l'Union a récemment légiféré en sens inverse sur les structures d'actions à droits de vote multiples dans la directive (UE) 2024/2810. L'interaction avec cette directive constitue un point d'articulation ouvert et non résolu.

Aucune disposition du présent règlement ne crée de ressource propre de l'Union, et aucun élément n'entre dans le budget de l'Union. Il s'agit d'une contrainte de conception et non d'une propriété accessoire: voir section 4.

---

## 2. Base juridique, subsidiarité et proportionnalité

### 2.1 Base juridique

La base juridique est exposée par couche, et non selon un centre de gravité
unique pour l'ensemble de l'acte, car des procédures législatives
incompatibles ne peuvent être fusionnées en une seule base (Dioxyde de
titane, C-300/89) et parce qu'une argumentation unitaire concéderait la
qualification de la couche la plus faible aux opposants à la couche la plus
forte. La note sur la divisibilité expose ces couches; la règle de
décomposition no 3 impose ce traitement. L'article 114 du TFUE sous-tend le
régime de désignation, les obligations de transparence et le warrant: des
règles adressées à des entreprises opérant sur l'ensemble du marché
intérieur, éliminant les divergences que des prélèvements nationaux
distincts sur la participation et l'automatisation créent déjà. La
Commission a enregistré une initiative reposant sur cette même logique de
divergence en terrain au moins aussi contesté : l'initiative de 2023 sur
l'imposition des grandes fortunes, par la décision (UE) 2023/1487. L'avis
indépendant obtenu par l'intermédiaire du Forum de l'ICE le 27 août 2026,
consigné dans pipeline/EXTERNAL-REVIEWS.md et qui ne lie personne, interprète cette décision de la même manière et recommande de la citer ici. L'article 352 du
TFUE sous-tend les éléments que l'article 114 ne couvre pas, à savoir
l'établissement de la Réserve en tant qu'organisme au niveau de l'Union et
le droit individuel des citoyens. Cette base n'est pas un terrain vierge
pour la participation : le Conseil a agi sur la participation des
travailleurs salariés aux bénéfices et aux résultats de l'entreprise par la
recommandation 92/443/CEE, adoptée sur le prédécesseur de l'article 352. Une
recommandation ne crée aucune compétence et le présent exposé des motifs n'en revendique aucune ; ce qu'elle établit est plus étroit et utile : l'Union a
déjà traité la participation aux résultats de l'entreprise comme une
question de niveau européen sur cette base. Ces éléments sont rédigés de
manière à être séparables, précisément pour que l'unanimité qu'ils
requièrent ne puisse prendre en otage les couches fondées sur l'article 114,
et pour qu'un enregistrement partiel ou une annulation partielle élague
l'instrument plutôt que de le détruire.

L'article 114, paragraphe 2, du TFUE exclut les dispositions fiscales, et la
question de qualification qui en découle constitue le risque juridique le
plus sérieux que comporte le présent instrument. Elle est exposée dans toute
sa force et traitée à l'objection 2, et c'est dans cette objection, et non
dans le présent exposé des motifs, que se trouve l'argumentation. En résumé:
l'obligation porte sur un actif et non sur un flux, est payable en actions
et jamais en numéraire, ne finance aucun budget, ne transite par aucun
trésor public et ne confère aucune recette à l'Union. L'avis du Forum de
l'ICE du 27 août 2026 mentionne l'article 115 du TFUE comme base
envisageable si cette qualification venait à échouer ; il est consigné ici,
non retenu. L'article 115 n'exclut pas les dispositions fiscales, mais,
selon l'analyse des conseillers eux-mêmes, il exige la même lecture
d'harmonisation que l'article 114 tout en abandonnant le vote à la majorité
qualifiée, et la rédaction par couches intègre déjà l'unanimité là où elle
est inévitable.

### 2.2 Choix de l'instrument

Un règlement, et non une directive, pour trois raisons. L'obligation s'attache à un nombre restreint d'entreprises opérant sur l'ensemble du marché intérieur, et une transposition dans vingt-sept régimes nationaux reproduirait exactement les divergences que la mesure a pour objet d'éliminer. Le warrant doit avoir un contenu identique dans chaque État membre car une entreprise donnée émet un instrument unique auprès d'une Réserve unique. Et le droit est détenu directement par les citoyens à l'encontre d'un organisme de l'Union, ce qui exige une applicabilité directe plutôt que des mesures nationales d'exécution. Le chapitre V confie l'administration des droits à des véhicules nationaux, ce qui constitue le lieu approprié et autorisé pour les variations nationales.

### 2.3 Subsidiarité

L'objectif ne peut pas être atteint de manière suffisante par les États membres agissant séparément, car les entreprises concernées opèrent sur l'ensemble du marché intérieur et des mesures nationales créeraient précisément la divergence que le règlement élimine. Un régime national de participation s'appliquerait à des entreprises dont la valeur découle d'une activité à l'échelle de l'Union, ce qui, soit manquerait sa cible, soit produirait vingt-sept prétentions incompatibles sur le même capital. Le considérant 34 en contient la formulation formelle.

### 2.4 Proportionnalité

L'ingérence dans le droit de propriété au titre de l'article 17 de la Charte est réelle et n'est pas minimisée dans ce dossier. La proportionnalité est assurée par cinq caractéristiques de la rédaction: le pourcentage est fixe et faible; l'obligation est prospective et ne s'attache qu'à la valeur constituée après la désignation; elle ne se cristallise que lorsque les propriétaires mêmes de l'entreprise réalisent de la valeur; l'évaluation est indépendante et susceptible de recours distinct au titre des articles 6 et 7; et la détention est passive, sans droit de vote, sans siège au conseil d'administration et sans direction de la gestion.

Sur le volet de la nécessité, le présent exposé des motifs prend acte d'une limite plutôt que de revendiquer un point fort. L'article 1er, paragraphe 2, énonce désormais un objectif chiffré, et trois pour cent constitue le plus petit pourcentage entier qui s'en approche selon le modèle publié, de sorte que la nécessité peut pour la première fois être démontrée à partir d'une quantité définie plutôt que simplement affirmée. Toutefois, le modèle étant linéaire par rapport au pourcentage, la cible elle-même est choisie plutôt que déduite. L'objection 21 expose ce point de manière exhaustive, y compris sa circularité, avant qu'un réviseur ne le fasse.

---

## 3. Résultats des évaluations ex post, des consultations des parties prenantes et des analyses d'impact

### 3.1 Évaluations ex post

Néant. Il n'existe aucun instrument de l'Union en vigueur dans ce domaine susceptible d'être évalué.

### 3.2 Consultation des parties prenantes

Aucune consultation formelle n'a été menée, et aucune n'aurait pu l'être : il s'agit d'un projet citoyen et aucune institution n'a procédé à une consultation à son sujet. Affirmer que « les parties prenantes ont été consultées » serait faux, et le présent exposé des motifs ne l'affirmera pas.

Ce qui existe en lieu et place est un examen contradictoire, mené sur le texte à chaque étape et publié dans son intégralité : six points de contrôle couvrant la forme juridique, le respect des contraintes, la base juridique, l'analyse contradictoire hostile, la cohérence avec l'acquis et la fidélité de structure, chaque verdict étant consigné, y compris les échecs, ainsi qu'un registre public consignant ce que chaque cycle a modifié et ce qui a été refusé, motifs à l'appui. Vingt et une objections sont formulées sous leur forme la plus rigoureuse et reçoivent une réponse, plusieurs d'entre elles étant fatales si elles étaient fondées, et au moins deux options de conception complètes ont été écartées au cours de ce processus avant d'atteindre le stade de la publication.

Cela ne remplace pas la consultation des personnes qu'un instrument lierait, et le présent exposé des motifs ne le présente pas comme tel. C'est ce qu'un dossier peut accomplir avant d'avoir qualité pour consulter quiconque. Une demande relative à la recevabilité est en cours d'examen auprès du forum de l'initiative citoyenne européenne.

### 3.3 Analyse d'impact

Aucune analyse d'impact formelle au titre des lignes directrices pour une meilleure réglementation n'a été effectuée, et une initiative citoyenne n'est pas tenue d'en réaliser une. Ce qui suit constitue l'analyse existante, sous la forme utilisée par ces lignes directrices, en précisant ses limites.

**Options stratégiques envisagées.**

*Option 0, absence d'action de l'Union.* Les États membres continuent de légiférer séparément sur les prélèvements sur l'automatisation et les régimes de participation. Les divergences s'accentuent, les entreprises concernées sont confrontées à vingt-sept régimes ou à aucun, et la question de la propriété reçoit une réponse nationale là où elle ne peut trouver de réponse qu'à l'échelle à laquelle opèrent les entreprises. Il s'agit du scénario de référence par rapport auquel les autres options sont évaluées, et c'est l'option que l'examen contradictoire identifie systématiquement comme étant la plus sûre pour le législateur de l'Union et la pire pour l'objectif visé.

*Option 1, une taxe sur la production automatisée ou sur les jetons d'inférence.* Il s'agit de la famille concurrente directe : des propositions législatives de ce type existent dans des pays tiers, y compris une proposition déposée aux États-Unis en août 2026 prévoyant un taux progressif à mesure que le chômage augmente. Elle permet de lever des fonds plus tôt et en montants plus élevés au cours des premières décennies, ce que le warrant ne fait pas. Elle a été rejetée pour deux motifs de fond, et une troisième observation est consignée séparément car elle ne doit pas être confondue avec un motif. Premièrement, il s'agit d'un flux et non d'un actif, de sorte que les citoyens reçoivent un transfert plutôt qu'une détention, et la distinction entre une prestation et une participation constitue la thèse centrale du présent instrument : un transfert est renégocié annuellement et annulable à la majorité simple, une détention constitue une propriété. Deuxièmement, et pour la même raison, elle peut être abrogée par la majorité qui l'adopte, ce que l'historique des ponctions documenté dans le corpus de données probantes montre qu'il ne s'agit pas d'un risque théorique. L'observation distincte est qu'un prélèvement sur la consommation ou sur la production relève sans ambiguïté du domaine fiscal et exigerait l'unanimité en vertu de l'article 113 du TFUE. Il s'agit là d'une conséquence de la nature d'un tel instrument, et non d'un motif de lui préférer le présent instrument, et le présent exposé des motifs ne la présente pas comme telle. La thèse de la propriété est antérieure à toute question de compétence et demeurerait identique si les deux voies requéraient la même majorité. Le lecteur est fondé à mettre à l'épreuve cette affirmation au regard des quatre critères énoncés dans GOVERNANCE.md, qui ont été adoptés avant le choix de toute base juridique et qui rejettent les instruments fondés sur les flux selon leurs propres termes. La comparaison complète, y compris les ordres de grandeur, est publiée sous evidence/token-taxes.md.

*Option 2, un fonds souverain de l'Union capitalisé par le budget.* Cela nécessite des fonds dont l'Union ne dispose pas, entre en concurrence directe avec toutes les autres lignes budgétaires et aboutit à un fonds détenu par l'Union plutôt que par les citoyens, ce qui va à l'encontre de l'objectif d'appropriation et expose les actifs précisément à l'historique de ponctions documenté dans le corpus de données probantes.

*Option 3, une participation assortie de droits de vote.* Une Réserve détenant des actions avec droit de vote conférerait à l'Union une influence sur les entreprises qu'elle régule. Option rejetée : il s'agit du pot de miel assorti d'un levier de l'objection 9 et de l'action spécifique de l'objection 16, que la Cour a invalidée sous toutes ses formes.

*Option 4, le warrant de capital citoyen, privilégiée.* Sans droit de vote, pourcentage fixe, prospective, ne se cristallisant qu'à la réalisation par les propriétaires eux-mêmes, payable uniquement en actions. Elle est retenue parce qu'elle est la seule option identifiée qui transfère la propriété plutôt que des revenus et qui transforme l'abrogation en expropriation : un législateur futur peut toujours s'en saisir, mais il doit le faire au titre d'une privation de propriété, dans le respect de l'article 17 et de l'article 52, paragraphe 1, de la Charte, plutôt qu'en modifiant une ligne budgétaire. La règle DC-23 énonce le principe qui sous-tend ce choix, selon lequel la résistance aux ponctions constitue une friction et jamais une impossibilité, et le présent exposé des motifs ne revendique rien de plus qu'une friction.

**Incidences économiques.** Les entreprises désignées subissent une dilution de trois pour cent de leur capital, en une seule fois, se cristallisant lors de leur propre événement de liquidité, lors d'un prélèvement au profit des actionnaires supérieur au seuil fixé ou à l'échéance butoir de sept ans, la première occurrence étant retenue, de sorte que le calendrier leur appartient uniquement jusqu'à ce que l'échéance butoir soit atteinte. Les investisseurs intégreront dans les prix la dilution future obligatoire dès la désignation, ce qui constitue un coût réel examiné à l'objection 4. Neuf entreprises sont présumées désignées sur la base des chiffres d'août 2026, pour une valeur combinée d'environ 20,5 billions d'euros ; le calcul figure sous evidence/designation-count.md. L'instrument n'a aucun effet sur les entreprises extérieures à cet ensemble, et les petites et moyennes entreprises en sont très éloignées : les entreprises les plus à forte intensité capitalistique dépendantes de la main-d'œuvre observées atteignent un ratio valeur/masse salariale compris entre trente et quarante, pour un seuil fixé à quatre-vingts.

**Incidences sociales.** L'incidence sociale visée est la distribution égale d'une part de propriété aux citoyens de l'Union, sans condition de ressources, demande préalable ni critère d'éligibilité, le droit s'attachant en vertu de la citoyenneté de l'Union et les distributions étant effectuées à compter de l'âge de la majorité conformément à l'article 10 ; son ampleur attendue est énoncée en toute franchise à l'article 1er, paragraphe 2, et dans le simulateur : proche de zéro pendant des années, progressant pour atteindre un ordre de grandeur de quelques centaines d'euros par an sur plusieurs décennies, et sensiblement plus uniquement si l'automatisation transforme l'économie bien au-delà de son état actuel. Le présent règlement ne promet ni statut, ni finalité, ni sens, et le considérant 5 l'indique expressément. Il ne s'agit pas d'une mesure de remplacement du revenu et elle ne peut le devenir à aucun pourcentage que cet instrument pourrait porter : le calcul arithmétique figure sous evidence/sizing-the-ask.md.

**Incidences environnementales.** Évaluées comme non significatives, au regard du principe consistant à « ne pas causer de préjudice important » et de l'obligation de cohérence prévue à l'article 6, paragraphe 4, du règlement (UE) 2021/1119 (la loi européenne sur le climat), plutôt qu'écartées d'emblée. L'instrument ne réglemente ni ce qu'une entreprise produit, ni la manière dont elle le produit, ni l'énergie qu'elle utilise. Il transfère une part de propriété et ne génère aucune activité physique, aucune infrastructure, aucun transport et aucun changement dans les décisions de production, de sorte qu'aucun des six objectifs environnementaux n'est affecté négativement par une disposition opérationnelle quelconque. Les canaux méritant d'être mentionnés sont indirects et sont cités ici afin que le lecteur puisse les soupeser plutôt que de les découvrir. Premièrement, les entreprises désignées comprennent des exploitants d'infrastructures informatiques à forte intensité énergétique, et le règlement n'augmente ni ne restreint cette consommation ; il est neutre à cet égard, ce qui constitue un constat d'absence d'effet et non la revendication d'un avantage. Deuxièmement, une Réserve détenant des participations dans de telles entreprises acquiert une exposition à leur risque de transition, que son obligation de préservation du capital au titre de l'annexe II l'oblige à gérer ; l'article 9 lui interdit d'utiliser cette détention pour orienter la conduite d'une quelconque entreprise, sur le plan environnemental ou autre. Troisièmement, les distributions aux citoyens constituent des revenus du patrimoine d'une ampleur précisée ailleurs dans le présent exposé des motifs, trop faible au cours des décennies concernées pour produire un effet mesurable sur la consommation. Aucun avantage environnemental positif n'est revendiqué, et aucune évaluation de la pérennité climatique au titre de la boîte à outils pour une meilleure réglementation n'a été réalisée. Au vu des éléments disponibles, l'instrument est neutre pour l'environnement par conception.

**Droits fondamentaux.** L'article 17 (propriété) est concerné par l'obligation d'émission et examiné en détail ci-dessus ainsi qu'à l'objection 1. L'article 16 (liberté d'entreprise) est concerné par l'imposition de l'émission. L'article 41 (bonne administration) est concerné par les décisions individuelles de désignation au titre de l'article 3 et par les enquêtes de marché au titre de l'article 4, et est garanti par le droit d'être entendu sur les conclusions préliminaires de la Commission prévu à l'article 4, paragraphe 4, par les délais de décision fixes et par l'obligation de motivation. L'article 47 (recours effectif et tribunal impartial) est concerné par ces mêmes décisions une fois adoptées, par l'évaluation indépendante contraignante au titre des articles 6 et 7 et par les sanctions au titre de l'article 13 ; il est garanti par un contrôle juridictionnel complet devant la Cour de justice, et l'article 7 rend l'évaluation justiciable séparément afin qu'un litige sur la valeur n'ait pas à être intégré dans un litige relatif à la désignation. Les articles 20 et 21 (égalité et non-discrimination) sont concernés par les critères de seuil de l'article 3, paragraphe 2, qui s'appliquent de manière identique aux entreprises de l'Union et des pays tiers. L'article 8 (protection des données à caractère personnel) est concerné par la gestion des droits et traité au considérant 33 et à l'article 11, paragraphe 5. L'article 34 de la Charte (sécurité sociale et aide sociale) est mentionné dans le considérant relatif à la Charte en tant qu'élément de contexte, non comme fondement.

**Incidence budgétaire** : voir section 4.

### 3.4 Adéquation de la réglementation et simplification

L'instrument impose une obligation de notification aux entreprises atteignant les seuils et n'impose rien à quiconque d'autre. Les deux valeurs utilisées dans le critère de désignation figurent déjà dans des comptes audités, de sorte que la conformité ne nécessite aucune nouvelle mesure. La désignation elle-même constitue une décision de la Commission assortie d'un délai fixe, et la voie de réfutation est strictement circonscrite.

### 3.5 Ce dont la présente section ne peut se prévaloir

Il n'y a eu aucune consultation des entreprises qui seraient désignées, aucune modélisation macroéconomique au-delà du simulateur publié, aucun avis du comité d'examen de la réglementation, et aucune évaluation réalisée par des professionnels de la discipline. Chaque énoncé quantitatif ci-dessus repose sur les quatre notes de données probantes et sur le modèle publié, tous reproductibles, aucun n'ayant fait l'objet d'un audit. Le lecteur qui s'appuie sur le présent exposé des motifs doit le considérer comme un projet rigoureusement testé et non comme une analyse d'impact.

---

## 4. Incidence budgétaire

Le règlement ne crée aucune ressource propre de l'Union, aucune recette pour le budget de l'Union et aucune obligation de dépense pour les États membres. Aucun flux de trésorerie n'intervient à aucun moment entre une entreprise et une autorité publique : l'obligation est acquittée en actions, auprès de la Réserve, qui appartient aux citoyens.

Deux coûts sont réels et ne sauraient être masqués par cette architecture. La Commission supporte des coûts administratifs au titre des décisions de désignation, des enquêtes de marché, du régime d'évaluation indépendante et de l'évaluation périodique prévue à l'article 14 ; une estimation dérivée, étalonnée sur les effectifs affectés à l'application du règlement sur les marchés numériques pour une population comparable d'entreprises et présentée sous la forme d'une fourchette plutôt que d'un engagement, évalue ces besoins entre 30 et 60 équivalents temps plein, soit de l'ordre de 5 à 12 millions d'EUR par an au sein des lignes budgétaires existantes (evidence/administrative-cost.md). Les évaluations elles-mêmes sont supportées, à chaque événement, par l'entreprise couverte en vertu de l'article 6, paragraphe 3, à un ratio de coût proche d'un millionième de la valeur couverte, et les coûts de fonctionnement propres de la Réserve sont étalonnés par rapport aux 4 à 5 points de base publiés du fonds norvégien, qu'une conception plus passive devrait permettre de réduire. La Réserve prend en charge les coûts de conservation, d'administration et de distribution, que l'annexe II, point 2, déduit des revenus réalisés avant toute distribution, et l'article 10, paragraphe 6, plafonne les frais que les véhicules nationaux peuvent prélever afin que l'administration ne puisse éroder le droit.

Ces fourchettes constituent des comparaisons étalonnées et non une fiche financière législative ; une proposition de la Commission en nécessiterait une, établie en ayant accès aux données du tableau des effectifs dont le présent dossier ne dispose pas, et l'évaluation au titre de l'article 14 est le mécanisme qui remplacera les fourchettes par des coûts mesurés, à la hausse comme à la baisse. Le point structurel demeure valable indépendamment des fourchettes : les coûts de fonctionnement pèsent sur les revenus propres du fonds et sur l'enveloppe administrative existante de la Commission, non sur de nouveaux crédits, et l'instrument est conçu de sorte qu'une année au cours de laquelle la Réserve ne génère aucun revenu est une année où elle ne distribue rien, plutôt qu'une année où des coûts sont facturés à quiconque.

## 5. Autres éléments

### 5.1 Plans de mise en œuvre et suivi

L'article 14 oblige la Commission à suivre la diffusion des systèmes cognitifs automatisés, la détention d'actions par les ménages, les parts du travail et du capital dans la valeur ajoutée au sein des secteurs concernés, le fonctionnement même du règlement ainsi que l'évolution, à la hausse comme à la baisse, de la part du travail dans l'Union par rapport à 2025. Elle doit procéder à une évaluation et présenter un rapport au plus tard le 31 décembre 2032, puis tous les trois ans.

La condition de réfutabilité constitue la disposition inhabituelle et procède d'un choix délibéré. L'article 14, paragraphe 3, oblige le rapport à indiquer expressément les cas où les éléments de preuve ne corroborent pas la prémisse même du règlement, et à proposer une modification ou une abrogation. L'article 1er, paragraphe 2, oblige ce même rapport à évaluer si l'objectif quantifié est manifestement hors d'atteinte ou manifestement dépassé, et à proposer de modifier le pourcentage ou les seuils, à la hausse comme à la baisse. Un règlement reposant sur une affirmation empirique réfutable se doit de comporter son propre test.

### 5.2 Documents explicatifs

L'ensemble du dossier est public : le dispositif, les considérants, les annexes, le présent exposé des motifs, la note relative aux contre-arguments, la note relative à la divisibilité, la base de données probantes ainsi que chaque avis d'examen, y compris ceux auxquels le texte n'a pas satisfait. L'historique de rédaction constitue un journal des modifications public.

### 5.3 Explication détaillée des dispositions spécifiques

Le chapitre Ier (articles 1er à 2) énonce l'objet, l'objectif quantifié et les définitions. Le chapitre II (articles 3 à 4) procède à la désignation des entreprises couvertes sur la base de critères qualitatifs cumulatifs assortis d'une présomption quantitative réfragable, et prévoit des enquêtes de marché ainsi qu'un réexamen. Le chapitre III (articles 5 à 7) crée le warrant de capital citoyen, ses événements de cristallisation, y compris le déclencheur du prélèvement au profit des actionnaires et l'échéance butoir de sept ans, l'évaluation indépendante et les garanties. Le chapitre IV (articles 8 à 9) institue la Réserve et lui interdit de voter, de diriger, d'acquérir au-delà du warrant ou de recourir à l'effet de levier. Le chapitre V (articles 10 à 11) crée le droit individuel du citoyen et son administration par l'intermédiaire de véhicules nationaux. Le chapitre VI (article 12) protège la Réserve et les droits. Le chapitre VII (articles 13 à 16) prévoit les sanctions, le suivi, les délégations de pouvoir et la procédure de comité. Le chapitre VIII (articles 17 à 18) contient les dispositions transitoires et l'entrée en vigueur. L'annexe I définit la méthodologie de calcul ; l'annexe II, l'arithmétique de rétention et de distribution.

La note relative à la divisibilité précise la manière dont l'instrument se décompose en cas d'invalidation d'une partie, en quatre niveaux, de sorte qu'un enregistrement partiel ou une annulation partielle élague l'instrument au lieu de le détruire.

### 5.4 Points ouverts, énoncés plutôt que dissimulés

- Cinq points d'articulation avec l'acquis, y compris l'interaction avec la directive (UE) 2024/2810 relative aux structures avec actions à droits de vote multiples.
- La question de savoir si un critère par segment d'activité devrait être réintroduit en tant que seconde présomption à l'article 3, paragraphe 2, en cas de constatation d'une dilution par acquisition antérieure à la désignation.
- La question de savoir si l'instrument doit s'étendre à la fabrication de semi-conducteurs, ce que le volet qualitatif et la réfutation prévue à l'article 3, paragraphe 5, laissent actuellement à décider au cas par cas.

Chacun de ces points est consigné dans le registre d'examen ou dans les notes de rédaction, avec le raisonnement qui a conduit à le laisser ouvert.


# FULL SOURCE: own-the-machine/regulation/memorandum/explanatory-memorandum.md

# Explanatory memorandum

Accompanying the draft Regulation of the European Parliament and of the
Council on harmonised rules for citizen participation in automated
productivity gains.

This memorandum follows the structure the Commission uses for its own
proposals. It is written by citizens, not by the Commission, and it is not
required: Regulation (EU) 2019/788 permits a citizens' initiative to attach
a draft legal act and asks nothing of this kind. It exists because the
questions the Commission's services would have to answer about this
instrument are worth answering before they are asked, and because a file
that cannot answer them is not ready to be acted on. Where an answer does
not exist yet, this memorandum says so rather than filling the heading.

---

## 1. Context of the proposal

### 1.1 Reasons for and objectives of the proposal

Automated cognitive systems are beginning to produce output at a scale that
does not require a corresponding quantity of human labour. Where that
decoupling occurs, the returns to production accrue to the holders of the
capital that embodies the automation, and the share reaching citizens
through wages falls with the labour share.

The problem this Regulation addresses is not that outcome in itself, which
is a matter for many instruments, but a narrower one within the Union's
competence: the ownership of the capital in which those returns
concentrate is extremely narrow, and Member States have begun to respond
separately, with divergent national levies, participation schemes and
proposals for taxing automated output. Those divergences fragment the
internal market for exactly the undertakings that operate across all of
it.

The objective is stated and quantified in Article 1(2): participation of
citizens of the Union in the capital value created by hyper-automated
production, at a scale where the holdings behind each citizen's entitlement
reach the order of six months of median equivalised disposable income in the
Union within a generation of the first designations.

### 1.2 Consistency with existing provisions in the policy area

The designation architecture follows Regulation (EU) 2022/1925 (the Digital
Markets Act): cumulative qualitative criteria, quantitative thresholds
giving rise to a rebuttable presumption, self-notification, a
below-threshold designation route on the facts, and an anti-circumvention
power. That is a deliberate reuse of a structure the Union legislature has
already adopted and the Court has not disturbed.

The company-law interface is drafted as express, narrow derogation from
Directive (EU) 2017/1132 rather than as general override, following the
formula of the resolution acquis. The prospectus interface is an express
exemption under Regulation (EU) 2017/1129. Article 1(5) preserves Directive
(EU) 2016/2341 and Regulation (EU) 2019/1238 save as Article 11 provides.

Five acquis interface points remain open and are listed in section 5.4.
They are recorded rather than resolved, which is the honest state.

### 1.3 Consistency with other Union policies

The instrument takes non-voting equity and confers no governance right,
which keeps it outside the field the Court's case law on special public
shareholdings occupies (Commission v Germany, C-112/05, and the line
following it). That choice has a cost, examined at objection 20: voteless
shares raise the relative voting weight of the remaining holders, and the
Union has lately legislated in the other direction on multiple-vote share
structures in Directive (EU) 2024/2810. The interaction with that Directive
is an open interface point, not a resolved one.

Nothing in this Regulation creates a Union own resource, and nothing enters
the Union budget. That is a design constraint, not an incidental property:
see section 4.

---

## 2. Legal basis, subsidiarity and proportionality

### 2.1 Legal basis

The legal basis is stated by layer, not as a single centre of gravity for
the whole act, because incompatible legislative procedures cannot be fused
into one basis (Titanium Dioxide, C-300/89) and because a unitary argument
would concede the weakest layer's characterisation to the strongest layer's
opponents. The severability memorandum sets the layers out; decomposition
rule 3 requires this treatment. Article 114 TFEU carries the designation
regime, the transparency obligations and the warrant: rules addressed to
undertakings operating across the whole internal market, removing the
divergence that separate national participation and automation levies are
already creating. The Commission has registered an initiative resting on
that same divergence logic over comparably contested ground: the 2023
wealth-tax initiative, by Decision (EU) 2023/1487. The independent advice
obtained through the ECI Forum on 27 August 2026, recorded in
pipeline/EXTERNAL-REVIEWS.md and binding on nobody, reads that decision the
same way and recommends citing it here. Article 352 TFEU carries the
elements Article 114 does not reach, namely the establishment of the Reserve
as a Union-level body and the individual entitlement of citizens. That basis
is not untrodden ground for participation: the Council acted on the
participation of employed persons in profits and enterprise results by
Recommendation 92/443/EEC, adopted on Article 352's predecessor. A
recommendation creates no power and this memorandum claims none from it;
what it establishes is narrower and useful, that the Union has treated
participation in enterprise results as a Union-level concern under this
basis before. Those elements are drafted to be severable precisely so that
the unanimity they require cannot hold the Article 114 layers hostage, and
so that partial registration or partial annulment trims the instrument
rather than destroying it.

The preamble of the draft cites Article 114 alone. A single act cannot
carry two legislative procedures: Article 352 requires unanimity in the
Council and the consent of the Parliament where Article 114 requires the
ordinary legislative procedure, and the legal-form and legal-basis gates of
6 September 2026 (pipeline/reviews) confirmed that a citation scoped by
chapter is not an available form. The Reserve, the entitlement and their
protection, Chapters IV to VI, are therefore drafted so that, if Article
114 is held not to reach them, they can be enacted as a separate Council
Regulation on Article 352 with the warrant regime unchanged. That is the
form Layer 3 of the severability memorandum provides for, and it is what
the registration
text's reference to Article 352 contemplates.

Article 114(2) excludes fiscal provisions, and the characterisation question
that follows is the most serious legal risk this instrument carries. It is
stated at full strength and answered at objection 2, and that objection, not
this memorandum, is where the argument lives. The short form: the obligation
takes an asset and not a flow, is payable in shares and never in cash, funds
no budget, passes through no treasury and confers no revenue on the Union.
The ECI Forum's advice of 27 August 2026 notes Article 115 TFEU as a
conceivable basis if that characterisation were to fail; it is recorded
here, not adopted. Article 115 does not exclude fiscal provisions, but on
the advisers' own analysis it demands the same harmonisation reading as
Article 114 while surrendering qualified majority voting, and the layered
drafting already prices unanimity in where it is unavoidable.

### 2.2 Choice of the instrument

A Regulation, and not a Directive, for three reasons. The obligation
attaches to a small number of undertakings operating across the entire
internal market, and transposition into twenty-seven national regimes
would reproduce exactly the divergence the measure exists to remove. The
warrant must have identical content in every Member State because a single
undertaking issues one instrument to one Reserve. And the entitlement is
held directly by citizens against a Union body, which requires direct
applicability rather than national implementing law. Chapter V leaves the
administration of entitlements to national vehicles, which is where
national variation belongs and is permitted.

### 2.3 Subsidiarity

The objective cannot be sufficiently achieved by Member States acting
separately, because the undertakings concerned operate across the entire
internal market and national measures would create the very divergence the
Regulation removes. A national participation scheme would apply to
undertakings whose value arises from Union-wide activity, which either
under-reaches or produces twenty-seven incompatible claims on the same
capital. Recital 34 carries the formal statement.

### 2.4 Proportionality

The interference with the right to property under Article 17 of the Charter
is real and is not minimised in this file. Proportionality is carried by
five features of the drafting: the percentage is fixed and small; the
obligation is prospective and attaches only to value formed after
designation; it crystallises only when the undertaking's own owners realise
value; the valuation is independent and separately justiciable under
Articles 6 and 7; and the holding is passive, with no vote, no board seat
and no direction of management.

On the necessity limb, this memorandum records a limit rather than claiming
a strength. Article 1(2) now states a quantified objective, and three per
cent is the smallest integer percentage that approaches it on the published
model, so necessity can for the first time be argued from a stated quantity
rather than asserted. But the model is linear in the percentage, so the
target itself is chosen rather than derived. Objection 21 sets this out in
full, including the circularity, before a reviewer does.

---

## 3. Results of ex-post evaluations, stakeholder consultations and impact assessments

### 3.1 Ex-post evaluations

None. There is no existing Union instrument in this field to evaluate.

### 3.2 Stakeholder consultations

No formal consultation has been held, and none could be: this is a citizens'
draft and no institution has consulted on it. Saying "stakeholders were
consulted" would be false and this memorandum will not say it.

What exists instead is adversarial review, run against the text at every
stage and published in full: six review gates covering legal form,
constraint compliance, legal basis, hostile counsel, acquis coherence and
layer fidelity, with every verdict committed including the failures, and a
public ledger recording what each round changed and what was refused with
reasons. Twenty-one objections are stated at their strongest and answered,
several of them fatal-if-true, and at least two whole design alternatives
were killed in that process before reaching publication.

That is not a substitute for consulting the people an instrument would
bind, and this memorandum does not present it as one. It is what a file can
do before it has standing to consult anybody. A registrability enquiry is
pending with the European Citizens' Initiative Forum.

### 3.3 Impact assessment

No formal impact assessment under the Better Regulation guidelines has been
carried out, and a citizens' initiative is not required to carry one. What
follows is the analysis that does exist, in the form those guidelines use,
with its limits stated.

**Policy options considered.**

*Option 0, no Union action.* Member States continue to legislate separately
on automation levies and participation schemes. The divergence grows, the
undertakings concerned face twenty-seven regimes or none, and the ownership
question is answered nationally where it can only be answered at the scale
the undertakings operate. This is the baseline against which the others are
measured, and it is the option hostile review consistently identifies as
the safest for the Union legislature and the worst for the objective.

*Option 1, a tax on automated output or on tokens of inference.* This is the
live competing family: legislative proposals of this kind exist in third
countries, including one introduced in the United States in August 2026 with
a rate that escalates as unemployment rises. It raises money sooner and in
larger amounts in the early decades, which the warrant does not. It was
rejected on two substantive grounds, and a third observation is recorded
separately because it must not be mistaken for a reason. First, it is a flow
and not an asset, so citizens receive a transfer rather than a holding, and
the distinction between a benefit and a stake is the entire thesis of this
instrument: a transfer is renegotiated annually and cancellable by simple
majority, a holding is property. Second, and for the same reason, it is
repealable by the majority that enacts it, which the raid history in the
evidence base shows is not a theoretical risk. The separate observation is
that a consumption or output levy is unambiguously fiscal and would require
unanimity under Article 113 TFEU. That is a consequence of what such an
instrument is, not a reason for preferring this one, and this memorandum
does not offer it as one. The ownership thesis is prior to any competence
question and would be the same if both routes required the same majority. A
reader is entitled to test that claim against the four tests in
GOVERNANCE.md, which were adopted before any legal basis was chosen and
which reject flow-based instruments on their own terms. The full comparison,
including the magnitudes, is published at evidence/token-taxes.md.

*Option 2, a Union sovereign wealth fund capitalised from the budget.* This
requires the money the Union does not have, competes directly with every
other budget line, and produces a fund owned by the Union rather than by
citizens, which fails the ownership objective and exposes the assets to
exactly the raid history the evidence base documents.

*Option 3, a voting stake.* A Reserve holding voting shares would give the
Union influence over the undertakings it regulates. Rejected: it is
objection 9's honeypot with a lever attached and objection 16's golden
share, which the Court has struck down in every form it has taken.

*Option 4, the citizens' capital warrant, preferred.* Non-voting, fixed
percentage, prospective, crystallising only at the owners' own realisation,
payable only in shares. It is chosen because it is the only option
identified that transfers ownership rather than income and converts repeal
into expropriation: a future legislature can still take it, but it must do
so as a taking of property, meeting Article 17 and Article 52(1) of the
Charter, rather than by amending a budget line. DC-23 states the rule this
reflects, that raid resistance is friction and never impossibility, and this
memorandum does not claim more than friction.

**Economic impacts.** The designated undertakings bear a dilution of three
per cent of capital, once, crystallising on their own liquidity event, on
shareholder extraction above the stated threshold, or at the seven-year long
stop, whichever comes first, so the timing is theirs only until the long
stop reaches it. Investors will price mandatory future dilution from
designation onward, which is a real cost and is examined at objection 4.
Nine undertakings are presumptively designated on August 2026 figures, with
roughly EUR 20,5 trillion of combined value; the calculation is at
evidence/designation-count.md. The instrument has no effect on any
undertaking outside that set, and small and medium-sized enterprises fall
far outside it: the most capital-intensive labour-reliant undertakings
observed reach a value-to-payroll ratio in the thirties, against a threshold
of eighty.

**Social impacts.** The intended social impact is the distribution of an
ownership stake equally to citizens of the Union, without means test,
application or condition, the entitlement attaching by virtue of Union
citizenship and distributions being made from the age of majority under
Article 10, and its expected magnitude is stated honestly in Article 1(2)
and in the simulator: near zero for years, growing to something of the order
of a few hundred euros a year across decades, and materially more only if
automation transforms the economy far beyond its present state. This
Regulation does not promise status, purpose or meaning, and recital 5 says
so in terms. It is not an income-replacement measure and cannot become one
at any percentage this instrument could carry: the arithmetic is at
evidence/sizing-the-ask.md.

**Environmental impacts.** Assessed as not significant, against the do no
significant harm principle and the consistency duty in Article 6(4) of
Regulation (EU) 2021/1119 (the European Climate Law), rather than dismissed.
The instrument regulates neither what an undertaking produces, nor how, nor
what energy it uses. It transfers a share of ownership and creates no
physical activity, no infrastructure, no transport and no change in any
production decision, so none of the six environmental objectives is
adversely affected by any operative provision. The channels worth naming are
indirect and are named here so that a reader can weigh them rather than
discover them. First, the designated undertakings include operators of
energy-intensive computing infrastructure, and the Regulation neither
increases nor restrains that consumption; it is neutral to it, which is a
statement of no effect and not a claim of benefit. Second, a Reserve holding
equity in such undertakings acquires an exposure to their transition risk,
which its capital-preservation duty under Annex II obliges it to manage;
Article 9 forbids it from using that holding to direct any undertaking's
conduct, environmental or otherwise. Third, distributions to citizens are
property income of a magnitude stated elsewhere in this memorandum, too
small in the relevant decades to produce a measurable consumption effect. No
positive environmental benefit is claimed, and no climate-proofing
assessment under the Better Regulation toolbox has been carried out. On the
evidence available the instrument is environmentally neutral by
construction.

**Fundamental rights.** Article 17 (property) is engaged by the issuance
obligation and examined at length above and at objection 1. Article 16
(freedom to conduct a business) is engaged by compelling issuance. Article
41 (good administration) is engaged by the individual designation decisions
under Article 3 and the market investigations under Article 4, and is served
by the right to be heard on the Commission's preliminary findings in Article
4(4), by the fixed decision deadlines and by the duty to state reasons.
Article 47 (effective remedy and fair trial) is engaged by those same
decisions once taken, by the binding independent valuation under Articles 6
and 7 and by the penalties under Article 13; it is served by full judicial
review before the Court of Justice, and Article 7 makes the valuation
separately justiciable so that a dispute about value need not be carried
inside a dispute about designation. Articles 20 and 21 (equality and non-
discrimination) are engaged by the threshold criteria in Article 3(2), which
apply identically to Union and third-country undertakings. Article 8
(protection of personal data) is engaged by the administration of
entitlements and addressed in recital 33 and Article 11(5). Article 34 of
the Charter (social security and social assistance) is referenced in the
Charter recital as context, not as a basis.

**Budgetary implications**: see section 4.

### 3.4 Regulatory fitness and simplification

The instrument imposes a notification duty on undertakings meeting the
thresholds and nothing on anyone else. Both figures in the designation test
are already in audited accounts, so compliance requires no new
measurement. Designation itself is a Commission decision with a fixed
deadline, and the rebuttal route is cabined.

### 3.5 What this section cannot claim

There has been no consultation of the undertakings that would be
designated, no macroeconomic modelling beyond the published simulator, no
Regulatory Scrutiny Board opinion, and no assessment by anyone who does
this professionally. Every quantitative statement above rests on the four
evidence notes and the published model, all reproducible, none audited. A
reader relying on this memorandum should treat it as a well-tested draft
and not as an impact assessment.

---

## 4. Budgetary implications

The Regulation creates no Union own resource, no revenue for the Union
budget and no expenditure obligation on the Member States. No cash flows
from any undertaking to any public authority at any point: the obligation
is discharged in shares, to the Reserve, which is owned by citizens.

Two costs are real and should not be hidden by that architecture. The
Commission bears administrative costs for designation decisions, market
investigations, the independent valuation regime and the periodic evaluation
under Article 14; a derived estimate, calibrated against the Digital Markets
Act's enforcement staffing for a comparable population of undertakings and
stated as a range rather than a promise, puts this at 30 to 60 full-time
equivalents, in the order of EUR 5 to 12 million a year within existing
budget headings (evidence/administrative-cost.md). The valuations themselves
are borne per event by the covered undertaking under Article 6(3), at a cost
ratio near one part in a million of the covered value, and the Reserve's own
running costs are benchmarked against the Norwegian fund's published 4 to 5
basis points, which its more passive design should undercut. The Reserve
bears the costs of custody, administration and distribution, which Annex II
point 2 deducts from realised income before anything is distributed, and
Article 10(6) caps the fees national vehicles may levy so that
administration cannot erode the entitlement.

These ranges are calibrated comparisons, not a legislative financial
statement; a Commission proposal would require one, prepared with access to
establishment-plan data this file does not have, and the Article 14
evaluation is the mechanism that will replace the ranges with measured cost,
in both directions. The structural point stands independently of the ranges:
the running costs fall on the fund's own income and on the Commission's
existing administrative envelope, not on a new appropriation, and the
instrument is designed so that a year in which the Reserve earns nothing is
a year in which it distributes nothing rather than a year in which someone
is billed.

---

## 5. Other elements

### 5.1 Implementation plans and monitoring

Article 14 obliges the Commission to monitor the diffusion of automated
cognitive systems, household equity holdings, the labour and capital shares
of value added in the sectors concerned, the Regulation's own operation,
and the evolution of the Union labour share against 2025 in either
direction. It must evaluate and report by 31 December 2032 and every three
years thereafter.

The falsification condition is the unusual part and is deliberate. Article
14(3) obliges the report to state expressly where the evidence does not
support the Regulation's own premise, and to propose amendment or repeal.
Article 1(2) obliges the same report to assess whether the quantified
objective is manifestly unattainable or manifestly exceeded, and to propose
amending the percentage or the thresholds in either direction. A regulation
resting on a falsifiable empirical claim should carry its own test.

### 5.2 Explanatory documents

The whole file is public: the enacting terms, the recitals, the annexes,
this memorandum, the counter-arguments memorandum, the severability
memorandum, the evidence base and every review verdict including the ones
the text failed. The drafting history is a public commit log.

### 5.3 Detailed explanation of the specific provisions

Chapter I (Articles 1 to 2) states the subject matter, the quantified
objective and the definitions. Chapter II (Articles 3 to 4) designates
covered undertakings on cumulative qualitative criteria with a rebuttable
quantitative presumption, and provides for market investigation and review.
Chapter III (Articles 5 to 7) creates the citizens' capital warrant, its
crystallisation events including the extraction trigger and the seven-year
long stop, the independent valuation and the safeguards. Chapter IV
(Articles 8 to 9) establishes the Reserve and prohibits it from voting,
directing, acquiring beyond the warrant, or leveraging. Chapter V (Articles
10 to 11) creates the individual entitlement and its administration through
national vehicles. Chapter VI (Article 12) protects the Reserve and the
entitlements. Chapter VII (Articles 13 to 16) provides penalties,
monitoring, delegation and committee procedure. Chapter VIII (Articles 17
to 18) contains the transitional provisions and entry into force. Annex I
carries the counting methodology; Annex II the retention and distribution
arithmetic.

The severability memorandum sets out how the instrument decomposes if a
part fails, in four layers, so that partial registration or partial
annulment trims rather than destroys.

### 5.4 Open points, stated rather than concealed

- Five acquis interface points, including the interaction with Directive
  (EU) 2024/2810 on multiple-vote share structures.
- Whether a segment-level limb should return as a second presumption in
  Article 3(2) if pre-designation dilution by acquisition is observed.
- Whether the instrument should reach semiconductor fabrication at all,
  which the qualitative limb and the Article 3(5) rebuttal currently leave
  to be decided case by case.

Each of these is on the record in the review ledger or the drafting notes
with the reasoning that left it open.


# FULL SOURCE: own-the-machine/regulation/memorandum/severability.md

# Severability layering

How the instrument decomposes when institutions start cutting, and what
each cut costs. This document is strategy, not law: it binds the drafters
and the campaign, and the layer-fidelity gate reviews the articles against
it. It exists because the legal-basis gate's standing finding is real: the
complete instrument's centre of gravity is contestable, and the honest
response is to know in advance which parts stand on which legal basis, and
what the ask becomes at each stage of trimming.

## The four layers

### Layer 0: the question (survives everything)

The ask that survives any trimming, including partial registration of a
European Citizens' Initiative under the settled case law allowing it:

> The Commission is asked to assess, and to propose instruments for,
> the participation of citizens of the Union in the productivity gains of
> hyper-automated production, including designation criteria for
> undertakings whose output is substantially decoupled from employment,
> and mechanisms by which the gains of such production become broadly
> owned.

Nothing in Layer 0 requires any particular legal basis, because it asks
for an assessment and a proposal, which is what an initiative may ask.
Registration of Layer 0 is the Gate 1 floor: if the Commission will not
register even this, the project's premise about the legal channel fails
and the kill criterion in campaign/GATES.md applies.

### Layer 1: designation and transparency (Article 114 TFEU, comfortable)

Articles 1 to 4, 14, 16, 18, with Annex I; penalties limited to the
notification and information duties; recitals 1 to 8, 30 to 32, 34 to 36.

A regulation that designates hyper-automated undertakings on harmonised
criteria, makes the designation public, and reports on adoption,
employment effects and ownership concentration. It harmonises exactly the
thing Member States are starting to do divergently, on the DMA's own
architecture, and it carries the falsification condition. No warrant, no
Reserve, no entitlement.

This layer is defensible under Article 114 on the DMA precedent with no
novel doctrine. It is also, standing alone, worth having: designation
plus the Article 14 evidence base is what every subsequent instrument,
Union or national, would build on.

### Layer 2: the warrant (Article 114 TFEU, contested; fallback 352)

Articles 5 to 7, 13 in full, 15, 17, with the company-law derogations and
the valuation machinery; recitals 9 to 20, 29.

The obligation to issue the citizens' capital warrant, crystallising on
the first liquidity event, on shareholder extraction above the stated
share of covered turnover or on the seven-year long-stop, whichever comes
first, with the BRRD-pattern safeguards. The Article
114 case: it removes the incentive for divergent national levies and
participation schemes (recital 1), harmonises the company-law derogations
the subscription needs, and secures the level playing field between Union
and third-country undertakings. The attack (legal-basis gate, first run):
the centre of gravity is redistribution, not market-building, and
Article 114(2) excludes fiscal provisions; the controlling line is Tobacco
Advertising (C-376/98), which demands genuine obstacles or appreciable
distortions, not a desirable policy. The defence rests on the
non-fiscal structure being real (Article 8's insulation, settlement in
shares only), not asserted, and on recital 1's divergence record being
genuine.

If the characterisation fails, this layer moves to Article 352: unanimity
in Council, consent of the Parliament. That is a political mountain, and
this document says so rather than pretending otherwise.

### Layer 3: the Reserve and the entitlement (Article 352 TFEU, honestly)

Articles 8 to 12, with Annex II; recitals 21 to 28, 33.

The Reserve as a new Union-level body holding assets for citizens, the
universal entitlement arising by operation of law, national vehicles, the
raid-proofing. Creating a new body with legal personality and a direct
Union-to-citizen property relationship is where Article 114 is weakest and
where the subsidiarity objection concentrates. The body-creation precedents
cut both ways: Article 114 has sustained Union bodies that serve
harmonisation (ENISA, C-217/04; ESMA's intervention powers, C-270/12), but a
new legal form standing apart from national laws required what is now
Article 352 (the European Cooperative Society, C-436/03), and a Reserve
owing citizens a direct property relationship resembles the second more than
the first. The honest position: Layer 3 is drafted to be defensible under
Article 352, and its unanimity requirement is priced in. The campaign's
answer to "you will never get unanimity" is the wealth-tax precedent: the
fight is meant for the Council, in public, on the record. The basis itself
has carried participation before: Council Recommendation 92/443/EEC, on the
promotion of participation by employed persons in profits and enterprise
results, was adopted on Article 352's predecessor, a reference supplied by
the ECI Forum's advice of 27 August 2026 (pipeline/EXTERNAL-REVIEWS.md,
review 4). A recommendation confers no power; it shows the terrain is not
untrodden.

## Decomposition rules

1. Every layer must function with the layers above it struck. Layer 1
   without Layers 2 and 3 is a designation-and-evidence regulation.
   Layers 1 and 2 without Layer 3 would park crystallised shares with an
   independent depositary pending a distribution instrument; that escrow
   amendment is not in the draft, because in the draft the Reserve
   exists, but it is the prepared answer if Layer 3 is severed in
   legislative procedure, and no article may be drafted in a way that
   forecloses it.
2. No article may create a dependency downward on a higher-numbered
   layer's existence, other than Layer 2's delivery of shares to the
   Reserve, for which point 1's escrow is the severance answer.
3. The memorandum must argue each layer's basis separately. A single
   centre-of-gravity argument for the whole instrument concedes the
   weakest layer's characterisation to the strongest layer's opponents.
4. At Council stage, concessions run top down: Layer 3 is conceded to a
   separate instrument before Layer 2 is weakened, and Layer 2 is
   conceded to Article 352 procedure before Layer 1 is abandoned.
   Nothing in Layer 1 is conceded; it is the floor above Layer 0.
5. The ECI registration ask is Layer 0 as primary request with the full
   Regulation annexed as the suggested instrument, so that partial
   registration, if the Commission insists on it, trims the annex and
   not the ask.

**This rule was an assumption until 27 August 2026; it is now a finding,
within the limits of its source.** The ECI Forum's legal advice service,
answering questions 2 and 3 of campaign/GATE1-LETTER.md (reply of 27 August
2026, recorded verbatim in pipeline/EXTERNAL-REVIEWS.md, review 4), states
that if the goals comply with the ECI Regulation the initiative must be
registered "regardless of the mechanism described in your proposed legal
act", that the mechanism's contestability "is not a relevant consideration
for the registration", and that a full draft act may be provided where it
shows the proposal falls within the Commission's competence. The contrary
reading surfaced on 21 August, that the annex enlarges what is assessed, did
not survive the question. The limits: the advice is independent, expressly
non-binding on the Commission, and a finding about the registration stage
only; it says nothing about how the annex fares in legislative procedure,
which is what rules 1 to 4 are for.

## What this costs and why it is worth it

Layering is a concession in advance, and hostile readers will quote it as
lack of confidence. The alternative is a monolith that dies whole at its
weakest point, which is how most redistributive proposals at Union level
have died. The book's own analysis is that the mechanism matters more
than the vehicle: designation and evidence (Layer 1) create the factual
record; the warrant (Layer 2) is the mechanism; the Reserve (Layer 3) is
one distribution architecture among several possible. Losing Layer 3 to
an intergovernmental or successor instrument loses elegance, not the
point.


# FULL SOURCE: own-the-machine/regulation/recitals.md

# Recitals

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 114 thereof,

Having regard to the proposal from the European Commission,

After transmission of the draft legislative act to the national parliaments,

Having regard to the opinion of the European Economic and Social Committee,

Acting in accordance with the ordinary legislative procedure,

Whereas:

(1) The internal market comprises an area without internal frontiers in
which the free movement of goods, services, persons and capital is ensured.
The conditions under which highly automated undertakings operate in the
internal market are increasingly the subject of divergent national
initiatives, including proposals for levies on automated production,
national social-dividend schemes and mandatory employee-participation
regimes extended to undertakings with few employees. Such divergence
creates fragmentation, distorts competition and gives undertakings an
incentive to locate activities according to regulatory exposure rather
than economic merit. That this is the pattern rather than a
possibility is established by the taxation of digital activity, where
the absence of a Union measure was followed by unilateral national
taxes in eight Member States, at rates, on bases and with
thresholds that do not correspond, so that the same undertaking falls
inside one national regime and outside its neighbour's on identical
revenue. Harmonised rules at Union level are therefore necessary, and
are more effective before national answers multiply than after.

(2) Advances in artificial intelligence and related automation
technologies enable a new category of undertaking: one which attains very
substantial turnover and market value while engaging very little human
labour in production. Such undertakings are lawful, productive and often
beneficial. Their emergence is nevertheless economically unprecedented,
because the mechanisms by which productivity gains have historically been
diffused through the population, above all wages and the broad taxation of
labour income, presuppose that production requires labour at scale.

(3) Where output is substantially decoupled from employment, the gains
from automation accrue by default to a narrow base of shareholders. No
existing instrument of Union law addresses the resulting concentration of
capital ownership. Competition law addresses conduct, not ownership;
Regulation (EU) 2022/1925 addresses the contestability of digital markets;
Regulation (EU) 2024/1689 addresses the safety of artificial intelligence
systems. This Regulation complements those instruments by addressing the
distribution of the ownership of automated production itself.

(4) The appropriate response is not a tax on the flows of automated
production. Taxes on flows burden activity year by year, are borne in part
by consumers and employees, depend on annual political renewal and treat
the gains of automation as public revenue to be spent. The response chosen
by this Regulation operates on assets instead: a limited, one-time right
to subscribe for equity in the most labour-decoupled undertakings, held in
a common reserve for the benefit of all Union citizens. An equity stake
participates in gains only where gains exist, imposes no recurring burden
on production and converts the automation dividend into broadly held
capital rather than public expenditure.

(5) This Regulation addresses the distribution of the capital value
created by hyper-automated production and does not purport to regulate
employment, wages, taxation as such, or the internal organisation of
undertakings beyond what the citizens' capital warrant requires. It does
not promise status, purpose, meaning or the other goods that employment
supplies as a by-product, and nothing in this Regulation, and no material
presenting it, should be read as making such a promise. Its object is
narrower and more precise than that: a broadly held equity stake in the
value that automation creates, and nothing beyond it. That object is
stated in Article 1 with its scale: an ownership position for each
citizen measured against a published statistic of Union living
standards, reached within a generation, so that the necessity of the
percentage laid down in Article 5 can be assessed against a stated
objective and revisited on the evidence. The stake is the objective;
distributions remain the property income that follows from ownership
and are not the purpose of the obligation.

(6) So that the obligations laid down in this Regulation apply only to
undertakings in which the decoupling of output from labour is extreme,
durable and of Union significance, undertakings should be designated on the
basis of objective qualitative criteria, accompanied by quantitative
thresholds giving rise to a rebuttable presumption. That architecture, which
follows the model of Regulation (EU) 2022/1925, provides legal certainty for
undertakings while preserving the ability of the Commission to designate on
the facts and to disregard arrangements whose main purpose or effect is the
avoidance of designation. Designation should be capable of preceding any
liquidity event and of applying irrespective of admission to trading,
because the warrant attaches to value at its formation and a contrary rule
would let an undertaking place itself beyond the Regulation by remaining
private; and arrangements whose main purpose or effect is the avoidance of
designation are disregarded, which is the settled anti-circumvention formula
of Union market regulation and restricts no restructuring undertaken for
genuine commercial reasons. Small and medium-sized enterprises fall far
outside the thresholds and are unaffected by this Regulation.

(7) The quantitative thresholds should capture only undertakings of very
substantial scale whose market valuation stands in a proportion to their
expenditure on human labour that has no precedent among labour-intensive
undertakings. Compensation of labour is the appropriate measure of the
labour actually engaged, because it is recorded in audited accounts and
cannot be increased without genuine payment for genuine work, so that an
undertaking reduces its decoupling ratio only by remunerating labour,
which is consistent with the objectives of this Regulation. The ratio
laid down in this Regulation is fixed in its own terms, so that an
undertaking can establish its position from its own audited accounts
alone: it exceeds by a margin of more than double the highest ratios
observed among capital-intensive undertakings whose value remains
explained by their expenditure on labour, and by an order of magnitude
the prevailing ratio among large undertakings admitted to trading in the
Union. It is reviewed under Article 14 and may be amended only by the
ordinary legislative procedure. For the same reasons the thresholds are
assessed at the level of the group of linked enterprises, the single
economic unit to which the value of the automated services accrues.

(8) Designation should follow a notification by the undertaking itself
within a fixed period, with a decision of the Commission within a fixed
period thereafter. Arguments against the presumption should be taken into
account only where they manifestly call it into question, and arguments
based on the definition of the relevant market should not be taken into
account, since designation does not depend on a finding of market power.
Where a designation is repealed, a warrant not yet crystallised should
lapse after five years, ensuring legal certainty for the undertaking while
preserving for a reasonable period the rights acquired by the Reserve.

(9) The citizens' capital warrant should be modest, precise and singular:
a right to subscribe, at nominal value, for shares representing 3 % of the
fully diluted capital of the covered undertaking, once per designation.
The warrant should confer no voting rights and no influence over
management, so that neither the Union nor any public authority obtains
control or direction of any undertaking by virtue of this Regulation. This
Regulation therefore leaves untouched the rules in Member States governing
the system of property ownership and does not effect any transfer of any
undertaking to public ownership.

(10) The warrant should crystallise upon the first liquidity event
following designation: an admission to trading, a change of control or a
substantial secondary sale. It should also crystallise, on the same terms
and before any liquidity event, where the covered undertaking extracts
value to its own shareholders above the threshold this Regulation sets
for that purpose, or where seven years have elapsed since the warrant was
issued. Attaching the public stake to the point at which the
undertaking's own choices, or the mere elapse of that period, make value
claimable keeps the warrant dormant until one of those points is reached
and interferes with no going concern before it is. For the same reason,
an admission to trading which occurred before the entry into force of
this Regulation should not constitute a liquidity event, and this
Regulation should not apply to a liquidity event or other crystallising
event completed before its entry into force.

(11) Shareholder extraction above the threshold this Regulation sets for
that purpose should crystallise the warrant on the same footing as a
liquidity event, because in substance it is the same event. A liquidity
event realises value for the shareholders of a covered undertaking by
converting an unrealised stake into cash or its equivalent; extraction
realises the same value by a different route, distributing it directly to
those shareholders without any sale of the undertaking itself. An
instrument that crystallised only on a sale, an admission to trading or a
comparable transaction would depend on the form the owners of a covered
undertaking choose for taking value out of it, and owners able to achieve
the same result by dividend, buy-back or capital reduction would have
every reason to choose that form instead. The extraction trigger closes
that route, without altering the liquidity-event trigger in any other
respect.

(12) The seven-year long-stop answers a case the liquidity-event and
extraction triggers do not reach: an undertaking that remains privately
held indefinitely, keeps its distributions to shareholders below the
extraction threshold, and so never crystallises the warrant at all, while
its value continues nonetheless to accrue for the benefit of those
shareholders. Absent a long-stop, such an undertaking could defeat the
objective of this Regulation by the simple expedient of staying private
and patient. The long-stop is the answer to that possibility, and it is
proportionate under Article 52(1) of the Charter of Fundamental Rights of
the European Union: it is quantified in years rather than left to
discretion, it is known to the undertaking from the moment of its
designation, and it is subject to the same independent valuation and the
same separate right of challenge before the courts that apply to
crystallisation at a liquidity event.

(13) The warrant should be incapable of settlement in cash. It confers an
entitlement to shares and to nothing else. It is accordingly not a levy,
not a charge on turnover or profit and not revenue of any public
authority, and it is so designed that no payment obligation towards any
budget can arise from it. In excluding settlement in money, the
prohibition restricts the freedom of the undertaking to structure the
discharge of its obligation; that restriction is justified and
proportionate, because it confines the interference to capital ownership
and keeps the undertaking's operating liquidity untouched, which a cash
alternative would not.

(14) Undertakings within the scope of this Regulation include undertakings
governed by the law of third countries which meet the thresholds through
their activity in the internal market. Equal treatment and the level
playing field require that such undertakings assume obligations of
equivalent effect. The obligations laid down in this Regulation attach
only where activity in the internal market meets the thresholds laid down
in it, so that their application to such undertakings rests on the
immediate, substantial and foreseeable effects of their conduct within
the internal market and not on the mere accessibility of their services.
Where the law governing an undertaking does not give
effect to the subscription right, the undertaking should be required to
procure a subscription of equivalent effect as an obligation of result,
without prejudice to the company law of its incorporation, and compliance
should be secured through the enforcement powers laid down in this Regulation,
including, as a last resort, the power to prohibit the making available of
the relevant goods and services on the internal market.

(15) The issuance of shares pursuant to a citizens' capital warrant
requires derogations from certain provisions of Directive (EU) 2017/1132
of the European Parliament and of the Council concerning pre-emption
rights and the consideration for issued shares. Comparable derogations,
adopted in the general interest, form part of the established acquis in
the field of bank recovery and resolution. Because the shares subscribed
by the Reserve are non-voting for as long as it holds them, provisions of
the law of a Member State that restrict the proportion, issuance
conditions or characteristics of non-voting shares should not apply to the
extent that they would prevent the issuance or holding of those shares. The derogations provided for in this Regulation
are strictly limited to what the execution of the subscription requires,
and they are necessary: an issuance that existing shareholders could
pre-empt, that could be made conditional on a resolution of the general
meeting, or that a Member State's non-voting-share rules could block
outright, could not perform the function this Regulation assigns to it.

(16) The shares subscribed pursuant to the citizens' capital warrant
should rank, for the Reserve, equally with the most favourable class of
shares created after the covered undertaking's designation, and otherwise
equally with its ordinary shares, without affecting the ranking of any
creditor. Ranking the Reserve behind classes created after designation
would let the interference be diluted by the covered undertaking's own
subsequent choices; ranking it above every class, including preference
shares subscribed and paid for before designation, would take from those
earlier investors the protection they bargained and paid for, which this
Regulation does not do. Equal ranking with the most favourable class
created after designation, and no disturbance of the claims of creditors,
confines the interference to what the warrant is: an equity interest, not
a priority claim.

(17) The obligations laid down in this Regulation would be of little
value if they could be routed around by an arrangement that subordinates
the Reserve's participation, by moving the automated assets on which a
covered undertaking's designation rests into another entity, or by the
extinguishment of the warrant in an insolvency or restructuring procedure
engineered or exploited by the same persons who controlled the covered
undertaking. An arrangement that subordinates, reduces or defeats the
Reserve's participation should accordingly be ineffective as against the
Reserve, while remaining effective between the parties to it and as
against third parties, so that anti-avoidance is achieved without
unwinding transactions to which the Reserve was not a party. Where a
covered undertaking transfers its automated assets to another undertaking
otherwise than at arm's length, or to a member of its own group or a
person who controls it or is controlled by it, the obligations laid down
in this Regulation should attach to the transferee as if it were the
covered undertaking, so that the assets which carry the value cannot be
moved beyond the warrant's reach while the covered undertaking that
issued it remains bound in respect of what it retains. Anti-avoidance
should not become a multiplier: a group that divides its automated assets
among several entities should owe the same share of its capital as one
that does not, and the stated percentage should therefore apply to the
dilution borne by the shareholders of the covered undertaking and of every
transferee taken together, and not separately to each of them. Where those assets are instead
acquired in an insolvency or restructuring procedure and control of the
transferee ends up, directly or indirectly, with the persons who
controlled the covered undertaking, or with persons acting in concert or
connected with them, the same obligations should reattach to the
transferee, because no genuine change of ownership has in substance
occurred. That reattachment should not extend to a transferee controlled
by persons who did not control the covered undertaking: a genuine sale to
unconnected purchasers in insolvency or restructuring is the ordinary
operation of that law, not an avoidance of this Regulation, and should be
left to run its course without the obligations of this Regulation
attaching to it.

(18) This Regulation interferes with the right to property of the
shareholders of covered undertakings, whose holdings are diluted upon
crystallisation. That interference is provided for by law, genuinely meets
an objective of general interest recognised by the Union and respects the
essence of the right to property: it is a one-time dilution, capped at a
stated percentage, borne at a moment of realised gain by the shareholders
of undertakings whose value derives from an unprecedented decoupling of
output from labour. The Court of Justice has consistently held that the
right to property is not absolute and that its exercise may be regulated
where regulation is proportionate to a legitimate aim of general
interest. The interference effected by this Regulation is quantified,
foreseeable from designation and less intrusive than measures already
upheld in the field of bank resolution. Subscription at nominal
value rather than by gratuitous transfer keeps the mechanism within the
forms of company law while ensuring that the interference is the stated
dilution and nothing more; requiring the Reserve to pay a market price
would demand public expenditure this Regulation is designed not to need
and would convert a mechanism of ownership into a budgetary one. The fair balance rests also on
what the covered undertaking receives: a single harmonised regime of
access to the internal market in place of divergent national levies and
participation schemes, and the legal certainty of an interference fixed
in advance in amount and in moment.

(19) Proportionality further requires safeguards. The dilution borne by
shareholders is capped by this Regulation and verified by an independent
valuation, which is challengeable separately from the transaction it
accompanies and correctable in both directions. The safeguard the
valuation secures is that the interference can never exceed the stated
percentage in execution: the dilution is capped, its price is set by the
event that crystallises it, and no application of this Regulation may take
from shareholders more than the interference it names. That executional
ceiling, not a crisis counterfactual, is what keeps the interference
proportionate in a permanent regime. Neither designation nor
crystallisation suspends, conditions or unwinds any transaction. Every
decision taken under this Regulation is subject to effective judicial
protection in accordance with Article 47 of the Charter of Fundamental
Rights of the European Union.

(20) Where a liquidity event itself establishes a price, a valuation
delivered in advance of the event would be conjecture about a number the
event is about to produce. The independent valuation should therefore be
delivered promptly after completion, while the legal effect of the
subscription attaches at completion and its execution follows delivery of
the valuation.

(21) The European Citizens' Capital Reserve should hold the warrants and
the shares arising from them exclusively for the benefit of holders. Its
assets and income are not public revenue: they should not enter the
general budget of the Union or any national budget, and no payment should
flow between the Reserve and any budget in either direction. In this the
Reserve resembles a statutory funded pension scheme, whose assets are held
for beneficiaries and are not at the disposal of any treasury, rather than
a fund of the Union. The insulation of the Reserve from public finances is
not an administrative preference but a constitutive feature: it is what
makes this Regulation a mechanism of ownership rather than of taxation.

(22) Income from holdings in undertakings governed by the law of a third
country may be taxed at source in that country at rates which the Reserve,
being resident in no State, may be unable to reduce by treaty. The remedy, where there is one, lies in
international agreements, which are concluded in accordance with the
procedures laid down in the Treaties and which this Regulation neither
prejudges nor requires. This Regulation does not direct the Reserve to
arrange its holdings so as to reduce taxation in a third country; an
instrument founded on the proposition that capital should be broadly owned
is in no position to legislate its own treaty shopping. What this
Regulation can do, and does, is oblige the Reserve to report each year the
amount it was unable to recover, so that the cost is known rather than
assumed away.

(23) The Reserve should be a passive owner. It should exercise no votes,
seek no influence over the management of any undertaking and pursue no
industrial policy. Its function is to hold and to distribute, not to
direct. The mandatory presence of the Reserve in the capital of covered
undertakings restricts the free movement of capital. That restriction is
justified: it serves the general interest set out in these recitals, it
applies without distinction to undertakings and investors of the Union
and of third countries, and it is proportionate precisely because the
statutory passivity of the Reserve withholds from it every attribute of
special control that has led the Court of Justice to censure public
shareholdings. A holding which can neither vote nor veto nor instruct
exerts no public influence for an investor to fear.

(24) The Reserve should retain from its income what is necessary to
preserve the real value of its capital and distribute the remainder. That
rule, drawn from the practice of long-horizon sovereign funds, means
distributions grow with the portfolio and compound across decades. It also
means distributions begin modestly. This Regulation makes no promise of
substantial early payments and should not be presented as making one; its
horizon is generational.

(25) Every citizen of the Union who has reached the age of 18 years should
hold an equal entitlement in the Reserve by operation of law, without
application, means test or condition. Universality is design, not
generosity: a means-tested entitlement would divide the population into
contributors and recipients, invite perpetual contestation of the boundary
and convert an ownership stake into a welfare payment. An equal
entitlement held by all is defensible by all.

(26) The entitlement should be personal. It should be incapable of
transfer, assignment, pledge, attachment, surrender or redemption, so that
it cannot be bought out of the hands of those it serves, whether by
markets, by creditors or by the holder's own moment of hardship. That
restriction on the alienability of the entitlement is a justified and
proportionate limitation under Article 52(1) of the Charter and respects
the essence of the right, since it attaches to the underlying entitlement
only, while amounts distributed are the holder's property, freely usable
and inheritable, and it is necessary so that the objective of durable,
broadly held capital ownership is not defeated by immediate liquidation.
Amounts
distributed, once received, are ordinary property of the holder,
inheritable and freely usable.

(27) Member States should administer entitlements through national
vehicles, since Member States hold the civil registries and payment
infrastructure that administration requires. Administration fees should be
capped and entitlements portable, so that the quality of a Member State's
administration cannot diminish the substance of a citizen's entitlement.
The cap on fees limits the freedom of designated vehicles to set prices;
that limitation is necessary and proportionate to prevent the erosion of
the entitlement by administrative costs. The administration of
entitlements is a service of general economic interest, and the cap is
compatible with the freedom to conduct a business on the conditions
Article 106(2) TFEU attaches to such services and proportionate under
Article 52(1) of the Charter; Member States remain free
to compensate designated vehicles for verifiable net costs above the cap.

(28) The history of pooled public assets is a history of raids. The assets
of the Reserve should therefore be protected by enumerated prohibitions on
lending, guarantee, transfer and encumbrance in favour of public
authorities, and the Reserve should not acquire sovereign debt, so that it
cannot become a captive purchaser of the obligations of any government.
The exclusion of sovereign debt is a rule of portfolio governance internal
to the Reserve, securing its independence, and restricts no movement of
capital by any other person. An
ordinary regulation cannot bind future legislatures, and this Regulation
does not pretend otherwise; what it can do is ensure that no derogation
from these protections arises by interpretation, and that any future
weakening would need to be enacted expressly, in public, informed by the
independent assessment its reporting provisions require.

(29) Penalties for non-compliance should be effective, proportionate and
dissuasive, and set at a level meaningful to undertakings of the scale
designated. Fines and periodic penalty payments should accrue to the
general budget of the Union and not to the Reserve, so that the body
holding assets for citizens never acquires a financial interest in the
punishment of undertakings. Where an undertaking governed by the law of a
third country persistently refuses to comply with its core obligations,
the Commission should be empowered, as a measure of last resort and
subject to proportionality, to prohibit the making available of the
relevant goods and services on the internal market, since no other means
of enforcement reaches an undertaking with no assets in the Union. Such a
prohibition restricts the freedom to conduct a business recognised by
Article 16 of the Charter of Fundamental Rights of the European Union, and
should accordingly remain available only where no less restrictive measure
can secure compliance, for as long as the refusal persists and no longer.
So conditioned, the prohibition respects the essence of that freedom: it
is temporary, reversible on compliance and confined to the goods and
services concerned, and it leaves the undertaking's activity outside the
internal market untouched.

(30) The premise of this Regulation, that automation at the designated
scale durably decouples output from labour and concentrates ownership, is
an empirical claim, and empirical claims can prove wrong. The Commission
should monitor adoption, employment effects and ownership concentration,
and where the evidence does not support the premise, should state so
expressly and propose amendment or repeal. A regulation founded on a
falsifiable claim should carry its own test. The same monitoring should
extend to the share of value added accruing to labour in the Union as a
whole, in both directions: where that share declines, the evidence
informs the assessment under Article 1 of whether the participation
secured remains adequate to its objective, and where it does not
decline, the same assessment asks whether the obligations imposed remain
justified at their level, so that the indicator moves no obligation of
any undertaking but disciplines the instrument itself.

(31) In order to keep the methodologies for counting turnover, employment
and value, and for calculating the retention necessary to preserve the
real capital of the Reserve, aligned with technological and market
developments, the power to adopt acts in accordance with Article 290 of
the Treaty on the Functioning of the European Union should be delegated to
the Commission in respect of amendments to Annexes I and II. The essential
elements of this Regulation, including the designation criteria, the
percentage and terms of the warrant, the entitlement and its protections,
are laid down in the enacting terms and are not subject to delegation. It
is of particular importance that the Commission carry out appropriate
consultations during its preparatory work, including at expert level, and
that those consultations be conducted in accordance with the principles
laid down in the Interinstitutional Agreement of 13 April 2016 on Better
Law-Making. In particular, to ensure equal participation in the
preparation of delegated acts, the European Parliament and the Council
receive all documents at the same time as Member States' experts, and
their experts systematically have access to meetings of Commission expert
groups dealing with the preparation of delegated acts.

(32) In order to ensure uniform conditions for the implementation of this
Regulation as regards the establishment of the list of independent valuers
and their appointment, implementing powers should be conferred on the
Commission. Those powers should be exercised in accordance with Regulation
(EU) No 182/2011 of the European Parliament and of the Council.

(33) The administration of entitlements involves the processing of
personal data, limited to what the identification of holders and the
execution of distributions require. That processing is necessary for the
performance of a task carried out in the public interest, and no data
beyond those fields should be collected or retained. Regulation (EU)
2016/679 applies to such processing. The European Data Protection Supervisor was consulted in
accordance with Article 42(1) of Regulation (EU) 2018/1725 of the European
Parliament and of the Council and delivered an opinion on [date].

(34) Since the objective of this Regulation, namely to ensure on the basis
of harmonised rules that the gains of hyper-automated production in the
internal market are broadly owned, cannot be sufficiently achieved by the
Member States, because the undertakings concerned operate across the
entire internal market and national measures would create the very
divergence this Regulation removes, but can rather, by reason of its scale
and effects, be better achieved at Union level, the Union may adopt
measures, in accordance with the principle of subsidiarity as set out in
Article 5 of the Treaty on European Union. In accordance with the
principle of proportionality as set out in that Article, this Regulation
does not go beyond what is necessary in order to achieve that objective.

(35) This Regulation respects the fundamental rights and observes the
principles recognised by the Charter of Fundamental Rights of the European
Union, in particular Articles 16, 17, 20, 34 and 47 thereof, concerning
respectively the freedom to conduct a business, the right to property,
equality before the law and the right to an effective remedy and to a
fair trial.

(36) Application of the substantive obligations of this Regulation should
be deferred so that undertakings, Member States and the Commission can
prepare, while the notification obligation applies from entry into force
so that the first designations follow without delay,

---

Drafting notes (non-normative). Recitals use 'should' throughout and
impose nothing (JPG guideline 10). Each recital carries weight the
enacting terms need: (4) is the assets-not-flows doctrine; (5) is the
DC-26 scope-and-limits recital answering objection 12, conceded in full;
(10) the in-time doctrine and the answer to retroactivity, with (11) and
(12) justifying the extraction and long-stop triggers added to Article
5(3); (13) and (21) the fiscal characterisation defence; (9) the Article
345 TFEU answer; (15) and (18) the BRRD-pattern property-interference
justification, with (19) and (20) the safeguards, and (16) and (17) the
ranking and anti-avoidance rules added to Article 5(4)(b) and 5(10) to
(12); (24) the DC-14 honesty rule; (25) the universality argument; (28)
the honest limits of entrenchment after the round-1 and round-2 findings;
(30) the falsification condition, which is DC-18; (31) carries
the standard Better Law-Making language including the equal-access
sentence the Parliament expects; (34) is the standard subsidiarity
formula. The final recital ends with a comma by convention, leading into
the enacting formula.


# FULL SOURCE: own-the-machine/evidence/EVIDENCE.md

# The evidence

A draft law owes its readers three things: the evidence for its premise,
the evidence against it, and the numbers it refuses to use. This page
carries all three. Every figure was verified at source, not relayed from
commentary; assembled 18 August 2026, extended 19 August 2026, corrections
welcome by pull request.

The Regulation's premise is stated in its own recitals and tested by its
own Article 14: hyper-automated production decouples output from labour
at the level of the firm, the gains concentrate in whoever owns the
platform, and the ownership of productive capital in Europe is too
narrow for those gains to reach citizens by themselves. Each section
below maps to a part of that premise, and section 3 records what the
European evidence does not show, because the instrument is designed
around that honesty.

## 1. Ownership is narrow

The condition the instrument answers: Europeans own homes and pension
promises, not productive capital.

- **In the euro area, 60 % of households own their home and 11 % own
  shares in a company.** Belgium 67 against 13. Italy 75 against 4.
  Greece 68 against 1. *ECB Household Finance and Consumption Survey,
  wave 5, 2023 reference year, published June 2026.* Same file, same
  population, same survey.
- **The richest tenth of euro-area households own 83 % of directly held
  shares; the poorest half own 2 %.** Italy: 93 against 0,5. *ECB
  Distributional Wealth Accounts, 2025-Q4.* Caveat to state: every DWA
  observation is an ECB estimate.
- **The bottom half of euro-area households hold 63 % of their assets
  as housing and 3 % as equity.** Belgium: 76 % housing, 2 % equity.
  *ECB DWA, 2025-Q4.* The premise as one row of a table.
- **The typical Dutch household is worth EUR 135 500, or EUR 23 000
  once the house is taken away.** *CBS 83834NED, 1 January 2024*, tax
  registers, not a survey. State the pension exclusion first.
- **Belgian households have accrued EUR 1 740 bn of pension claims and
  own EUR 136 bn of it.** About 92 % is a promise from future
  taxpayers. *OECD/Eurostat Table 29, 2021.* Netherlands 49 % funded;
  France 0,0 %.
- **Danish households hold pension assets worth 206 % of national
  output; German households hold 6 %.** *OECD, 2024.* Caveat: the
  German figure excludes Direktzusage book reserves.

## 2. The gains concentrate at the platform

Why Article 3 designates what it designates: where production is
automated, the price that holds is the licence price, and the volume
that falls is the hours.

- **European cloud companies tripled their revenue in seven years and
  their share of their own home market still fell from 29 % to 15 %,**
  because the market grew sixfold. Amazon, Microsoft and Google take
  70 % of a EUR 61 bn European market; SAP and Deutsche Telekom hold
  about 2 % each. *Synergy Research Group, 24 July 2025.* Completed
  revenue history, not a forecast.
- **France 2025: services firms -1,8 %, technology consulting -2,5 %,
  software and cloud +8,2 %,** in the trade body's own words "surtout
  de la hausse des tarifs", with budget increases "absorbée par les
  évolutions des plateformes cloud". *Numeum/PAC, December 2025.*
- **Germany 2026: IT services +3,1 %, software +9,9 %, cloud software
  +21,9 %, AI platforms +75,8 %.** *Bitkom/IDC, August 2026.*
- **Germany produces a third more software and IT services in real
  terms than five years ago, with the ICT vacancy rate down from 6,3 %
  to 2,5 %.** Production volume index 99,2 (2021-Q1) to 134,0
  (2026-Q1). *Eurostat, verified against the API.*
- **In Germany and France the whole job market is back at pre-pandemic
  levels while software-developer postings sit at half.** Germany 50,6
  against 104,5; France 51,1 against 100,0 (February 2020 = 100).
  *Indeed Hiring Lab, 7 August 2026.* The control group is built in.
- **Hays Germany: fees +3 % while volumes fell 9 %.** *Hays plc H1 and
  Q4 FY26, audited and listed.* **Belgium: project-sourcing revenue
  +0,4 % while billable hours fell 3,4 %** (*Federgon*).
  **Netherlands: the seconded rate rose 3,3 % to EUR 71,32 while
  seconded FTE fell 9,3 %** (*VvDN, self-reported trade body*).

## 3. What the evidence does not show

The instrument is built around three facts that cut against the loudest
versions of the automation story, and it does not need those versions.

- **There is no European labour-share collapse.** The EU27 labour share
  moved about one point in thirty years; Germany's is at a series high;
  the Dutch series (81,4 % in 1995 to 70,6 % in 2025) has risen three
  years running. Anyone resting a law on a collapsing labour share
  loses the argument in Europe, so this law does not.
- **Aggregate displacement is not yet demonstrable.** The EU27
  employment rate is at a record 76,3 %; ICT specialists rose from
  3,5 % to 5,0 % of employment; compensation of employees was 48,09 %
  of EU27 GDP in 2025, above 2015, 2019 and 2022. Danish register data
  on ~25 000 workers finds precise nulls two years after ChatGPT
  (*Humlum and Vestergaard*); the German federal government formally
  finds "keine Hinweise" of junior displacement (*Bundestag Drucksache
  21/3722, 19 January 2026*). Same technology, opposite choices:
  Publicis added roughly 5 800 staff in the year WPP shed 9 389.
- **The mechanism has not diffused far.** Only 19,95 % of EU firms with
  ten or more employees used any AI in 2025. The serious claim is a
  forecast about a mechanism, not a report about the past.

This is why the Regulation claims nothing in the past tense. Designation
under Article 3 requires demonstrated decoupling at the level of the
firm, not an economy-wide story; the warrant under Article 5 takes
nothing until gains actually crystallise; and Article 14(3) carries the
falsification condition on its face: if automation spreads without the
decoupling and concentration the premise asserts, the Commission must
report that the premise is unsupported and propose amendment or repeal.
A law founded on an empirical claim should carry its own test.

## 4. What happens to pooled claims

Why Chapter VI of the Regulation looks the way it does: the history of
pooled public assets in Europe is a history of raids, and the history of
individual claims is better.

- **Poland, one line of law: 51,5 % of the money in every citizen's
  pension account cancelled on a named day.** *Act of 6 December 2013,
  Dz.U. 2013 poz. 1717, Article 23(1).* Article 23(2) took the Treasury
  bonds first, so the state could retire its own debt. The raid is not
  a hypothesis; it is a statute, and Article 12 of this Regulation is
  drafted against its enumerated verbs.
- **Spain's pension reserve fund fell 97 %,** from EUR 66,8 bn (2011)
  to EUR 2,1 bn, cumulative withdrawals EUR 80,3 bn. The law protecting
  it was passed in 2023, after it was empty.
- **Ireland's National Pensions Reserve Fund held over EUR 21 bn at the
  end of 2007. Its discretionary portfolio was EUR 7,1 bn when the fund
  was wound up seven years later,** the difference having been directed
  into the recapitalisation of Allied Irish Banks and Bank of Ireland,
  EUR 10 bn of it converted to cash and placed on deposit with those
  same banks in April 2011 before being invested in them that July. The
  assets passed to the Ireland Strategic Investment Fund on 22 December
  2014 and the fund's own mandate ended with it. *NTMA, National
  Pensions Reserve Fund Commission Annual Report 2014; NTMA valuation of
  the Discretionary Portfolio at 21 December 2014; National Treasury
  Management Agency (Amendment) Act 2014.* Hungary's -75,9 % is the
  other benchmark. These are the strongest cases against this
  Regulation's own mechanism, and they are why the Reserve's protections
  are operative articles rather than promises.
- **Sweden abolished its wage-earner funds in 1991, eight years after
  creating them, on a change of government.** The funds were legislated in
  1983 as five regional bodies financed by a levy on profits and on the wage
  sum, holding no more than 8 % of any one undertaking. They were the
  diluted survivor of the 1976 Meidner plan, which would have required
  profitable undertakings to issue new shares worth 20 % of annual profits
  to collectively held funds until those funds held a majority; the
  compulsory issuance was abandoned before the Riksdag ever voted on it. A
  centre-right government wound the funds up in 1991 with little resistance
  from the movement that had proposed them. This is the closest precedent
  anywhere to the mechanism in Article 5, and it is the strongest case
  against it, which is why objection 19 states it rather than the evidence
  base burying it.
- **Estonia proves a claim is necessary but not sufficient.** When the
  second pillar went voluntary in January 2021, 149 083 people took out
  EUR 1,32 bn in a single month; leavers averaged age 41 with
  EUR 8 468, earning slightly below the national average. That is why
  the entitlement in Article 10 is incapable of surrender: a claim that
  can be bought out of a citizen's hands will be, cheapest first.
- **A Danish worker's frozen 1978 pay rise of DKK 4 368 is worth
  DKK 119 506 tax-free today,** about 27 times over 46 years, in an
  account with the worker's name on it. *Lønmodtagernes Dyrtidsfond, at
  31 December 2025.* Deferred income converted into owned capital: the
  closest existing instrument to what this Regulation builds.
- **Two-thirds of Norway's fund was never oil:** NOK 15 210 bn of
  NOK 22 683 bn is compound return. The answer to "we have no oil" is
  that Norway largely does not either, any more; it has a rule, and
  Annex II is that rule made law.
- **Across Europe's development and reserve funds, citizens hold no
  individual claim at all**: Invest-NL, the Nationaal Groeifonds,
  COFIDES, SEPI, Spain's FRSS, Portugal's BPF and FEFSS, Greece's
  Growth Fund, Finland's Solidium, Bpifrance, Italy's CDP, Slovenia's
  SDH, Poland's PFR, Ireland's FIF, ICNF and ISIF. No account, no unit,
  no inheritable right. Individual claims exist only in pension
  vehicles, which is the gap Article 10 closes.

## 5. What we will not cite

Numbers that circulate in this debate, checked and retired, including
some that would have helped us.

- **"The OECD says only 9 % of jobs are automatable."** Superseded by
  Nedelkoska and Quintini (WP 202, 2018): 14 % above 70 % probability,
  another 32 % between 50 and 70.
- **"Bruegel found AI exposure correlated with employment growth."**
  Misattributed (it is OECD WP 265, and equivocal). Bruegel's own
  European result is negative: one extra robot per thousand workers
  cuts the employment rate 0,16 to 0,20 points.
- **European cloud share "27 % to 13 %".** Wrong; it is 29 % to 15 %.
- **Klarna as "700 people replaced by AI".** A hiring freeze plus 15 to
  20 % annual attrition; "700 agents" was a chat-volume calculation.
- **"SAP cut 10 000 jobs for AI."** Headcount rose in both years.
- **The 160 000 telecom job losses as an AI story.** The sector's own
  assessment: "this dramatic shrinkage owes very little to AI"; the
  same operators shed over 380 000 between 2014 and 2022.
- **Job-board causation claims** (entry-level postings "down 32 % since
  ChatGPT" and similar): windows containing the entire rate-tightening
  cycle, asserted as AI effects by parties selling recruitment
  products.

## 6. Measurement traps

- **Three defensible labour-share measures differ by up to 19 points.**
  Italy 2024: unadjusted 39,4 %, adjusted 58,3 %. Never quote one
  without naming it.
- **WID, HFCS and DWA figures must never share a table**: different
  units and methods. The Dutch top-10 % share is 44,8, 52,0 or 56,1
  depending on which you pick.
- **Every major European household-wealth statistic excludes
  pensions**, which inverts the ranking and makes the Netherlands and
  Denmark look asset-poor.
- **Norway's wage share is a gas-price denominator effect**; do not use
  it. **Germany has a hard series break at 1991**; never splice.
- **Eurostat ICT vacancy data stop at 2025-Q4** while price and
  employment series run into 2026; the legs are not aligned in time.

## 7. The long horizon

The Reserve is an instrument built for a horizon politics rarely
rewards, so this page states plainly what fifty years do, and what they
do not.

- **Alaska has paid every resident a dividend for 44 consecutive
  years.** The Permanent Fund holds more than USD 86 bn for about
  740 000 residents, roughly USD 116 000 of fund capital per resident;
  a resident collecting every dividend from 1982 to 2016 received
  USD 37 027 in total. *Alaska Permanent Fund Corporation; Alaska
  Department of Revenue, dividend table.* No legislature has touched
  the principal in half a century, because every citizen had a reason
  to defend it.
- **Alaska also shows the failure mode.** Since 2016 the dividend has
  been set by annual political bargain; the statutory formula remains
  in law and is simply not followed, and the 2025 dividend of
  USD 1 000 is the smallest in the programme's history once adjusted
  for inflation. A distribution rule in ordinary statute is capturable
  by a budget fight. That is why the rule here is Annex II of the
  Regulation itself, why the entitlement is an operative article, and
  why the Commission reports on the formula rather than sets it.
- **The AI-value forecasts stay out of the premise.** PwC puts
  artificial intelligence at USD 15,7 tn of global product by 2030;
  Goldman Sachs at about USD 7 tn over a decade; McKinsey at USD 2,6
  to 4,4 tn a year. These are forecasts of a mechanism, with error
  bars measured in trillions, and section 5's discipline applies: this
  Regulation does not rest on them. They appear in one place only, as
  labelled scenario inputs to the public simulator, beside a sceptic
  setting that assumes almost nothing.
- **What the arithmetic of Annex II does with fifty years.** Run
  cautiously (EUR 150 bn of covered revenue at designated firms,
  Norway-class real returns), the simulator's central curve reaches a stake of roughly
  EUR 1 200 of Reserve capital per citizen and a dividend of roughly
  EUR 47 a year by year fifty; run at the forecasts above, roughly
  EUR 10 000 and EUR 370, in constant 2026 euros: a fund on the scale
  Norway's rule built. Both curves spend their first decade
  indistinguishable from zero. That is the design: Annex II preserves
  capital before it distributes, and the stake compounds while the
  payout waits. If neither curve materialises, Article 14(3) obliges
  the Commission to report that the premise failed and to propose
  amendment or repeal.

## 8. The fragmentation is not hypothetical

Article 114 TFEU carries this Regulation only if divergent national rules
obstruct the internal market or distort competition appreciably, and
*Tobacco Advertising* (C-376/98) means that has to be shown rather than
asserted. It can be shown, because the Union has already watched it happen
once in the same economic domain.

- **Eight Member States tax digital activity unilaterally, at rates from
  1,5 % to 7,5 %, on bases that do not match.** Austria 5 % on online
  advertising alone; Denmark 2 % with a 3 % surcharge on streaming;
  France 3 % on digital interfaces, targeted advertising and the
  transmission of user data, with a reduced 1,2 % band; Hungary 7,5 %,
  currently suspended to nil through June 2026; Italy 3 %, having
  removed its global-turnover threshold; Poland 1,5 % and 3 % on
  audiovisual media and advertising; Portugal 4 % and 1 % on video and
  on-demand platforms; Spain 3 % on advertising and the sale of user
  data. *Tax Foundation Europe, digital services taxes in Europe, 2026.*
- **The entry thresholds differ by four orders of magnitude,** from
  HUF 100 million in Hungary and EUR 3 million in Spain to EUR 25
  million in France and Austria and EUR 1 billion of group turnover in
  Poland. The same undertaking is inside one national regime and outside
  its neighbour's on the same revenue.
- **Six more Member States have proposed or announced such taxes without
  adopting them:** Belgium, Czechia, Germany, Latvia, Slovakia and
  Slovenia. Roughly half of European OECD members have announced,
  proposed or implemented one. *Same source.*
- **The sequence is the point.** A Union-level measure was attempted and
  did not pass; Member States then legislated alone, and the fragmented
  landscape the Commission had hoped to avoid is what the internal
  market now has. Nothing about the next round is different: the
  European Parliament rejected a robot tax in February 2017 (the
  Delvaux report), the proposal has returned in the current debate on
  large-scale AI adoption, and no Union instrument occupies the field.
- **What the comparison does and does not establish.** It does not show
  that automation levies are coming; it shows what Member States do when
  a new form of value appears in the internal market and the Union does
  not act, and that they do it at incompatible rates, on incompatible
  bases, with incompatible thresholds. That is the obstacle this
  Regulation forecloses by harmonising the trigger, the instrument and
  the vehicle before twenty-seven answers exist rather than after.

---

Working notes for the three research strands sit in this directory;
they carry the full sourcing trail. Dispute a number by opening an
issue or a pull request: a figure that does not survive contact with
its source comes off this page and goes into section 5.


# FULL SOURCE: own-the-machine/pipeline/reviews/2026-09-06-hostile-counsel-claims-r2.md

---
gate: hostile-counsel
target: campaign and website claim corrections
commit: ed351bc
verdict: REVISE
disposition: see-claims-disposition
date: 2026-09-06
---

# Review

> Reviewer: `vertex/claude-fable-5.1@eu` · router router.eu.requesty.ai · geolocation eu · retention 30d · trained-on false · lab anthropic
> 2026-09-06T19:01:17+00:00 · tokens in=140048 out=32379
> Prompt: otm-hostile-counsel-claims.md · Verbatim model output below ; do not edit.

> Bundle SHA-256: `9f52db9be44b15ee862f8cde7af0a4384118b9ef82b07555e1753a11653faf1b`
> Prompt SHA-256: `bf7875b99628d77f2399522338c60748a7cd2b9afd3024334236076275668e26`

# Hostile-counsel / Legal Service screening memo — claim-correction bundle, 6 September 2026

Register: I assess the changed prose (site pages, `en.mjs`, `REGISTRATION-TEXT.md`, `DISTRIBUTION.md`, the launch plan, the tooling) against the unchanged draft. Where the kill lives in the unchanged articles it is labelled **PRE-EXISTING** and does not count against this package's publishability, except where a changed page repeats or aggravates it. Confidence figures are the probability the attack succeeds before the named forum (Legal Service: refusal or trimming on that ground; CJEU: annulment or forced amendment; ridicule: the line lands as quoted).

---

## 1. REGISTRATION KILLS

**R1. The registration annex misdescribes its own annexed act.** *(in scope)*
Text: "Deliberately, nothing is payable in cash, nothing enters any public budget, and no undertaking is required to sell anything."
Against: Art. 13(6) "Fines and periodic penalty payments imposed under this Article shall accrue to the general budget of the Union"; Art. 6(3) "The costs of the valuation shall be borne by the covered undertaking"; Art. 5(5) "the Reserve shall pay up the shares in full in cash at their nominal value".
Argument: the sentence a registration officer will read first is false in three particulars against the document in field 5. Not a ground under Art. 6(3) of Reg. 2019/788, but it is the sentence I write into the recitals of a partial-registration decision to justify treating the annexed mechanism as unexamined.
Confidence: refusal 5 %; written into the decision / used to justify trimming 35 %; op-ed quote 90 %.

**R2. The annex asserts the labour-share collapse the project's own evidence forbids.** *(in scope)*
Text: "the historic channel through which citizens shared in productivity, namely wages, no longer carries the gains."
Against: counter-arguments objection 7 ("no recital may argue a European labour-share collapse"), DC-15, and the launch plan's own row "Registration objectives assert falling labour share… Reconcile… before filing." The objectives field was reconciled; the annex was not.
Argument: as Legal Service I do nothing with this. As counsel I file it beside `evidence/` and let the campaign's own page refute its filing.
Confidence: Legal Service 5 %; credibility kill in the hearing room 80 %. This is a remaining contradiction in a changed page.

**R3. One draft act on Article 114 alone, filed under a Treaty field that promises Article 352.** *(in scope, registration prose against the unchanged preamble)*
Text: field 3, "Article 352 TFEU, as the residual basis for any element … in particular the creation of a Union body holding assets and the individual entitlement"; field 5, "The complete draft Regulation … is submitted in that slot." Recitals: "Having regard to … Article 114 thereof" — and nothing else. Memorandum 2.1 concedes "a citation scoped by chapter is not an available form" and that Chapters IV–VI are "drafted so that … they can be enacted as a separate Council Regulation on Article 352" — but no such second act is annexed.
Argument (Legal Service): register objectives 1 and 3; register objective 2 with an express statement that the Commission's power to propose does not extend, under Article 114, to the creation of a Union body holding private equity for citizens or a direct Union-to-citizen entitlement; treat the annexed draft as not covered beyond Chapters I–III. That is partial registration under Art. 6(4) and it is the outcome the file says it prefers, so it is a wound, not a kill.
Confidence: outright refusal 10 %; partial registration 30 %.

**R4. Falsification clause overstated in the annex.** *(in scope)*
Text: "if designated undertakings do not in fact show the decoupling the criteria assume, the evidence is published and the instrument is to be corrected or repealed."
Against: Art. 14(3): the trigger is diffusion above one quarter plus two ownership indicators, not designated undertakings' decoupling; the consequence is "accompanied, where appropriate, by a proposal". The FAQ gets this right ("does not automatically switch itself off"); the filing text does not.
Confidence: Legal Service 10 %; ridicule 40 %.

**R5. Fiscal characterisation in substance (Art. 114(2)).** *(PRE-EXISTING; correctly stated in the changed FAQ/brief/press)*
The changed pages now say "contested". Registration test is "manifestly outside"; wealth-tax ECI registered. Confidence of refusal at registration: 10 %. The fight is in Council under 352 unanimity, where the mechanism dies politically, not legally.

**R6. Treaty change in disguise.** Text: "No amendment of the Treaties is sought." Nothing in the draft requires one. Confidence: 5 %.

---

## 2. LITIGATION KILLS

**L1. The memorandum tells the Court the interference reaches only post-designation value; Article 5(2) takes 3 % of everything.** *(explanatory copy in the bundle; provenance of sentence unknown, so flagged in-scope with that caveat)*
Text: memorandum 2.4 "the obligation is prospective and attaches only to value formed after designation". Art. 5(2): "shares representing 3 % of the fully diluted capital of the covered undertaking determined immediately before that event". A company listed in 2010 and designated in 2031 is diluted on 2010–2031 value.
Motion: plead that the legislature's proportionality reasoning rests on a description of the measure that the measure contradicts (Art. 296 TFEU; C-376/98 on genuine reasoning; Charter 52(1) necessity tested against a misstated interference). Recital 18 avoids the claim; the memorandum makes it.
Confidence: 55 % that the sentence is turned against the proportionality defence. Must be struck from EN and FR.

**L2. Charter Art. 17: uncompensated nominal-value dilution of healthy going concerns.** *(PRE-EXISTING)*
Text: Art. 5(2) "subscribe at nominal value"; the file's own concession: "no decided case puts a permanent, non-crisis, uncompensated equity dilution of a healthy undertaking on the right side of Article 17."
Motion: annulment of Chapter III under Art. 17(1) read with James and Hauer; BRRD authorities distinguished on the insolvency counterfactual the file itself concedes is absent.
Confidence: 45 %.

**L3. Article 3(8) disregards the very hiring recital 7 says is the route down.** *(PRE-EXISTING; the changed FAQ faithfully repeats the article, thereby exposing the conflict)*
Text: Art. 3(8) "shall likewise disregard any transaction, arrangement or attribution the main purpose or one of the main effects of which is to increase the compensation of labour". Recital 7: "an undertaking reduces its decoupling ratio only by remunerating labour, which is consistent with the objectives of this Regulation." FAQ: "hiring more people is not an automatic exemption."
Motion: legal certainty. Every pay rise has as one of its main effects an increase in compensation of labour; the article commands the Commission to disregard genuine wages; a recital cannot cure it (C-162/97 Nilsson) and ambiguity is read restrictively against the drafter (C-6/98 ARD).
Confidence: 55 % (declaration of inapplicability to genuine remuneration or forced amendment).

**L4. Article 5(4)(e) contradicts 5(1), 5(3), 5(5) and 5(11).** *(PRE-EXISTING; the launch plan itself flags it)*
Text: "impose no obligation on the covered undertaking prior to a liquidity event other than the notification obligation in paragraph 6." Yet paragraph 1 compels issuance, paragraph 3 crystallises with no liquidity event, paragraph 5 compels execution within 20 working days after such crystallisation.
Confidence: 40 % (forced amendment; a court asked to enforce a 5(3) crystallisation is handed the undertaking's defence by the drafter).

**L5. Already-listed undertakings: "moment of realised gain" is false for the class Article 17(2) creates.** *(PRE-EXISTING)*
Text: recital 18 "borne at a moment of realised gain"; Art. 17(2) + 5(3)(b): an already-listed undertaking with no change of control and no 20 % transfer is diluted by lapse of seven years, gain or none.
Motion: legitimate expectations and proportionality for listed shareholders who bought before entry into force; the justificatory recital does not describe their case.
Confidence: 35 %.

**L6. Equal treatment across the 80× line and below-threshold designation on an undefined limb.** *(PRE-EXISTING)*
Text: Art. 3(2)(b) "eighty times"; Art. 3(6) designation on "substantially decoupled" (undefined). Court defers to legislative thresholds (DMA line). Confidence: 20 %.

**L7. Art. 345 / Art. 63 golden share.** *(PRE-EXISTING)* Non-voting, no board, no instructions (Art. 9). Confidence: 10–15 %.

---

## 3. STRUCTURAL KILLS

**S1. A Union body with legal personality and no organs.** *(PRE-EXISTING)*
Text: Art. 8(1) "The Reserve shall have legal personality"; Art. 10(6) "The Reserve shall declare a distribution"; Art. 8(6) "publish annually audited accounts"; Art. 9(1)(e) permits borrowing; Art. 5(5) "the Reserve shall pay up the shares".
Attack: no governing body, no appointment mechanism, no seat, no statutes, no auditor, no staff basis, no representation in litigation, and no Art. 290/291 empowerment to supply any of it (Art. 15 delegates only the Annexes; Art. 16's implementing power is scoped to valuers). Nobody can lawfully declare, borrow, publish or pay. The memorandum benchmarks "the Reserve's own running costs" against a fund that has a board.
Confidence: 75 % that the legal-form gate or the Legal Service returns this as fatal on form.

**S2. Enforcement without an enforcer for the obligation that matters.** *(PRE-EXISTING)*
Text: Art. 13(1)(a) covers failure "to issue the citizens' capital warrant in accordance with Article 5(1)"; (b) covers only "the third sentence of Article 5(5)", i.e. the third-country obligation of result. There is no infringement for a Union-law undertaking that issues the warrant and then refuses to "execute the subscription within 20 working days" (fifth sentence of 5(5)); Art. 13(2) periodic penalties are tied to "the obligations referred to in paragraph 1"; transferees under Art. 5(11)–(12) are not "covered undertakings" and are outside Art. 13 entirely.
Confidence: 65 %.

**S3. How I restructure a client around the thresholds.** *(PRE-EXISTING)*
(a) *Denominator inflation by grant value.* Annex I point 3 counts "share-based compensation measured at grant value" and averages "over the last two financial years". Two years before likely designation, convert the cash bonus pool into RSUs at an internally supported grant valuation; a EUR 2 bn payroll becomes EUR 6–7 bn of "compensation of employees", moving the 80× trigger from EUR 160 bn to over EUR 500 bn. Art. 3(8) can catch this only by disregarding genuine employee pay, which recital 7 forbids by design (see L3). (b) *Break durability every second year.* Art. 3(2)(c) requires both thresholds "in each of the last two financial years". Annex I point 4 takes "the most recent" of a ≥ 2 % independent transfer, an independent valuation within 12 months, or six-month average capitalisation. In alternate years, place 2 % with an independent secondary buyer at a discount, or commission a standards-compliant independent valuation with ordinary illiquidity and control discounts. The presumption never completes; the Commission is pushed to a 12-month market investigation (Art. 4(1)) on the undefined "substantially decoupled". (c) *Pre-revenue frontier lab.* Keep Union turnover below EUR 7,5 bn by selling through an arm's-length distributor that is not a "linked enterprise" under Recommendation 2003/361 (a definition written for SMEs and imported here at trillion-euro scale), and hold fair market value below EUR 75 bn via route (b). A genuine independent valuation is not an "arrangement".
Confidence: 50 % that at least one route defeats designation for two cycles.

**S4. Article 12(4) confers a remedy a Regulation cannot confer.** *(PRE-EXISTING)*
Text: "Every holder … shall have the right to an effective remedy before a court or tribunal against any act or omission infringing this Article." National courts cannot invalidate Union acts (Foto-Frost); Art. 263(4) standing cannot be enlarged by secondary law. The drafters deleted exactly this error from Art. 7 ("secondary law must not paraphrase remedies conferred by primary law") and left it in Art. 12.
Confidence: 50 %.

**S5. Undefined operative terms.** *(PRE-EXISTING)* "substantially decoupled", "durable", "to a significant extent" (Art. 3(1)); "persons independent of the undertaking" (Annex I 4(a)). Confidence: 35 %.

**Tooling (in scope).**
T1. The public-material retention exception is invoked for a bundle containing an unpublished internal operating plan "for discussion with the founding group" and a named third party ("the Zwart comment", DISTRIBUTION.md), while the README says the exception "does not cover private correspondence, personal data or other unpublished sensitive input". The provenance line will disclose the 30-day retention correctly; the scoping claim is the soft spot. Confidence 30 %.
T2. The README presents the ZDR exception as Fable-only, but the environment route (`REVIEW_REQUIRE_ZDR=0` with any `REVIEW_MODEL`) is not restricted; only the positional-argument path enforces the family. Disclosed by provenance, so low. Confidence 20 %.
T3. `simulator.ts` comment: "the disclaimer beside the chart names them" (PwC/Goldman/McKinsey). The changed `simulator.disclaimer` string names nobody. The code now lies about the copy. Confidence 60 % if a reader of the public repo notices.
T4. `fmt` floors displayed values at 0,1 while the disclaimer says payments "could be zero": the sentence can never print the zero the disclaimer promises. Formatting, not arithmetic, so in scope. Confidence 30 %.

---

## 4. RIDICULE KILLS (changed prose)

K1. "nothing enters any public budget" (registration annex) beside Art. 13(6). The op-ed writes itself.
K2. "wages … no longer carries the gains" beside the campaign's own evidence page.
K3. `en.mjs` objections.intro: "stated … before a single article was drafted". Counter-arguments status: "Objections 16 and 17 were added on 20 August 2026 from an external challenge"; 18 on 21 August; 20–21 on 22 August. Confidence 70 %.
K4. `en.mjs` ledger.intro1: "Before any text of this Regulation merges, it passes six adversarial gates." pipeline/README: prose changes run "lint + gates 1 and 6"; GOVERNANCE: "A REVISE with a written editor disposition can merge"; intro2 on the same page concedes it. "Passes" is false. Confidence 65 %.
K5. `contribute.md`: "it strengthens legal protection against diversion" and "A pull request that weakens a protection needs to say so in plain language." GOVERNANCE: a change that makes the instrument less raid-proof "fails review by definition". The public contribution page describes a merge rule the constitution forbids. Confidence 60 %.
K6. `about.md`: "No party, foundation, trade union, company … has contributed money, services, staff time or software" — three paragraphs above "the domain's DNS is answered by Cloudflare … the source repository is hosted on GitHub". Free-tier services from two US companies are services from companies. Confidence 45 %.
K7. Memorandum 4 (EN and FR): "Article 10(6) caps the fees national vehicles may levy". The cap is Art. 11(3); Art. 10(6) is the distribution trigger. Confidence 60 %.
K8. Memorandum 1.2: "Five acquis interface points remain open and are listed in section 5.4." Section 5.4 lists the number, not the five. Confidence 50 %.
K9. Memorandum 3.4 "imposes a notification duty on undertakings meeting the thresholds and nothing on anyone else" and 3.3 "no effect on any undertaking outside that set", against Art. 5(11) ("irrespective of whether the transferee meets the conditions laid down in Article 3"), Art. 3(6), Art. 11 (Member States), Art. 17(1). Confidence 55 %.
K10. Simulator calendar: x-axis and sentences anchored to 2027 for an initiative unregistered in September 2026 whose Commission response cannot precede 2028 and whose application date is entry into force plus 18 months. The launch plan told the team to fix this; the changed strings keep "%YEAR%" on a 2027 base and rely on the disclaimer ("illustrative 2027 start"). "Their own chart assumes the law is in force next year." Confidence 50 %.
K11. FR memorandum omits the new 2.1 paragraph on the single-act/Article 114-alone problem; its header says "l'anglais prévaut" and carries no stale marker in the file. The one correction the 5 September review demanded (legal basis visible where a reader lands) is absent from the French. Confidence 40 %.
K12. DISTRIBUTION.md: "losing @ownthestable to a squatter" in a campaign called Own the Machine; "a royalty pledge … to the ASBL" while about.md says "No organisation" and "The campaign takes nothing from the book's sales"; "ahead of the admissibility opinion (Gate 1)" for what the same bundle insists is non-binding Forum advice, not a Commission act. Confidence 35 %.
K13. GOVERNANCE process step 1 still says "objections (1-18)" — not named as changed; logged as pre-existing housekeeping.

---

## Disposition

What is fixed and holds: FAQ/brief/press/home now state the three triggers, the rebuttable presumption and below-threshold designation, the contested fiscal classification, the non-approval status of Forum advice, the limits of Article 12, the 15,840 Belgian threshold, seven residences not nationalities, and DC-31 stake-beside-payout. The tooling's provenance stamping is honest and the tests cover the exception path.

What still contradicts the draft in the changed pages and therefore blocks publication: R1, R2, R4 (registration annex); L1, K7, K8, K9 (memorandum EN, and FR where mirrored); K3, K4 (`en.mjs`); K5 (`contribute.md`); K6 (`about.md`); T3 (code comment versus changed string); K11 (FR memorandum drift). Pre-existing normative items (L2–L7, S1–S5, the Art. 5(4)(e) and Art. 3(8) conflicts) are logged for the substantive pipeline and are not cured or aggravated by this package, except that the FAQ's faithful restatement of Art. 3(8) now advertises the recital 7 conflict publicly.

VERDICT: REVISE

## Editor disposition (prepared for final editorial review)

The model output above is preserved verbatim. See
[the claim-correction disposition](https://github.com/ownthemachine/own-the-machine/blob/main/pipeline/reviews/2026-09-06-claims-disposition.md) for
accepted fixes, scope decisions, provenance qualifications and remaining
legal findings. A PUBLISH applies to this submitted snapshot only; it is not
legal approval or clearance of the entire instrument.

Specific scope dispositions: L1 and K7–K9 describe unchanged memorandum passages. Their substance is retained as open legal/explanatory work, but their classification as new changes is declined: no memorandum file is modified by this package. T2 describes the pre-existing generic environment switches; the named positional Fable exception does not purport to prohibit all other explicitly configured runs. The requested public-copy fixes are addressed in subsequent snapshots, rather than this REVISE being silently overridden.


# FULL SOURCE: own-the-machine/pipeline/reviews/2026-09-06-layer-fidelity-claims-r3.md

---
gate: layer-fidelity
target: campaign and website claim corrections
commit: ed351bc
verdict: REVISE
disposition: see-claims-disposition
date: 2026-09-06
---

# Review

> Reviewer: `vertex/claude-fable-5.1@eu` · router router.eu.requesty.ai · geolocation eu · retention 30d · trained-on false · lab anthropic
> 2026-09-06T19:36:54+00:00 · tokens in=153216 out=27479
> Prompt: otm-layer-fidelity-r3.md · Verbatim model output below ; do not edit.

> Bundle SHA-256: `32f9b8ae499c954f6238c26cceb328374eeff0e6746f3bd78fe03878f1b3357a`
> Prompt SHA-256: `69e50293bef58b180b6c70fc2f047c7d5bc4be65a32ae9968fb8223b6b58090c`

# Layer-fidelity review: claim-correction package, 6 September 2026

Scope applied as instructed: the changed plain pages (brief, FAQ, join, sign, press, about, contribute), `en.mjs` strings, `REGISTRATION-TEXT.md`, DISTRIBUTION/GATES/launch plan, simulator source and strings, and the review tooling, read against the unchanged articles, annexes, recitals and memoranda as reference. Pre-existing defects in reference layers are listed separately at the end and do not bear on the verdict.

## What the corrections get right (verified, not assumed)

- DC-14: no plain page states a first-year or early-year income. Home ("Returns may be small or zero"), brief ("may be zero"), FAQ ("could be zero"), press ("could be zero") all match Annex II point 2 and recital 24. The simulator reports year 20 and year 50 only, shows the stake beside every payout (DC-31, `stakeSentence`, `generationSentence`), permits zero in `fmt`, and its assumption strings describe what `run()` actually does (positive `r`, no retention line, collar floored at `0.02 * capital`, cohorts continuing at `growth = 0`).
- DC-23: home, brief, FAQ and press all state protection as friction ("cannot prevent all future amendments", "legal barriers, not a guarantee", "cannot guarantee that future legislators never amend"). No plain page says "untouchable" any more.
- Article 10(6) is now rendered precisely in the FAQ (ten-times-cost rule, once-in-every-third-positive-year backstop, roll-forward), and the FAQ glosses "backstop" as the draft's "long-stop".
- Triggers are consistent across home, brief, FAQ, press and registration: first liquidity event, extraction above the Article 5(3)(a) threshold, seven-year long-stop; issuing the warrant is distinguished from crystallising it.
- Registration now discloses nominal cash payment (5(5)), valuation costs on the undertaking (6(3)), fines to the budget (13(6)), the Article 352 two-act incompleteness, and non-automatic repeal (14(3)); the labour-share premise is gone.
- Sign/join/about/press: 18-or-older, seven Member States of residence not nationalities, Belgium 15,840 on 720 MEPs, COCS online with paper permitted, response-not-legislation. All match the bundle's stated ECI facts.
- Tooling: `review.sh` exits 2 on REVISE/missing/ambiguous verdicts, stamps bundle and prompt hashes, refuses Astra substitution and silent ZDR relaxation; README and about.md describe that behaviour accurately, and neither claims Astra ran.

## Findings

### 1. UNDERDISCLOSURE (scope narrowing) — registration annex omits the below-threshold designation route and the rebuttal that the FAQ and press now disclose

Plain layer (REGISTRATION-TEXT.md §4, the text that would be filed):
> "Undertakings above objective thresholds would be designated on the model of Regulation (EU) 2022/1925."

Articles:
> Article 3(2): "An undertaking shall be presumed to satisfy…"; Article 3(5): "The undertaking may … present sufficiently substantiated arguments …"; Article 3(6): "The Commission may designate as a covered undertaking any undertaking that satisfies the requirements of paragraph 1 without meeting the thresholds of paragraph 2, following a market investigation…"

Same site, corrected FAQ:
> "A company may rebut the presumption. The Commission may also designate a company below those thresholds after investigation."

Reader harm: the filing text presents the thresholds as the perimeter, which is the exact narrowing the launch plan classed "Immediate" for the FAQ and brief. The FAQ was fixed; the annex, which is the fixed text a registration officer and every signer reads, still carries the narrower description, so two plain pages now give the instrument two different reaches. A signer reading only the Commission's register would learn the wider reach (and the Commission's investigation power) from a critic, not from the organisers.

Minimal fix (plain layer, registration §4; ~60 characters, within the 5 000 limit): "Undertakings would be designated on the model of Regulation (EU) 2022/1925: a rebuttable presumption above objective thresholds, and designation on the facts below them after a market investigation."

While in that paragraph, two minor precisions in the same layer: "enforcement fines accrue to public budgets" should read "to the Union budget" (Article 13(6) names the general budget of the Union and excludes the Reserve; "public budgets" implies national receipt), and "above a stated share of its turnover" should read "of its turnover from the covered activity" (Article 5(3)(a) measures against covered turnover, a smaller denominator that fires sooner). Neither alone would warrant REVISE.

### 2. TERM DRIFT — "backstop" now names two different rules depending on layer

Plain layer: home col1 "a seven-year backstop"; brief "the seven-year backstop"; press "the seven-year backstop after issuance"; simulator `lagNote` and assumptions "the seven-year backstop".
Articles/recitals: recital 12 "The seven-year long-stop"; memorandum §5.3 "the seven-year long stop".
Memorandum, objection 15 and DC-40: "a hard backstop of one distribution in every three years"; Article 10 drafting notes "The three-year backstop".

Reader harm: a reader who moves from the home page to the objections page meets "backstop" first as the warrant's seven-year rule and then as the distribution's three-year rule, with the recital calling the first one "long-stop". Only the FAQ glosses the two words together. This does not change who would sign, but it is a defined-concept split across layers on a project whose credibility is precision, and the label check in `check-labels.mjs` exists for exactly this defect class.

Minimal fix (plain layer): use "seven-year long-stop" in home, brief, press and the simulator strings, or gloss once per page as the FAQ does ("seven-year long-stop (backstop)"). No article change.

### 3. TERM DRIFT (low) — retention exception described as a class on the site, as a single run in the tooling

Plain layer (about.md): "For the public or intended-for-publication, non-sensitive material Fable 5.1 reviews introduced on 6 September 2026, the editor permits the router-reported 30-day retention…"
Tooling (README): "The editor requested Fable 5.1 for the public claim-correction review. For that public-material run only, use the documented retention exception"; `.env.example`: "public-material exceptions require REVIEW_REQUIRE_ZDR=0 explicitly"; `review.sh`: exception per invocation, positional, Fable only.

Reader harm: a reader relying on the zero-retention disclosure cannot tell from the site whether one review or a standing category of reviews runs under 30-day retention. The runner makes it per-run and explicit; the site reads as a standing policy.

Minimal fix (plain layer, about.md): "…the editor may permit, explicitly and per run, the router-reported 30-day retention for public, non-sensitive material; each such review's provenance line records it." Tooling unchanged.

## Optional preferences (not required; recorded separately)

- FAQ one-sentence answer says the fund "pays equal distributions to adult EU citizens"; every other page uses "would" and "aged 18 or older". Align tense and age wording (Article 10(1) fixes 18; "adult" is a Member State concept).
- "Fund" is used colloquially (FAQ "Who controls the fund?", "a small fund") for a body Article 8(7) and recital 21 expressly distinguish from a fund; the Forum's own sceptical framing was "the creation of a fund". "Reserve" throughout would cost nothing.
- Home "basis" and brief "Legal basis" list Articles 114 and 352 as proposed bases; the draft's preamble cites 114 alone. The registration text discloses this; a short clause on home/brief ("the draft's preamble cites Article 114; Article 352 would need a separate act") would close the gap for readers who never reach the registration page.
- Article 11(3) charges on holders (up to 0,3 % annually) are nowhere in the plain layer; FAQ "after costs" reads as Reserve costs. One clause in "Do I get money?" would disclose the only charge a citizen personally bears.
- Registration §4 alternates "a common reserve"/"The reserve" with "The Reserve"; pick the defined-term capitalisation.
- Contribute: "A pull request that weakens a protection does not merge" is stronger than GOVERNANCE.md, which says such a change "fails review by definition" while a REVISE with a written disposition can merge. "Fails review under the published governance rules" is the exact statement.

## Pre-existing defects in reference layers (for the six-gate legal revision, not this package)

1. **Article 5(4)(e) v Article 5(3)/(5).** 5(4)(e) says the warrant imposes "no obligation on the covered undertaking prior to a liquidity event other than the notification obligation in paragraph 6", yet 5(3) crystallises before any liquidity event and 5(5) then obliges execution within 20 working days. The plain layer correctly follows 5(3); the articles are internally inconsistent. Related: Article 5(6) notifies liquidity events only; there is no notification duty for 5(3) crystallisation. The launch plan already lists this for counsel.
2. **Article 13(1) coverage.** The fine list reaches failure to issue the warrant, third-country procurement measures, notification and information failures, and circumvention; failure to execute the subscription itself (last sentence of 5(5)) by a Union-law undertaking is not enumerated, and 13(2) periodic penalties are tied to the paragraph 1 list. Worth hostile counsel's attention.
3. **Memorandum §4 cross-reference (EN and FR):** "Article 10(6) caps the fees national vehicles may levy" — the cap is Article 11(3); 10(6) is the distribution-frequency rule.
4. **Memorandum, objection 15 v objection 21:** "roughly EUR 400 of owned capital behind every citizen by year thirty" is a pre-22 August figure; objection 21 and the current simulator model put the per-adult stake in the thousands (about EUR 8 400 within a generation at 3 %). Objection 15 also states a payout order without the stake beside it, which DC-31 forbids in the project's own material.
5. **Memorandum §3.3 (social impacts):** "distributions being made from the age of majority under Article 10" — Article 10(1) fixes 18, not majority.
6. **FR courtesy memorandum** lacks the 6 September paragraph in §2.1 on the preamble citing Article 114 alone; the `source-commit` staleness banner should be firing on that page. Verify it does.

VERDICT: REVISE

## Editor disposition (prepared for final editorial review)

The model output above is preserved verbatim. See
[the claim-correction disposition](https://github.com/ownthemachine/own-the-machine/blob/main/pipeline/reviews/2026-09-06-claims-disposition.md) for
accepted fixes, scope decisions, provenance qualifications and remaining
legal findings. A PUBLISH applies to this submitted snapshot only; it is not
legal approval or clearance of the entire instrument.

Specific disposition: required findings 1–3 were corrected in the final r9 bundle and independently checked by the standard layer-fidelity closure run r4. Fines now name the Union budget; the extraction denominator names covered activity. Optional preferences are not represented as compulsory legal findings. The ordinary-language word fund denotes the proposed Reserve in an expressly hypothetical explanation; the page disclaims any current benefit. Constitutional non-weakening rules remain the contribution criterion, notwithstanding the general ability to record dispositions on other REVISE findings. Unchanged statutory and memorandum issues remain open.


# FULL SOURCE: own-the-machine/pipeline/reviews/2026-09-06-claims-disposition.md

---
gate: editorial-disposition
target: campaign and website claim corrections
commit: f0ac665
verdict: PUBLISH
disposition: ready-for-editor-review
date: 2026-09-06
---

# Claim corrections, reviewer routing and automation-first planning

Working disposition prepared by the coding assistant under the initiator's request to correct claims and run the reviewer pipeline. David Vanheeswijck retains final editorial responsibility. This record does not claim a native-language human review, legal approval, registration or adoption.

## Scope and authority

The initiator authorised claim corrections, use of the existing reviewer pipeline, support for Astra and Fable 5.1, and an automation/volunteer-first operating plan. The changes cover the seven English campaign pages, their four translations, registration prose, home/simulator and related dictionary entries, distribution guidance, the cash-readiness gate and review/release tooling. No enacting article, recital, definition, legal threshold or economic calculation is amended. A display floor in the simulator now allows zero. Legal-prose review class: lint, gate 1 and gate 6. The additional hostile-counsel review is retained, including its unresolved attacks on the unchanged instrument.

The source of the work is the user's instruction in the shared engineering session; no public issue preceded drafting. This is a process deviation from GOVERNANCE step 1, recorded rather than backdated. The package is prepared on local review branches, not merged into the published instrument.

## Required corrections and dispositions

| Finding | Action |
|---|---|
| Seven-year crystallisation omitted; thresholds presented as exhaustive exemptions | Brief, FAQ, press, home and simulator now state the alternative triggers and rebuttable/below-threshold designation routes. |
| Fiscal classification stated as settled | Public explanations now identify the contested classification and link the objections. Settlement in shares is not presented as dispositive. |
| Raid protection presented as impossible to undo | Public prose now describes legal barriers and possible future legislative change. |
| ECI signatures described as automatic enactment; seven nationalities; stale Belgian threshold | Corrected to consideration and a reasoned response, organisers resident in seven Member States, and Belgium 15,840. Current Commission guidance checked 6 September 2026. |
| Forum advice or pending status presented as institutional approval | Dated the status, recorded received independent feedback, and retained the distinction between advice, registration and adoption. |
| Registration: cash/public-budget absolutes (hostile R1/K1, layer 1.2) | Disclosed Reserve nominal-value cash payment, company valuation costs and enforcement fines entering public budgets. |
| Registration: wage-collapse assertion (R2/K2) | Conditional statement that wages may not carry all gains. |
| Registration: incomplete Article 114/352 architecture (R3) | Disclosed that the illustrative draft cites Article 114 only and is not a completed two-act architecture; the Commission decides what can proceed. |
| Registration: automatic correction/repeal (R4) | Described published assessment and a proposal where appropriate, not automatic repeal. |
| Registration: passive ownership (layer 1.1) | Replaced with absence of votes, board seats and management direction. |
| FAQ payment-frequency omission (layer 2.1) | Added annual cost threshold, the positive-calendar-year three-year rule and roll-forward of small unpaid amounts. |
| Backstop/long-stop terminology (layer 3.1) | After the later review, unified the changed English pages and simulator labels on seven-year long-stop; translations preserve their equivalent term and the FAQ gloss. |
| Every text allegedly passes six gates (K4, layer 1.3) | Contribute and ledger now state the three change classes and record verdicts and dispositions. |
| Fourth merge test attached the claim too late; weaker protections sounded mergeable (K5, layer 3.2) | Claim established while capital forms, before crystallisation; changes weakening constitutional protections do not merge under current rules. |
| All objections allegedly predated all articles (K3) | Intro now distinguishes the initial objection-first method from subsequent objections and revisions. |
| Funding denied all external services (K6) | Distinguished no recorded campaign-specific support from ordinary GitHub/Cloudflare platform services. |
| Retention exception and personal attribution (T1) | Clarified public or intended-for-publication, non-sensitive material; excludes private correspondence, non-public personal data and sensitive unpublished input. Public author attribution is not excluded. |
| Fable-only exception claim versus generic environment switches (T2) | The named positional exception is Fable-only. Generic explicit retention switches predate this change and remain documented; no claim that all possible environment configurations enforce the named exception. |
| Simulator comment and zero floor (T3/T4) | Removed obsolete source-name comment; formatting now permits zero. Economic arithmetic unchanged. |
| Simulator calendar (K10) | Kept as an explicitly illustrative 2027 origin, not a promised application date. A relative-year axis remains a possible future usability change; the present disclaimer states the limitation. |
| Distribution: obsolete handle, supposed royalty pledge, advice called an opinion (K12) | Corrected the project name, stated no royalty pledge is adopted, and called the sounding independent advice. Removed unsupported audience and reach generalisations. |
| Historical findings read as still open (layer housekeeping) | Marked the launch-plan table as initial findings and linked disposition work. |
| EUR 300,000 staffing assumption | Replaced as a prerequisite with named volunteer responsibilities, automation, backups and cash-by-need planning. EUR 10,000 preparation and EUR 25,000 collection-year examples are unquoted scenarios, not minimums or promises of signature yield. Existing donor exclusions remain. |

## Review history and provenance

Legal-form rounds 1–3 returned REVISE (unchanged Annex I drafting issue, an em-dash in new tooling, then obsolete recital/objection counts). The unchanged Annex point is a pre-existing legal item; the new form/count issues were corrected. Round 4 returned PUBLISH, followed by a shortened brief and subsequent substantive prose corrections. Rounds 5 and 6 returned PUBLISH on their respective snapshots; later fixes were submitted in rounds 7 and 8, which also returned PUBLISH. Each verdict concerns its submitted snapshot, not all later edits.

The first hostile-counsel attempt failed in the runner and produced no review file or valid verdict: the shell script was edited while a request was running. The next run is preserved as hostile-counsel round 2, REVISE. Layer-fidelity rounds 1 and 2 are preserved as REVISE. Round 2 additionally required the registration age-18 condition, the equivalised-income qualifier in press, the non-weakening contribution test and clarification that COCS is mandatory for online collection while paper remains permitted. All four were corrected; round 3 reviewed that snapshot and returned REVISE for registration coverage, long-stop terminology and per-run retention wording. All three were corrected, along with the covered-turnover and Union-budget precisions. Legal-form round 9 and the standard layer-fidelity closure round 4 then returned PUBLISH. The final closure reviewer was vertex/gemini-3.7-flash@eu; Fable's preceding REVISE remains visible and is not relabelled as PUBLISH.

The earlier runner computed hashes after receiving the model response. Legal-form round 4's recorded bundle hash therefore identifies a later on-disk edit, not its submitted input. A reconstructed request snapshot is archived separately; its hash is f93d00082b61e798519005e6dd56c81bbbb7e401e04466b22510d1c315bfee08. This reconstruction is not an original capture. The verified layer-fidelity round 1 snapshot hash is 9f52db9be44b15ee862f8cde7af0a4384118b9ef82b07555e1753a11653faf1b. Do not infer exact historical request identity where an original snapshot was not preserved.

The runner now copies both input and prompt before any request and hashes those snapshots. Regression tests mutate the source files during a simulated request and verify that the stored hashes still identify the sent text. Existing outputs cannot be overwritten; missing, ambiguous and REVISE verdicts exit nonzero. EU, retention and training metadata are checked independently.

Astra was not listed in the configured Requesty catalogue on 6 September. The exact-family profile is supported but fails closed when unavailable; no Astra review is claimed. Fable 5.1 ran at vertex/claude-fable-5.1@eu with router-reported EU hosting, 30-day retention and no training use, using the explicit exception disclosed in the tool documentation and About page. Default routing remains EU, zero retention and no training.

## Open legal findings, outside this prose correction package

These are model findings requiring assessment, not validated legal conclusions or accepted probability estimates. They remain visible in the hostile-counsel and layer-fidelity records and should enter a separate legal revision with the gates its class requires.

- Article 5(4)(e)'s no-pre-liquidity-obligation language against warrant issuance, extraction and seven-year crystallisation; notification and execution coverage.
- Article 3(8)'s treatment of labour compensation versus genuine hiring and recital 7.
- Reserve governance, organs and representation; enforcement coverage for execution and transferees; available judicial remedies.
- Property-rights and fiscal-characterisation objections, designation boundaries and avoidance mechanisms.
- Existing memorandum: post-designation-value and own-realisation-only descriptions; passive-owner wording; age of majority versus 18; duty/scope descriptions; Article 10(6) versus 11(3) fee reference; unenumerated acquis interfaces. Hostile L1/K7/K8/K9 concern that unchanged memorandum, not newly edited text. Their substance is retained for follow-up; their classification as changes in this package is declined based on the repository diff.
- French memorandum alignment, stale Article 5 drafting notes and the existing stale plain-language Article 5 translations. Existing staleness warnings are not promoted to current or human-verified.
- Governance's old objection count and pipeline's old constraint count are pre-existing housekeeping.

## Verification and release state

Final required automated gates: legal-form claims r9 PUBLISH; layer-fidelity claims r4 PUBLISH. All four final translation checks (r6) returned PUBLISH. Fable supplied the stronger adversarial rounds; its earlier REVISE outputs, fixes and scope decisions remain preserved. Neither the normal closing reviewer nor the coding assistant is an independent human/native legal reviewer.

Validation: legislative linter 0 errors and 7 existing warnings; 10 offline review-runner tests pass; full site build and release checks pass (structural translation checks, labels, one A4 brief in each language, reachable tables of contents and navigation across 16 pages in all five languages). Registration rendering preserves all five form sections and excludes duplicate body titles and drafting notes. Mobile screenshots of the home page, Dutch brief and simulator were visually inspected. Existing stale Article 5 plain-language translations retain their warnings.

Source commits: campaign plan and first corrections 806de39; final registration wording f0ac665; English site and release tooling 8d35a77 plus 31760e8; reviewer tooling 7b27d54 plus 8326df6. Submitted full-file snapshots are archived under pipeline/bundles; their uncompressed hashes identify exact review inputs across all three repositories. The individual review metadata uses ed351bc as the common law-repository starting point, not as a claim that the uncommitted request text was already present in that commit.

All work is on local feat/claims-and-automation-review branches. No push, merge, deployment or legislative filing is performed. Translations are machine-reviewed, not native-verified. Final editorial responsibility remains with the initiator.
